extends Node
# Owner Mode (v30): you are the farmer. Walk anywhere on your land with a round
# joystick, see the farm from behind your shoulder, and do the work yourself:
# collect milk, eggs, truffles and apples, plant, water, weed and harvest crops,
# and open the shops. Coins, XP, stock and saves are shared with the normal game.

var g: Node
var v: Node

const SailScript := preload("res://scripts/sail.gd")
const GROUND_Y := 0.15
const WALK_SPEED := 4.2
const LIMIT := 18.0

var on: bool = false
var top_view: bool = false
var player: Node3D
var model: Node3D
var cam: Camera3D
var heading: float = 0.0          # player yaw; the model faces local +x
var cam_h: float = 0.0
var speed: float = 0.0
var phase: float = 0.0
var hop_t: float = 0.0
var t: float = 0.0
var built: bool = false
var obstacles: Array = []
var target: Dictionary = {}
var steer_vis: float = 0.0

var hud: CanvasLayer
var enter_btn: Button
var exit_btn: Button
var view_btn: Button
var act_btn: Button
var joy: Control
var bottom_bar: Control

const SOLIDS := [
    Vector3(-4.2, -4.1, 2.3),    # farmhouse
    Vector3(3.7, -4.1, 2.4),     # barn
    Vector3(9.6, -7.4, 1.6),     # silo
    Vector3(-10.8, -1.4, 1.8),   # bakery oven
    Vector3(8.2, 11.0, 2.3),     # market tent
    Vector3(-10.0, 12.5, 2.6),   # windmill site
    Vector3(5.0, 0.1, 0.9),      # well
    Vector3(-12.0, -6.5, 3.1),   # pond
    Vector3(15.5, 7.0, 2.7),     # pond
]

# ----------------------------------------------------------------- HUD

func _style(b: Button, col: Color, radius: int) -> void:
    b.add_theme_font_size_override("font_size", 22)
    b.add_theme_color_override("font_color", Color.WHITE)
    b.add_theme_color_override("font_pressed_color", Color.WHITE)
    for st in ["normal", "hover", "pressed", "focus"]:
        var sb := StyleBoxFlat.new()
        sb.bg_color = col if st != "pressed" else col.darkened(0.3)
        sb.set_corner_radius_all(radius)
        sb.border_color = Color(1, 1, 1, 0.9)
        sb.set_border_width_all(4)
        sb.shadow_color = Color(0, 0, 0, 0.3)
        sb.shadow_size = 4
        b.add_theme_stylebox_override(st, sb)

func _ensure_hud() -> void:
    if hud != null:
        return
    hud = CanvasLayer.new()
    hud.layer = 62
    add_child(hud)
    enter_btn = Button.new()
    enter_btn.text = "WALK"
    enter_btn.anchor_top = 1.0
    enter_btn.anchor_bottom = 1.0
    enter_btn.offset_left = 14.0
    enter_btn.offset_right = 124.0
    enter_btn.offset_top = -126.0
    enter_btn.offset_bottom = -16.0
    _style(enter_btn, Color(0.25, 0.62, 0.30), 55)
    enter_btn.pressed.connect(enter)
    hud.add_child(enter_btn)
    exit_btn = Button.new()
    exit_btn.text = "< EXIT WALK"
    exit_btn.anchor_left = 0.5
    exit_btn.anchor_right = 0.5
    exit_btn.offset_left = -215.0
    exit_btn.offset_right = -5.0
    exit_btn.offset_top = 12.0
    exit_btn.offset_bottom = 72.0
    _style(exit_btn, Color(0.2, 0.3, 0.45, 0.9), 14)
    exit_btn.pressed.connect(leave)
    exit_btn.visible = false
    hud.add_child(exit_btn)
    view_btn = Button.new()
    view_btn.text = "TOP VIEW"
    view_btn.anchor_left = 0.5
    view_btn.anchor_right = 0.5
    view_btn.offset_left = 5.0
    view_btn.offset_right = 215.0
    view_btn.offset_top = 12.0
    view_btn.offset_bottom = 72.0
    _style(view_btn, Color(0.2, 0.3, 0.45, 0.9), 14)
    view_btn.pressed.connect(_toggle_view)
    view_btn.visible = false
    hud.add_child(view_btn)
    joy = SailScript.Joy.new()
    joy.anchor_top = 1.0
    joy.anchor_bottom = 1.0
    joy.offset_left = 30.0
    joy.offset_right = 290.0
    joy.offset_top = -290.0
    joy.offset_bottom = -30.0
    joy.visible = false
    hud.add_child(joy)
    act_btn = Button.new()
    act_btn.anchor_left = 1.0
    act_btn.anchor_right = 1.0
    act_btn.anchor_top = 1.0
    act_btn.anchor_bottom = 1.0
    act_btn.offset_left = -330.0
    act_btn.offset_right = -24.0
    act_btn.offset_top = -150.0
    act_btn.offset_bottom = -40.0
    _style(act_btn, Color(0.93, 0.55, 0.12), 30)
    act_btn.add_theme_font_size_override("font_size", 26)
    act_btn.pressed.connect(_act)
    act_btn.visible = false
    hud.add_child(act_btn)

# ----------------------------------------------------------------- build

func _build() -> void:
    if built:
        return
    built = true
    player = Node3D.new()
    player.name = "OwnerPlayer"
    g.add_child(player)
    model = Node3D.new()
    model.scale = Vector3.ONE * 1.25
    player.add_child(model)
    v._build_man(model, false)
    cam = Camera3D.new()
    cam.fov = 62.0
    cam.near = 0.1
    cam.far = 400.0
    g.add_child(cam)
    player.position = Vector3(0.6, GROUND_Y, 5.6)
    heading = deg_to_rad(90.0)       # facing the field (towards -z)
    cam_h = heading
    player.visible = false

func _make_obstacles() -> void:
    obstacles = SOLIDS.duplicate()
    for d in g.solid_discs:
        obstacles.append(d)

# ----------------------------------------------------------------- enter / leave

func can_enter() -> bool:
    if on or g == null:
        return false
    if v.hb != null and (v.hb.on or v.hb.sailing):
        return false
    if g.ui_root == null or not g.ui_root.visible:
        return false
    if g._any_panel_open():
        return false
    return true

func enter() -> void:
    if on or not can_enter():
        return
    _ensure_hud()
    _build()
    _make_obstacles()
    on = true
    g.owner_on = true
    if bottom_bar == null:
        for c in g.ui_root.get_children():
            if c is HBoxContainer and absf((c as Control).anchor_left - 0.22) < 0.01 and (c as Control).anchor_top == 1.0:
                bottom_bar = c
    if bottom_bar != null:
        bottom_bar.visible = false
    top_view = false
    player.visible = true
    cam_h = heading
    enter_btn.visible = false
    exit_btn.visible = true
    view_btn.visible = true
    view_btn.text = "TOP VIEW"
    joy.visible = true
    speed = 0.0
    _update_cam(1.0)
    cam.make_current()
    g._show_toast("You are the farmer! Walk up to animals, crops and shops.")

func leave() -> void:
    if not on:
        return
    on = false
    g.owner_on = false
    player.visible = false
    g.camera.make_current()
    if bottom_bar != null:
        bottom_bar.visible = true
    exit_btn.visible = false
    view_btn.visible = false
    joy.visible = false
    act_btn.visible = false
    (joy as SailScript.Joy).vec = Vector2.ZERO
    g.cam_zoom = 16.8
    g.cam_target = Vector3(0.0, 0.25, 0.0)
    g._update_camera()
    if g.crop_bar != null and not g.crop_bar_dismissed:
        g.crop_bar.visible = true

func _toggle_view() -> void:
    top_view = not top_view
    view_btn.text = "WALK VIEW" if top_view else "TOP VIEW"
    if top_view:
        g.cam_zoom = 11.0
        g.cam_target = player.position
        g.camera.make_current()
    else:
        cam.make_current()

# ----------------------------------------------------------------- actions

func _near_producer() -> Dictionary:
    var best: Dictionary = {}
    var best_d: float = 2.5
    for p in g.producers:
        if not bool(p["ready"]):
            continue
        var n: Node3D = p["node"]
        if not is_instance_valid(n):
            continue
        var d: float = Vector2(n.global_position.x - player.position.x, n.global_position.z - player.position.z).length()
        if d < best_d:
            best_d = d
            best = {"type": "prod", "p": p, "pos": n.global_position}
    return best

func _near_plot() -> Dictionary:
    var best_key: String = ""
    var best_d: float = g.CELL * 0.85
    for k in g.plot_centers.keys():
        var c: Vector3 = g.plot_centers[k]
        var d: float = maxf(absf(c.x - player.position.x), absf(c.z - player.position.z))
        if d < best_d:
            best_d = d
            best_key = str(k)
    if best_key == "":
        return {}
    var st: Dictionary = g.crop_states[best_key]
    var c2: Vector3 = g.plot_centers[best_key]
    var planted: bool = bool(st.get("planted", false))
    var ripe: bool = planted and float(st.get("age", 0.0)) >= g._grow_time_of(st)
    if v.care.has(best_key) and not ripe:
        var kind: String = str(v.care[best_key])
        return {"type": "care", "key": best_key, "pos": c2, "label": "WATER THE CROP" if kind == "water" else "PULL THE WEEDS"}
    if ripe:
        return {"type": "harvest", "key": best_key, "pos": c2, "label": "HARVEST"}
    if not planted:
        return {"type": "plant", "key": best_key, "pos": c2, "label": "PLANT SEEDS (%d)" % g.seeds}
    return {}

func _near_building() -> Dictionary:
    var pp := Vector2(player.position.x, player.position.z)
    if pp.distance_to(Vector2(g.OVEN_POS.x, g.OVEN_POS.z)) < 3.6:
        return {"type": "bakery", "pos": g.OVEN_POS, "label": "OPEN BAKERY"}
    for mp in [g.BARN_POS, g.MARKET_POS, g.SILO_POS]:
        if pp.distance_to(Vector2(mp.x, mp.z)) < 3.7:
            return {"type": "market", "pos": mp, "label": "OPEN MARKET"}
    if pp.distance_to(Vector2(g.WM_POS.x, g.WM_POS.z)) < 3.8:
        return {"type": "windmill", "pos": g.WM_POS, "label": "WINDMILL"}
    return {}

func _find_target() -> void:
    target = _near_producer()
    if target.is_empty():
        target = _near_plot()
        if not target.is_empty() and str(target["type"]) == "plant":
            var b: Dictionary = _near_building()
            if not b.is_empty():
                target = b
    if target.is_empty():
        target = _near_building()
    if target.is_empty():
        act_btn.visible = false
        return
    act_btn.visible = not g._any_panel_open()
    if str(target["type"]) == "prod":
        var kind: int = int(target["p"]["kind"])
        act_btn.text = "COLLECT " + str(g.PROD_NAMES[kind]).to_upper()
    else:
        act_btn.text = str(target["label"])

func _act() -> void:
    if not on or target.is_empty() or g._any_panel_open():
        return
    var pos: Vector3 = target["pos"]
    var d := Vector2(pos.x - player.position.x, pos.z - player.position.z)
    if d.length() > 0.3:
        heading = atan2(-d.y, d.x)
    hop_t = 0.4
    var ty: String = str(target["type"])
    if ty == "prod":
        g._collect_producer(target["p"])
    elif ty == "plant" or ty == "harvest" or ty == "care":
        var old: String = g.active_action
        g.active_action = "harvest" if ty == "harvest" else "plant"
        g._flash_cell(str(target["key"]))
        g._apply_plot_action(str(target["key"]))
        g.active_action = old
    elif ty == "bakery":
        g._open_bakery()
    elif ty == "market":
        g._open_market()
    elif ty == "windmill":
        g._tap_buildings(Vector3(g.WM_POS.x - 1.3, 0.0, g.WM_POS.z - 1.95))
    target = {}

# ----------------------------------------------------------------- per frame

func _update_cam(k: float) -> void:
    var dir := Vector3(cos(cam_h), 0.0, -sin(cam_h))
    var p: Vector3 = player.position
    var cp: Vector3 = p - dir * 4.4 + Vector3(0.0, 2.7, 0.0)
    cam.global_position = cam.global_position.lerp(cp, k) if k < 1.0 else cp
    cam.look_at(p + Vector3(0.0, 1.0, 0.0) + dir * 2.2, Vector3.UP)

func tick(delta: float) -> void:
    t += delta
    if hud == null:
        if g != null and g.ui_root != null:
            _ensure_hud()
        else:
            return
    if not on:
        enter_btn.visible = can_enter()
        return
    if g.crop_bar != null:
        g.crop_bar.visible = false
    var jv: Vector2 = (joy as SailScript.Joy).vec
    var busy: bool = g._any_panel_open()
    var steer: float = jv.x if (absf(jv.x) > 0.12 and not busy) else 0.0
    var thr: float = -jv.y if not busy else 0.0
    if absf(thr) < 0.12:
        thr = 0.0
    var tspeed: float = thr * WALK_SPEED if thr > 0.0 else thr * WALK_SPEED * 0.5
    speed = move_toward(speed, tspeed, 14.0 * delta)
    var turn: float = deg_to_rad(110.0)
    if steer != 0.0:
        heading -= steer * turn * delta
    steer_vis = lerpf(steer_vis, steer, clampf(8.0 * delta, 0.0, 1.0))
    var dir := Vector3(cos(heading), 0.0, -sin(heading))
    var p: Vector3 = player.position + dir * speed * delta
    for o in obstacles:
        var ov: Vector3 = o
        var dd := Vector2(p.x - ov.x, p.z - ov.y)
        if dd.length() < ov.z:
            var n: Vector2 = dd.normalized() if dd.length() > 0.001 else Vector2(1, 0)
            p.x = ov.x + n.x * ov.z
            p.z = ov.y + n.y * ov.z
    p.x = clampf(p.x, -LIMIT, LIMIT)
    p.z = clampf(p.z, -LIMIT, LIMIT)
    var moved: float = Vector2(p.x - player.position.x, p.z - player.position.z).length()
    phase += moved * 2.4 / 0.45 * 0.5
    player.position.x = p.x
    player.position.z = p.z
    var bob: float = absf(sin(phase * 2.0)) * 0.07 if moved > 0.002 else 0.0
    var hop: float = 0.0
    if hop_t > 0.0:
        hop_t -= delta
        hop = sin(clampf(hop_t / 0.4, 0.0, 1.0) * PI) * 0.18
    player.position.y = GROUND_Y + bob + hop
    player.rotation.y = heading
    model.rotation.x = sin(phase * 2.0) * 0.05 if moved > 0.002 else 0.0
    model.rotation.z = -deg_to_rad(5.0) * clampf(speed / WALK_SPEED, 0.0, 1.0)
    cam_h = lerp_angle(cam_h, heading, clampf(1.0 - exp(-3.2 * delta), 0.0, 1.0))
    if top_view:
        g.cam_target = g.cam_target.lerp(player.position, clampf(1.0 - exp(-6.0 * delta), 0.0, 1.0))
        g._update_camera()
    else:
        _update_cam(clampf(1.0 - exp(-12.0 * delta), 0.0, 1.0))
    _find_target()
