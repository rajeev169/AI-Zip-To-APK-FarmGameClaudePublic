package com.fluenthire.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fluenthire.app.AppDeps
import com.fluenthire.app.data.GrammarBank
import com.fluenthire.app.data.GrammarCategory
import com.fluenthire.app.data.McqItem
import com.fluenthire.app.data.SessionRecord
import com.fluenthire.app.ui.theme.Bad
import com.fluenthire.app.ui.theme.Good
import com.fluenthire.app.ui.theme.Warn
import com.fluenthire.app.ui.theme.scoreColor
import kotlinx.coroutines.delay

const val GRAMMAR_TYPE = "Grammar MCQ"
private const val QUESTIONS_PER_ROUND = 10
private const val SECONDS_PER_QUESTION = 30

// ------------------------------------------------------------------ categories

@Composable
fun GrammarCategoriesScreen(deps: AppDeps, refreshKey: Int, onBack: () -> Unit, onOpen: (GrammarCategory) -> Unit) {
    val best = remember(refreshKey) { deps.prefs.bestScores(GRAMMAR_TYPE) }
    Scaffold(topBar = { AppTopBar("Grammar MCQ", onBack) }) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            InfoCard(container = MaterialTheme.colorScheme.secondaryContainer) {
                Text("Recruiter-style grammar practice", fontWeight = FontWeight.SemiBold)
                Text(
                    "$QUESTIONS_PER_ROUND questions per round with 4 options each. " +
                        if (deps.prefs.hasApiKey) "The AI writes new questions every time." else "Add a Gemini key in Settings for new AI questions every time.",
                    style = MaterialTheme.typography.bodySmall,
                )
            }

            // Mixed test first: it feels like the real exam.
            CategoryCard(GrammarCategory.MIXED, best[GrammarCategory.MIXED.recordTitle], highlight = true) { onOpen(GrammarCategory.MIXED) }

            Text("Practise by type", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(top = 4.dp))
            GrammarCategory.practiceCategories.forEach { c ->
                CategoryCard(c, best[c.recordTitle], highlight = false) { onOpen(c) }
            }
            Spacer(Modifier.height(16.dp))
        }
    }
}

@Composable
private fun CategoryCard(c: GrammarCategory, best: Int?, highlight: Boolean, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (highlight) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface
        ),
        border = if (highlight) BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary) else null,
        elevation = CardDefaults.cardElevation(1.dp),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(c.emoji, fontSize = 24.sp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(c.title, fontWeight = FontWeight.SemiBold)
                Text(c.blurb, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
            }
            if (best != null) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("$best", fontWeight = FontWeight.Bold, color = scoreColor(best), fontSize = 18.sp)
                    Text("best", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                }
            } else {
                Icon(Icons.AutoMirrored.Filled.ArrowForward, null, tint = MaterialTheme.colorScheme.outline)
            }
        }
    }
}

// ------------------------------------------------------------------ one round

private data class McqResult(val item: McqItem, val picked: Int) {   // picked = -1 when time ran out
    val correct: Boolean get() = picked == item.answer
}

private enum class GPhase { Loading, Ready, Playing, Done }

@Composable
fun GrammarRoundScreen(
    deps: AppDeps,
    category: GrammarCategory,
    onBack: () -> Unit,
    onNextCategory: (GrammarCategory) -> Unit,
) {
    val prefs = deps.prefs
    val coach = remember { coachOrNull(deps) }

    var round by remember { mutableIntStateOf(0) }
    var phase by remember { mutableStateOf(GPhase.Loading) }
    var items by remember { mutableStateOf<List<McqItem>>(emptyList()) }
    var notice by remember { mutableStateOf<String?>(null) }
    var index by remember { mutableIntStateOf(0) }
    var picked by remember { mutableStateOf<Int?>(null) }        // null = not answered yet, -1 = time up
    var secondsLeft by remember { mutableIntStateOf(SECONDS_PER_QUESTION) }
    val results = remember { mutableStateListOf<McqResult>() }
    var confirmExit by remember { mutableStateOf(false) }
    var saved by remember { mutableStateOf(false) }

    LaunchedEffect(round) {
        phase = GPhase.Loading
        notice = null
        results.clear()
        saved = false
        val ai: List<McqItem> = if (coach != null) {
            try { coach.generateMcq(category, QUESTIONS_PER_ROUND) } catch (e: Exception) {
                notice = "Using built-in questions (${e.message})"
                emptyList()
            }
        } else emptyList()
        val fill = GrammarBank.random(category, QUESTIONS_PER_ROUND)
            .filter { b -> ai.none { it.question.equals(b.question, ignoreCase = true) } }
        items = (ai + fill).take(QUESTIONS_PER_ROUND)
        index = 0
        picked = null
        phase = GPhase.Ready
    }

    // 30-second countdown (Mixed Test only).
    LaunchedEffect(phase, index, picked) {
        if (phase != GPhase.Playing || !category.timed || picked != null) return@LaunchedEffect
        secondsLeft = SECONDS_PER_QUESTION
        while (secondsLeft > 0) {
            delay(1000)
            if (picked != null) return@LaunchedEffect
            secondsLeft--
        }
        if (picked == null) {
            picked = -1
            items.getOrNull(index)?.let { results += McqResult(it, -1) }
        }
    }

    fun answer(choice: Int) {
        if (picked != null) return
        val item = items.getOrNull(index) ?: return
        picked = choice
        results += McqResult(item, choice)
    }

    fun next() {
        if (index + 1 < items.size) {
            index++
            picked = null
        } else {
            phase = GPhase.Done
        }
    }

    BackHandler { if (phase == GPhase.Playing) confirmExit = true else onBack() }

    if (confirmExit) {
        AlertDialog(
            onDismissRequest = { confirmExit = false },
            title = { Text("Leave this test?") },
            text = { Text("Your answers in this round will not be saved.") },
            confirmButton = { TextButton(onClick = { confirmExit = false; onBack() }) { Text("Leave") } },
            dismissButton = { TextButton(onClick = { confirmExit = false }) { Text("Stay") } },
        )
    }

    Scaffold(topBar = {
        AppTopBar(
            if (phase == GPhase.Done) "${category.title} – Result" else "Grammar MCQ • ${category.title}",
            onBack = { if (phase == GPhase.Playing) confirmExit = true else onBack() },
        )
    }) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            when (phase) {
                GPhase.Loading -> LoadingBlock(
                    if (coach != null) "The AI is writing $QUESTIONS_PER_ROUND new questions…" else "Getting questions ready…"
                )

                GPhase.Ready -> {
                    InfoCard(container = MaterialTheme.colorScheme.primaryContainer) {
                        Text("${category.emoji} ${category.title}", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(6.dp))
                        Text(category.blurb)
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "${items.size} questions • choose 1 of 4 options" +
                                if (category.timed) " • $SECONDS_PER_QUESTION seconds per question" else " • no time limit",
                            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline,
                        )
                    }
                    if (category.timed) {
                        InfoCard(container = Color(0xFFFFF7ED)) {
                            Text("⏱️ Like a real recruiter test", fontWeight = FontWeight.SemiBold, color = Color(0xFF9A3412))
                            Text("If time runs out, the question is marked wrong and the answer is shown.",
                                style = MaterialTheme.typography.bodySmall)
                        }
                    }
                    notice?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline) }
                    Button(
                        onClick = { phase = GPhase.Playing },
                        modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(14.dp),
                    ) { Text("Start", fontSize = 16.sp) }
                }

                GPhase.Playing -> items.getOrNull(index)?.let { item ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Question ${index + 1} of ${items.size}", color = MaterialTheme.colorScheme.outline,
                            modifier = Modifier.weight(1f))
                        if (category.timed) {
                            val urgent = picked == null && secondsLeft <= 10
                            Text(
                                if (picked == -1) "⏰ Time's up" else "⏱️ ${secondsLeft}s",
                                fontWeight = FontWeight.Bold,
                                color = if (urgent || picked == -1) Bad else MaterialTheme.colorScheme.primary,
                            )
                        }
                    }
                    LinearProgressIndicator(
                        progress = { index.toFloat() / items.size },
                        modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                    )
                    if (category.timed && picked == null) {
                        LinearProgressIndicator(
                            progress = { secondsLeft / SECONDS_PER_QUESTION.toFloat() },
                            modifier = Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp)),
                            color = if (secondsLeft <= 10) Bad else Warn,
                            trackColor = MaterialTheme.colorScheme.surfaceVariant,
                        )
                    }

                    InfoCard(container = MaterialTheme.colorScheme.primaryContainer) {
                        if (category == GrammarCategory.MIXED || item.category == GrammarCategory.ONE_WORD) {
                            Text("${item.category.emoji} ${item.category.title}",
                                style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.height(6.dp))
                        }
                        Text(item.question, fontSize = 20.sp, lineHeight = 28.sp, fontWeight = FontWeight.Medium)
                    }

                    item.options.forEachIndexed { i, opt ->
                        OptionButton(
                            letter = "ABCD"[i].toString(), text = opt,
                            state = when {
                                picked == null -> OptState.Normal
                                i == item.answer -> OptState.Right
                                i == picked -> OptState.Wrong
                                else -> OptState.Dim
                            },
                            onClick = { answer(i) },
                        )
                    }

                    if (picked != null) {
                        val p = picked
                        val correct = p == item.answer
                        InfoCard(container = if (correct) Color(0xFFF0FDF4) else Color(0xFFFEF2F2)) {
                            Text(
                                when {
                                    correct -> "✓ Correct!"
                                    p == -1 -> "⏰ Time's up"
                                    else -> "✗ Wrong"
                                },
                                fontWeight = FontWeight.Bold, fontSize = 18.sp, color = if (correct) Good else Bad,
                            )
                            if (!correct) Text("Answer: ${"ABCD"[item.answer]}. ${item.correctText}", fontWeight = FontWeight.Medium,
                                modifier = Modifier.padding(top = 4.dp))
                            if (item.explanation.isNotBlank()) Text("💡 ${item.explanation}", style = MaterialTheme.typography.bodyMedium,
                                modifier = Modifier.padding(top = 6.dp))
                        }
                        HindiTip(item.hindiTip)
                        Button(
                            onClick = { next() },
                            modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(14.dp),
                        ) { Text(if (index + 1 < items.size) "Next question" else "See my result", fontSize = 16.sp) }
                    }
                }

                GPhase.Done -> {
                    val correctCount = results.count { it.correct }
                    val score = if (results.isEmpty()) 0 else correctCount * 100 / results.size
                    LaunchedEffect(Unit) {
                        if (!saved) {
                            saved = true
                            val subs = if (category == GrammarCategory.MIXED)
                                results.groupBy { it.item.category }.mapKeys { it.key.title }
                                    .mapValues { (_, v) -> v.count { it.correct } * 100 / v.size }
                            else emptyMap<String, Int>()
                            prefs.addRecord(
                                SessionRecord(
                                    type = GRAMMAR_TYPE, title = category.recordTitle, score = score,
                                    timestamp = System.currentTimeMillis(),
                                    summary = "$correctCount of ${results.size} correct",
                                    subScores = subs,
                                )
                            )
                        }
                    }

                    InfoCard {
                        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("${category.emoji} ${category.title}", color = MaterialTheme.colorScheme.outline)
                            Spacer(Modifier.height(8.dp))
                            ScoreRing(score, size = 140.dp, label = "score")
                            Spacer(Modifier.height(8.dp))
                            Text("$correctCount of ${results.size} correct", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            if (category.timed) {
                                val timeUps = results.count { it.picked == -1 }
                                if (timeUps > 0) Text("⏰ $timeUps ran out of time", style = MaterialTheme.typography.bodySmall,
                                    color = Bad)
                            }
                            Text(
                                when {
                                    score >= 90 -> "Excellent! You're ready for recruiter grammar tests."
                                    score >= 70 -> "Good score. Review the mistakes below and practise again."
                                    score >= 50 -> "You're getting there. Read the explanations carefully."
                                    else -> "Keep practising — each round teaches you new rules."
                                },
                                textAlign = TextAlign.Center, style = MaterialTheme.typography.bodyMedium,
                                modifier = Modifier.padding(top = 4.dp),
                            )
                        }
                    }

                    if (category == GrammarCategory.MIXED) {
                        InfoCard {
                            Text("Score by type", fontWeight = FontWeight.SemiBold)
                            results.groupBy { it.item.category }.forEach { (cat, list) ->
                                ScoreBar("${cat.emoji} ${cat.title} (${list.count { it.correct }}/${list.size})",
                                    list.count { it.correct } * 100 / list.size)
                            }
                        }
                    }

                    // Buttons first so they are easy to reach; review below.
                    val perfect = results.isNotEmpty() && results.all { it.correct }
                    val next = if (category == GrammarCategory.MIXED) null
                    else GrammarCategory.entries.getOrNull(category.ordinal + 1)
                    if (perfect && next != null) {
                        Button(
                            onClick = { onNextCategory(next) },
                            modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(14.dp),
                        ) { Text("Next category → ${next.title}", fontSize = 16.sp) }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedButton(onClick = onBack, modifier = Modifier.weight(1f).height(52.dp)) { Text("All categories") }
                        if (perfect && next != null) {
                            OutlinedButton(onClick = { round++ }, modifier = Modifier.weight(1f).height(52.dp)) { Text("Practice more") }
                        } else {
                            Button(onClick = { round++ }, modifier = Modifier.weight(1f).height(52.dp)) { Text("Practice more") }
                        }
                    }

                    Text("Review your answers", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    results.forEachIndexed { i, r ->
                        InfoCard {
                            Text("${i + 1}. ${r.item.question}", fontWeight = FontWeight.Medium)
                            Spacer(Modifier.height(4.dp))
                            if (r.correct) {
                                Text("✓ ${r.item.correctText}", color = Good, fontWeight = FontWeight.Medium)
                            } else {
                                Text(
                                    if (r.picked == -1) "⏰ No answer (time up)" else "✗ You chose: ${r.item.options[r.picked]}",
                                    color = Bad, style = MaterialTheme.typography.bodyMedium,
                                )
                                Text("✓ Answer: ${r.item.correctText}", color = Good, fontWeight = FontWeight.Medium)
                            }
                            if (r.item.explanation.isNotBlank()) Text("💡 ${r.item.explanation}", style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.outline, modifier = Modifier.padding(top = 4.dp))
                        }
                    }
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

private enum class OptState { Normal, Right, Wrong, Dim }

@Composable
private fun OptionButton(letter: String, text: String, state: OptState, onClick: () -> Unit) {
    val bg = when (state) {
        OptState.Normal -> MaterialTheme.colorScheme.surface
        OptState.Right -> Color(0xFFDCFCE7)
        OptState.Wrong -> Color(0xFFFEE2E2)
        OptState.Dim -> MaterialTheme.colorScheme.surface
    }
    val border = when (state) {
        OptState.Normal -> MaterialTheme.colorScheme.outline
        OptState.Right -> Good
        OptState.Wrong -> Bad
        OptState.Dim -> MaterialTheme.colorScheme.surfaceVariant
    }
    val badge = when (state) {
        OptState.Right -> Good
        OptState.Wrong -> Bad
        OptState.Normal -> MaterialTheme.colorScheme.primary
        OptState.Dim -> MaterialTheme.colorScheme.outline
    }
    Surface(
        onClick = onClick,
        enabled = state == OptState.Normal,
        shape = RoundedCornerShape(14.dp),
        color = bg,
        border = BorderStroke(1.dp, border),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Row(Modifier.padding(horizontal = 14.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(32.dp).clip(CircleShape).background(badge),
                contentAlignment = Alignment.Center,
            ) { Text(letter, color = Color.White, fontWeight = FontWeight.Bold) }
            Spacer(Modifier.width(12.dp))
            Text(
                text, fontSize = 17.sp, modifier = Modifier.weight(1f),
                color = if (state == OptState.Dim) MaterialTheme.colorScheme.outline else MaterialTheme.colorScheme.onSurface,
            )
            when (state) {
                OptState.Right -> Text("✓", color = Good, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                OptState.Wrong -> Text("✗", color = Bad, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                else -> Unit
            }
        }
    }
}
