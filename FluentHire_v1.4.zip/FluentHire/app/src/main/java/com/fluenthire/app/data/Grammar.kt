package com.fluenthire.app.data

enum class GrammarCategory(
    val title: String,
    val emoji: String,
    val blurb: String,
    val aiSpec: String,
    val timed: Boolean = false,
) {
    ARTICLES("Articles", "🅰️", "a / an / the",
        "articles: choose a, an, the, or no article (write '—' for no article)"),
    PREPOSITIONS("Prepositions", "📍", "in / on / at / for / since",
        "prepositions of time, place and direction (in, on, at, for, since, by, to, with, about)"),
    TENSES("Verbs & Tenses", "⏳", "goes / went / has gone / is going",
        "the correct verb form or tense (present, past, perfect, continuous, future, passive)"),
    AGREEMENT("Subject–Verb Agreement", "🤝", "is / are, has / have",
        "subject–verb agreement (is/are, was/were, has/have, verb + s), including tricky subjects like 'each', 'everyone', 'the team', 'one of the'"),
    VOCABULARY("Vocabulary", "📘", "The right word for the meaning",
        "choosing the right word for the meaning, including commonly confused words (affect/effect, advice/advise, lose/loose) and office vocabulary"),
    ONE_WORD("One-word Substitution", "🔤", "One word for a whole phrase",
        "one-word substitution: the question is a phrase describing something (no blank), and the options are single words; answer is the one word that means the phrase"),
    MIXED("Mixed Test", "⏱️", "All types • 30 seconds per question",
        "a mix of articles, prepositions, verb tenses, subject–verb agreement, vocabulary and one-word substitution", timed = true);

    val recordTitle: String get() = title

    companion object {
        val practiceCategories: List<GrammarCategory> get() = entries.filter { it != MIXED }
    }
}

/** A multiple-choice question. [options] always has 4 items; [answer] is the index of the correct option. */
data class McqItem(
    val question: String,
    val options: List<String>,
    val answer: Int,
    val explanation: String,
    val category: GrammarCategory,
    val hindiTip: String = "",
) {
    val correctText: String get() = options[answer]

    /** Same question with the options in a random order (answer index updated). */
    fun shuffledOptions(): McqItem {
        val order = options.indices.shuffled()
        return copy(options = order.map { options[it] }, answer = order.indexOf(answer))
    }

    fun isValid(): Boolean =
        question.isNotBlank() && options.size == 4 && answer in 0..3 &&
            options.all { it.isNotBlank() } && options.map { it.trim().lowercase() }.toSet().size == 4
}

object GrammarBank {
    // First option is always the correct one; options are shuffled when shown.
    private fun q(c: GrammarCategory, question: String, right: String, w1: String, w2: String, w3: String, why: String) =
        McqItem(question, listOf(right, w1, w2, w3), 0, why, c)

    private val A = GrammarCategory.ARTICLES
    private val P = GrammarCategory.PREPOSITIONS
    private val T = GrammarCategory.TENSES
    private val S = GrammarCategory.AGREEMENT
    private val V = GrammarCategory.VOCABULARY
    private val O = GrammarCategory.ONE_WORD

    private val all = listOf(
        // ---------- Articles
        q(A, "She is ____ honest employee.", "an", "a", "the", "—", "'Honest' starts with a vowel sound (the h is silent), so we use 'an'."),
        q(A, "He wants to become ____ engineer.", "an", "a", "the", "—", "'Engineer' starts with a vowel sound, so 'an'."),
        q(A, "I waited for ____ hour at the bank.", "an", "a", "the", "—", "'Hour' has a silent h, so it starts with a vowel sound: 'an hour'."),
        q(A, "She works at ____ university in Patna.", "a", "an", "the", "—", "'University' starts with a 'yu' sound (consonant sound), so 'a'."),
        q(A, "____ sun rises in the east.", "The", "A", "An", "—", "There is only one sun, so we use 'the'."),
        q(A, "Please close ____ door behind you.", "the", "a", "an", "—", "Both people know which door, so we use 'the'."),
        q(A, "He is ____ best player in our team.", "the", "a", "an", "—", "Superlatives (best, tallest) take 'the'."),
        q(A, "I have ____ interview tomorrow morning.", "an", "a", "the", "—", "'Interview' starts with a vowel sound, so 'an'."),
        q(A, "She bought ____ new phone yesterday.", "a", "an", "the", "—", "First mention of one phone, starting with a consonant sound: 'a'."),
        q(A, "My father is ____ doctor.", "a", "an", "the", "—", "Jobs take 'a/an': 'a doctor'."),
        q(A, "____ Ganga is a holy river.", "The", "A", "An", "—", "Names of rivers take 'the'."),
        q(A, "We had ____ lunch at one o'clock.", "—", "a", "an", "the", "Meals like lunch and dinner usually take no article."),

        // ---------- Prepositions
        q(P, "I have been working here ____ 2020.", "since", "for", "from", "at", "'Since' + a starting point in time (2020)."),
        q(P, "She has lived in Delhi ____ five years.", "for", "since", "from", "by", "'For' + a period of time (five years)."),
        q(P, "The meeting is ____ Monday.", "on", "in", "at", "by", "Use 'on' with days and dates."),
        q(P, "The office opens ____ 9 a.m.", "at", "on", "in", "by", "Use 'at' with clock times."),
        q(P, "He was born ____ 1998.", "in", "on", "at", "since", "Use 'in' with years, months and seasons."),
        q(P, "Please submit the report ____ Friday at the latest.", "by", "since", "from", "during", "'By' means 'not later than'."),
        q(P, "She is good ____ mathematics.", "at", "in", "on", "with", "We say 'good at' something."),
        q(P, "I am interested ____ this job.", "in", "on", "for", "at", "We say 'interested in'."),
        q(P, "The poster is ____ the wall.", "on", "in", "into", "of", "'On' = touching a surface, like a wall."),
        q(P, "He apologised ____ being late.", "for", "of", "with", "on", "We say 'apologise for' something."),
        q(P, "She is afraid ____ dogs.", "of", "from", "with", "by", "We say 'afraid of'."),
        q(P, "We will reach the station ____ ten minutes.", "in", "on", "at", "since", "'In' + time = after that much time from now."),

        // ---------- Verbs & Tenses
        q(T, "She ____ to the office every day.", "goes", "go", "going", "gone", "Habit, third person singular: 'goes'."),
        q(T, "Yesterday I ____ my manager.", "met", "meet", "have met", "meeting", "'Yesterday' = finished past time, so simple past: 'met'."),
        q(T, "Look! It ____ outside.", "is raining", "rains", "rained", "has rain", "'Look!' shows an action happening now: present continuous."),
        q(T, "I ____ my work already.", "have finished", "finishing", "finish", "am finish", "'Already' usually goes with present perfect: 'have finished'."),
        q(T, "By the time we arrived, the train ____.", "had left", "has left", "leaves", "is leaving", "An action before another past action: past perfect 'had left'."),
        q(T, "If it rains tomorrow, we ____ at home.", "will stay", "stayed", "would stayed", "stays", "First conditional: if + present, will + verb."),
        q(T, "She ____ English for three years.", "has been learning", "is learn", "learn", "have learning", "Action that started in the past and continues: present perfect continuous."),
        q(T, "The letter ____ yesterday.", "was sent", "sent", "is send", "has sending", "Passive voice in the past: was + past participle."),
        q(T, "He ____ TV when the phone rang.", "was watching", "watched", "is watching", "watches", "Longer action interrupted in the past: past continuous."),
        q(T, "They ____ the project next week.", "will start", "started", "have started", "starting", "'Next week' = future: 'will start'."),
        q(T, "I usually ____ tea in the morning.", "drink", "drinks", "drinking", "drunk", "'I' + habit = base verb 'drink'."),
        q(T, "She ____ not come to the meeting yesterday.", "did", "does", "has", "was", "Negative in simple past: did not + base verb."),

        // ---------- Subject–Verb Agreement
        q(S, "Each of the students ____ a laptop.", "has", "have", "are having", "were", "'Each' is singular, so 'has'."),
        q(S, "The team ____ working hard.", "is", "are being", "were be", "be", "A team acting as one unit takes a singular verb: 'is'."),
        q(S, "Neither he nor I ____ ready.", "am", "is", "are", "be", "With 'neither…nor', the verb agrees with the nearer subject ('I am')."),
        q(S, "One of my friends ____ in Mumbai.", "lives", "live", "living", "are living", "'One of…' is singular: 'lives'."),
        q(S, "Everyone ____ to be happy.", "wants", "want", "are wanting", "were want", "'Everyone' is singular: 'wants'."),
        q(S, "The price of vegetables ____ gone up.", "has", "have", "are", "were", "The subject is 'the price' (singular), not 'vegetables'."),
        q(S, "My brother and sister ____ teachers.", "are", "is", "was", "has", "Two subjects joined by 'and' are plural: 'are'."),
        q(S, "There ____ many people at the station.", "were", "was", "is", "has", "'Many people' is plural: 'there were'."),
        q(S, "Mathematics ____ my favourite subject.", "is", "are", "were", "have", "Subjects like mathematics and news are singular."),
        q(S, "The manager, along with his team, ____ arrived.", "has", "have", "are", "were", "'Along with' does not change the subject: 'the manager has'."),
        q(S, "Ten kilometres ____ a long distance to walk.", "is", "are", "were", "have", "Distances and amounts as one unit take a singular verb."),
        q(S, "Either the boys or the girl ____ the prize.", "has won", "have won", "are winning", "were won", "The verb agrees with the nearer subject 'the girl': 'has won'."),

        // ---------- Vocabulary
        q(V, "Please give me some ____ about my career.", "advice", "advise", "advices", "adviser", "'Advice' is the noun; 'advise' is the verb."),
        q(V, "The new rule will ____ all employees.", "affect", "effect", "effort", "afford", "'Affect' is usually the verb; 'effect' is usually the noun."),
        q(V, "Don't ____ your ID card.", "lose", "loose", "loss", "lost", "'Lose' = to stop having something; 'loose' = not tight."),
        q(V, "He was ____ for the job because of his experience.", "selected", "rejected", "elected", "collected", "'Selected' = chosen."),
        q(V, "Please ____ the form and submit it.", "fill in", "fill on", "fill at", "full in", "We 'fill in' a form."),
        q(V, "The company will ____ new staff next month.", "recruit", "retire", "resign", "repeat", "'Recruit' = to hire new people."),
        q(V, "She was ____ to get the job offer.", "delighted", "delightful", "delight", "delighting", "People feel 'delighted'; things are 'delightful'."),
        q(V, "Can you ____ me your pen?", "lend", "borrow", "lent", "loan to", "You 'lend' something to someone; you 'borrow' it from them."),
        q(V, "The opposite of 'expensive' is ____.", "cheap", "costly", "valuable", "rich", "'Cheap' means low in price."),
        q(V, "Our ____ is to deliver on time.", "priority", "priorly", "prior", "prioritise", "We need a noun here: 'priority'."),
        q(V, "He gave a very ____ answer in the interview.", "confident", "confidence", "confidently", "confide", "An adjective describes the noun 'answer': 'confident'."),
        q(V, "I am ____ to work night shifts.", "willing", "wiling", "will", "willingly", "'Willing to' = ready to do something."),

        // ---------- One-word Substitution
        q(O, "A person who speaks many languages", "Polyglot", "Linguist", "Translator", "Orator", "A polyglot knows and uses several languages."),
        q(O, "A person who works for no payment", "Volunteer", "Employee", "Labourer", "Servant", "A volunteer offers work without pay."),
        q(O, "A list of items to be discussed at a meeting", "Agenda", "Minutes", "Schedule", "Notice", "An agenda lists the topics of a meeting."),
        q(O, "A person who looks on the bright side of things", "Optimist", "Pessimist", "Realist", "Fatalist", "An optimist expects good things."),
        q(O, "A written record of what was said in a meeting", "Minutes", "Agenda", "Memo", "Draft", "Minutes are the written notes of a meeting."),
        q(O, "To leave a job by your own choice", "Resign", "Retire", "Dismiss", "Suspend", "To resign is to leave a job by choice."),
        q(O, "That which cannot be seen", "Invisible", "Visible", "Illegible", "Invincible", "'Invisible' means cannot be seen."),
        q(O, "Writing that cannot be read", "Illegible", "Invisible", "Eligible", "Illiterate", "'Illegible' handwriting cannot be read."),
        q(O, "A person who cannot read or write", "Illiterate", "Illegible", "Ignorant", "Innocent", "'Illiterate' means unable to read or write."),
        q(O, "A period of ten years", "Decade", "Century", "Decennial", "Millennium", "A decade is ten years."),
        q(O, "A person who is new to a job or activity", "Novice", "Expert", "Veteran", "Master", "A novice is a beginner."),
        q(O, "Fit or qualified to be chosen", "Eligible", "Legible", "Edible", "Audible", "'Eligible' means qualified to be chosen."),
    )

    /** [n] random built-in questions for a category (Mixed draws from all), options shuffled. */
    fun random(category: GrammarCategory, n: Int): List<McqItem> {
        val pool = if (category == GrammarCategory.MIXED) all else all.filter { it.category == category }
        return pool.shuffled().take(n).map { it.shuffledOptions() }
    }

    val size: Int get() = all.size
    fun allItems(): List<McqItem> = all
}
