package com.fluenthire.app.ai

import com.fluenthire.app.data.GrammarCategory
import com.fluenthire.app.data.JobRole
import com.fluenthire.app.data.McqItem
import com.fluenthire.app.data.PracticeFactory
import com.fluenthire.app.data.PracticeTask
import com.fluenthire.app.data.Section
import com.fluenthire.app.data.SentenceItem
import com.fluenthire.app.data.SentenceLevel
import org.json.JSONArray
import org.json.JSONObject

data class Correction(val wrong: String, val right: String)

data class AnswerFeedback(
    val question: String,
    val answer: String,
    val fluency: Int,
    val grammar: Int,
    val vocabulary: Int,
    val relevance: Int,
    val overall: Int,
    val feedback: String,
    val corrections: List<Correction>,
    val betterAnswer: String,
    val hindiTip: String,
    val fillers: Int,
)

data class InterviewTurnResult(val feedback: AnswerFeedback, val nextQuestion: String?)

data class FinalReport(
    val summary: String,
    val strengths: List<String>,
    val improvements: List<String>,
    val readiness: String,
)

data class OpenScore(val score: Int, val feedback: String, val hindiTip: String)

/** All AI prompts live here. */
class Coach(private val client: GeminiClient, private val hindi: Boolean) {

    private val hindiRule get() =
        if (hindi) "Also give \"hindiTip\": one short, simple tip in Hindi (Devanagari script) explaining the main mistake or how to improve."
        else "Set \"hindiTip\" to an empty string."

    private fun interviewerSystem(role: JobRole, level: String) = """
        You are a friendly but professional HR interviewer in India conducting a spoken English job interview
        for the role "${role.name}" (${role.blurb}). Candidate experience: $level.
        The candidate is practising to improve spoken English and interview skills. Their answers come from
        speech-to-text, so ignore missing punctuation and small transcription errors in spelling.
        Ask one clear question at a time, in simple international English, under 30 words.
        Always reply ONLY with valid JSON.
    """.trimIndent()

    suspend fun firstQuestion(role: JobRole, level: String): String {
        val prompt = """
            Start the interview. Greet the candidate in one short sentence and ask the first question
            (usually a variation of "Tell me about yourself").
            Example questions for this role: ${role.sampleQuestions.joinToString(" | ")}
            Reply as JSON: {"question": "..."}
        """.trimIndent()
        val o = client.generateJson(interviewerSystem(role, level), prompt, 0.8)
        return o.optString("question").ifBlank { role.sampleQuestions.first() }
    }

    suspend fun evaluate(
        role: JobRole, level: String,
        history: List<Pair<String, String>>,
        question: String, answer: String,
        questionNumber: Int, total: Int,
        fillers: Int,
    ): InterviewTurnResult {
        val isLast = questionNumber >= total
        val past = history.joinToString("\n") { (q, a) -> "Q: $q\nA: $a" }.ifBlank { "(none)" }
        val prompt = """
            Earlier in this interview:
            $past

            Current question ($questionNumber of $total): $question
            Candidate's spoken answer: "$answer"

            Evaluate ONLY the current answer. Score each 0-100:
            - fluency (flow, sentence length, natural speech; the answer contains $fillers filler words)
            - grammar
            - vocabulary (range and professional words)
            - relevance (does it answer the question well, with examples, for this job)
            Give "overall" 0-100.
            "feedback": 2-3 short, encouraging, specific sentences.
            "corrections": up to 4 items {"wrong": exact phrase they said, "right": corrected phrase}. Empty list if none.
            "betterAnswer": a model answer the candidate could say, in their own situation, 60-90 words, simple and natural.
            $hindiRule
            ${if (isLast) "This was the last question. Set \"nextQuestion\" to an empty string."
              else "\"nextQuestion\": the next interview question. Sometimes ask a natural follow-up based on their answer; otherwise move to a new topic relevant to this role. Do not repeat earlier questions."}

            Reply as JSON: {"fluency":0,"grammar":0,"vocabulary":0,"relevance":0,"overall":0,"feedback":"","corrections":[],"betterAnswer":"","hindiTip":"","nextQuestion":""}
        """.trimIndent()
        val o = client.generateJson(interviewerSystem(role, level), prompt, 0.5)
        val next = o.optString("nextQuestion").trim().takeIf { !isLast && it.isNotBlank() }
        return InterviewTurnResult(parseFeedback(o, question, answer, fillers), next)
    }

    suspend fun finalReport(role: JobRole, level: String, items: List<AnswerFeedback>): FinalReport {
        val transcript = items.joinToString("\n\n") {
            "Q: ${it.question}\nA: ${it.answer}\nScore: ${it.overall}"
        }
        val prompt = """
            The interview is over. Here is the full transcript with scores:
            $transcript

            Write a short final report for the candidate:
            "summary": 2-3 sentences on overall performance.
            "strengths": 2-3 short points.
            "improvements": 3 short, practical action points for the next week.
            "readiness": one of "Ready for interviews", "Almost ready", "Needs more practice".
            Reply as JSON: {"summary":"","strengths":[],"improvements":[],"readiness":""}
        """.trimIndent()
        val o = client.generateJson(interviewerSystem(role, level), prompt, 0.5)
        return FinalReport(
            summary = o.optString("summary"),
            strengths = o.optJSONArray("strengths").toStringList(),
            improvements = o.optJSONArray("improvements").toStringList(),
            readiness = o.optString("readiness").ifBlank { "Keep practising" },
        )
    }

    /** Scores a story retelling or an open answer in the practice test. */
    suspend fun scoreOpen(taskType: String, taskText: String, answer: String): OpenScore {
        val system = """
            You are an expert spoken English examiner for job seekers in India.
            The response is from speech-to-text, so ignore punctuation and small spelling errors.
            Always reply ONLY with valid JSON.
        """.trimIndent()
        val prompt = """
            Task type: $taskType
            Task: $taskText
            Candidate's spoken response: "$answer"

            Give a score 0-100 for overall spoken English quality on this task
            (content accuracy/completeness, grammar, vocabulary, fluency).
            "feedback": 1-2 short, specific sentences.
            $hindiRule
            Reply as JSON: {"score":0,"feedback":"","hindiTip":""}
        """.trimIndent()
        val o = client.generateJson(system, prompt, 0.3)
        return OpenScore(
            o.optInt("score").coerceIn(0, 100),
            o.optString("feedback"),
            o.optString("hindiTip"),
        )
    }

    // ------------------------------------------------------------ question generators

    private val themes = listOf(
        "office work", "customer service calls", "banking", "online shopping", "travel and trains",
        "school and college", "health and hospitals", "technology and mobile phones", "food and restaurants",
        "family and home", "sports", "weather", "job interviews", "small business", "village and farming",
    )

    private val generatorSystem = """
        You write fresh English practice questions for job seekers in India (level A2 to B2).
        Use simple, natural, international English. No names of real celebrities, no sensitive topics.
        Always reply ONLY with valid JSON.
    """.trimIndent()

    /** [n] fresh AI questions for one Versant-style part. Invalid items are dropped (caller fills the gap). */
    suspend fun generatePart(section: Section, n: Int, harder: Boolean): List<PracticeTask> {
        val theme = themes.shuffled().take(2).joinToString(" and ")
        val level = if (harder) "slightly harder than usual (B1–B2)" else "everyday level (A2–B1)"
        val spec = when (section) {
            Section.READ -> """$n sentences to read aloud, 10 to 16 words each. JSON: {"items":[{"text":""}]}"""
            Section.REPEAT -> """$n sentences to listen to and repeat, 5 to 10 words each. JSON: {"items":[{"text":""}]}"""
            Section.SHORT -> """$n simple general-knowledge questions that have a one- to three-word answer.
                "answers" lists 2 to 5 acceptable short answers in lowercase (include synonyms and the number written as digits AND words if it is a number).
                JSON: {"items":[{"question":"","answers":["",""]}]}"""
            Section.BUILD -> """$n sentences, each split into exactly 3 word groups in the CORRECT order (the app will mix them).
                Each group 1 to 4 words, lowercase except names and "I", no final full stop.
                JSON: {"items":[{"phrases":["","",""]}]}"""
            Section.RETELL -> """$n very short stories (3 sentences, 35 to 55 words each) with a clear person, problem and ending.
                "keywords": 8 to 10 important lowercase words from the story (names, actions, objects).
                JSON: {"items":[{"story":"","keywords":[""]}]}"""
            Section.OPEN -> """$n opinion questions a candidate can answer in 30 to 60 seconds, each under 20 words.
                JSON: {"items":[{"question":""}]}"""
        }
        val prompt = """
            Part: ${section.fullTitle} — ${section.instruction}
            Topic ideas: $theme. Difficulty: $level.
            Make every item different. Write $spec
        """.trimIndent()
        val arr = client.generateJson(generatorSystem, prompt, 0.95).optJSONArray("items") ?: return emptyList()
        val out = mutableListOf<PracticeTask>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val task = when (section) {
                Section.READ -> o.optString("text").clean().takeIf { it.wordCount() in 5..22 }?.let { PracticeFactory.readAloud(it) }
                Section.REPEAT -> o.optString("text").clean().takeIf { it.wordCount() in 3..14 }?.let { PracticeFactory.repeat(it) }
                Section.SHORT -> {
                    val q = o.optString("question").clean()
                    val ans = o.optJSONArray("answers").toStringList().map { it.lowercase().trim() }.filter { it.isNotBlank() }
                    if (q.isNotBlank() && ans.isNotEmpty()) PracticeFactory.shortAnswer(q, ans) else null
                }
                Section.BUILD -> {
                    val ph = o.optJSONArray("phrases").toStringList().map { it.trim().trimEnd('.') }.filter { it.isNotBlank() }
                    if (ph.size == 3) PracticeFactory.build(ph) else null
                }
                Section.RETELL -> {
                    val s = o.optString("story").clean()
                    val k = o.optJSONArray("keywords").toStringList().map { it.lowercase() }
                    if (s.wordCount() in 20..90 && k.size >= 4) PracticeFactory.retell(s, k) else null
                }
                Section.OPEN -> o.optString("question").clean().takeIf { it.wordCount() in 4..30 }?.let { PracticeFactory.open(it) }
            }
            if (task != null) out += task
        }
        return out.take(n)
    }

    /** [n] fresh sentences for the tap-to-arrange Sentence Building game. */
    suspend fun generateSentences(level: SentenceLevel, n: Int): List<SentenceItem> {
        val theme = themes.shuffled().take(2).joinToString(" and ")
        val prompt = """
            Write $n different English sentences for a word-ordering game: ${level.aiStyle}.
            Topic ideas: $theme.
            Rules: each sentence must have exactly ONE clearly correct word order (avoid sentences where words can be
            moved around and still be correct); do not start with a person's name; no quotation marks; end with a full stop.
            "tip": one short grammar tip (under 15 words) explaining the word order.
            "alternatives": other word orders that are ALSO fully correct (usually an empty list).
            $hindiRule
            Reply as JSON: {"items":[{"sentence":"","tip":"","hindiTip":"","alternatives":[]}]}
        """.trimIndent()
        val arr = client.generateJson(generatorSystem, prompt, 0.95).optJSONArray("items") ?: return emptyList()
        val out = mutableListOf<SentenceItem>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val s = o.optString("sentence").clean()
            val wc = s.wordCount()
            if (wc < 3 || wc > level.words.last + 3) continue
            out += SentenceItem(
                sentence = s,
                tip = o.optString("tip").clean(),
                hindiTip = if (hindi) o.optString("hindiTip").trim() else "",
                alternatives = o.optJSONArray("alternatives").toStringList(),
            )
        }
        return out.take(n)
    }

    /**
     * Sentence Building fair check: the learner used all the same words but in a different order than expected.
     * Returns true when their order is also fully correct, natural English with the same meaning.
     */
    suspend fun isAlsoCorrect(expected: String, learner: String): Boolean {
        val prompt = """
            A learner arranged jumbled word tiles into a sentence. They used exactly the same words as the expected sentence.
            Expected sentence: "$expected"
            Learner's sentence: "$learner"
            Is the learner's sentence ALSO fully correct, natural standard English with the same basic meaning?
            Ignore capital letters and punctuation. Be strict: if the word order is unnatural or ungrammatical, answer false.
            Reply as JSON: {"correct": true or false}
        """.trimIndent()
        val o = client.generateJson(generatorSystem, prompt, 0.0)
        return o.optBoolean("correct", false)
    }

    /** [n] fresh multiple-choice grammar questions (recruiter-test style). Invalid items are dropped. */
    suspend fun generateMcq(category: GrammarCategory, n: Int): List<McqItem> {
        val theme = themes.shuffled().take(2).joinToString(" and ")
        val catKeys = GrammarCategory.practiceCategories.joinToString(", ") { it.name }
        val prompt = """
            Write $n multiple-choice English grammar questions like those in Indian company recruitment tests
            (Jio, TCS, BPOs). Type: ${category.aiSpec}.
            Topic ideas for the sentences: $theme. Level: A2 to B2.
            Rules:
            - For fill-in-the-blank questions, write the blank as ____ (four underscores) exactly once.
            - Exactly 4 options. Exactly ONE option is correct; the other three must be clearly wrong in this sentence.
            - Options must be different from each other and short (1 to 4 words).
            - "answer" is the 0-based index of the correct option.
            - "explanation": one short sentence (under 20 words) explaining why the answer is correct.
            ${if (category == GrammarCategory.MIXED) "- \"category\": one of $catKeys for each question; use a good mix." else "- \"category\": \"${category.name}\"."}
            $hindiRule
            Reply as JSON: {"items":[{"question":"","options":["","","",""],"answer":0,"explanation":"","hindiTip":"","category":""}]}
        """.trimIndent()
        val arr = client.generateJson(generatorSystem, prompt, 0.9).optJSONArray("items") ?: return emptyList()
        val out = mutableListOf<McqItem>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val cat = if (category == GrammarCategory.MIXED)
                GrammarCategory.practiceCategories.firstOrNull { it.name == o.optString("category").trim().uppercase() }
                    ?: GrammarCategory.VOCABULARY
            else category
            val item = McqItem(
                question = o.optString("question").clean(),
                options = o.optJSONArray("options").toStringList().map { it.trim() },
                answer = o.optInt("answer", -1),
                explanation = o.optString("explanation").clean(),
                category = cat,
                hindiTip = if (hindi) o.optString("hindiTip").trim() else "",
            )
            if (item.isValid()) out += item.shuffledOptions()
        }
        return out.take(n)
    }

    private fun String.clean() = trim().removeSurrounding("\"").trim()
    private fun String.wordCount() = trim().split(Regex("\\s+")).count { it.isNotBlank() }

    private fun parseFeedback(o: JSONObject, q: String, a: String, fillers: Int): AnswerFeedback {
        val corr = mutableListOf<Correction>()
        o.optJSONArray("corrections")?.let { arr ->
            for (i in 0 until arr.length()) {
                val c = arr.optJSONObject(i) ?: continue
                val w = c.optString("wrong"); val r = c.optString("right")
                if (w.isNotBlank() && r.isNotBlank()) corr += Correction(w, r)
            }
        }
        val f = o.optInt("fluency").coerceIn(0, 100)
        val g = o.optInt("grammar").coerceIn(0, 100)
        val v = o.optInt("vocabulary").coerceIn(0, 100)
        val r = o.optInt("relevance").coerceIn(0, 100)
        val overall = o.optInt("overall", (f + g + v + r) / 4).coerceIn(0, 100)
        return AnswerFeedback(
            q, a, f, g, v, r, overall,
            o.optString("feedback"), corr, o.optString("betterAnswer"),
            if (hindi) o.optString("hindiTip") else "", fillers,
        )
    }
}

private fun JSONArray?.toStringList(): List<String> {
    if (this == null) return emptyList()
    return (0 until length()).mapNotNull { optString(it).takeIf { s -> s.isNotBlank() } }
}
