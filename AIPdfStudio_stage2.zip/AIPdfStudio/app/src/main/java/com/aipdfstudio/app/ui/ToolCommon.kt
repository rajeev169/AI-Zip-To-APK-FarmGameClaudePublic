@file:OptIn(ExperimentalMaterial3Api::class)

package com.aipdfstudio.app.ui

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.ErrorOutline
import androidx.compose.material.icons.outlined.FolderOpen
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.PictureAsPdf
import androidx.compose.material.icons.outlined.SaveAlt
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.aipdfstudio.app.data.Outputs
import com.aipdfstudio.app.data.Picked
import com.aipdfstudio.app.data.fmtSize
import java.io.File

/** Common frame for every tool: top bar, scrolling content, a main button at the bottom, busy dialog. */
@Composable
fun ToolPage(
    title: String,
    vm: ToolVm,
    onBack: () -> Unit,
    actionLabel: String? = null,
    actionEnabled: Boolean = true,
    onAction: () -> Unit = {},
    topActions: @Composable () -> Unit = {},
    bottomExtra: @Composable () -> Unit = {},
    content: LazyListScope.() -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(title) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = { topActions() }
            )
        },
        bottomBar = {
            if (actionLabel != null) {
                Surface(color = MaterialTheme.colorScheme.surfaceContainer) {
                    Column(Modifier.fillMaxWidth().navigationBarsPadding().padding(16.dp, 10.dp)) {
                        bottomExtra()
                        Button(
                            onClick = onAction,
                            enabled = actionEnabled && vm.busy == null && !vm.loading,
                            modifier = Modifier.fillMaxWidth().height(52.dp)
                        ) { Text(actionLabel) }
                    }
                }
            }
        }
    ) { pad ->
        LazyColumn(
            modifier = Modifier.padding(pad).fillMaxSize().imePadding(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            content = content
        )
    }

    val working = vm.busy
    if (working != null) {
        AlertDialog(
            onDismissRequest = {},
            confirmButton = {},
            text = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(Modifier.size(28.dp), strokeWidth = 3.dp)
                    Spacer(Modifier.width(16.dp))
                    Text(working)
                }
            }
        )
    }
}

@Composable
fun Hint(text: String) {
    Text(text, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
}

/** Shows the chosen PDF, or a big button to choose one. */
@Composable
fun PickedCard(p: Picked?, loading: Boolean, onPick: () -> Unit) {
    if (p == null) {
        Surface(
            onClick = onPick,
            enabled = !loading,
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surfaceContainer,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                Modifier.padding(28.dp).fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                if (loading) CircularProgressIndicator(Modifier.size(32.dp))
                else Icon(Icons.Outlined.FolderOpen, contentDescription = null, modifier = Modifier.size(36.dp), tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.height(10.dp))
                Text("Choose a PDF", style = MaterialTheme.typography.titleMedium)
            }
        }
    } else {
        FileRow(p, trailing = {
            TextButton(onClick = onPick, enabled = !loading) { Text("Change") }
        })
    }
}

@Composable
fun FileRow(p: Picked, leading: (@Composable () -> Unit)? = null, trailing: @Composable () -> Unit = {}) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surfaceContainer,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(Modifier.padding(start = 12.dp, end = 4.dp, top = 10.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            if (leading != null) leading()
            Box(
                Modifier.size(40.dp).background(MaterialTheme.colorScheme.primaryContainer, RoundedCornerShape(10.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    if (p.locked) Icons.Outlined.Lock else Icons.Outlined.PictureAsPdf,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onPrimaryContainer
                )
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(p.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
                val info = when {
                    p.locked -> "Password protected"
                    p.broken -> "Can't read this file"
                    else -> listOf("${p.pages} page${if (p.pages == 1) "" else "s"}", fmtSize(p.size)).filter { it.isNotBlank() }.joinToString(" · ")
                }
                Text(
                    info,
                    style = MaterialTheme.typography.bodySmall,
                    color = if (p.locked || p.broken) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            trailing()
        }
    }
}

/** Error message, note and finished files with Open / Share / Save buttons. */
fun LazyListScope.outcome(vm: ToolVm, onOpen: (Uri) -> Unit) {
    vm.error?.let { msg ->
        item(key = "error") { MessageCard(msg, isError = true) }
    }
    vm.note?.let { msg ->
        item(key = "note") { MessageCard(msg, isError = false) }
    }
    if (vm.results.isNotEmpty()) {
        item(key = "results") { ResultsPanel(vm.results, onOpen) }
    }
}

@Composable
fun MessageCard(text: String, isError: Boolean) {
    val cs = MaterialTheme.colorScheme
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = if (isError) cs.errorContainer else cs.secondaryContainer,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(
                if (isError) Icons.Outlined.ErrorOutline else Icons.Outlined.CheckCircle,
                contentDescription = null,
                tint = if (isError) cs.onErrorContainer else cs.onSecondaryContainer
            )
            Spacer(Modifier.width(12.dp))
            Text(text, color = if (isError) cs.onErrorContainer else cs.onSecondaryContainer)
        }
    }
}

@Composable
private fun ResultsPanel(files: List<File>, onOpen: (Uri) -> Unit) {
    val ctx = LocalContext.current
    var saving by remember { mutableStateOf<File?>(null) }

    fun toast(t: String) = Toast.makeText(ctx, t, Toast.LENGTH_SHORT).show()

    val saveOne = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { dest ->
        val f = saving
        if (dest != null && f != null) {
            try {
                Outputs.copyTo(ctx, f, dest)
                toast("Saved")
            } catch (e: Exception) {
                toast("Couldn't save the file")
            }
        }
        saving = null
    }
    val saveAll = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { tree ->
        if (tree != null) {
            try {
                val n = Outputs.saveAllToFolder(ctx, files, tree)
                toast("Saved $n files")
            } catch (e: Exception) {
                toast("Couldn't save to that folder")
            }
        }
    }

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
            if (files.size == 1) "Your file is ready" else "${files.size} files are ready",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Medium
        )
        if (files.size > 1) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilledTonalButton(onClick = { saveAll.launch(null) }) {
                    Icon(Icons.Outlined.SaveAlt, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Save all")
                }
                OutlinedButton(onClick = { tryShare(ctx, files) }) {
                    Icon(Icons.Outlined.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Share all")
                }
            }
        }
        files.forEach { f ->
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surfaceContainer,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(start = 14.dp, end = 6.dp, top = 10.dp, bottom = 4.dp)) {
                    Text(f.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
                    Text(fmtSize(f.length()), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Row {
                        SmallAction("Open", Icons.Outlined.Visibility) { onOpen(Outputs.uri(ctx, f)) }
                        SmallAction("Share", Icons.Outlined.Share) { tryShare(ctx, listOf(f)) }
                        SmallAction("Save", Icons.Outlined.SaveAlt) {
                            saving = f
                            saveOne.launch(f.name)
                        }
                    }
                }
            }
        }
        Hint("Files stay inside the app until you save or share them.")
    }
}

private fun tryShare(ctx: android.content.Context, files: List<File>) {
    try {
        Outputs.share(ctx, files)
    } catch (e: Exception) {
        Toast.makeText(ctx, "No app available to share with", Toast.LENGTH_SHORT).show()
    }
}

@Composable
private fun SmallAction(label: String, icon: ImageVector, onClick: () -> Unit) {
    TextButton(onClick = onClick) {
        Icon(icon, contentDescription = null, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(6.dp))
        Text(label)
    }
}

/** A radio-style option row used by Split and Compress. */
@Composable
fun ChoiceRow(title: String, sub: String?, selected: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(16.dp),
        color = if (selected) cs.primaryContainer else cs.surfaceContainer,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(Modifier.padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            androidx.compose.material3.RadioButton(selected = selected, onClick = onClick)
            Column(Modifier.padding(vertical = 6.dp)) {
                Text(title, fontWeight = FontWeight.Medium, color = if (selected) cs.onPrimaryContainer else cs.onSurface)
                if (sub != null) {
                    Text(
                        sub,
                        style = MaterialTheme.typography.bodySmall,
                        color = if (selected) cs.onPrimaryContainer else cs.onSurfaceVariant
                    )
                }
            }
        }
    }
}
