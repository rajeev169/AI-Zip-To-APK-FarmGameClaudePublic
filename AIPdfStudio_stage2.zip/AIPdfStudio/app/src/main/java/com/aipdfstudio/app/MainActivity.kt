package com.aipdfstudio.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.aipdfstudio.app.ui.AiViewModel
import com.aipdfstudio.app.ui.AppRoot
import com.aipdfstudio.app.ui.theme.AppTheme

class MainActivity : ComponentActivity() {
    private val ai: AiViewModel by viewModels()
    private var incoming by mutableStateOf<Uri?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        if (savedInstanceState == null) incoming = intent?.data
        setContent {
            AppTheme {
                AppRoot(ai = ai, incoming = incoming, onIncomingHandled = { incoming = null })
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        incoming = intent.data
    }
}
