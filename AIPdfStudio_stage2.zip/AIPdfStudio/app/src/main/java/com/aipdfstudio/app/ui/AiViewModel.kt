package com.aipdfstudio.app.ui

import android.app.Application
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.aipdfstudio.app.data.GeminiClient
import com.aipdfstudio.app.data.PdfText
import com.aipdfstudio.app.data.SecureStore
import kotlinx.coroutines.launch

class ChatMsg(val fromUser: Boolean, val text: String, val isError: Boolean = false)

class AiViewModel(app: Application) : AndroidViewModel(app) {
    val store = SecureStore(app)

    var hasKey by mutableStateOf(store.apiKey.isNotBlank())
        private set
    var docUri by mutableStateOf<Uri?>(null)
        private set
    var docName by mutableStateOf("")
        private set
    var busy by mutableStateOf(false)
        private set
    val messages = mutableStateListOf<ChatMsg>()

    private var docText: String? = null
    private val history = mutableListOf<Pair<String, String>>()

    fun refreshKey() {
        hasKey = store.apiKey.isNotBlank()
    }

    fun setDocument(uri: Uri, name: String) {
        if (uri == docUri) return
        docUri = uri
        docName = name
        docText = null
        messages.clear()
        history.clear()
    }

    fun clearDocument() {
        docUri = null
        docName = ""
        docText = null
        messages.clear()
        history.clear()
    }

    fun ask(display: String, instruction: String) {
        val uri = docUri ?: return
        if (busy) return
        messages.add(ChatMsg(true, display))
        busy = true
        viewModelScope.launch {
            try {
                if (docText == null) {
                    docText = try {
                        PdfText.extract(getApplication<Application>(), uri)
                    } catch (e: Exception) {
                        null
                    }
                }
                val text = docText
                if (text.isNullOrBlank()) {
                    messages.add(
                        ChatMsg(
                            false,
                            "I couldn't find readable text in this PDF. If it's a scan or password protected, support for that is coming in a later update.",
                            true
                        )
                    )
                    return@launch
                }
                val system = "You are the assistant inside a PDF app. Answer using only the document below. " +
                    "If the answer isn't in the document, say so. Be clear and concise, and mention page " +
                    "numbers only if the text makes them clear.\n\nDOCUMENT:\n" + text
                val contents = history.takeLast(10) + ("user" to instruction)
                when (val r = GeminiClient.generate(store.apiKey, store.model, system, contents)) {
                    is GeminiClient.Result.Ok -> {
                        history.add("user" to instruction)
                        history.add("model" to r.text)
                        messages.add(ChatMsg(false, cleanMarkdown(r.text)))
                    }
                    is GeminiClient.Result.Err -> messages.add(ChatMsg(false, r.message, true))
                }
            } finally {
                busy = false
            }
        }
    }
}

fun cleanMarkdown(s: String): String = s.lines().joinToString("\n") { line ->
    val l = line.trimEnd().replace("**", "").replace("__", "")
    val t = l.trimStart()
    if (t.startsWith("* ") || t.startsWith("- ")) "• " + t.drop(2)
    else if (t.startsWith("#")) t.trimStart('#').trim()
    else l
}
