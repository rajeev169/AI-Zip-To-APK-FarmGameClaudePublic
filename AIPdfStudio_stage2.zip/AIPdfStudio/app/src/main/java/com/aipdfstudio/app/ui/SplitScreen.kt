package com.aipdfstudio.app.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.lifecycle.viewmodel.compose.viewModel
import com.aipdfstudio.app.data.Outputs
import com.aipdfstudio.app.data.PdfOps

private enum class SplitMode { EXTRACT, EVERY, SINGLE }

@Composable
fun SplitScreen(onBack: () -> Unit, onOpen: (Uri) -> Unit, vm: ToolVm = viewModel()) {
    val ctx = LocalContext.current
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.addFiles(listOf(uri), replace = true)
    }
    var mode by rememberSaveable { mutableStateOf(SplitMode.EXTRACT) }
    var ranges by rememberSaveable { mutableStateOf("") }
    var every by rememberSaveable { mutableStateOf("2") }

    val p = vm.single
    val usable = p != null && !p.locked && !p.broken
    val pageCount = p?.pages ?: 0
    val everyN = every.toIntOrNull() ?: 0
    val parts = if (everyN > 0 && pageCount > 0) (pageCount + everyN - 1) / everyN else 0

    val label = when {
        !usable -> "Choose a PDF"
        mode == SplitMode.EXTRACT -> "Extract pages"
        mode == SplitMode.EVERY -> if (parts > 0) "Split into $parts files" else "Split"
        else -> "Split into $pageCount files"
    }

    ToolPage(
        title = "Split PDF",
        vm = vm,
        onBack = onBack,
        actionLabel = label,
        actionEnabled = usable && when (mode) {
            SplitMode.EXTRACT -> ranges.isNotBlank()
            SplitMode.EVERY -> everyN in 1 until pageCount
            SplitMode.SINGLE -> pageCount > 1
        },
        onAction = act@{
            val src = p ?: return@act
            when (mode) {
                SplitMode.EXTRACT -> vm.run("Extracting pages…") {
                    val r = PdfOps.parseRanges(ranges, src.pages)
                    val tag = ranges.replace(" ", "").replace(Regex("[^0-9,\\-]"), "").replace(',', '_').take(30)
                    val out = Outputs.newFile(ctx, src.name, "pages_$tag")
                    PdfOps.extract(ctx, src.uri, r, out)
                    listOf(out) to null
                }
                SplitMode.EVERY, SplitMode.SINGLE -> {
                    val n = if (mode == SplitMode.SINGLE) 1 else everyN
                    vm.run("Splitting…") { progress ->
                        val files = PdfOps.splitEvery(ctx, src.uri, n, { a, b ->
                            Outputs.newFile(ctx, src.name, if (a == b) "page_$a" else "pages_$a-$b")
                        }, progress)
                        files to null
                    }
                }
            }
        }
    ) {
        item(key = "file") { PickedCard(p, vm.loading) { picker.launch(arrayOf("application/pdf")) } }
        if (p != null && p.locked) {
            item(key = "locked") { MessageCard("This PDF is password protected. Unlock it first with the Unlock tool.", isError = true) }
        }
        if (usable) {
            item(key = "how") {
                Text("How do you want to split it?", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Medium)
            }
            item(key = "m1") {
                ChoiceRow("Pick pages", "Copy the pages you choose into one new PDF", mode == SplitMode.EXTRACT) { mode = SplitMode.EXTRACT }
            }
            item(key = "m2") {
                ChoiceRow("Split every few pages", "For example every 2 pages becomes one file", mode == SplitMode.EVERY) { mode = SplitMode.EVERY }
            }
            item(key = "m3") {
                ChoiceRow("One file per page", "Every page becomes its own PDF", mode == SplitMode.SINGLE) { mode = SplitMode.SINGLE }
            }
            when (mode) {
                SplitMode.EXTRACT -> item(key = "ranges") {
                    OutlinedTextField(
                        value = ranges,
                        onValueChange = { ranges = it; vm.clearOutcome() },
                        label = { Text("Pages (1 to $pageCount)") },
                        placeholder = { Text("e.g. 1-3, 5, 8-") },
                        supportingText = { Text("Use commas between parts. 8- means page 8 to the end.") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                SplitMode.EVERY -> item(key = "every") {
                    OutlinedTextField(
                        value = every,
                        onValueChange = { v -> every = v.filter { it.isDigit() }.take(4); vm.clearOutcome() },
                        label = { Text("Pages in each file") },
                        supportingText = {
                            Text(if (everyN >= pageCount) "Must be less than $pageCount" else "Makes $parts files")
                        },
                        isError = everyN >= pageCount,
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                SplitMode.SINGLE -> if (pageCount > 60) {
                    item(key = "many") { Hint("This will make $pageCount separate files.") }
                }
            }
        }
        outcome(vm, onOpen)
    }
}
