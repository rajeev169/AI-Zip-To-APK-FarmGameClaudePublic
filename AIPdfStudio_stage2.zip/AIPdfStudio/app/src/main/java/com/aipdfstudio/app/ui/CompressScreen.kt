package com.aipdfstudio.app.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.lifecycle.viewmodel.compose.viewModel
import com.aipdfstudio.app.data.CompressLevel
import com.aipdfstudio.app.data.Outputs
import com.aipdfstudio.app.data.PdfOps
import com.aipdfstudio.app.data.fmtSize

@Composable
fun CompressScreen(onBack: () -> Unit, onOpen: (Uri) -> Unit, vm: ToolVm = viewModel()) {
    val ctx = LocalContext.current
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.addFiles(listOf(uri), replace = true)
    }
    var level by rememberSaveable { mutableStateOf(CompressLevel.RECOMMENDED) }
    val p = vm.single
    val usable = p != null && !p.locked && !p.broken

    ToolPage(
        title = "Compress PDF",
        vm = vm,
        onBack = onBack,
        actionLabel = "Compress",
        actionEnabled = usable,
        onAction = act@{
            val src = p ?: return@act
            val chosen = level
            vm.run("Reading file…") { progress ->
                val before = if (src.size > 0) src.size else 0L
                val out = Outputs.newFile(ctx, src.name, "compressed")
                PdfOps.compress(ctx, src.uri, chosen, out, progress)
                val after = out.length()
                if (before > 0 && after >= before * 0.97) {
                    out.delete()
                    emptyList<java.io.File>() to
                        "This PDF is already well compressed, so it couldn't be made smaller. " +
                        "Mostly text files and already-optimised images don't shrink much."
                } else {
                    val msg = if (before > 0) {
                        val saved = ((before - after) * 100 / before).toInt()
                        "${fmtSize(before)} → ${fmtSize(after)} ($saved% smaller)"
                    } else "Compressed to ${fmtSize(after)}"
                    listOf(out) to msg
                }
            }
        }
    ) {
        item(key = "hint") {
            Hint("Shrinks photos and scanned images inside the PDF. Text stays sharp. Your original file is not changed.")
        }
        item(key = "file") { PickedCard(p, vm.loading) { picker.launch(arrayOf("application/pdf")) } }
        if (p != null && p.locked) {
            item(key = "locked") { MessageCard("This PDF is password protected. Unlock it first with the Unlock tool.", isError = true) }
        }
        if (usable) {
            item(key = "lvl") {
                Text("Compression level", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Medium)
            }
            CompressLevel.entries.forEach { l ->
                item(key = "lvl_" + l.name) {
                    ChoiceRow(l.label, l.sub, level == l) { level = l; vm.clearOutcome() }
                }
            }
        }
        outcome(vm, onOpen)
    }
}
