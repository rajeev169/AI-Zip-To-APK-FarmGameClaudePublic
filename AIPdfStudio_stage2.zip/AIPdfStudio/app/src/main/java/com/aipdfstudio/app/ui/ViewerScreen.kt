@file:OptIn(ExperimentalMaterial3Api::class)

package com.aipdfstudio.app.ui

import android.graphics.Bitmap
import android.graphics.Color as AColor
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.DarkMode
import androidx.compose.material.icons.outlined.ErrorOutline
import androidx.compose.material.icons.outlined.LightMode
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material.icons.outlined.ZoomIn
import androidx.compose.material.icons.outlined.ZoomOut
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.aipdfstudio.app.data.Outputs
import com.aipdfstudio.app.data.RecentFile
import com.aipdfstudio.app.data.RecentStore
import com.aipdfstudio.app.data.queryName
import com.aipdfstudio.app.data.querySize
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.IOException

private class PdfDoc(val renderer: PdfRenderer, val pfd: ParcelFileDescriptor, val pages: Int) {
    val lock = Any()
    @Volatile var closed = false

    fun close() {
        synchronized(lock) {
            if (!closed) {
                closed = true
                try { renderer.close() } catch (ignored: Exception) {}
                try { pfd.close() } catch (ignored: Exception) {}
            }
        }
    }
}

private val InvertFilter = ColorFilter.colorMatrix(
    ColorMatrix(
        floatArrayOf(
            -1f, 0f, 0f, 0f, 255f,
            0f, -1f, 0f, 0f, 255f,
            0f, 0f, -1f, 0f, 255f,
            0f, 0f, 0f, 1f, 0f
        )
    )
)

private fun renderPage(doc: PdfDoc, index: Int, widthPx: Int): Bitmap? = synchronized(doc.lock) {
    if (doc.closed) return null
    val page = doc.renderer.openPage(index)
    try {
        val h = (widthPx.toFloat() * page.height / page.width).toInt().coerceAtLeast(1)
        val bmp = Bitmap.createBitmap(widthPx, h, Bitmap.Config.ARGB_8888)
        bmp.eraseColor(AColor.WHITE)
        page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
        bmp
    } finally {
        page.close()
    }
}

@Composable
fun ViewerScreen(uri: Uri, recents: RecentStore, onBack: () -> Unit, onAskAi: (String) -> Unit) {
    val ctx = LocalContext.current
    val name = remember(uri) { queryName(ctx, uri) }
    val size = remember(uri) { querySize(ctx, uri) }
    var doc by remember { mutableStateOf<PdfDoc?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var night by remember { mutableStateOf(false) }
    var zoomIdx by remember { mutableIntStateOf(0) }
    val listState = rememberLazyListState()

    LaunchedEffect(uri) {
        val result: Any = withContext(Dispatchers.IO) {
            try {
                val pfd = ctx.contentResolver.openFileDescriptor(uri, "r") ?: throw IOException("open failed")
                try {
                    val r = PdfRenderer(pfd)
                    PdfDoc(r, pfd, r.pageCount)
                } catch (e: Exception) {
                    pfd.close()
                    throw e
                }
            } catch (e: SecurityException) {
                "This PDF is password protected. Use Tools → Unlock to make a copy without the password."
            } catch (e: Exception) {
                "Couldn't open this file. It may be damaged or not a PDF."
            }
        }
        if (result is PdfDoc) {
            doc = result
            val last = recents.find(uri.toString())?.lastPage ?: 0
            recents.upsert(RecentFile(uri.toString(), name, result.pages, last, System.currentTimeMillis(), size))
            if (last in 0 until result.pages) listState.scrollToItem(last)
        } else {
            error = result as String
        }
    }

    DisposableEffect(uri) {
        onDispose {
            val d = doc
            if (d != null) {
                recents.upsert(
                    RecentFile(uri.toString(), name, d.pages, listState.firstVisibleItemIndex, System.currentTimeMillis(), size)
                )
                d.close()
            }
        }
    }

    val cfg = LocalConfiguration.current
    val density = LocalDensity.current
    val zoom = listOf(1f, 1.5f, 2f)[zoomIdx]
    val pageWidthDp = (cfg.screenWidthDp * zoom).dp
    val pageWidthPx = with(density) { pageWidthDp.roundToPx() }.coerceAtMost(2600)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { if (zoomIdx > 0) zoomIdx-- }) {
                        Icon(Icons.Outlined.ZoomOut, contentDescription = "Zoom out")
                    }
                    IconButton(onClick = { if (zoomIdx < 2) zoomIdx++ }) {
                        Icon(Icons.Outlined.ZoomIn, contentDescription = "Zoom in")
                    }
                    IconButton(onClick = { night = !night }) {
                        Icon(
                            if (night) Icons.Outlined.LightMode else Icons.Outlined.DarkMode,
                            contentDescription = "Night mode"
                        )
                    }
                    IconButton(onClick = {
                        try {
                            Outputs.shareUri(ctx, uri, name)
                        } catch (e: Exception) {
                            android.widget.Toast.makeText(ctx, "No app available to share with", android.widget.Toast.LENGTH_SHORT).show()
                        }
                    }) {
                        Icon(Icons.Outlined.Share, contentDescription = "Share")
                    }
                    IconButton(onClick = { onAskAi(name) }) {
                        Icon(Icons.Outlined.AutoAwesome, contentDescription = "Ask AI about this PDF")
                    }
                }
            )
        }
    ) { pad ->
        Box(
            Modifier.fillMaxSize().padding(pad)
                .background(MaterialTheme.colorScheme.surfaceContainerHigh)
        ) {
            val d = doc
            val err = error
            when {
                err != null -> Column(
                    Modifier.fillMaxSize().padding(32.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(Icons.Outlined.ErrorOutline, contentDescription = null, modifier = Modifier.size(40.dp), tint = MaterialTheme.colorScheme.error)
                    Text(err, textAlign = TextAlign.Center, modifier = Modifier.padding(vertical = 16.dp))
                    Button(onClick = onBack) { Text("Go back") }
                }
                d == null -> CircularProgressIndicator(Modifier.align(Alignment.Center))
                else -> {
                    Box(Modifier.fillMaxSize().horizontalScroll(rememberScrollState())) {
                        LazyColumn(
                            state = listState,
                            modifier = Modifier.width(pageWidthDp).fillMaxHeight(),
                            contentPadding = PaddingValues(vertical = 8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(d.pages) { index -> PageItem(d, index, pageWidthPx, night) }
                        }
                    }
                    val current by remember { derivedStateOf { listState.firstVisibleItemIndex + 1 } }
                    Surface(
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.surfaceContainerHighest,
                        modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 16.dp)
                    ) {
                        Text(
                            "$current / ${d.pages}",
                            style = MaterialTheme.typography.labelLarge,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun PageItem(doc: PdfDoc, index: Int, widthPx: Int, night: Boolean) {
    var bmp by remember(doc, index, widthPx) { mutableStateOf<Bitmap?>(null) }
    LaunchedEffect(doc, index, widthPx) {
        bmp = withContext(Dispatchers.IO) { renderPage(doc, index, widthPx) }
    }
    val b = bmp
    if (b == null) {
        Box(
            Modifier.fillMaxWidth().aspectRatio(0.707f).background(Color.White),
            contentAlignment = Alignment.Center
        ) { CircularProgressIndicator(strokeWidth = 2.dp, modifier = Modifier.size(24.dp)) }
    } else {
        Image(
            bitmap = b.asImageBitmap(),
            contentDescription = "Page ${index + 1}",
            modifier = Modifier.fillMaxWidth(),
            contentScale = ContentScale.FillWidth,
            colorFilter = if (night) InvertFilter else null
        )
    }
}
