package com.aipdfstudio.app.ui

import android.graphics.Bitmap
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.automirrored.outlined.ArrowForward
import androidx.compose.material.icons.automirrored.outlined.Undo
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.RotateLeft
import androidx.compose.material.icons.outlined.RotateRight
import androidx.compose.material.icons.outlined.SelectAll
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.aipdfstudio.app.data.Outputs
import com.aipdfstudio.app.data.PageEdit
import com.aipdfstudio.app.data.PdfOps
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun PagesScreen(onBack: () -> Unit, onOpen: (Uri) -> Unit, vm: ToolVm = viewModel()) {
    val ctx = LocalContext.current
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.addFiles(listOf(uri), replace = true, forPages = true)
    }
    val p = vm.single
    val usable = p != null && !p.locked && !p.broken && vm.pages.isNotEmpty()
    val sel = vm.selected.size

    ToolPage(
        title = "Page tools",
        vm = vm,
        onBack = onBack,
        actionLabel = if (usable) "Save as new PDF" else null,
        actionEnabled = vm.changed,
        onAction = act@{
            val src = p ?: return@act
            val edits = vm.pages.toList()
            vm.run("Saving ${edits.size} pages…") {
                val out = Outputs.newFile(ctx, src.name, "edited")
                PdfOps.organize(ctx, src.uri, edits, out)
                listOf(out) to null
            }
        },
        topActions = {
            if (usable) {
                IconButton(onClick = { vm.undo() }, enabled = vm.canUndo) {
                    Icon(Icons.AutoMirrored.Outlined.Undo, contentDescription = "Undo")
                }
                IconButton(onClick = { if (sel == vm.pages.size) vm.clearSelection() else vm.selectAll() }) {
                    Icon(Icons.Outlined.SelectAll, contentDescription = "Select all")
                }
            }
        },
        bottomExtra = {
            if (usable) {
                Column {
                    Text(
                        when (sel) {
                            0 -> "Tap pages to select them"
                            1 -> "1 page selected"
                            else -> "$sel pages selected"
                        },
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        BarButton(Icons.Outlined.RotateLeft, "Left", sel > 0) { vm.rotateSelected(-90) }
                        BarButton(Icons.Outlined.RotateRight, "Right", sel > 0) { vm.rotateSelected(90) }
                        BarButton(Icons.AutoMirrored.Outlined.ArrowBack, "Earlier", sel == 1) { vm.moveSelected(-1) }
                        BarButton(Icons.AutoMirrored.Outlined.ArrowForward, "Later", sel == 1) { vm.moveSelected(1) }
                        BarButton(Icons.Outlined.Delete, "Delete", sel > 0) { vm.deleteSelected() }
                    }
                }
            }
        }
    ) {
        item(key = "file") { PickedCard(p, vm.loading) { picker.launch(arrayOf("application/pdf")) } }
        if (p == null) {
            item(key = "hint") { Hint("Rotate, delete and reorder pages. Your original file is never changed.") }
        } else if (p.locked) {
            item(key = "locked") { MessageCard("This PDF is password protected. Unlock it first with the Unlock tool.", isError = true) }
        }
        if (usable) {
            item(key = "summary") {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "${vm.pages.size} of ${p?.pages ?: 0} pages",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.weight(1f)
                    )
                    if (vm.changed) TextButton(onClick = { vm.resetPages() }) { Text("Reset") }
                }
            }
            val rows = vm.pages.toList().withIndex().chunked(3)
            rows.forEach { row ->
                item(key = "row_" + row.first().value.src) {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        row.forEach { (pos, e) ->
                            Box(Modifier.weight(1f)) {
                                PageThumb(vm, e, pos + 1, vm.selected.contains(e.src)) { vm.toggle(e.src) }
                            }
                        }
                        repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
                    }
                }
            }
        }
        outcome(vm, onOpen)
    }
}

@Composable
private fun BarButton(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, enabled: Boolean, onClick: () -> Unit) {
    TextButton(onClick = onClick, enabled = enabled, contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 6.dp)) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, contentDescription = null, modifier = Modifier.size(22.dp))
            Text(label, style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
private fun PageThumb(vm: ToolVm, e: PageEdit, position: Int, selected: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val thumbs = vm.thumbs
    var bmp by remember(thumbs, e.src) { mutableStateOf<Bitmap?>(null) }
    LaunchedEffect(thumbs, e.src) {
        bmp = withContext(Dispatchers.IO) { thumbs?.get(e.src) }
    }
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(14.dp),
        color = if (selected) cs.primaryContainer else cs.surfaceContainer,
        border = if (selected) BorderStroke(2.dp, cs.primary) else null,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.fillMaxWidth().aspectRatio(1f), contentAlignment = Alignment.Center) {
                val b = bmp
                if (b == null) {
                    CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                } else {
                    Image(
                        bitmap = b.asImageBitmap(),
                        contentDescription = "Page ${e.src + 1}",
                        contentScale = ContentScale.Fit,
                        modifier = Modifier.fillMaxSize().rotate(e.rot.toFloat())
                    )
                }
                if (selected) {
                    Icon(
                        Icons.Outlined.CheckCircle,
                        contentDescription = "Selected",
                        tint = cs.primary,
                        modifier = Modifier.align(Alignment.TopEnd).background(Color.White, CircleShape)
                    )
                }
            }
            Text(
                if (e.src + 1 == position) "$position" else "$position  (was ${e.src + 1})",
                style = MaterialTheme.typography.labelMedium,
                color = if (selected) cs.onPrimaryContainer else cs.onSurfaceVariant,
                modifier = Modifier.padding(top = 4.dp)
            )
        }
    }
}
