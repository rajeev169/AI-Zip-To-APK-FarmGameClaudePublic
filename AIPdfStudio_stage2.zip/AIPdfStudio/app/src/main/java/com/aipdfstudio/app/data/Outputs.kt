package com.aipdfstudio.app.data

import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.provider.DocumentsContract
import androidx.core.content.FileProvider
import java.io.File
import java.io.IOException

/** A PDF the user picked for a tool. pages: -1 = password protected, 0 = can't read. */
data class Picked(val uri: Uri, val name: String, val size: Long, val pages: Int) {
    val locked get() = pages < 0
    val broken get() = pages == 0
}

fun probePdf(ctx: Context, uri: Uri): Picked {
    val pages = try {
        val pfd = ctx.contentResolver.openFileDescriptor(uri, "r") ?: throw IOException()
        try {
            val r = PdfRenderer(pfd)
            val c = r.pageCount
            r.close()
            c
        } finally {
            try { pfd.close() } catch (ignored: Exception) {}
        }
    } catch (e: SecurityException) {
        -1
    } catch (e: Exception) {
        0
    }
    return Picked(uri, queryName(ctx, uri), querySize(ctx, uri), pages)
}

/** Files the tools create. They live in the app's private storage until the user saves or shares them. */
object Outputs {
    private const val MIME = "application/pdf"

    fun dir(ctx: Context): File = File(ctx.filesDir, "outputs").apply { mkdirs() }

    fun newFile(ctx: Context, sourceName: String, suffix: String): File {
        val base = sourceName
            .replace(Regex("\\.pdf$", RegexOption.IGNORE_CASE), "")
            .replace(Regex("[\\\\/:*?\"<>|]"), "_")
            .trim()
            .take(60)
            .ifBlank { "document" }
        val d = dir(ctx)
        var f = File(d, "${base}_$suffix.pdf")
        var n = 2
        while (f.exists()) {
            f = File(d, "${base}_${suffix}_$n.pdf")
            n++
        }
        return f
    }

    fun uri(ctx: Context, f: File): Uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f)

    fun share(ctx: Context, files: List<File>) {
        if (files.isEmpty()) return
        val uris = files.map { uri(ctx, it) }
        val send = if (uris.size == 1) {
            Intent(Intent.ACTION_SEND).putExtra(Intent.EXTRA_STREAM, uris[0])
        } else {
            Intent(Intent.ACTION_SEND_MULTIPLE).putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(uris))
        }
        send.type = MIME
        val clip = ClipData.newUri(ctx.contentResolver, files[0].name, uris[0])
        uris.drop(1).forEach { clip.addItem(ClipData.Item(it)) }
        send.clipData = clip
        send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        ctx.startActivity(
            Intent.createChooser(send, "Share PDF").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }

    /** Shares a file the user opened from elsewhere (used by the viewer). */
    fun shareUri(ctx: Context, uri: Uri, name: String) {
        val send = Intent(Intent.ACTION_SEND).putExtra(Intent.EXTRA_STREAM, uri)
        send.type = MIME
        send.clipData = ClipData.newUri(ctx.contentResolver, name, uri)
        send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        ctx.startActivity(Intent.createChooser(send, "Share PDF").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun copyTo(ctx: Context, f: File, dest: Uri) {
        val out = ctx.contentResolver.openOutputStream(dest, "w") ?: throw IOException("Can't write there")
        out.use { o -> f.inputStream().use { it.copyTo(o) } }
    }

    /** Saves every file into a folder the user picked. Returns how many were saved. */
    fun saveAllToFolder(ctx: Context, files: List<File>, tree: Uri): Int {
        val parent = DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree))
        var saved = 0
        files.forEach { f ->
            val doc = DocumentsContract.createDocument(ctx.contentResolver, parent, MIME, f.name)
                ?: throw IOException("Can't create file")
            copyTo(ctx, f, doc)
            saved++
        }
        return saved
    }
}
