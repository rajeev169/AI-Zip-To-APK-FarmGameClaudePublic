package com.aipdfstudio.app.ui

import android.app.Application
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color as AColor
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.util.LruCache
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.aipdfstudio.app.data.PageEdit
import com.aipdfstudio.app.data.PdfOps
import com.aipdfstudio.app.data.Picked
import com.aipdfstudio.app.data.probePdf
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/** Renders small page previews for the page tools screen. */
class Thumbs(private val ctx: Context, private val uri: Uri) {
    private var pfd: ParcelFileDescriptor? = null
    private var renderer: PdfRenderer? = null
    private var closed = false
    private val cache = LruCache<Int, Bitmap>(80)

    @Synchronized
    fun get(index: Int, widthPx: Int = 260): Bitmap? {
        cache.get(index)?.let { return it }
        if (closed) return null
        return try {
            val r = renderer ?: run {
                val p = ctx.contentResolver.openFileDescriptor(uri, "r") ?: return null
                pfd = p
                PdfRenderer(p).also { renderer = it }
            }
            val page = r.openPage(index)
            try {
                val h = (widthPx.toFloat() * page.height / page.width).toInt().coerceIn(1, widthPx * 3)
                val bmp = Bitmap.createBitmap(widthPx, h, Bitmap.Config.ARGB_8888)
                bmp.eraseColor(AColor.WHITE)
                page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                cache.put(index, bmp)
                bmp
            } finally {
                page.close()
            }
        } catch (e: Exception) {
            null
        }
    }

    @Synchronized
    fun close() {
        closed = true
        try { renderer?.close() } catch (ignored: Exception) {}
        try { pfd?.close() } catch (ignored: Exception) {}
        renderer = null
        pfd = null
    }
}

/**
 * State for one tool screen. Each screen gets its own instance, so it survives screen rotation
 * and returning from the viewer.
 */
class ToolVm(app: Application) : AndroidViewModel(app) {
    private val ctx: Context get() = getApplication<Application>()

    val files = mutableStateListOf<Picked>()
    var loading by mutableStateOf(false)
        private set
    var busy by mutableStateOf<String?>(null)
        private set
    var error by mutableStateOf<String?>(null)
    var results by mutableStateOf<List<File>>(emptyList())
        private set
    var note by mutableStateOf<String?>(null)
        private set

    // Page tools
    val pages = mutableStateListOf<PageEdit>()
    val selected = mutableStateListOf<Int>()
    private val history = ArrayDeque<List<PageEdit>>()
    var canUndo by mutableStateOf(false)
        private set
    var thumbs by mutableStateOf<Thumbs?>(null)
        private set

    val single: Picked? get() = files.firstOrNull()

    fun clearOutcome() {
        error = null
        note = null
        results = emptyList()
    }

    private fun keepAccess(uri: Uri) {
        try {
            ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (ignored: Exception) {
        }
    }

    /** Adds files. With [replace] the list is cleared first (single-file tools). */
    fun addFiles(uris: List<Uri>, replace: Boolean, forPages: Boolean = false) {
        if (uris.isEmpty() || loading) return
        clearOutcome()
        loading = true
        viewModelScope.launch {
            val got = withContext(Dispatchers.IO) { uris.map { keepAccess(it); probePdf(ctx, it) } }
            if (replace) files.clear()
            got.forEach { p -> if (files.none { it.uri == p.uri }) files.add(p) }
            loading = false
            if (forPages) setupPages()
        }
    }

    fun removeAt(i: Int) {
        if (i in files.indices) files.removeAt(i)
        clearOutcome()
    }

    fun move(i: Int, delta: Int) {
        val j = i + delta
        if (i !in files.indices || j !in files.indices) return
        val a = files[i]
        files[i] = files[j]
        files[j] = a
        clearOutcome()
    }

    /** Runs a tool job in the background. [job] returns the files it made and an optional note. */
    fun run(working: String, job: suspend (progress: (String) -> Unit) -> Pair<List<File>, String?>) {
        if (busy != null) return
        clearOutcome()
        busy = working
        viewModelScope.launch {
            try {
                val (made, msg) = withContext(Dispatchers.IO) {
                    job { text -> viewModelScope.launch { if (busy != null) busy = text } }
                }
                results = made
                note = msg
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                error = PdfOps.friendly(e)
            } finally {
                busy = null
            }
        }
    }

    // ---------- Page tools ----------

    private fun setupPages() {
        thumbs?.close()
        thumbs = null
        pages.clear()
        selected.clear()
        history.clear()
        canUndo = false
        val p = single ?: return
        if (p.pages <= 0) return
        pages.addAll((0 until p.pages).map { PageEdit(it) })
        thumbs = Thumbs(ctx, p.uri)
    }

    val changed: Boolean
        get() {
            val total = single?.pages ?: return false
            if (pages.size != total) return true
            return pages.withIndex().any { (i, e) -> e.src != i || e.rot != 0 }
        }

    private fun snapshot() {
        history.addLast(pages.toList())
        if (history.size > 40) history.removeFirst()
        canUndo = true
        clearOutcome()
    }

    fun toggle(src: Int) {
        if (selected.contains(src)) selected.remove(src) else selected.add(src)
    }

    fun selectAll() {
        selected.clear()
        selected.addAll(pages.map { it.src })
    }

    fun clearSelection() = selected.clear()

    fun rotateSelected(delta: Int) {
        if (selected.isEmpty()) return
        snapshot()
        for (i in pages.indices) {
            val e = pages[i]
            if (e.src in selected) pages[i] = e.copy(rot = ((e.rot + delta) % 360 + 360) % 360)
        }
    }

    fun deleteSelected() {
        if (selected.isEmpty()) return
        if (selected.size >= pages.size) {
            error = "You can't delete every page. Keep at least one."
            return
        }
        snapshot()
        pages.removeAll { it.src in selected }
        selected.clear()
    }

    fun moveSelected(delta: Int) {
        if (selected.size != 1) return
        val i = pages.indexOfFirst { it.src == selected[0] }
        val j = i + delta
        if (i < 0 || j !in pages.indices) return
        snapshot()
        val a = pages[i]
        pages[i] = pages[j]
        pages[j] = a
    }

    fun undo() {
        val last = history.removeLastOrNull() ?: return
        pages.clear()
        pages.addAll(last)
        selected.retainAll(last.map { it.src }.toSet())
        canUndo = history.isNotEmpty()
        clearOutcome()
    }

    fun resetPages() {
        if (!changed) return
        snapshot()
        val total = single?.pages ?: return
        pages.clear()
        pages.addAll((0 until total).map { PageEdit(it) })
        selected.clear()
    }

    override fun onCleared() {
        thumbs?.close()
        super.onCleared()
    }
}
