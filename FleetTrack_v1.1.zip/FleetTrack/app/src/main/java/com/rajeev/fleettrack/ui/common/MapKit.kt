package com.rajeev.fleettrack.ui.common

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.rajeev.fleettrack.data.VehicleStatus
import com.rajeev.fleettrack.ui.theme.AmberIdle
import com.rajeev.fleettrack.ui.theme.GreenOk
import com.rajeev.fleettrack.ui.theme.GreyOff
import com.rajeev.fleettrack.ui.theme.RedAlert
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.BoundingBox
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.CustomZoomButtonsController
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.CopyrightOverlay

val DEFAULT_CENTER = GeoPoint(25.5941, 85.1376) // Patna

/** OpenStreetMap view for Compose. [onUpdate] runs on every recomposition with fresh data. */
@Composable
fun OsmMap(modifier: Modifier = Modifier, onCreated: (MapView) -> Unit = {}, onUpdate: (MapView) -> Unit) {
    val ctx = LocalContext.current
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    val map = remember {
        MapView(ctx).apply {
            setTileSource(TileSourceFactory.MAPNIK)
            setMultiTouchControls(true)
            zoomController.setVisibility(CustomZoomButtonsController.Visibility.NEVER)
            isTilesScaledToDpi = true
            minZoomLevel = 4.0
            controller.setZoom(11.0)
            controller.setCenter(DEFAULT_CENTER)
            overlays.add(CopyrightOverlay(ctx))
            onCreated(this)
        }
    }
    DisposableEffect(lifecycle) {
        val obs = LifecycleEventObserver { _, e ->
            when (e) {
                Lifecycle.Event.ON_RESUME -> map.onResume()
                Lifecycle.Event.ON_PAUSE -> map.onPause()
                else -> {}
            }
        }
        lifecycle.addObserver(obs)
        map.onResume()
        onDispose {
            lifecycle.removeObserver(obs)
            map.onPause()
            map.onDetach()
        }
    }
    AndroidView(factory = { map }, modifier = modifier, update = { onUpdate(it) })
}

fun MapView.fitTo(points: List<GeoPoint>, paddingPx: Int = 120) {
    if (points.isEmpty()) return
    val doFit = {
        if (points.size == 1) {
            controller.setZoom(15.0)
            controller.animateTo(points[0])
        } else {
            val box = BoundingBox.fromGeoPointsSafe(points)
            // avoid zooming in too much when all points are at one spot
            if (box.latitudeSpan < 0.002 && box.longitudeSpanWithDateLine < 0.002) {
                controller.setZoom(16.0)
                controller.animateTo(box.centerWithDateLine)
            } else {
                zoomToBoundingBox(box, true, paddingPx)
            }
        }
    }
    if (width > 0 && height > 0) doFit() else addOnFirstLayoutListener { _, _, _, _, _ -> doFit() }
}

object MarkerIcons {
    private val cache = HashMap<String, Drawable>()

    fun color(status: VehicleStatus): Int = when (status) {
        VehicleStatus.MOVING -> GreenOk.toArgb()
        VehicleStatus.STOPPED -> AmberIdle.toArgb()
        VehicleStatus.OVERSPEED, VehicleStatus.GPS_OFF -> RedAlert.toArgb()
        VehicleStatus.OFFLINE, VehicleStatus.OFF_DUTY -> GreyOff.toArgb()
    }

    /** Round badge with the speed number and a small arrow showing direction. */
    fun vehicle(ctx: Context, status: VehicleStatus, speed: Int, bearing: Float, selected: Boolean): Drawable {
        val key = "${status.name}-$speed-${(bearing / 15).toInt()}-$selected"
        cache[key]?.let { return it }
        val d = ctx.resources.displayMetrics.density
        val size = (52 * d).toInt()
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val cx = size / 2f
        val r = size * 0.32f
        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = color(status) }
        val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = if (selected) 0xFF0D47A1.toInt() else 0xFFFFFFFF.toInt()
            style = Paint.Style.STROKE
            strokeWidth = (if (selected) 4f else 3f) * d
        }
        // direction arrow
        if (status == VehicleStatus.MOVING || status == VehicleStatus.OVERSPEED) {
            c.save()
            c.rotate(bearing, cx, cx)
            val p = Path().apply {
                moveTo(cx, cx - r - 9 * d)
                lineTo(cx - 7 * d, cx - r + 2 * d)
                lineTo(cx + 7 * d, cx - r + 2 * d)
                close()
            }
            c.drawPath(p, fill)
            c.restore()
        }
        c.drawCircle(cx, cx, r, fill)
        c.drawCircle(cx, cx, r, ring)
        val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xFFFFFFFF.toInt()
            textAlign = Paint.Align.CENTER
            typeface = Typeface.DEFAULT_BOLD
            textSize = (if (speed >= 100) 11f else 13f) * d
        }
        val label = if (status == VehicleStatus.OFFLINE || status == VehicleStatus.OFF_DUTY || status == VehicleStatus.GPS_OFF) "–" else speed.toString()
        c.drawText(label, cx, cx - (txt.descent() + txt.ascent()) / 2, txt)
        val dr = BitmapDrawable(ctx.resources, bmp)
        if (cache.size > 300) cache.clear()
        cache[key] = dr
        return dr
    }

    fun dot(ctx: Context, color: Int, sizeDp: Int = 18): Drawable {
        val d = ctx.resources.displayMetrics.density
        val size = (sizeDp * d).toInt()
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.drawCircle(size / 2f, size / 2f, size / 2f - 2 * d, Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color })
        c.drawCircle(size / 2f, size / 2f, size / 2f - 2 * d, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = 0xFFFFFFFF.toInt(); style = Paint.Style.STROKE; strokeWidth = 2.5f * d
        })
        return BitmapDrawable(ctx.resources, bmp)
    }
}
