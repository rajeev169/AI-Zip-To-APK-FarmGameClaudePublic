package com.rajeev.fleettrack.alerts

import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.google.firebase.firestore.DocumentChange
import com.google.firebase.firestore.ListenerRegistration
import com.rajeev.fleettrack.R
import com.rajeev.fleettrack.data.Alert
import com.rajeev.fleettrack.data.AlertType
import com.rajeev.fleettrack.data.Repo
import com.rajeev.fleettrack.data.toAlert
import com.rajeev.fleettrack.util.Notifs

/** Title + text shown for an alert, in the Alerts list and as a phone notification. */
object AlertText {
    fun title(a: Alert): String = when (a.type) {
        AlertType.SOS -> "SOS from ${a.driverName}"
        AlertType.OVERSPEED -> "Overspeed ${a.speed.toInt()} km/h"
        AlertType.GPS_OFF -> "${a.driverName}'s GPS is OFF"
        AlertType.GPS_ON -> "${a.driverName}'s location is back"
        AlertType.BATTERY_LOW -> "${a.driverName}'s battery low"
        AlertType.STALE -> "No update from ${a.driverName}"
        AlertType.NOT_STARTED -> "${a.driverName} has not started duty"
        AlertType.DUTY_START -> "${a.driverName} started duty"
        AlertType.DUTY_END -> "${a.driverName} ended duty"
        AlertType.FUEL -> "Fuel added"
        else -> a.type
    }

    fun text(a: Alert): String = when (a.type) {
        AlertType.OVERSPEED -> listOf(a.vehicleName, a.driverName).filter { it.isNotBlank() }.joinToString(" • ") + " • limit ${a.limit}"
        AlertType.DUTY_START -> a.vehicleName.ifBlank { a.message }
        else -> a.message.ifBlank { listOf(a.vehicleName, a.vehicleNumber).filter { it.isNotBlank() }.joinToString(" ") }
    }
}

object AlertWatcher {
    /** Listens for NEW alerts from now on and shows a phone notification for the important ones. */
    fun watch(ctx: Context, fleetId: String): ListenerRegistration {
        val since = System.currentTimeMillis()
        val app = ctx.applicationContext
        return Repo.alerts(fleetId).whereGreaterThan("at", since).addSnapshotListener { snap, _ ->
            snap?.documentChanges?.forEach { ch ->
                if (ch.type == DocumentChange.Type.ADDED) notifyAlert(app, ch.document.toAlert())
            }
        }
    }

    fun notifyAlert(ctx: Context, a: Alert) {
        if (a.type !in AlertType.IMPORTANT) return
        val title = if (a.type == AlertType.SOS) "🚨 " + AlertText.title(a) else AlertText.title(a)
        Notifs.showOnce(ctx, a.id, title, AlertText.text(a))
    }
}

object ManagerPrefs {
    private fun p(ctx: Context) = ctx.getSharedPreferences("manager", Context.MODE_PRIVATE)
    fun backgroundAlerts(ctx: Context) = p(ctx).getBoolean("bgAlerts", false)
    fun setBackgroundAlerts(ctx: Context, on: Boolean) = p(ctx).edit().putBoolean("bgAlerts", on).apply()
    fun fleetId(ctx: Context) = p(ctx).getString("fleetId", "") ?: ""
    fun setFleetId(ctx: Context, f: String) = p(ctx).edit().putString("fleetId", f).apply()
}

/** Optional: keeps listening for alerts on the manager phone even when the app is closed. */
class AlertService : Service() {

    companion object {
        var isRunning = false
            private set

        fun start(ctx: Context) {
            try {
                ContextCompat.startForegroundService(ctx, Intent(ctx, AlertService::class.java))
            } catch (_: Exception) {
            }
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, AlertService::class.java))
        }
    }

    private var reg: ListenerRegistration? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val fleetId = ManagerPrefs.fleetId(this)
        if (fleetId.isBlank() || !ManagerPrefs.backgroundAlerts(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        val n = NotificationCompat.Builder(this, Notifs.CH_SERVICE)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("Watching for fleet alerts")
            .setContentText("You'll be notified about SOS, overspeed, GPS off and more")
            .setOngoing(true)
            .setContentIntent(Notifs.openAppIntent(this))
            .build()
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                ServiceCompat.startForeground(this, 303, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            } else {
                startForeground(303, n)
            }
        } catch (_: Exception) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (reg == null) reg = AlertWatcher.watch(this, fleetId)
        isRunning = true
        return START_STICKY
    }

    override fun onDestroy() {
        reg?.remove()
        reg = null
        isRunning = false
        super.onDestroy()
    }
}
