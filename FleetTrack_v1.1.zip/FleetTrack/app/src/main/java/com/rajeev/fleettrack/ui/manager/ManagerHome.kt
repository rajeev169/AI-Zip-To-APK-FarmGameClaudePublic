package com.rajeev.fleettrack.ui.manager

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.core.content.ContextCompat
import com.google.firebase.firestore.Query
import com.rajeev.fleettrack.alerts.AlertService
import com.rajeev.fleettrack.alerts.AlertWatcher
import com.rajeev.fleettrack.alerts.ManagerCheckWorker
import com.rajeev.fleettrack.alerts.ManagerChecks
import com.rajeev.fleettrack.alerts.ManagerPrefs
import com.rajeev.fleettrack.data.AlertType
import com.rajeev.fleettrack.data.Repo
import com.rajeev.fleettrack.data.listen
import com.rajeev.fleettrack.data.toAlert
import com.rajeev.fleettrack.data.toDriver
import com.rajeev.fleettrack.data.toFleet
import com.rajeev.fleettrack.data.toLive
import com.rajeev.fleettrack.data.toVehicle
import com.rajeev.fleettrack.ui.theme.Navy

enum class ManagerTab(val title: String, val icon: ImageVector) {
    LIVE("Live", Icons.Filled.Map),
    HISTORY("Routes", Icons.Filled.History),
    REPORTS("Reports", Icons.Filled.Assessment),
    ALERTS("Alerts", Icons.Filled.Notifications),
    SETUP("Setup", Icons.Filled.Settings),
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ManagerHome(fleetId: String, onSignOut: () -> Unit) {
    val ctx = LocalContext.current
    var tab by rememberSaveable { mutableStateOf(ManagerTab.LIVE) }
    var historyVehicle by remember { mutableStateOf("") }
    var bgAlerts by remember { mutableStateOf(ManagerPrefs.backgroundAlerts(ctx)) }

    val fleet by remember(fleetId) { Repo.fleet(fleetId).listen { it.toFleet() } }.collectAsState(null)
    val vehicles by remember(fleetId) { Repo.vehicles(fleetId).listen { it.toVehicle() } }.collectAsState(emptyList())
    val drivers by remember(fleetId) { Repo.drivers(fleetId).listen { it.toDriver() } }.collectAsState(emptyList())
    val live by remember(fleetId) { Repo.live(fleetId).listen { it.toLive() } }.collectAsState(emptyList())
    val alerts by remember(fleetId) {
        Repo.alerts(fleetId).orderBy("at", Query.Direction.DESCENDING).limit(150).listen { it.toAlert() }
    }.collectAsState(emptyList())
    val unseen = alerts.count { !it.seen && it.type in AlertType.IMPORTANT }

    val notifPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(fleetId) {
        ManagerPrefs.setFleetId(ctx, fleetId)
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        if (ManagerPrefs.backgroundAlerts(ctx)) AlertService.start(ctx)
        ManagerCheckWorker.schedule(ctx)
        // while the app is open: check "no update" / duty reminder every minute
        while (true) {
            try {
                ManagerChecks.run(ctx, fleetId)
            } catch (_: Exception) {
            }
            kotlinx.coroutines.delay(60_000L)
        }
    }
    // While the app is open, show alert notifications here (unless the background listener does it)
    DisposableEffect(fleetId, bgAlerts) {
        val reg = if (!bgAlerts) AlertWatcher.watch(ctx, fleetId) else null
        onDispose { reg?.remove() }
    }

    val speedLimit = fleet?.speedLimit ?: 60

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(fleet?.name?.ifBlank { null } ?: "My Fleet", fontWeight = FontWeight.Bold)
                        Text(tab.title, style = androidx.compose.material3.MaterialTheme.typography.bodySmall, color = Color.White.copy(alpha = 0.8f))
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Navy, titleContentColor = Color.White)
            )
        },
        bottomBar = {
            NavigationBar {
                ManagerTab.entries.forEach { t ->
                    NavigationBarItem(
                        selected = tab == t,
                        onClick = { tab = t },
                        icon = {
                            if (t == ManagerTab.ALERTS && unseen > 0) {
                                BadgedBox(badge = { Badge { Text(if (unseen > 99) "99+" else unseen.toString()) } }) {
                                    Icon(t.icon, t.title)
                                }
                            } else Icon(t.icon, t.title)
                        },
                        label = { Text(t.title) }
                    )
                }
            }
        }
    ) { pad ->
        Box(
            Modifier
                .padding(pad)
                .fillMaxSize()
        ) {
            when (tab) {
                ManagerTab.LIVE -> LiveScreen(
                    live = live,
                    drivers = drivers,
                    hasSetup = vehicles.isNotEmpty() && drivers.isNotEmpty(),
                    onGoSetup = { tab = ManagerTab.SETUP },
                    onShowRoute = { vid -> historyVehicle = vid; tab = ManagerTab.HISTORY },
                )
                ManagerTab.HISTORY -> HistoryScreen(fleetId, vehicles, speedLimit, historyVehicle)
                ManagerTab.REPORTS -> ReportsScreen(fleetId, fleet?.name ?: "My Fleet", vehicles)
                ManagerTab.ALERTS -> AlertsScreen(fleetId, alerts)
                ManagerTab.SETUP -> SetupScreen(
                    fleetId = fleetId, fleet = fleet, drivers = drivers, vehicles = vehicles,
                    bgAlerts = bgAlerts,
                    onBgAlerts = { on ->
                        bgAlerts = on
                        ManagerPrefs.setBackgroundAlerts(ctx, on)
                        if (on) AlertService.start(ctx) else AlertService.stop(ctx)
                    },
                    onSignOut = {
                        AlertService.stop(ctx)
                        ManagerCheckWorker.cancel(ctx)
                        onSignOut()
                    }
                )
            }
        }
    }
}
