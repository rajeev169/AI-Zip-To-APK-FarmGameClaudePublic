package com.rajeev.fleettrack.tracking

import android.annotation.SuppressLint
import android.app.Notification
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.location.Location
import android.location.LocationManager
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.SetOptions
import com.rajeev.fleettrack.R
import com.rajeev.fleettrack.data.AlertType
import com.rajeev.fleettrack.data.Repo
import com.rajeev.fleettrack.data.toVehicle
import com.rajeev.fleettrack.util.Fmt
import com.rajeev.fleettrack.util.Notifs
import java.util.Locale
import kotlin.math.max

/**
 * Runs on the driver phone and shares location with the manager.
 *
 * Duty mode   : runs between Start Duty and Stop Duty, one trip per duty.
 * Always-on   : runs 24h (restarts after reboot), one trip per day created automatically
 *               when the vehicle first moves; GPS slows down while parked to save battery.
 *
 * Both modes: live position + speed, route history, overspeed / GPS off / low battery alerts.
 */
class TrackingService : Service() {

    companion object {
        private const val ACTION_START = "start"
        private const val ACTION_STOP = "stop"
        private const val NOTIF_ID = 101
        private const val MOVING_KMH = 3.0
        private const val SLOW_AFTER_STOP_MS = 3 * 60_000L
        private const val HEARTBEAT_MS = 5 * 60_000L

        @Volatile
        var isRunning = false
            private set

        fun start(ctx: Context, cfg: DutyConfig) {
            DutyPrefs.saveConfig(ctx, cfg)
            ContextCompat.startForegroundService(ctx, Intent(ctx, TrackingService::class.java).setAction(ACTION_START))
        }

        /** Restart tracking (app reopened, phone restarted, watchdog) keeping the same trip. */
        fun resume(ctx: Context) {
            if (!DutyPrefs.isActive(ctx) || isRunning) return
            try {
                ContextCompat.startForegroundService(ctx, Intent(ctx, TrackingService::class.java).setAction(ACTION_START))
            } catch (_: Exception) {
                // Android may refuse a background start; the watchdog / app open will try again.
            }
        }

        fun stop(ctx: Context) {
            if (isRunning) {
                ctx.startService(Intent(ctx, TrackingService::class.java).setAction(ACTION_STOP))
            } else {
                // Service is not running (e.g. GPS permission was removed): close the duty directly.
                val c = DutyPrefs.config(ctx)
                val p = DutyPrefs.progress(ctx)
                if (c != null) {
                    val now = System.currentTimeMillis()
                    if (p.tripId.isNotBlank()) {
                        Repo.trips(c.fleetId).document(p.tripId)
                            .set(mapOf("active" to false, "endAt" to now), SetOptions.merge())
                    }
                    Repo.live(c.fleetId).document(c.email).set(
                        mapOf("onDuty" to false, "speed" to 0.0, "overspeed" to false, "updatedAt" to now, "alwaysOn" to false),
                        SetOptions.merge()
                    )
                }
                DutyPrefs.clear(ctx)
                TrackingState.set(TrackingUi())
            }
        }

        fun alwaysOnTripId(email: String, day: String) =
            "ao_" + email.replace(Regex("[^A-Za-z0-9]"), "_") + "_" + day
    }

    private lateinit var fused: FusedLocationProviderClient
    private val main = Handler(Looper.getMainLooper())
    private var cfg: DutyConfig? = null
    private var progress = DutyProgress()
    private var speedLimit = 60
    private var running = false

    private var fastMode = true
    private var lastAccepted: Location? = null
    private val buffer = mutableListOf<Map<String, Any>>()
    private var lastBufferedLoc: Location? = null
    private var lastBufferedAt = 0L
    private var lastFlushAt = 0L
    private var lastLiveWriteAt = 0L
    private var lastLiveOverspeed = false
    private var lastLiveMoving = false
    private var lastMovingAt = 0L
    private var stoppedSince = 0L
    private var overReadings = 0
    private var lastOverAlertAt = 0L
    private var lastLoc: Location? = null
    private var gpsOff = false
    private var limitReg: ListenerRegistration? = null
    private var driverReg: ListenerRegistration? = null
    private var wakeLock: PowerManager.WakeLock? = null

    private val callback = object : LocationCallback() {
        override fun onLocationResult(result: LocationResult) {
            result.lastLocation?.let { onLocation(it) }
        }
    }

    private val gpsReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            checkGps(false)
        }
    }

    private val heartbeat = object : Runnable {
        override fun run() {
            if (!running) return
            val now = System.currentTimeMillis()
            if (now - lastLiveWriteAt >= HEARTBEAT_MS - 5_000) writeHeartbeat(now)
            checkBattery()
            main.postDelayed(this, 60_000L)
        }
    }

    private val prefs by lazy { getSharedPreferences("tracking_flags", Context.MODE_PRIVATE) }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        fused = LocationServices.getFusedLocationProviderClient(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            endDuty()
            return START_NOT_STICKY
        }
        if (running) return START_STICKY

        val c = DutyPrefs.config(this)
        if (c == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        cfg = c
        speedLimit = c.speedLimit

        try {
            ServiceCompat.startForeground(
                this, NOTIF_ID, buildNotification("Starting GPS…"),
                ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION
            )
        } catch (e: Exception) {
            // Location permission missing or Android blocked a background start — cannot track now.
            stopSelf()
            return START_NOT_STICKY
        }
        running = true
        isRunning = true

        val now = System.currentTimeMillis()
        val saved = DutyPrefs.progress(this)
        if (c.alwaysOn) {
            // Continue today's automatic trip if there is one; a new trip starts on first movement.
            progress = if (saved.tripId == alwaysOnTripId(c.email, Fmt.dayKey(now))) saved else DutyProgress()
            DutyPrefs.saveProgress(this, progress)
        } else if (saved.tripId.isNotBlank()) {
            progress = saved // resume the same duty
        } else {
            val tripRef = Repo.trips(c.fleetId).document()
            progress = DutyProgress(tripId = tripRef.id, startAt = now)
            DutyPrefs.saveProgress(this, progress)
            tripRef.set(tripStartMap(c, now))
            Repo.alerts(c.fleetId).add(
                alertMap(c, AlertType.DUTY_START, 0.0, 0.0, 0.0, "${c.driverName} started duty on ${c.vehicleName}")
            )
        }
        lastFlushAt = now
        lastMovingAt = progress.startAt

        TrackingState.set(
            TrackingUi(
                running = true, vehicleLabel = vehicleLabel(c), startAt = progress.startAt,
                distanceKm = progress.distanceM / 1000.0, maxSpeed = progress.maxSpeed, speedLimit = speedLimit,
                alwaysOn = c.alwaysOn,
            )
        )

        // Show the driver on the manager's map right away, even before the first GPS fix
        Repo.live(c.fleetId).document(c.email).set(
            liveIdentity(c) + mapOf(
                "onDuty" to true, "alwaysOn" to c.alwaysOn, "tripId" to progress.tripId,
                "dutyStart" to (if (c.alwaysOn) 0L else progress.startAt),
                "tripKm" to progress.distanceM / 1000.0,
                "updatedAt" to now, "battery" to battery().first,
            ),
            SetOptions.merge()
        )
        lastLiveWriteAt = now

        // Follow speed-limit changes made by the manager
        limitReg = Repo.fleet(c.fleetId).addSnapshotListener { snap, _ ->
            val l = (snap?.get("speedLimit") as? Number)?.toInt()
            if (l != null && l > 0) {
                speedLimit = l
                TrackingState.update { it.copy(speedLimit = l) }
            }
        }
        // Always-on: follow the manager switching it off or changing the vehicle
        if (c.alwaysOn) {
            driverReg = Repo.drivers(c.fleetId).document(c.email).addSnapshotListener { snap, err ->
                if (err != null || snap == null) return@addSnapshotListener
                val on = snap.exists() && snap.getBoolean("alwaysOn") == true
                if (!on) {
                    endDuty()
                    return@addSnapshotListener
                }
                val vId = snap.getString("vehicleId") ?: ""
                val name = snap.getString("name") ?: c.driverName
                val phone = snap.getString("phone") ?: c.driverPhone
                if (vId != cfg?.vehicleId || name != cfg?.driverName || phone != cfg?.driverPhone) updateVehicle(vId, name, phone)
            }
        }

        try {
            registerReceiver(gpsReceiver, IntentFilter(LocationManager.PROVIDERS_CHANGED_ACTION))
        } catch (_: Exception) {
        }
        checkGps(true)
        main.postDelayed(heartbeat, 60_000L)

        // Duty mode keeps the CPU awake for the work day; always-on relies on the
        // foreground service + location callbacks so it does not drain the battery.
        if (!c.alwaysOn) acquireWakeLock()
        startGps(fast = true)
        return START_STICKY
    }

    @SuppressLint("MissingPermission")
    private fun startGps(fast: Boolean) {
        fastMode = fast
        val req = if (fast) {
            LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 5_000L)
                .setMinUpdateIntervalMillis(3_000L)
                .setWaitForAccurateLocation(false)
                .build()
        } else {
            // Parked: one balanced-accuracy fix per minute — wakes up to fast mode when moving again
            LocationRequest.Builder(Priority.PRIORITY_BALANCED_POWER_ACCURACY, 60_000L)
                .setMinUpdateIntervalMillis(30_000L)
                .build()
        }
        try {
            fused.removeLocationUpdates(callback)
            fused.requestLocationUpdates(req, callback, Looper.getMainLooper())
        } catch (_: SecurityException) {
            endDuty()
        }
    }

    private fun onLocation(loc: Location) {
        val c = cfg ?: return
        val now = System.currentTimeMillis()
        lastLoc = loc
        val acc = if (loc.hasAccuracy()) loc.accuracy.toDouble() else 50.0
        if (acc > (if (fastMode) 80.0 else 150.0)) {
            TrackingState.update { it.copy(waitingForGps = true, accuracy = acc) }
            return
        }

        // ---- always-on: new day -> close yesterday's trip ----
        if (c.alwaysOn && progress.tripId.isNotBlank() && progress.tripId != alwaysOnTripId(c.email, Fmt.dayKey(now))) {
            flush()
            Repo.trips(c.fleetId).document(progress.tripId).set(mapOf("active" to false), SetOptions.merge())
            progress = DutyProgress()
            DutyPrefs.saveProgress(this, progress)
        }

        // ---- speed ----
        var kmh = if (loc.hasSpeed()) loc.speed * 3.6 else -1.0
        val prev = lastAccepted
        var moved = 0.0
        if (prev == null) {
            lastAccepted = loc
            if (kmh < 0) kmh = 0.0
        } else {
            val d = prev.distanceTo(loc).toDouble()
            val dtSec = max(1L, loc.time - prev.time) / 1000.0
            val calcKmh = d / dtSec * 3.6
            // in parked (low-power) mode there is often no speed: treat a real jump as movement
            if (kmh < 0) kmh = if (fastMode || d > max(150.0, acc * 1.5)) calcKmh else 0.0
            // ignore GPS jitter while standing still and impossible jumps
            if (d >= max(10.0, acc) && calcKmh < 180) {
                moved = d
                lastAccepted = loc
            } else if (calcKmh >= 180) {
                lastAccepted = loc
            }
        }
        if (kmh < 2.0) kmh = 0.0
        val moving = kmh >= MOVING_KMH

        // ---- always-on: start today's trip on first movement ----
        if (c.alwaysOn && moving && progress.tripId.isBlank()) {
            val id = alwaysOnTripId(c.email, Fmt.dayKey(now))
            progress = DutyProgress(tripId = id, startAt = now)
            DutyPrefs.saveProgress(this, progress)
            Repo.trips(c.fleetId).document(id).set(tripStartMap(c, now), SetOptions.merge())
            TrackingState.update { it.copy(startAt = now) }
        }
        val hasTrip = progress.tripId.isNotBlank()
        if (hasTrip && moved > 0) progress = progress.copy(distanceM = progress.distanceM + moved)
        if (hasTrip && kmh > progress.maxSpeed) progress = progress.copy(maxSpeed = kmh)

        // ---- stopped / smart GPS ----
        if (moving) {
            stoppedSince = 0L
            lastMovingAt = now
            if (!fastMode) startGps(fast = true)
        } else {
            if (stoppedSince == 0L) stoppedSince = now
            if (c.alwaysOn && fastMode && now - stoppedSince > SLOW_AFTER_STOP_MS) startGps(fast = false)
        }

        // ---- overspeed ----
        val over = kmh > speedLimit
        if (over) {
            overReadings++
            if (overReadings >= 2 && now - lastOverAlertAt > 120_000) {
                lastOverAlertAt = now
                progress = progress.copy(overspeedCount = progress.overspeedCount + 1)
                Repo.alerts(c.fleetId).add(
                    alertMap(
                        c, AlertType.OVERSPEED, kmh, loc.latitude, loc.longitude,
                        "${c.vehicleName} • ${c.driverName} • limit $speedLimit"
                    )
                )
                Notifs.show(
                    this, Notifs.CH_DRIVER_WARN, 202, "Slow down!",
                    "You are driving at ${kmh.toInt()} km/h. Speed limit is $speedLimit km/h."
                )
            }
        } else {
            overReadings = 0
        }
        val overspeedNow = overReadings >= 2

        // ---- route points (buffered) ----
        if (hasTrip) {
            val lb = lastBufferedLoc
            val gap = if (moving) 60_000L else 5 * 60_000L
            if (lb == null || (moving && lb.distanceTo(loc) >= 15) || now - lastBufferedAt >= gap) {
                buffer.add(
                    mapOf(
                        "a" to loc.latitude, "o" to loc.longitude,
                        "s" to (Math.round(kmh * 10) / 10.0), "t" to now
                    )
                )
                lastBufferedLoc = loc
                lastBufferedAt = now
            }
        }
        if (buffer.size >= 80 || now - lastFlushAt >= 120_000) flush()

        // ---- live position (throttled to save Firestore writes) ----
        val interval = when {
            moving -> 10_000L
            c.alwaysOn -> HEARTBEAT_MS
            else -> 60_000L
        }
        if (now - lastLiveWriteAt >= interval || overspeedNow != lastLiveOverspeed || moving != lastLiveMoving) {
            lastLiveWriteAt = now
            lastLiveOverspeed = overspeedNow
            lastLiveMoving = moving
            Repo.live(c.fleetId).document(c.email).set(
                liveIdentity(c) + mapOf(
                    "lat" to loc.latitude, "lng" to loc.longitude,
                    "speed" to (Math.round(kmh * 10) / 10.0),
                    "bearing" to (if (loc.hasBearing()) loc.bearing.toDouble() else 0.0),
                    "accuracy" to acc, "battery" to battery().first,
                    "onDuty" to true, "alwaysOn" to c.alwaysOn, "gpsOff" to false,
                    "updatedAt" to now, "stoppedSince" to stoppedSince,
                    "tripId" to progress.tripId, "tripKm" to progress.distanceM / 1000.0,
                    "overspeed" to overspeedNow, "dutyStart" to (if (c.alwaysOn) 0L else progress.startAt),
                ),
                SetOptions.merge()
            )
            updateNotification(kmh)
            TrackingState.update { it.copy(lastSentAt = now) }
        }

        TrackingState.update {
            it.copy(
                speed = kmh, distanceKm = progress.distanceM / 1000.0, maxSpeed = progress.maxSpeed,
                lastFixAt = now, accuracy = acc, lat = loc.latitude, lng = loc.longitude,
                overspeed = over, speedLimit = speedLimit, waitingForGps = false, gpsOff = false,
            )
        }
    }

    private fun flush() {
        val c = cfg ?: return
        lastFlushAt = System.currentTimeMillis()
        if (progress.tripId.isBlank()) {
            buffer.clear()
            return
        }
        val tripRef = Repo.trips(c.fleetId).document(progress.tripId)
        if (buffer.isNotEmpty()) {
            val idx = progress.chunkIndex
            tripRef.collection("chunks").document(String.format(Locale.US, "%05d", idx))
                .set(mapOf("i" to idx, "pts" to buffer.toList()))
            buffer.clear()
            progress = progress.copy(chunkIndex = idx + 1)
        }
        tripRef.set(
            mapOf(
                "distanceKm" to Math.round(progress.distanceM / 100.0) / 10.0,
                "maxSpeed" to Math.round(progress.maxSpeed * 10) / 10.0,
                "overspeedCount" to progress.overspeedCount,
                // always-on: "duty time" = first to last movement of the day
                "endAt" to (if (c.alwaysOn) max(lastMovingAt, progress.startAt) else lastFlushAt),
            ),
            SetOptions.merge()
        )
        DutyPrefs.saveProgress(this, progress)
    }

    /** Keeps the manager's map fresh while parked / indoors without a GPS fix. */
    private fun writeHeartbeat(now: Long) {
        val c = cfg ?: return
        lastLiveWriteAt = now
        Repo.live(c.fleetId).document(c.email).set(
            mapOf(
                "updatedAt" to now, "battery" to battery().first, "onDuty" to true,
                "alwaysOn" to c.alwaysOn, "gpsOff" to gpsOff,
                "speed" to (if (stoppedSince > 0 || gpsOff) 0.0 else TrackingState.ui.value.speed),
            ),
            SetOptions.merge()
        )
        TrackingState.update { it.copy(lastSentAt = now) }
    }

    private fun checkGps(initial: Boolean) {
        val c = cfg ?: return
        val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val enabled = if (Build.VERSION.SDK_INT >= 28) lm.isLocationEnabled
        else lm.isProviderEnabled(LocationManager.GPS_PROVIDER) || lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)
        val off = !enabled
        if (!initial && off == gpsOff) return
        gpsOff = off
        TrackingState.update { it.copy(gpsOff = off) }
        val now = System.currentTimeMillis()
        Repo.live(c.fleetId).document(c.email).set(
            mapOf("gpsOff" to off, "updatedAt" to now, "speed" to 0.0), SetOptions.merge()
        )
        lastLiveWriteAt = now
        // alert only when the state really changed since the last alert (survives restarts)
        val lastAlerted = prefs.getBoolean("gpsOffAlerted", false)
        if (off && !lastAlerted) {
            prefs.edit().putBoolean("gpsOffAlerted", true).apply()
            Repo.alerts(c.fleetId).add(
                alertMap(c, AlertType.GPS_OFF, 0.0, lastLoc?.latitude ?: 0.0, lastLoc?.longitude ?: 0.0, "Location turned off on ${c.driverName}'s phone")
            )
        } else if (!off && lastAlerted) {
            prefs.edit().putBoolean("gpsOffAlerted", false).apply()
            Repo.alerts(c.fleetId).add(alertMap(c, AlertType.GPS_ON, 0.0, 0.0, 0.0, "GPS turned on again"))
        }
        if (!off) updateNotification(TrackingState.ui.value.speed)
        else updateNotificationText("GPS is OFF — please turn on Location")
    }

    private fun checkBattery() {
        val c = cfg ?: return
        val (level, charging) = battery()
        if (level < 0) return
        val alerted = prefs.getBoolean("batteryAlerted", false)
        if (level <= 15 && !charging && !alerted) {
            prefs.edit().putBoolean("batteryAlerted", true).apply()
            Repo.alerts(c.fleetId).add(
                alertMap(c, AlertType.BATTERY_LOW, 0.0, lastLoc?.latitude ?: 0.0, lastLoc?.longitude ?: 0.0, "Battery $level% — ask ${c.driverName} to charge the phone")
            )
        } else if (alerted && (charging || level >= 25)) {
            prefs.edit().putBoolean("batteryAlerted", false).apply()
        }
    }

    private fun updateVehicle(vehicleId: String, name: String, phone: String) {
        val c = cfg ?: return
        if (vehicleId.isBlank()) {
            applyConfig(c.copy(vehicleId = "", vehicleName = "", vehicleNumber = "", vehicleType = "", driverName = name, driverPhone = phone))
            return
        }
        Repo.vehicles(c.fleetId).document(vehicleId).get().addOnSuccessListener { d ->
            val v = if (d.exists()) d.toVehicle() else null
            applyConfig(
                c.copy(
                    vehicleId = vehicleId, vehicleName = v?.name ?: "", vehicleNumber = v?.number ?: "",
                    vehicleType = v?.type ?: "", driverName = name, driverPhone = phone,
                )
            )
        }
    }

    private fun applyConfig(n: DutyConfig) {
        cfg = n
        DutyPrefs.updateConfig(this, n)
        Repo.live(n.fleetId).document(n.email).set(liveIdentity(n), SetOptions.merge())
        if (progress.tripId.isNotBlank()) {
            Repo.trips(n.fleetId).document(progress.tripId).set(
                mapOf("vehicleId" to n.vehicleId, "vehicleName" to n.vehicleName, "vehicleNumber" to n.vehicleNumber, "driverName" to n.driverName),
                SetOptions.merge()
            )
        }
        TrackingState.update { it.copy(vehicleLabel = vehicleLabel(n)) }
    }

    private fun endDuty() {
        val c = cfg ?: DutyPrefs.config(this)
        try {
            fused.removeLocationUpdates(callback)
        } catch (_: Exception) {
        }
        limitReg?.remove(); limitReg = null
        driverReg?.remove(); driverReg = null
        main.removeCallbacksAndMessages(null)
        try {
            unregisterReceiver(gpsReceiver)
        } catch (_: Exception) {
        }
        if (c != null && running) {
            cfg = c
            flush()
            val now = System.currentTimeMillis()
            if (progress.tripId.isNotBlank()) {
                Repo.trips(c.fleetId).document(progress.tripId)
                    .set(
                        mapOf("active" to false, "endAt" to (if (c.alwaysOn) max(lastMovingAt, progress.startAt) else now)),
                        SetOptions.merge()
                    )
            }
            Repo.live(c.fleetId).document(c.email).set(
                mapOf(
                    "onDuty" to false, "alwaysOn" to false, "speed" to 0.0, "overspeed" to false,
                    "updatedAt" to now, "battery" to battery().first,
                ),
                SetOptions.merge()
            )
            if (!c.alwaysOn) {
                Repo.alerts(c.fleetId).add(
                    alertMap(
                        c, AlertType.DUTY_END, 0.0, lastAccepted?.latitude ?: 0.0, lastAccepted?.longitude ?: 0.0,
                        "${c.driverName} ended duty — ${Fmt.km(progress.distanceM / 1000.0)} in ${Fmt.duration(now - progress.startAt)}"
                    )
                )
            }
        }
        DutyPrefs.clear(this)
        running = false
        isRunning = false
        TrackingState.set(TrackingUi())
        releaseWakeLock()
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        if (running) {
            // System killed us mid-duty: save what we have; START_STICKY / boot / watchdog / app open will resume.
            try {
                fused.removeLocationUpdates(callback)
            } catch (_: Exception) {
            }
            flush()
            limitReg?.remove()
            driverReg?.remove()
            main.removeCallbacksAndMessages(null)
            try {
                unregisterReceiver(gpsReceiver)
            } catch (_: Exception) {
            }
            running = false
            isRunning = false
            TrackingState.update { it.copy(running = false) }
            releaseWakeLock()
        }
        super.onDestroy()
    }

    // ---------------- helpers ----------------

    private fun liveIdentity(c: DutyConfig) = mapOf(
        "driverName" to c.driverName, "driverPhone" to c.driverPhone,
        "vehicleId" to c.vehicleId, "vehicleName" to c.vehicleName,
        "vehicleNumber" to c.vehicleNumber, "vehicleType" to c.vehicleType,
    )

    private fun tripStartMap(c: DutyConfig, now: Long) = mapOf(
        "driverEmail" to c.email, "driverName" to c.driverName,
        "vehicleId" to c.vehicleId, "vehicleName" to c.vehicleName, "vehicleNumber" to c.vehicleNumber,
        "date" to Fmt.dayKey(now), "startAt" to now, "endAt" to now,
        "distanceKm" to 0.0, "maxSpeed" to 0.0, "overspeedCount" to 0, "active" to true,
        "alwaysOn" to c.alwaysOn,
    )

    private fun alertMap(c: DutyConfig, type: String, speed: Double, lat: Double, lng: Double, msg: String) = mapOf(
        "type" to type, "driverName" to c.driverName, "driverEmail" to c.email,
        "vehicleName" to c.vehicleName, "vehicleNumber" to c.vehicleNumber,
        "speed" to (Math.round(speed * 10) / 10.0), "limit" to speedLimit,
        "lat" to lat, "lng" to lng, "at" to System.currentTimeMillis(), "seen" to false, "message" to msg,
    )

    private fun vehicleLabel(c: DutyConfig) =
        if (c.vehicleNumber.isBlank()) c.vehicleName else "${c.vehicleName} • ${c.vehicleNumber}"

    /** battery % and whether charging */
    private fun battery(): Pair<Int, Boolean> = try {
        val bm = getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) to bm.isCharging
    } catch (_: Exception) {
        -1 to false
    }

    private fun title(): String {
        val c = cfg
        return if (c?.alwaysOn == true) {
            val who = c.ownerName.trim().split(" ").firstOrNull()?.ifBlank { null } ?: "your manager"
            "Location sharing with $who is ON"
        } else "On duty — location shared with manager"
    }

    private fun buildNotification(text: String): Notification =
        NotificationCompat.Builder(this, Notifs.CH_TRACKING)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title())
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(Notifs.openAppIntent(this))
            .build()

    private fun updateNotificationText(text: String) {
        if (!Notifs.canPost(this)) return
        try {
            NotificationManagerCompat.from(this).notify(NOTIF_ID, buildNotification(text))
        } catch (_: SecurityException) {
        }
    }

    private fun updateNotification(kmh: Double) {
        val v = cfg?.vehicleName?.ifBlank { null }
        updateNotificationText(
            "${Fmt.speed(kmh)} • ${Fmt.km(progress.distanceM / 1000.0)} today" + if (v != null) " • $v" else ""
        )
    }

    private fun acquireWakeLock() {
        if (wakeLock?.isHeld == true) return
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "FleetTrack:tracking").apply {
            setReferenceCounted(false)
            acquire(16 * 60 * 60 * 1000L)
        }
    }

    private fun releaseWakeLock() {
        try {
            if (wakeLock?.isHeld == true) wakeLock?.release()
        } catch (_: Exception) {
        }
        wakeLock = null
    }
}
