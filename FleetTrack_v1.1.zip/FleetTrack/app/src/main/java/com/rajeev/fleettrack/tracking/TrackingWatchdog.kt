package com.rajeev.fleettrack.tracking

import android.content.Context
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import java.util.concurrent.TimeUnit

/** Every 15 min: if location sharing should be on but Android stopped it, start it again. */
class TrackingWatchdog(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    override fun doWork(): Result {
        val ctx = applicationContext
        if (!DutyPrefs.isActive(ctx)) {
            WorkManager.getInstance(ctx).cancelUniqueWork(NAME)
            return Result.success()
        }
        if (!TrackingService.isRunning) TrackingService.resume(ctx)
        return Result.success()
    }

    companion object {
        private const val NAME = "trackingWatchdog"
        fun schedule(ctx: Context) {
            val req = PeriodicWorkRequestBuilder<TrackingWatchdog>(15, TimeUnit.MINUTES).build()
            WorkManager.getInstance(ctx).enqueueUniquePeriodicWork(NAME, ExistingPeriodicWorkPolicy.KEEP, req)
        }
    }
}
