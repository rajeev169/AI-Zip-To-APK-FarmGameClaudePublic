package com.rajeev.fleettrack.ui.manager

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TimePicker
import androidx.compose.material3.rememberTimePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rajeev.fleettrack.alerts.ManagerChecks
import com.rajeev.fleettrack.data.AuthManager
import com.rajeev.fleettrack.data.Driver
import com.rajeev.fleettrack.data.Fleet
import com.rajeev.fleettrack.data.Repo
import com.rajeev.fleettrack.data.Vehicle
import com.rajeev.fleettrack.ui.common.SectionTitle
import com.rajeev.fleettrack.ui.theme.Navy
import com.rajeev.fleettrack.ui.theme.Orange
import com.rajeev.fleettrack.util.Share
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

val VEHICLE_TYPES = listOf("Truck", "Tractor", "Pickup", "Tempo", "Bus", "Car", "Bike", "JCB", "Other")

/** null = closed, Driver("") = add new, else edit that driver */
private class DriverDialog(val editing: Driver?)

@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun SetupScreen(
    fleetId: String,
    fleet: Fleet?,
    drivers: List<Driver>,
    vehicles: List<Vehicle>,
    bgAlerts: Boolean,
    onBgAlerts: (Boolean) -> Unit,
    onSignOut: () -> Unit,
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf("") }
    var limit by remember { mutableFloatStateOf(60f) }
    var loaded by remember { mutableStateOf(false) }
    var driverDialog by remember { mutableStateOf<DriverDialog?>(null) }
    var addVehicle by remember { mutableStateOf(false) }
    var pickTime by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf<Pair<String, () -> Unit>?>(null) }

    LaunchedEffect(fleet) {
        if (fleet != null && !loaded) {
            name = fleet.name
            limit = fleet.speedLimit.toFloat()
            loaded = true
        }
    }

    fun toast(m: String) = Toast.makeText(ctx, m, Toast.LENGTH_SHORT).show()

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp)
    ) {
        // ---------- business ----------
        SectionTitle("Business")
        OutlinedTextField(
            value = name, onValueChange = { name = it },
            label = { Text("Business name") }, singleLine = true, modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(12.dp))
        Text("Speed limit: ${limit.roundToInt()} km/h", fontWeight = FontWeight.SemiBold)
        Text("Overspeed alert when any vehicle goes above this", fontSize = 12.sp, color = Color.Gray)
        Slider(value = limit, onValueChange = { limit = (it / 5).roundToInt() * 5f }, valueRange = 20f..120f, steps = 19)
        Button(
            onClick = {
                scope.launch {
                    try {
                        Repo.updateFleet(fleetId, name, limit.roundToInt()); toast("Saved")
                    } catch (e: Exception) {
                        toast("Save failed: ${e.message}")
                    }
                }
            },
            enabled = name.isNotBlank()
        ) { Text("Save") }

        // ---------- drivers ----------
        Row(verticalAlignment = Alignment.CenterVertically) {
            SectionTitle("Drivers (${drivers.size})", Modifier.weight(1f))
            TextButton(onClick = { driverDialog = DriverDialog(null) }) {
                Icon(Icons.Filled.Add, null); Text("Add driver")
            }
        }
        Text(
            "Add the driver's Gmail. When they install Fleet Track and sign in with that Gmail, they are linked to you automatically. Tap a driver to edit.",
            fontSize = 12.sp, color = Color.Gray
        )
        Spacer(Modifier.height(6.dp))
        drivers.sortedBy { it.name }.forEach { d ->
            val v = vehicles.firstOrNull { it.id == d.vehicleId }
            ListRow(
                icon = { Icon(Icons.Filled.Person, null, tint = Color.Gray) },
                title = d.name,
                subtitle = d.email + if (d.alwaysOn) "" else " • Duty mode",
                badge = if (d.alwaysOn) "24h" + (v?.let { " • ${it.name}" } ?: "") else null,
                onClick = { driverDialog = DriverDialog(d) },
                onDelete = {
                    confirmDelete = "Remove driver ${d.name}? They will no longer be able to share location." to {
                        scope.launch { runCatching { Repo.removeDriver(fleetId, d.email) } }
                        Unit
                    }
                }
            )
        }

        // ---------- vehicles ----------
        Row(verticalAlignment = Alignment.CenterVertically) {
            SectionTitle("Vehicles (${vehicles.size})", Modifier.weight(1f))
            TextButton(onClick = { addVehicle = true }) {
                Icon(Icons.Filled.Add, null); Text("Add vehicle")
            }
        }
        if (vehicles.isEmpty()) Text("No vehicles yet", color = Color.Gray)
        vehicles.sortedBy { it.name }.forEach { v ->
            ListRow(
                icon = { Icon(Icons.Filled.DirectionsCar, null, tint = Color.Gray) },
                title = v.name, subtitle = listOf(v.number, v.type).filter { it.isNotBlank() }.joinToString(" • "),
                onDelete = {
                    confirmDelete = "Remove vehicle ${v.name}?" to {
                        scope.launch { runCatching { Repo.removeVehicle(fleetId, v.id) } }
                        Unit
                    }
                }
            )
        }

        // ---------- alerts ----------
        SectionTitle("Alerts")
        Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
            Column(Modifier.padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Duty reminder", fontWeight = FontWeight.SemiBold)
                        Text(
                            "Alert me if a driver has not started duty by ${ManagerChecks.timeLabel(fleet?.reminderMinutes ?: 540)}",
                            fontSize = 12.sp, color = Color.Gray
                        )
                    }
                    Switch(
                        checked = fleet?.reminderOn == true,
                        onCheckedChange = { on ->
                            scope.launch { runCatching { Repo.updateReminder(fleetId, on, fleet?.reminderMinutes ?: 540) } }
                        }
                    )
                }
                if (fleet?.reminderOn == true) {
                    OutlinedButton(onClick = { pickTime = true }) {
                        Text("Change time: ${ManagerChecks.timeLabel(fleet.reminderMinutes)}")
                    }
                }
                Spacer(Modifier.height(10.dp))
                HorizontalDivider()
                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Instant alerts when app is closed", fontWeight = FontWeight.SemiBold)
                        Text("SOS, overspeed, GPS off, low battery — right away, even if Fleet Track is not open", fontSize = 12.sp, color = Color.Gray)
                    }
                    Switch(checked = bgAlerts, onCheckedChange = onBgAlerts)
                }
                if (bgAlerts && !Share.isIgnoringBatteryOptimization(ctx)) {
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(onClick = { Share.askIgnoreBatteryOptimization(ctx) }) {
                        Text("Allow running in background (battery)")
                    }
                }
            }
        }

        // ---------- account ----------
        SectionTitle("Account")
        Text(AuthManager.user?.email ?: "", color = Color.DarkGray)
        Spacer(Modifier.height(8.dp))
        OutlinedButton(onClick = onSignOut) {
            Icon(Icons.AutoMirrored.Filled.Logout, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text("Sign out")
        }
        Spacer(Modifier.height(32.dp))
    }

    // ---------- add / edit driver (same design as the plan) ----------
    driverDialog?.let { dlg ->
        val e = dlg.editing
        var dName by remember(dlg) { mutableStateOf(e?.name ?: "") }
        var dEmail by remember(dlg) { mutableStateOf(e?.email ?: "") }
        var dPhone by remember(dlg) { mutableStateOf(e?.phone ?: "") }
        var always by remember(dlg) { mutableStateOf(e?.alwaysOn ?: false) }
        var vehicleId by remember(dlg) { mutableStateOf(e?.vehicleId ?: "") }
        val emailOk = android.util.Patterns.EMAIL_ADDRESS.matcher(dEmail.trim()).matches()
        AlertDialog(
            onDismissRequest = { driverDialog = null },
            title = { Text(if (e == null) "Add driver" else "Edit driver", fontWeight = FontWeight.Bold) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    OutlinedTextField(dName, { dName = it }, label = { Text("Driver name") }, singleLine = true)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        dEmail, { dEmail = it }, label = { Text("Driver's Gmail") }, singleLine = true,
                        enabled = e == null,
                        isError = dEmail.isNotBlank() && !emailOk,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email)
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        dPhone, { dPhone = it }, label = { Text("Phone") }, singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone)
                    )
                    Spacer(Modifier.height(14.dp))
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .border(BorderStroke(2.5.dp, Orange), RoundedCornerShape(12.dp))
                            .clickable { always = !always }
                            .padding(horizontal = 10.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text("Always share location", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text(
                                if (always) "24 hours, no Start Duty needed" else "OFF = driver uses Start / Stop Duty",
                                fontSize = 11.sp, color = Color.Gray
                            )
                        }
                        Switch(checked = always, onCheckedChange = { always = it })
                    }
                    if (always) {
                        Spacer(Modifier.height(10.dp))
                        Text("Vehicle", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        if (vehicles.isEmpty()) Text("Add a vehicle first (optional)", fontSize = 12.sp, color = Color.Gray)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            vehicles.sortedBy { it.name }.forEach { v ->
                                FilterChip(
                                    selected = vehicleId == v.id,
                                    onClick = { vehicleId = if (vehicleId == v.id) "" else v.id },
                                    label = { Text(v.name) }
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        scope.launch {
                            try {
                                val vId = if (always) vehicleId else ""
                                if (e == null) {
                                    Repo.addDriver(fleetId, fleet?.name ?: "", dName, dEmail, dPhone, always, vId)
                                    toast("Driver added — ask them to sign in with ${dEmail.trim()}")
                                } else {
                                    Repo.updateDriver(fleetId, e.email, dName, dPhone, always, vId)
                                    toast("Saved")
                                }
                                driverDialog = null
                            } catch (ex: Exception) {
                                toast("Failed: ${ex.message}")
                            }
                        }
                    },
                    enabled = dName.isNotBlank() && emailOk
                ) { Text(if (e == null) "Add" else "Save") }
            },
            dismissButton = { TextButton(onClick = { driverDialog = null }) { Text("Cancel") } }
        )
    }

    if (addVehicle) {
        var vName by remember { mutableStateOf("") }
        var vNum by remember { mutableStateOf("") }
        var vType by remember { mutableStateOf("Truck") }
        AlertDialog(
            onDismissRequest = { addVehicle = false },
            title = { Text("Add vehicle") },
            text = {
                Column {
                    OutlinedTextField(vName, { vName = it }, label = { Text("Name (e.g. Truck 1)") }, singleLine = true)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        vNum, { vNum = it }, label = { Text("Number plate (e.g. BR01 AB 1234)") }, singleLine = true,
                        keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Characters)
                    )
                    Spacer(Modifier.height(8.dp))
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        VEHICLE_TYPES.forEach { t ->
                            FilterChip(selected = vType == t, onClick = { vType = t }, label = { Text(t) })
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        scope.launch {
                            try {
                                Repo.addVehicle(fleetId, vName, vNum, vType); addVehicle = false
                            } catch (ex: Exception) {
                                toast("Failed: ${ex.message}")
                            }
                        }
                    },
                    enabled = vName.isNotBlank()
                ) { Text("Add") }
            },
            dismissButton = { TextButton(onClick = { addVehicle = false }) { Text("Cancel") } }
        )
    }

    if (pickTime) {
        val m = fleet?.reminderMinutes ?: 540
        val state = rememberTimePickerState(initialHour = m / 60, initialMinute = m % 60, is24Hour = false)
        AlertDialog(
            onDismissRequest = { pickTime = false },
            title = { Text("Duty reminder time") },
            text = { TimePicker(state = state) },
            confirmButton = {
                TextButton(onClick = {
                    pickTime = false
                    scope.launch { runCatching { Repo.updateReminder(fleetId, true, state.hour * 60 + state.minute) } }
                }) { Text("OK") }
            },
            dismissButton = { TextButton(onClick = { pickTime = false }) { Text("Cancel") } }
        )
    }

    confirmDelete?.let { (msg, action) ->
        AlertDialog(
            onDismissRequest = { confirmDelete = null },
            title = { Text("Are you sure?") },
            text = { Text(msg) },
            confirmButton = {
                TextButton(onClick = { action(); confirmDelete = null }) { Text("Remove", color = Color(0xFFD32F2F)) }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = null }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun ListRow(
    icon: @Composable () -> Unit,
    title: String,
    subtitle: String,
    onDelete: () -> Unit,
    badge: String? = null,
    onClick: (() -> Unit)? = null,
) {
    Column {
        Row(
            Modifier
                .fillMaxWidth()
                .let { if (onClick != null) it.clickable(onClick = onClick) else it }
                .padding(vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            icon()
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.SemiBold)
                if (subtitle.isNotBlank()) Text(subtitle, fontSize = 12.sp, color = Color.Gray)
                if (badge != null) {
                    Text(
                        badge, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Navy,
                        modifier = Modifier
                            .padding(top = 3.dp)
                            .background(Color(0xFFE3F2FD), RoundedCornerShape(50))
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                    )
                }
            }
            IconButton(onClick = onDelete) { Icon(Icons.Filled.Delete, "Remove", tint = Color.Gray) }
        }
        HorizontalDivider()
    }
}
