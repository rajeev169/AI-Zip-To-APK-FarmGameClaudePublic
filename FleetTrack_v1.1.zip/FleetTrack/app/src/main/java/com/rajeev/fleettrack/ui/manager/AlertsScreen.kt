package com.rajeev.fleettrack.ui.manager

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rajeev.fleettrack.alerts.AlertText
import com.rajeev.fleettrack.data.Alert
import com.rajeev.fleettrack.data.AlertType
import com.rajeev.fleettrack.data.Repo
import com.rajeev.fleettrack.ui.common.EmptyNote
import com.rajeev.fleettrack.ui.theme.AmberIdle
import com.rajeev.fleettrack.ui.theme.GreenOk
import com.rajeev.fleettrack.ui.theme.GreyOff
import com.rajeev.fleettrack.ui.theme.Navy
import com.rajeev.fleettrack.ui.theme.Orange
import com.rajeev.fleettrack.ui.theme.RedAlert
import com.rajeev.fleettrack.util.Share
import kotlinx.coroutines.launch

private enum class AlertFilter(val label: String) { ALL("All"), IMPORTANT("Important"), DUTY("Duty"), FUEL("Fuel") }

private val DUTY_TYPES = setOf(AlertType.DUTY_START, AlertType.DUTY_END, AlertType.NOT_STARTED)

@Composable
fun AlertsScreen(fleetId: String, alerts: List<Alert>) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var filter by remember { mutableStateOf(AlertFilter.ALL) }

    val shown = alerts.filter {
        when (filter) {
            AlertFilter.ALL -> true
            AlertFilter.IMPORTANT -> it.type in AlertType.IMPORTANT
            AlertFilter.DUTY -> it.type in DUTY_TYPES
            AlertFilter.FUEL -> it.type == AlertType.FUEL
        }
    }
    val unseenIds = alerts.filter { !it.seen }.map { it.id }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(start = 12.dp, end = 4.dp, top = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                Modifier
                    .weight(1f)
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                AlertFilter.entries.forEach { f ->
                    FilterChip(selected = filter == f, onClick = { filter = f }, label = { Text(f.label) })
                }
            }
            TextButton(
                onClick = { scope.launch { runCatching { Repo.markAllAlertsSeen(fleetId, unseenIds) } } },
                enabled = unseenIds.isNotEmpty()
            ) {
                Icon(Icons.Filled.DoneAll, null, Modifier.size(18.dp)); Spacer(Modifier.width(4.dp)); Text("Read")
            }
        }
        if (shown.isEmpty()) {
            EmptyNote("No alerts yet")
        } else {
            LazyColumn(
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(shown, key = { it.id }) { a ->
                    AlertRow(a) {
                        if (a.lat != 0.0 || a.lng != 0.0) Share.openInMaps(ctx, a.lat, a.lng, a.vehicleName.ifBlank { a.driverName })
                    }
                }
            }
        }
    }
}

/** glyph, circle colour */
private fun style(type: String): Pair<String, Color> = when (type) {
    AlertType.SOS -> "!" to RedAlert
    AlertType.GPS_OFF -> "!" to RedAlert
    AlertType.BATTERY_LOW -> "▮" to AmberIdle
    AlertType.STALE -> "?" to GreyOff
    AlertType.OVERSPEED -> "▲" to Orange
    AlertType.GPS_ON -> "✓" to GreenOk
    AlertType.NOT_STARTED -> "!" to AmberIdle
    AlertType.DUTY_START -> "▶" to GreenOk
    AlertType.DUTY_END -> "■" to GreyOff
    AlertType.FUEL -> "₹" to Navy
    else -> "•" to GreyOff
}

private fun shortAgo(at: Long, now: Long = System.currentTimeMillis()): String {
    val s = (now - at) / 1000
    return when {
        s < 60 -> "now"
        s < 3600 -> "${s / 60}m"
        s < 86400 -> "${s / 3600}h"
        else -> "${s / 86400}d"
    }
}

@Composable
private fun AlertRow(a: Alert, onClick: () -> Unit) {
    val (glyph, color) = style(a.type)
    val urgent = a.type == AlertType.SOS || a.type == AlertType.GPS_OFF
    Card(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(
            containerColor = when {
                urgent && !a.seen -> Color(0xFFFFEBEE)
                !a.seen && a.type in AlertType.IMPORTANT -> Color(0xFFFFF8E1)
                else -> Color.White
            }
        ),
        elevation = CardDefaults.cardElevation(1.dp)
    ) {
        Row(Modifier.padding(horizontal = 12.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(40.dp)
                    .background(color, CircleShape),
                contentAlignment = Alignment.Center
            ) { Text(glyph, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp) }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    AlertText.title(a), fontWeight = FontWeight.Bold,
                    color = if (urgent) RedAlert else Color(0xFF1A1A1A),
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                val sub = AlertText.text(a)
                if (sub.isNotBlank()) Text(sub, fontSize = 12.sp, color = Color.Gray, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
            Spacer(Modifier.width(8.dp))
            Column(horizontalAlignment = Alignment.End) {
                Text(shortAgo(a.at), fontSize = 12.sp, color = Color.Gray)
                if (!a.seen && a.type in AlertType.IMPORTANT) {
                    Box(
                        Modifier
                            .padding(top = 6.dp)
                            .size(8.dp)
                            .background(RedAlert, CircleShape)
                    )
                }
            }
        }
    }
}
