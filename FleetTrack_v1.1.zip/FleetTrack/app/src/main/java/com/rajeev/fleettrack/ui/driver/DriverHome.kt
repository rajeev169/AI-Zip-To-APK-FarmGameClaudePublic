package com.rajeev.fleettrack.ui.driver

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.LocationManager
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.GpsFixed
import androidx.compose.material.icons.filled.LocalGasStation
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.rajeev.fleettrack.data.AlertType
import com.rajeev.fleettrack.data.FuelEntry
import com.rajeev.fleettrack.data.Repo
import com.rajeev.fleettrack.data.Session
import com.rajeev.fleettrack.data.Vehicle
import com.rajeev.fleettrack.data.listen
import com.rajeev.fleettrack.data.toFleet
import com.rajeev.fleettrack.data.toDriver
import com.rajeev.fleettrack.data.toTrip
import com.rajeev.fleettrack.data.toVehicle
import com.rajeev.fleettrack.tracking.DutyConfig
import com.rajeev.fleettrack.tracking.DutyPrefs
import com.rajeev.fleettrack.tracking.TrackingService
import com.rajeev.fleettrack.tracking.TrackingState
import com.rajeev.fleettrack.tracking.TrackingWatchdog
import com.rajeev.fleettrack.ui.common.SectionTitle
import com.rajeev.fleettrack.ui.common.StatRow
import com.rajeev.fleettrack.ui.theme.GreenOk
import com.rajeev.fleettrack.ui.theme.Navy
import com.rajeev.fleettrack.ui.theme.RedAlert
import com.rajeev.fleettrack.util.Fmt
import com.rajeev.fleettrack.util.Share
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

private fun lastVehicle(ctx: Context) = ctx.getSharedPreferences("driver", Context.MODE_PRIVATE).getString("vehicle", "") ?: ""
private fun saveLastVehicle(ctx: Context, id: String) =
    ctx.getSharedPreferences("driver", Context.MODE_PRIVATE).edit().putString("vehicle", id).apply()

internal fun hasLocationPermission(ctx: Context) =
    ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

internal fun gpsOn(ctx: Context): Boolean {
    val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
    return lm.isProviderEnabled(LocationManager.GPS_PROVIDER) || lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)
}

/** Chooses Always-on (24h) screens or the normal Start/Stop Duty screens. */
@Composable
fun DriverHome(session: Session.DriverSession, onSignOut: () -> Unit) {
    val ctx = LocalContext.current
    val meLive by remember(session.fleetId, session.driver.email) {
        Repo.drivers(session.fleetId).document(session.driver.email).listen { it.toDriver() }
    }.collectAsState(session.driver)
    val me = meLive ?: session.driver
    LaunchedEffect(me.alwaysOn) {
        // Switched between modes by the manager: stop the tracking that belongs to the other mode
        val running = DutyPrefs.config(ctx)
        if (running != null && running.alwaysOn != me.alwaysOn) TrackingService.stop(ctx)
    }
    if (me.alwaysOn) AlwaysOnHome(session, me, onSignOut)
    else DutyModeHome(session, me, onSignOut)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DutyModeHome(session: Session.DriverSession, me: com.rajeev.fleettrack.data.Driver, onSignOut: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val f = session.fleetId
    val ui by TrackingState.ui.collectAsState()
    val fleet by remember(f) { Repo.fleet(f).listen { it.toFleet() } }.collectAsState(null)
    val vehicles by remember(f) { Repo.vehicles(f).listen { it.toVehicle() } }.collectAsState(emptyList())
    val today = Fmt.dayKey()
    val todayTrips by remember(f, today) {
        Repo.trips(f).whereEqualTo("date", today).listen { it.toTrip() }
    }.collectAsState(emptyList())
    val myTrips = todayTrips.filter { it.driverEmail == me.email }.sortedByDescending { it.startAt }

    var chosen by remember { mutableStateOf(lastVehicle(ctx)) }
    var showFuel by remember { mutableStateOf(false) }
    var showSos by remember { mutableStateOf(false) }
    var showStop by remember { mutableStateOf(false) }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var gpsEnabled by remember { mutableStateOf(gpsOn(ctx)) }

    val onDuty = (ui.running && !ui.alwaysOn) || (DutyPrefs.isActive(ctx) && DutyPrefs.config(ctx)?.alwaysOn != true)

    LaunchedEffect(Unit) {
        // Duty was on when the app was closed -> continue tracking the same trip
        if (DutyPrefs.isActive(ctx) && DutyPrefs.config(ctx)?.alwaysOn != true && !TrackingState.ui.value.running && hasLocationPermission(ctx)) {
            TrackingService.resume(ctx)
        }
        while (true) {
            now = System.currentTimeMillis()
            gpsEnabled = gpsOn(ctx)
            delay(5_000)
        }
    }

    fun startDuty() {
        val v = vehicles.firstOrNull { it.id == chosen } ?: return
        saveLastVehicle(ctx, v.id)
        TrackingService.start(
            ctx,
            DutyConfig(
                fleetId = f, email = me.email, driverName = me.name, driverPhone = me.phone,
                vehicleId = v.id, vehicleName = v.name, vehicleNumber = v.number, vehicleType = v.type,
                speedLimit = fleet?.speedLimit ?: 60, ownerName = fleet?.ownerName ?: "",
            )
        )
        TrackingWatchdog.schedule(ctx)
        if (!Share.isIgnoringBatteryOptimization(ctx)) Share.askIgnoreBatteryOptimization(ctx)
    }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        val loc = res[Manifest.permission.ACCESS_FINE_LOCATION] == true || res[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        if (loc || hasLocationPermission(ctx)) startDuty()
        else Toast.makeText(ctx, "Location permission is needed to share your location on duty", Toast.LENGTH_LONG).show()
    }

    fun requestAndStart() {
        val perms = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
        if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
        permLauncher.launch(perms.toTypedArray())
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Hi, ${me.name.ifBlank { "Driver" }}", fontWeight = FontWeight.Bold)
                        Text(
                            session.fleetName.ifBlank { fleet?.name ?: "" },
                            style = MaterialTheme.typography.bodySmall, color = Color.White.copy(alpha = 0.8f)
                        )
                    }
                },
                actions = {
                    IconButton(onClick = {
                        if (onDuty) Toast.makeText(ctx, "Stop duty before signing out", Toast.LENGTH_SHORT).show()
                        else onSignOut()
                    }) { Icon(Icons.AutoMirrored.Filled.Logout, "Sign out", tint = Color.White) }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Navy, titleContentColor = Color.White)
            )
        }
    ) { pad ->
        Column(
            Modifier
                .padding(pad)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            if (!gpsEnabled) {
                Card(
                    Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp)
                        .clickable { ctx.startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)) },
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFFEBEE))
                ) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.GpsFixed, null, tint = RedAlert)
                        Spacer(Modifier.width(10.dp))
                        Text("Phone location (GPS) is OFF. Tap to turn it on.", color = RedAlert, fontWeight = FontWeight.SemiBold)
                    }
                }
            }

            if (onDuty) {
                OnDutyPanel(
                    speed = ui.speed, limit = ui.speedLimit, km = ui.distanceKm, startAt = ui.startAt, now = now,
                    vehicle = ui.vehicleLabel.ifBlank { DutyPrefs.config(ctx)?.vehicleName ?: "" },
                    waitingGps = ui.waitingForGps, lastFixAt = ui.lastFixAt, maxSpeed = ui.maxSpeed,
                    running = ui.running,
                    onResume = { if (hasLocationPermission(ctx)) TrackingService.resume(ctx) else requestAndStart() },
                    onFuel = { showFuel = true }, onSos = { showSos = true }, onStop = { showStop = true },
                )
            } else {
                Text("Choose your vehicle", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                if (vehicles.isEmpty()) {
                    Text("Your manager has not added any vehicle yet.", color = Color.Gray)
                }
                vehicles.sortedBy { it.name }.forEach { v ->
                    VehicleChoice(v, chosen == v.id) { chosen = v.id }
                }
                Spacer(Modifier.height(16.dp))
                Button(
                    onClick = { requestAndStart() },
                    enabled = vehicles.any { it.id == chosen },
                    colors = ButtonDefaults.buttonColors(containerColor = GreenOk),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(64.dp)
                ) { Text("START DUTY", fontSize = 20.sp, fontWeight = FontWeight.Bold) }
                Spacer(Modifier.height(6.dp))
                Text(
                    "Your location and speed are shared with your manager only while you are on duty.",
                    fontSize = 12.sp, color = Color.Gray
                )
            }

            SectionTitle("My trips today")
            if (myTrips.isEmpty()) Text("No trips yet today", color = Color.Gray)
            myTrips.forEach { t ->
                Card(
                    Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(t.vehicleName, fontWeight = FontWeight.SemiBold)
                            Text(
                                "${Fmt.time(t.startAt)} → " + if (t.active) "now" else Fmt.time(t.endAt),
                                fontSize = 12.sp, color = Color.Gray
                            )
                        }
                        Text(Fmt.km(if (t.active) ui.distanceKm.coerceAtLeast(t.distanceKm) else t.distanceKm), fontWeight = FontWeight.Bold)
                    }
                }
            }
            val totalToday = myTrips.sumOf { if (it.active) ui.distanceKm.coerceAtLeast(it.distanceKm) else it.distanceKm }
            if (myTrips.isNotEmpty()) {
                Text("Total today: ${Fmt.km(totalToday)}", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
            }
            Spacer(Modifier.height(24.dp))
        }
    }

    // ---------- dialogs ----------
    if (showStop) {
        AlertDialog(
            onDismissRequest = { showStop = false },
            title = { Text("Stop duty?") },
            text = { Text("Location sharing will stop and today's trip will be saved.") },
            confirmButton = {
                Button(onClick = { showStop = false; TrackingService.stop(ctx) }, colors = ButtonDefaults.buttonColors(containerColor = RedAlert)) {
                    Text("Stop duty")
                }
            },
            dismissButton = { TextButton(onClick = { showStop = false }) { Text("Cancel") } }
        )
    }

    if (showSos) {
        AlertDialog(
            onDismissRequest = { showSos = false },
            icon = { Icon(Icons.Filled.Warning, null, tint = RedAlert) },
            title = { Text("Send SOS to manager?") },
            text = { Text("Use this for accident, breakdown or any emergency. Your manager gets an urgent alert with your location.") },
            confirmButton = {
                Button(
                    onClick = {
                        showSos = false
                        val c = DutyPrefs.config(ctx)
                        val s = TrackingState.ui.value
                        scope.launch {
                            try {
                                Repo.addAlert(
                                    f, mapOf(
                                        "type" to AlertType.SOS, "driverName" to me.name, "driverEmail" to me.email,
                                        "vehicleName" to (c?.vehicleName ?: ""), "vehicleNumber" to (c?.vehicleNumber ?: ""),
                                        "speed" to s.speed, "limit" to s.speedLimit, "lat" to s.lat, "lng" to s.lng,
                                        "at" to System.currentTimeMillis(), "seen" to false,
                                        "message" to if (s.lat != 0.0) Share.mapsLink(s.lat, s.lng) else "Location not available",
                                    )
                                )
                                Toast.makeText(ctx, "SOS sent to your manager", Toast.LENGTH_LONG).show()
                            } catch (e: Exception) {
                                Toast.makeText(ctx, "SOS saved — will send when internet returns", Toast.LENGTH_LONG).show()
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RedAlert)
                ) { Text("SEND SOS") }
            },
            dismissButton = { TextButton(onClick = { showSos = false }) { Text("Cancel") } }
        )
    }

    if (showFuel) {
        var litres by remember { mutableStateOf("") }
        var amount by remember { mutableStateOf("") }
        var note by remember { mutableStateOf("") }
        val c = DutyPrefs.config(ctx)
        AlertDialog(
            onDismissRequest = { showFuel = false },
            icon = { Icon(Icons.Filled.LocalGasStation, null) },
            title = { Text("Add fuel") },
            text = {
                Column {
                    Text(c?.vehicleName ?: "", fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        litres, { litres = it.filter { ch -> ch.isDigit() || ch == '.' } },
                        label = { Text("Litres") }, singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        amount, { amount = it.filter { ch -> ch.isDigit() || ch == '.' } },
                        label = { Text("Amount ₹") }, singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(note, { note = it }, label = { Text("Pump / note (optional)") }, singleLine = true)
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val l = litres.toDoubleOrNull() ?: 0.0
                        val a = amount.toDoubleOrNull() ?: 0.0
                        showFuel = false
                        val entry = FuelEntry(
                            vehicleId = c?.vehicleId ?: "", vehicleName = c?.vehicleName ?: "",
                            vehicleNumber = c?.vehicleNumber ?: "", driverName = me.name, driverEmail = me.email,
                            litres = l, amount = a, note = note.trim(), at = System.currentTimeMillis(),
                        )
                        val s = TrackingState.ui.value
                        scope.launch {
                            runCatching {
                                Repo.addFuel(f, entry)
                                Repo.addAlert(
                                    f, mapOf(
                                        "type" to AlertType.FUEL, "driverName" to me.name, "driverEmail" to me.email,
                                        "vehicleName" to entry.vehicleName, "vehicleNumber" to entry.vehicleNumber,
                                        "speed" to 0.0, "limit" to 0, "lat" to s.lat, "lng" to s.lng,
                                        "at" to entry.at, "seen" to false,
                                        "message" to "${me.name} added ${String.format(java.util.Locale.US, "%.1f", l)} L for ${Fmt.money(a)}" +
                                            if (entry.note.isNotBlank()) " (${entry.note})" else "",
                                    )
                                )
                            }
                        }
                        Toast.makeText(ctx, "Fuel entry saved", Toast.LENGTH_SHORT).show()
                    },
                    enabled = (litres.toDoubleOrNull() ?: 0.0) > 0 || (amount.toDoubleOrNull() ?: 0.0) > 0
                ) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { showFuel = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun VehicleChoice(v: Vehicle, selected: Boolean, onClick: () -> Unit) {
    Card(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = if (selected) MaterialTheme.colorScheme.primaryContainer else Color.White),
        border = if (selected) BorderStroke(2.dp, Navy) else null
    ) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            RadioButton(selected = selected, onClick = onClick)
            Icon(Icons.Filled.LocalShipping, null, tint = Navy)
            Spacer(Modifier.width(10.dp))
            Column {
                Text(v.name, fontWeight = FontWeight.Bold)
                Text(listOf(v.number, v.type).filter { it.isNotBlank() }.joinToString(" • "), fontSize = 12.sp, color = Color.Gray)
            }
        }
    }
}

@Composable
private fun OnDutyPanel(
    speed: Double, limit: Int, km: Double, startAt: Long, now: Long, vehicle: String,
    waitingGps: Boolean, lastFixAt: Long, maxSpeed: Double, running: Boolean,
    onResume: () -> Unit, onFuel: () -> Unit, onSos: () -> Unit, onStop: () -> Unit,
) {
    Card(
        Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(3.dp)
    ) {
        Column(Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier
                        .size(10.dp)
                        .padding(1.dp)
                ) {
                    Canvas(Modifier.fillMaxSize()) { drawCircle(if (running) GreenOk else RedAlert) }
                }
                Spacer(Modifier.width(6.dp))
                Text(if (running) "ON DUTY" else "PAUSED", fontWeight = FontWeight.Bold, color = if (running) GreenOk else RedAlert)
                Text("  •  $vehicle", color = Color.DarkGray)
            }
            if (!running) {
                Spacer(Modifier.height(8.dp))
                Button(onClick = onResume) { Text("Resume location sharing") }
            }
            Spacer(Modifier.height(8.dp))
            Speedometer(speed, limit)
            Text(
                when {
                    waitingGps && lastFixAt == 0L -> "Waiting for GPS signal…"
                    speed > limit -> "SLOW DOWN — limit $limit km/h"
                    else -> "Speed limit $limit km/h"
                },
                color = if (speed > limit) RedAlert else Color.Gray,
                fontWeight = if (speed > limit) FontWeight.Bold else FontWeight.Normal
            )
            Spacer(Modifier.height(14.dp))
            StatRow(
                "Distance" to Fmt.km(km),
                "On duty" to Fmt.duration(if (startAt > 0) now - startAt else 0),
                "Top speed" to Fmt.speed(maxSpeed),
            )
            if (lastFixAt > 0) {
                Spacer(Modifier.height(6.dp))
                Text("Location sent ${Fmt.ago(lastFixAt, now)}", fontSize = 11.sp, color = Color.Gray)
            }
        }
    }
    Spacer(Modifier.height(12.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        OutlinedButton(
            onClick = onFuel,
            modifier = Modifier
                .weight(1f)
                .height(52.dp)
        ) { Icon(Icons.Filled.LocalGasStation, null); Spacer(Modifier.width(6.dp)); Text("Add fuel") }
        Button(
            onClick = onSos,
            colors = ButtonDefaults.buttonColors(containerColor = RedAlert),
            modifier = Modifier
                .weight(1f)
                .height(52.dp)
        ) { Icon(Icons.Filled.Warning, null); Spacer(Modifier.width(6.dp)); Text("SOS", fontWeight = FontWeight.Bold) }
    }
    Spacer(Modifier.height(10.dp))
    Button(
        onClick = onStop,
        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF455A64)),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .height(58.dp)
    ) { Text("STOP DUTY", fontSize = 18.sp, fontWeight = FontWeight.Bold) }
}

@Composable
private fun Speedometer(speed: Double, limit: Int) {
    val maxV = 140f
    val over = speed > limit
    val color = if (over) RedAlert else GreenOk
    Box(Modifier.size(220.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = 22.dp.toPx()
            val inset = stroke / 2 + 4.dp.toPx()
            val arcSize = Size(size.width - inset * 2, size.height - inset * 2)
            val topLeft = Offset(inset, inset)
            drawArc(Color(0xFFE3E8F0), 150f, 240f, false, topLeft, arcSize, style = Stroke(stroke, cap = StrokeCap.Round))
            val frac = min(speed.toFloat(), maxV) / maxV
            if (frac > 0f) {
                drawArc(color, 150f, 240f * frac, false, topLeft, arcSize, style = Stroke(stroke, cap = StrokeCap.Round))
            }
            // speed-limit tick
            val ang = Math.toRadians((150.0 + 240.0 * (min(limit.toFloat(), maxV) / maxV)))
            val r1 = arcSize.width / 2 - stroke
            val r2 = arcSize.width / 2 + stroke / 2 + 2.dp.toPx()
            val c = Offset(size.width / 2, size.height / 2)
            drawLine(
                RedAlert,
                Offset(c.x + (r1 * cos(ang)).toFloat(), c.y + (r1 * sin(ang)).toFloat()),
                Offset(c.x + (r2 * cos(ang)).toFloat(), c.y + (r2 * sin(ang)).toFloat()),
                strokeWidth = 4.dp.toPx(), cap = StrokeCap.Round
            )
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(speed.toInt().toString(), fontSize = 64.sp, fontWeight = FontWeight.Bold, color = if (over) RedAlert else Color(0xFF1A1A1A))
            Text("km/h", color = Color.Gray)
        }
    }
}
