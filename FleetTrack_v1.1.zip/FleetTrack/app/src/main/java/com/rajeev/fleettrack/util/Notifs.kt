package com.rajeev.fleettrack.util

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.rajeev.fleettrack.R
import com.rajeev.fleettrack.ui.MainActivity

object Notifs {
    const val CH_TRACKING = "tracking"
    const val CH_ALERTS = "fleet_alerts"
    const val CH_DRIVER_WARN = "driver_warn"
    const val CH_SERVICE = "alert_service"

    fun createChannels(ctx: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH_TRACKING, "Duty tracking", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Shown while you are on duty and your location is shared"
            }
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_ALERTS, "Fleet alerts (overspeed, SOS)", NotificationManager.IMPORTANCE_HIGH)
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_DRIVER_WARN, "Speed warnings", NotificationManager.IMPORTANCE_HIGH)
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_SERVICE, "Alert listener", NotificationManager.IMPORTANCE_MIN)
        )
    }

    fun openAppIntent(ctx: Context): PendingIntent {
        val i = Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        return PendingIntent.getActivity(ctx, 0, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    fun canPost(ctx: Context): Boolean =
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    /** Show a notification for an alert only once, even if several listeners see it. */
    fun showOnce(ctx: Context, key: String, title: String, text: String) {
        val sp = ctx.getSharedPreferences("notified", Context.MODE_PRIVATE)
        val seen = sp.getStringSet("ids", emptySet())!!.toMutableSet()
        if (key in seen) return
        seen.add(key)
        if (seen.size > 300) seen.remove(seen.first())
        sp.edit().putStringSet("ids", seen).apply()
        show(ctx, CH_ALERTS, (key.hashCode() and 0x0fffffff) + 1000, title, text)
    }

    fun show(ctx: Context, channel: String, id: Int, title: String, text: String) {
        if (!canPost(ctx)) return
        val n = NotificationCompat.Builder(ctx, channel)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(openAppIntent(ctx))
            .build()
        try {
            NotificationManagerCompat.from(ctx).notify(id, n)
        } catch (_: SecurityException) {
        }
    }
}
