package com.rajeev.fleettrack.alerts

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.Query
import com.rajeev.fleettrack.data.AlertType
import com.rajeev.fleettrack.data.Repo
import com.rajeev.fleettrack.data.toAlert
import com.rajeev.fleettrack.data.toDriver
import com.rajeev.fleettrack.data.toFleet
import com.rajeev.fleettrack.data.toLive
import com.rajeev.fleettrack.util.Fmt
import com.rajeev.fleettrack.util.Notifs
import kotlinx.coroutines.tasks.await
import java.util.Calendar
import java.util.Locale
import java.util.concurrent.TimeUnit

/**
 * Checks done on the MANAGER phone (every 15 min in background, every minute while the app is open):
 *  - always-on driver has sent nothing for 30 min  -> "No update from Papa"
 *  - duty driver has not started duty by reminder time -> "Suresh has not started duty"
 *  - shows notifications for new important alerts (GPS off, battery low, SOS...) if missed
 */
object ManagerChecks {
    private const val STALE_MS = 30 * 60_000L

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("manager_checks", Context.MODE_PRIVATE)

    fun timeLabel(minutes: Int): String {
        val h = minutes / 60
        val m = minutes % 60
        val ampm = if (h < 12) "AM" else "PM"
        val h12 = when {
            h == 0 -> 12
            h > 12 -> h - 12
            else -> h
        }
        return String.format(Locale.US, "%d:%02d %s", h12, m, ampm)
    }

    suspend fun run(ctx: Context, fleetId: String) {
        if (FirebaseAuth.getInstance().currentUser == null || fleetId.isBlank()) return
        val sp = prefs(ctx)
        val now = System.currentTimeMillis()
        val fleet = Repo.fleet(fleetId).get().await().takeIf { it.exists() }?.toFleet() ?: return
        val drivers = Repo.drivers(fleetId).get().await().documents.map { it.toDriver() }
        val live = Repo.live(fleetId).get().await().documents.associate { it.id to it.toLive() }

        // ---- 1. always-on: no update for 30 min ----
        for (d in drivers.filter { it.alwaysOn }) {
            val l = live[d.email] ?: continue
            if (!l.onDuty || !l.alwaysOn || l.updatedAt == 0L) continue
            if (now - l.updatedAt < STALE_MS) continue
            val key = "stale_${d.email}_${l.updatedAt}"
            if (sp.getBoolean(key, false)) continue
            sp.edit().putBoolean(key, true).apply()
            val ref = Repo.alerts(fleetId).document()
            val msg = "Last update ${Fmt.time(l.updatedAt)} — phone may be off or no network"
            ref.set(
                mapOf(
                    "type" to AlertType.STALE, "driverName" to d.name, "driverEmail" to d.email,
                    "vehicleName" to l.vehicleName, "vehicleNumber" to l.vehicleNumber,
                    "speed" to 0.0, "limit" to 0, "lat" to l.lat, "lng" to l.lng,
                    "at" to now, "seen" to false, "message" to msg,
                )
            ).await()
            Notifs.showOnce(ctx, ref.id, "No update from ${d.name}", msg)
        }

        // ---- 2. duty reminder ----
        if (fleet.reminderOn) {
            val cal = Calendar.getInstance()
            val minutesNow = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
            if (minutesNow >= fleet.reminderMinutes && minutesNow < 23 * 60) {
                val today = Fmt.dayKey(now)
                val dutyDrivers = drivers.filter { !it.alwaysOn }
                if (dutyDrivers.isNotEmpty()) {
                    val startedToday = Repo.tripsOn(fleetId, today).map { it.driverEmail }.toSet()
                    for (d in dutyDrivers) {
                        if (d.email in startedToday || live[d.email]?.onDuty == true) continue
                        val key = "remind_${d.email}_$today"
                        if (sp.getBoolean(key, false)) continue
                        sp.edit().putBoolean(key, true).apply()
                        val ref = Repo.alerts(fleetId).document()
                        val msg = "Expected by ${timeLabel(fleet.reminderMinutes)}" + if (d.phone.isNotBlank()) " • ${d.phone}" else ""
                        ref.set(
                            mapOf(
                                "type" to AlertType.NOT_STARTED, "driverName" to d.name, "driverEmail" to d.email,
                                "vehicleName" to "", "vehicleNumber" to "",
                                "speed" to 0.0, "limit" to 0, "lat" to 0.0, "lng" to 0.0,
                                "at" to now, "seen" to false, "message" to msg,
                            )
                        ).await()
                        Notifs.showOnce(ctx, ref.id, "${d.name} has not started duty", "$msg — tap to open")
                    }
                }
            }
        }

        // ---- 3. notify any important alert we have not shown yet ----
        val since = sp.getLong("lastAlertCheck", now - 20 * 60_000L)
        Repo.alerts(fleetId).whereGreaterThan("at", since).orderBy("at", Query.Direction.ASCENDING).limit(50)
            .get().await().documents.map { it.toAlert() }
            .forEach { AlertWatcher.notifyAlert(ctx, it) }
        sp.edit().putLong("lastAlertCheck", now).apply()

        // keep the prefs file small
        if (sp.all.size > 400) {
            val keep = sp.getLong("lastAlertCheck", now)
            sp.edit().clear().putLong("lastAlertCheck", keep).apply()
        }
    }
}

class ManagerCheckWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        return try {
            ManagerChecks.run(applicationContext, ManagerPrefs.fleetId(applicationContext))
            Result.success()
        } catch (_: Exception) {
            Result.retry()
        }
    }

    companion object {
        private const val NAME = "managerChecks"
        fun schedule(ctx: Context) {
            val req = PeriodicWorkRequestBuilder<ManagerCheckWorker>(15, TimeUnit.MINUTES).build()
            WorkManager.getInstance(ctx).enqueueUniquePeriodicWork(NAME, ExistingPeriodicWorkPolicy.KEEP, req)
        }

        fun cancel(ctx: Context) = WorkManager.getInstance(ctx).cancelUniqueWork(NAME)
    }
}
