package com.rajeev.fleettrack.ui.driver

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.LocalGasStation
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.rajeev.fleettrack.data.AlertType
import com.rajeev.fleettrack.data.AuthManager
import com.rajeev.fleettrack.data.Driver
import com.rajeev.fleettrack.data.FuelEntry
import com.rajeev.fleettrack.data.Repo
import com.rajeev.fleettrack.data.Session
import com.rajeev.fleettrack.data.listen
import com.rajeev.fleettrack.data.toFleet
import com.rajeev.fleettrack.data.toVehicle
import com.rajeev.fleettrack.tracking.DutyConfig
import com.rajeev.fleettrack.tracking.DutyPrefs
import com.rajeev.fleettrack.tracking.TrackingService
import com.rajeev.fleettrack.tracking.TrackingState
import com.rajeev.fleettrack.tracking.TrackingWatchdog
import com.rajeev.fleettrack.ui.theme.GreenOk
import com.rajeev.fleettrack.ui.theme.Navy
import com.rajeev.fleettrack.ui.theme.Orange
import com.rajeev.fleettrack.ui.theme.RedAlert
import com.rajeev.fleettrack.util.Fmt
import com.rajeev.fleettrack.util.Share
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Locale

// ---------------- permission helpers ----------------

private fun granted(ctx: Context, p: String) = ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED

/** "Allow all the time" */
private fun locationAllTime(ctx: Context): Boolean =
    granted(ctx, Manifest.permission.ACCESS_FINE_LOCATION) &&
        (Build.VERSION.SDK_INT < 29 || granted(ctx, Manifest.permission.ACCESS_BACKGROUND_LOCATION))

private fun notificationsOk(ctx: Context) =
    Build.VERSION.SDK_INT < 33 || granted(ctx, Manifest.permission.POST_NOTIFICATIONS)

private fun setupKey(email: String) = "ao_setup_$email"
private fun setupDone(ctx: Context, email: String) =
    ctx.getSharedPreferences("driver", Context.MODE_PRIVATE).getBoolean(setupKey(email), false)
private fun setSetupDone(ctx: Context, email: String) =
    ctx.getSharedPreferences("driver", Context.MODE_PRIVATE).edit().putBoolean(setupKey(email), true).apply()

private fun openAppSettings(ctx: Context) {
    try {
        ctx.startActivity(
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + ctx.packageName))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    } catch (_: Exception) {
    }
}

private val isChinaRom: Boolean
    get() = Build.MANUFACTURER.lowercase(Locale.US) in setOf("xiaomi", "redmi", "poco", "vivo", "iqoo", "oppo", "realme", "oneplus", "huawei", "honor", "infinix", "tecno")

/** Opens the "Auto-start" screen on Xiaomi / Vivo / Oppo / Realme phones (falls back to app settings). */
private fun openAutoStart(ctx: Context) {
    val intents = listOf(
        ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity"),
        ComponentName("com.vivo.permissionmanager", "com.vivo.permissionmanager.activity.BgStartUpManagerActivity"),
        ComponentName("com.iqoo.secure", "com.iqoo.secure.ui.phoneoptimize.BgStartUpManager"),
        ComponentName("com.coloros.safecenter", "com.coloros.safecenter.permission.startup.StartupAppListActivity"),
        ComponentName("com.coloros.safecenter", "com.coloros.safecenter.startupapp.StartupAppListActivity"),
        ComponentName("com.oppo.safe", "com.oppo.safe.permission.startup.StartupAppListActivity"),
        ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity"),
    )
    for (c in intents) {
        try {
            ctx.startActivity(Intent().setComponent(c).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return
        } catch (_: Exception) {
        }
    }
    openAppSettings(ctx)
}

// ---------------- entry ----------------

@Composable
fun AlwaysOnHome(session: Session.DriverSession, me: Driver, onSignOut: () -> Unit) {
    val ctx = LocalContext.current
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    var refresh by remember { mutableIntStateOf(0) }
    DisposableEffect(lifecycle) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) refresh++ }
        lifecycle.addObserver(obs)
        onDispose { lifecycle.removeObserver(obs) }
    }
    var finished by remember(me.email) { mutableStateOf(setupDone(ctx, me.email)) }
    // re-read permissions every time the driver comes back from a settings screen
    val locOk = remember(refresh) { locationAllTime(ctx) }
    val notifOk = remember(refresh) { notificationsOk(ctx) }
    val batteryOk = remember(refresh) { Share.isIgnoringBatteryOptimization(ctx) }

    if (!finished || !locOk) {
        OneTimeSetup(session, me, locOk, notifOk, batteryOk, onAsk = { refresh++ }) {
            setSetupDone(ctx, me.email)
            finished = true
        }
    } else {
        SharingOnHome(session, me, onSignOut)
    }
}

// ---------------- screen 1: one-time setup ----------------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun OneTimeSetup(
    session: Session.DriverSession,
    me: Driver,
    locOk: Boolean,
    notifOk: Boolean,
    batteryOk: Boolean,
    onAsk: () -> Unit,
    onFinish: () -> Unit,
) {
    val ctx = LocalContext.current
    val fleet by remember(session.fleetId) { Repo.fleet(session.fleetId).listen { it.toFleet() } }.collectAsState(null)
    val owner = fleet?.ownerName?.trim()?.split(" ")?.firstOrNull()?.ifBlank { null } ?: "Your manager"
    var bgAsked by remember { mutableIntStateOf(0) }
    var notifAsked by remember { mutableIntStateOf(0) }

    val fgLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { onAsk() }
    val bgLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        bgAsked++
        if (!ok && bgAsked >= 2) {
            Toast.makeText(ctx, "Open Permissions → Location → choose \"Allow all the time\"", Toast.LENGTH_LONG).show()
            openAppSettings(ctx)
        }
        onAsk()
    }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        notifAsked++
        if (!ok && notifAsked >= 2) openAppSettings(ctx)
        onAsk()
    }

    fun askLocation() {
        when {
            !granted(ctx, Manifest.permission.ACCESS_FINE_LOCATION) -> {
                val perms = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
                if (Build.VERSION.SDK_INT == 29) perms.add(Manifest.permission.ACCESS_BACKGROUND_LOCATION)
                fgLauncher.launch(perms.toTypedArray())
            }
            Build.VERSION.SDK_INT >= 29 -> {
                Toast.makeText(ctx, "Choose \"Allow all the time\"", Toast.LENGTH_LONG).show()
                bgLauncher.launch(Manifest.permission.ACCESS_BACKGROUND_LOCATION)
            }
        }
    }

    fun askNotif() {
        if (Build.VERSION.SDK_INT >= 33) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    val allDone = locOk && notifOk && batteryOk

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Welcome, ${me.name.ifBlank { "Driver" }}", fontWeight = FontWeight.Bold)
                        Text(
                            "One-time setup — 2 minutes",
                            style = MaterialTheme.typography.bodySmall, color = Color.White.copy(alpha = 0.8f)
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Navy, titleContentColor = Color.White)
            )
        }
    ) { pad ->
        Column(
            Modifier
                .padding(pad)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 12.dp)
        ) {
            Text(
                "$owner will see your location to keep you safe on the road. Please allow these 3 things:",
                Modifier.padding(horizontal = 4.dp, vertical = 14.dp), fontSize = 15.sp, color = Color(0xFF333333)
            )
            StepCard(1, "Location", "Choose “Allow all the time”", locOk) { askLocation() }
            StepCard(2, "Notifications", "For SOS and speed warnings", notifOk) { askNotif() }
            StepCard(3, "Battery", "Choose “Don't restrict” / Auto-start", batteryOk) { Share.askIgnoreBatteryOptimization(ctx) }

            Spacer(Modifier.height(12.dp))
            val next = when {
                !locOk -> "Allow location" to { askLocation() }
                !notifOk -> "Allow notifications" to { askNotif() }
                !batteryOk -> "Allow battery" to { Share.askIgnoreBatteryOptimization(ctx) }
                else -> null
            }
            if (next != null) {
                Button(
                    onClick = next.second,
                    colors = ButtonDefaults.buttonColors(containerColor = Navy),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                ) { Text(next.first, fontSize = 17.sp, fontWeight = FontWeight.Bold) }
            }
            if (isChinaRom) {
                TextButton(onClick = { openAutoStart(ctx) }, modifier = Modifier.align(Alignment.CenterHorizontally)) {
                    Text("${Build.MANUFACTURER.replaceFirstChar { it.uppercase() }} phone: also turn ON Auto-start", color = Navy)
                }
            }

            Spacer(Modifier.height(40.dp))
            Button(
                onClick = {
                    startAlwaysOn(ctx, session, me)
                    onFinish()
                },
                enabled = allDone,
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = GreenOk),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
            ) { Text("Finish setup", fontSize = 17.sp, fontWeight = FontWeight.Bold) }
            if (!allDone && locOk) {
                TextButton(
                    onClick = {
                        startAlwaysOn(ctx, session, me)
                        onFinish()
                    },
                    modifier = Modifier.align(Alignment.CenterHorizontally)
                ) { Text("Skip for now", color = Color.Gray) }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun StepCard(n: Int, title: String, sub: String, done: Boolean, onClick: () -> Unit) {
    Card(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 5.dp)
            .clickable(enabled = !done, onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(1.dp)
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(40.dp)
                    .background(if (done) GreenOk else Orange, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(if (done) "✓" else n.toString(), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text(sub, fontSize = 12.sp, color = Color.Gray)
            }
            Text(
                if (done) "DONE" else "ALLOW", fontWeight = FontWeight.Bold, fontSize = 14.sp,
                color = if (done) GreenOk else Navy
            )
        }
    }
}

private fun startAlwaysOn(ctx: Context, session: Session.DriverSession, me: Driver) {
    // vehicle + speed limit are read fresh by the service listener; start with what we know
    Repo.fleet(session.fleetId).get().addOnCompleteListener { ft ->
        val fleet = if (ft.isSuccessful) ft.result?.takeIf { it.exists() }?.toFleet() else null
        fun go(vName: String, vNum: String, vType: String) {
            val cur = DutyPrefs.config(ctx)
            if (cur != null && cur.alwaysOn && TrackingService.isRunning) return
            TrackingService.start(
                ctx,
                DutyConfig(
                    fleetId = session.fleetId, email = me.email, driverName = me.name, driverPhone = me.phone,
                    vehicleId = me.vehicleId, vehicleName = vName, vehicleNumber = vNum, vehicleType = vType,
                    speedLimit = fleet?.speedLimit ?: 60, alwaysOn = true, ownerName = fleet?.ownerName ?: "",
                )
            )
            TrackingWatchdog.schedule(ctx)
        }
        if (me.vehicleId.isBlank()) go("", "", "")
        else Repo.vehicles(session.fleetId).document(me.vehicleId).get().addOnCompleteListener { vt ->
            val v = if (vt.isSuccessful) vt.result?.takeIf { it.exists() }?.toVehicle() else null
            go(v?.name ?: "", v?.number ?: "", v?.type ?: "")
        }
    }
}

// ---------------- screen 2: Location sharing is ON ----------------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SharingOnHome(session: Session.DriverSession, me: Driver, onSignOut: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val ui by TrackingState.ui.collectAsState()
    val vehicles by remember(session.fleetId) { Repo.vehicles(session.fleetId).listen { it.toVehicle() } }.collectAsState(emptyList())
    val vehicle = vehicles.firstOrNull { it.id == me.vehicleId }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var gpsEnabled by remember { mutableStateOf(gpsOn(ctx)) }
    var showSos by remember { mutableStateOf(false) }
    var showFuel by remember { mutableStateOf(false) }
    var confirmOut by remember { mutableStateOf(false) }

    // Make sure sharing is running whenever this screen is open
    LaunchedEffect(me.email) {
        val cur = DutyPrefs.config(ctx)
        if (cur == null || !cur.alwaysOn) startAlwaysOn(ctx, session, me)
        else if (!TrackingService.isRunning) TrackingService.resume(ctx)
        TrackingWatchdog.schedule(ctx)
        while (true) {
            now = System.currentTimeMillis()
            gpsEnabled = gpsOn(ctx)
            delay(5_000)
        }
    }

    val fleetName = session.fleetName
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Hi, ${me.name.ifBlank { "Driver" }}", fontWeight = FontWeight.Bold)
                        if (fleetName.isNotBlank()) Text(fleetName, style = MaterialTheme.typography.bodySmall, color = Color.White.copy(alpha = 0.8f))
                    }
                },
                actions = {
                    IconButton(onClick = { confirmOut = true }) {
                        Icon(Icons.AutoMirrored.Filled.Logout, "Sign out", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Navy, titleContentColor = Color.White)
            )
        }
    ) { pad ->
        Column(
            Modifier
                .padding(pad)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(12.dp)
        ) {
            val running = ui.running
            val off = !gpsEnabled
            val st = when {
                off -> HeroState(Color(0xFFFFEBEE), RedAlert, "!", "GPS is OFF", "Tap here to turn on Location")
                running -> HeroState(Color(0xFFE8F5E9), GreenOk, "✓", "Location sharing is ON", "Works all the time. No button needed.")
                else -> HeroState(Color(0xFFFFF3E0), Orange, "…", "Starting location sharing…", "Please wait a few seconds")
            }
            Card(
                Modifier
                    .fillMaxWidth()
                    .clickable(enabled = off) { ctx.startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)) },
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(2.dp)
            ) {
                Column(
                    Modifier
                        .fillMaxWidth()
                        .padding(vertical = 28.dp, horizontal = 12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        Modifier
                            .size(140.dp)
                            .background(st.ring, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Box(
                            Modifier
                                .size(92.dp)
                                .background(st.main, CircleShape),
                            contentAlignment = Alignment.Center
                        ) { Text(st.glyph, color = Color.White, fontSize = 46.sp, fontWeight = FontWeight.Bold) }
                    }
                    Spacer(Modifier.height(16.dp))
                    Text(st.title, color = st.main, fontSize = 22.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(4.dp))
                    Text(st.sub, color = Color.Gray, fontSize = 14.sp, textAlign = TextAlign.Center)
                }
            }
            Spacer(Modifier.height(10.dp))
            Card(
                Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(2.dp)
            ) {
                Row(Modifier.padding(vertical = 16.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                    BigStat(ui.speed.toInt().toString(), "km/h", Modifier.weight(1f))
                    BigStat(Fmt.km(ui.distanceKm), "today", Modifier.weight(1f))
                    BigStat(vehicle?.name ?: "—", "vehicle", Modifier.weight(1f))
                }
            }
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(
                    onClick = { showFuel = true },
                    border = BorderStroke(1.5.dp, Navy),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(58.dp)
                ) { Text("Add fuel", color = Navy, fontWeight = FontWeight.Bold, fontSize = 17.sp) }
                Button(
                    onClick = { showSos = true },
                    colors = ButtonDefaults.buttonColors(containerColor = RedAlert),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(58.dp)
                ) { Text("SOS", fontWeight = FontWeight.Bold, fontSize = 17.sp) }
            }
            Spacer(Modifier.height(14.dp))
            Text(
                "Last sent: " + Fmt.ago(ui.lastSentAt, now),
                color = Color.Gray, fontSize = 13.sp, modifier = Modifier.align(Alignment.CenterHorizontally)
            )
            if (!Share.isIgnoringBatteryOptimization(ctx)) {
                TextButton(onClick = { Share.askIgnoreBatteryOptimization(ctx) }, modifier = Modifier.align(Alignment.CenterHorizontally)) {
                    Text("⚠ Battery saver may stop sharing — tap to fix", color = RedAlert)
                }
            }
        }
    }

    if (showSos) SosDialog(scope, session.fleetId, me) { showSos = false }
    if (showFuel) FuelDialog(scope, session.fleetId, me, vehicle?.id ?: "", vehicle?.name ?: "", vehicle?.number ?: "") { showFuel = false }
    if (confirmOut) {
        AlertDialog(
            onDismissRequest = { confirmOut = false },
            title = { Text("Stop sharing and sign out?") },
            text = { Text("Your location will no longer be shared until you sign in again.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmOut = false
                    TrackingService.stop(ctx)
                    scope.launch { onSignOut() }
                }) { Text("Sign out", color = RedAlert) }
            },
            dismissButton = { TextButton(onClick = { confirmOut = false }) { Text("Cancel") } }
        )
    }
}

private data class HeroState(val ring: Color, val main: Color, val glyph: String, val title: String, val sub: String)

@Composable
private fun BigStat(value: String, label: String, modifier: Modifier = Modifier) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, fontWeight = FontWeight.Bold, fontSize = 20.sp, maxLines = 1)
        Text(label, color = Color.Gray, fontSize = 12.sp)
    }
}

// ---------------- shared dialogs ----------------

@Composable
private fun SosDialog(scope: kotlinx.coroutines.CoroutineScope, fleetId: String, me: Driver, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(Icons.Filled.Warning, null, tint = RedAlert) },
        title = { Text("Send SOS?") },
        text = { Text("Use this for accident, breakdown or any emergency. An urgent alert with your location is sent right away.") },
        confirmButton = {
            Button(
                onClick = {
                    onDismiss()
                    val c = DutyPrefs.config(ctx)
                    val s = TrackingState.ui.value
                    scope.launch {
                        try {
                            Repo.addAlert(
                                fleetId, mapOf(
                                    "type" to AlertType.SOS, "driverName" to me.name, "driverEmail" to me.email,
                                    "vehicleName" to (c?.vehicleName ?: ""), "vehicleNumber" to (c?.vehicleNumber ?: ""),
                                    "speed" to s.speed, "limit" to s.speedLimit, "lat" to s.lat, "lng" to s.lng,
                                    "at" to System.currentTimeMillis(), "seen" to false,
                                    "message" to if (s.lat != 0.0) Share.mapsLink(s.lat, s.lng) else "Location not available",
                                )
                            )
                            Toast.makeText(ctx, "SOS sent", Toast.LENGTH_LONG).show()
                        } catch (_: Exception) {
                            Toast.makeText(ctx, "SOS saved — will send when internet returns", Toast.LENGTH_LONG).show()
                        }
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = RedAlert)
            ) { Text("SEND SOS") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
private fun FuelDialog(
    scope: kotlinx.coroutines.CoroutineScope, fleetId: String, me: Driver,
    vehicleId: String, vehicleName: String, vehicleNumber: String, onDismiss: () -> Unit,
) {
    val ctx = LocalContext.current
    var litres by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(Icons.Filled.LocalGasStation, null) },
        title = { Text("Add fuel") },
        text = {
            Column {
                if (vehicleName.isNotBlank()) Text(vehicleName, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    litres, { litres = it.filter { ch -> ch.isDigit() || ch == '.' } },
                    label = { Text("Litres") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    amount, { amount = it.filter { ch -> ch.isDigit() || ch == '.' } },
                    label = { Text("Amount ₹") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(note, { note = it }, label = { Text("Pump / note (optional)") }, singleLine = true)
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val l = litres.toDoubleOrNull() ?: 0.0
                    val a = amount.toDoubleOrNull() ?: 0.0
                    onDismiss()
                    val entry = FuelEntry(
                        vehicleId = vehicleId, vehicleName = vehicleName, vehicleNumber = vehicleNumber,
                        driverName = me.name, driverEmail = me.email,
                        litres = l, amount = a, note = note.trim(), at = System.currentTimeMillis(),
                    )
                    val s = TrackingState.ui.value
                    scope.launch {
                        runCatching {
                            Repo.addFuel(fleetId, entry)
                            Repo.addAlert(
                                fleetId, mapOf(
                                    "type" to AlertType.FUEL, "driverName" to me.name, "driverEmail" to me.email,
                                    "vehicleName" to vehicleName, "vehicleNumber" to vehicleNumber,
                                    "speed" to 0.0, "limit" to 0, "lat" to s.lat, "lng" to s.lng,
                                    "at" to entry.at, "seen" to false,
                                    "message" to "${me.name} added ${String.format(Locale.US, "%.1f", l)} L for ${Fmt.money(a)}" +
                                        if (entry.note.isNotBlank()) " (${entry.note})" else "",
                                )
                            )
                        }
                    }
                    Toast.makeText(ctx, "Fuel entry saved", Toast.LENGTH_SHORT).show()
                },
                enabled = (litres.toDoubleOrNull() ?: 0.0) > 0 || (amount.toDoubleOrNull() ?: 0.0) > 0
            ) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
