package com.rajeev.fleettrack.tracking

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Phone restarted / app updated: continue sharing location if it was on. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            Intent.ACTION_BOOT_COMPLETED, Intent.ACTION_MY_PACKAGE_REPLACED, "android.intent.action.QUICKBOOT_POWERON" -> {
                if (DutyPrefs.isActive(context)) {
                    TrackingService.resume(context)
                    TrackingWatchdog.schedule(context)
                }
            }
        }
    }
}
