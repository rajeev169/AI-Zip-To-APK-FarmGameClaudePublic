package com.rajeev.fleettrack.data

import com.google.firebase.firestore.DocumentSnapshot

data class Fleet(
    val id: String = "",
    val name: String = "",
    val ownerEmail: String = "",
    val ownerName: String = "",
    val speedLimit: Int = 60,
    /** Alert the manager when a duty-mode driver has not started duty by [reminderMinutes] (minutes after midnight). */
    val reminderOn: Boolean = false,
    val reminderMinutes: Int = 9 * 60,
)

data class Driver(
    val email: String = "",
    val name: String = "",
    val phone: String = "",
    /** true = location shared 24 hours, no Start/Stop Duty. */
    val alwaysOn: Boolean = false,
    /** Vehicle used by an always-on driver. */
    val vehicleId: String = "",
)

data class Vehicle(
    val id: String = "",
    val name: String = "",
    val number: String = "",
    val type: String = "Truck",
) {
    val label: String get() = if (number.isBlank()) name else "$name ($number)"
}

/** Latest position of one driver, written by the driver phone, read by the manager. */
data class LiveInfo(
    val email: String = "",
    val driverName: String = "",
    val driverPhone: String = "",
    val vehicleId: String = "",
    val vehicleName: String = "",
    val vehicleNumber: String = "",
    val vehicleType: String = "",
    val lat: Double = 0.0,
    val lng: Double = 0.0,
    val speed: Double = 0.0,
    val bearing: Double = 0.0,
    val accuracy: Double = 0.0,
    val battery: Int = -1,
    val onDuty: Boolean = false,
    val updatedAt: Long = 0,
    val stoppedSince: Long = 0,
    val tripId: String = "",
    val tripKm: Double = 0.0,
    val overspeed: Boolean = false,
    val dutyStart: Long = 0,
    val alwaysOn: Boolean = false,
    val gpsOff: Boolean = false,
)

enum class VehicleStatus(val label: String) {
    MOVING("Moving"), STOPPED("Stopped"), OVERSPEED("Overspeed"), GPS_OFF("GPS off"), OFFLINE("No signal"), OFF_DUTY("Off duty")
}

fun LiveInfo.status(now: Long = System.currentTimeMillis()): VehicleStatus = when {
    !onDuty -> VehicleStatus.OFF_DUTY
    // always-on phones report every ~5 min while parked, so allow a longer gap
    now - updatedAt > (if (alwaysOn) 12 else 3) * 60_000L -> VehicleStatus.OFFLINE
    gpsOff -> VehicleStatus.GPS_OFF
    overspeed -> VehicleStatus.OVERSPEED
    speed >= 3 -> VehicleStatus.MOVING
    else -> VehicleStatus.STOPPED
}

data class Trip(
    val id: String = "",
    val driverEmail: String = "",
    val driverName: String = "",
    val vehicleId: String = "",
    val vehicleName: String = "",
    val vehicleNumber: String = "",
    val date: String = "",
    val startAt: Long = 0,
    val endAt: Long = 0,
    val distanceKm: Double = 0.0,
    val maxSpeed: Double = 0.0,
    val overspeedCount: Int = 0,
    val active: Boolean = false,
)

data class TrackPoint(val lat: Double, val lng: Double, val speed: Double, val time: Long)

data class Alert(
    val id: String = "",
    val type: String = "",
    val driverName: String = "",
    val driverEmail: String = "",
    val vehicleName: String = "",
    val vehicleNumber: String = "",
    val speed: Double = 0.0,
    val limit: Int = 0,
    val lat: Double = 0.0,
    val lng: Double = 0.0,
    val at: Long = 0,
    val seen: Boolean = false,
    val message: String = "",
)

object AlertType {
    const val OVERSPEED = "overspeed"
    const val SOS = "sos"
    const val DUTY_START = "duty_start"
    const val DUTY_END = "duty_end"
    const val FUEL = "fuel"
    const val GPS_OFF = "gps_off"
    const val GPS_ON = "gps_on"
    const val BATTERY_LOW = "battery_low"
    const val STALE = "stale"
    const val NOT_STARTED = "not_started"

    /** Types that make the manager's phone ring. */
    val IMPORTANT = setOf(SOS, OVERSPEED, GPS_OFF, BATTERY_LOW, STALE, NOT_STARTED)
}

data class FuelEntry(
    val id: String = "",
    val vehicleId: String = "",
    val vehicleName: String = "",
    val vehicleNumber: String = "",
    val driverName: String = "",
    val driverEmail: String = "",
    val litres: Double = 0.0,
    val amount: Double = 0.0,
    val note: String = "",
    val date: String = "",
    val at: Long = 0,
)

// ---------- Firestore mapping (manual, so number types never break parsing) ----------

private fun DocumentSnapshot.d(k: String): Double = (get(k) as? Number)?.toDouble() ?: 0.0
private fun DocumentSnapshot.l(k: String): Long = (get(k) as? Number)?.toLong() ?: 0L
private fun DocumentSnapshot.i(k: String, def: Int = 0): Int = (get(k) as? Number)?.toInt() ?: def
private fun DocumentSnapshot.s(k: String): String = getString(k) ?: ""
private fun DocumentSnapshot.b(k: String): Boolean = getBoolean(k) ?: false

fun DocumentSnapshot.toFleet() = Fleet(
    id, s("name"), s("ownerEmail"), s("ownerName"), i("speedLimit", 60),
    b("reminderOn"), i("reminderMinutes", 9 * 60),
)
fun DocumentSnapshot.toDriver() = Driver(id, s("name"), s("phone"), b("alwaysOn"), s("vehicleId"))
fun DocumentSnapshot.toVehicle() = Vehicle(id, s("name"), s("number"), s("type").ifBlank { "Truck" })

fun DocumentSnapshot.toLive() = LiveInfo(
    email = id, driverName = s("driverName"), driverPhone = s("driverPhone"),
    vehicleId = s("vehicleId"), vehicleName = s("vehicleName"), vehicleNumber = s("vehicleNumber"),
    vehicleType = s("vehicleType"),
    lat = d("lat"), lng = d("lng"), speed = d("speed"), bearing = d("bearing"), accuracy = d("accuracy"),
    battery = i("battery", -1), onDuty = b("onDuty"), updatedAt = l("updatedAt"),
    stoppedSince = l("stoppedSince"), tripId = s("tripId"), tripKm = d("tripKm"),
    overspeed = b("overspeed"), dutyStart = l("dutyStart"),
    alwaysOn = b("alwaysOn"), gpsOff = b("gpsOff"),
)

fun DocumentSnapshot.toTrip() = Trip(
    id = id, driverEmail = s("driverEmail"), driverName = s("driverName"),
    vehicleId = s("vehicleId"), vehicleName = s("vehicleName"), vehicleNumber = s("vehicleNumber"),
    date = s("date"), startAt = l("startAt"), endAt = l("endAt"), distanceKm = d("distanceKm"),
    maxSpeed = d("maxSpeed"), overspeedCount = i("overspeedCount"), active = b("active"),
)

fun DocumentSnapshot.toAlert() = Alert(
    id = id, type = s("type"), driverName = s("driverName"), driverEmail = s("driverEmail"),
    vehicleName = s("vehicleName"), vehicleNumber = s("vehicleNumber"),
    speed = d("speed"), limit = i("limit"), lat = d("lat"), lng = d("lng"),
    at = l("at"), seen = b("seen"), message = s("message"),
)

fun DocumentSnapshot.toFuel() = FuelEntry(
    id = id, vehicleId = s("vehicleId"), vehicleName = s("vehicleName"), vehicleNumber = s("vehicleNumber"),
    driverName = s("driverName"), driverEmail = s("driverEmail"),
    litres = d("litres"), amount = d("amount"), note = s("note"), date = s("date"), at = l("at"),
)

@Suppress("UNCHECKED_CAST")
fun DocumentSnapshot.toPoints(): List<TrackPoint> {
    val raw = get("pts") as? List<Map<String, Any?>> ?: return emptyList()
    return raw.mapNotNull { m ->
        val a = (m["a"] as? Number)?.toDouble() ?: return@mapNotNull null
        val o = (m["o"] as? Number)?.toDouble() ?: return@mapNotNull null
        TrackPoint(a, o, (m["s"] as? Number)?.toDouble() ?: 0.0, (m["t"] as? Number)?.toLong() ?: 0L)
    }
}
