# Fleet Track — live vehicle tracking for transport managers

One Android app for both the **manager** and the **drivers** (same idea as Tractor Khata):
sign in with Google → the app detects by Gmail who is a manager and who is a driver.

## What it does

**Manager**
- **Live map** (OpenStreetMap, free — no API key): every vehicle as a coloured badge showing its speed
  - green = moving, yellow = stopped (with "stopped for 25m"), red = overspeed, grey = no signal / off duty
  - list under the map: vehicle, number plate, driver, speed, km today, battery, last update
  - tap a vehicle → Call driver, Share location (WhatsApp), Navigate, Route today
- **Routes**: pick a day + vehicle → see every trip on the map (red parts = overspeed), with **playback** (1x/2x/4x)
- **Reports**: Today / Yesterday / Last 7 days / This month / Last month — km, trips, duty hours, top speed,
  overspeed count, fuel litres & ₹, km per litre — per vehicle and per driver. Share on **WhatsApp** or as **PDF**
- **Alerts**: overspeed, SOS, duty start/end, fuel added. Phone notification for overspeed & SOS
  (optional "alerts when app is closed" switch in Setup)
- **Setup**: business name, speed limit (20–120 km/h), vehicles, drivers (by Gmail + phone)

**Two tracking modes (choose per driver in Setup → Drivers)**
- **Always share location (24h)** — e.g. for family. One-time setup on the driver phone
  (Location "Allow all the time", Notifications, Battery "Don't restrict"), then nothing to press.
  Restarts by itself after phone reboot. Saves battery while parked (updates every ~5 min, every ~10 s while driving).
  Trips are created automatically per day. Manager gets alerts: GPS turned off, battery low (15%),
  no update for 30 min, overspeed, SOS.
- **Duty mode** — driver taps Start Duty / Stop Duty. Optional **duty reminder**: alert if a driver
  has not started duty by a time you choose (Setup → Alerts).

**Driver (duty mode)**
- Choose vehicle → **START DUTY** → location + speed shared every ~10 s while moving (every 60 s when standing)
- Big speedometer with speed-limit mark, "SLOW DOWN" warning + notification when over the limit
- **Add fuel** (litres, ₹, pump), **SOS** button, **STOP DUTY**
- My trips today with km
- Tracking keeps running with the screen off (foreground service). If the phone kills the app,
  opening it again continues the same trip.

## Firebase setup (one time — same steps you did for Family Shield)

1. Firebase console → **Add project** → name it `Fleet Track`.
2. **Add Android app** with package name **`com.rajeev.fleettrack`**.
   Add the **SHA-1** of the key your GitHub build signs with (same as your other apps).
3. Download **`google-services.json`** and put it in the **`app/`** folder (next to `app/build.gradle.kts`)
   *before* zipping/uploading. The build fails without it.
4. **Authentication → Sign-in method → Google → Enable** (this also creates the web client ID the app needs).
   If you enabled Google *after* downloading the json, download it again.
5. **Firestore Database → Create database** (production mode, region `asia-south1` Mumbai).
6. **Firestore → Rules** → paste everything from `firestore.rules` in this zip → **Publish**.

No indexes and no paid (Blaze) plan needed.

## First use

1. Manager installs, signs in → "Create my fleet" → Setup → add vehicles and drivers' Gmail.
2. Each driver installs the same APK, signs in with that Gmail → opens straight into the driver screen.
3. Driver picks vehicle → START DUTY → allow Location + Notifications → allow "battery" exception
   (important on Vivo/Oppo/Xiaomi/Realme so tracking isn't stopped).

## Notes
- Free Firestore quota is 20,000 writes/day. One driver on duty ~10 hrs ≈ 2,500–3,000 writes,
  so the free plan handles about 6–7 vehicles running full days. Beyond that, enable Blaze (pay as you go, very cheap).
- Works with patchy internet: positions are queued on the phone and uploaded when the network returns.
- Map tiles come from OpenStreetMap; they need internet on the manager phone.

## Build
Standard Gradle project (AGP 8.5, Kotlin 2.0, Compose, minSdk 26, targetSdk 35) —
works with your GitHub ZIP-to-APK pipeline: `./gradlew assembleRelease` (or `assembleDebug`).
