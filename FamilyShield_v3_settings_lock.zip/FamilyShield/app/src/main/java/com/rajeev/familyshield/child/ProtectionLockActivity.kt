package com.rajeev.familyshield.child

import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.GppBad
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.app.NotificationCompat
import com.rajeev.familyshield.FamilyShieldApp
import com.rajeev.familyshield.R
import com.rajeev.familyshield.data.ChildInfo
import com.rajeev.familyshield.data.Prefs
import com.rajeev.familyshield.ui.theme.FamilyShieldTheme
import kotlinx.coroutines.delay

/** Decides when the phone must stay locked because a core protection was switched off. */
object ProtectionLock {
    private const val NOTIFICATION_ID = 4021

    /** Keys of core protections that are currently off (see ChildInfo.PROTECTION_LABELS). */
    fun missing(ctx: Context): List<String> {
        val out = mutableListOf<String>()
        if (!Perms.hasUsageAccess(ctx)) out.add("usage")
        if (!Perms.hasAccessibility(ctx)) out.add("accessibility")
        if (!Perms.hasLocation(ctx)) out.add("location")
        return out
    }

    /**
     * Only locks after every core protection has been on at least once, so the first-time
     * setup on the child phone is never blocked.
     */
    fun needsLock(ctx: Context): Boolean {
        val prefs = Prefs(ctx)
        if (!prefs.linked) return false
        if (missing(ctx).isEmpty()) {
            if (!prefs.protectionWasOn) prefs.protectionWasOn = true
            return false
        }
        return prefs.protectionWasOn && RulesStore.get(ctx).lockOnProtectionOff
    }

    /** Calls, launcher and system UI stay usable; Settings only while the parent PIN or the fix button opened it. */
    fun isExempt(ctx: Context, pkg: String): Boolean {
        val unlocked = Prefs(ctx).settingsUnlockUntil > System.currentTimeMillis()
        val settingsLike = pkg in GuardAccessibilityService.SETTINGS_PACKAGES || pkg.endsWith("permissioncontroller")
        if (settingsLike) return unlocked
        return pkg in Essentials.alwaysAllowed(ctx)
    }

    fun show(ctx: Context) {
        val i = Intent(ctx, ProtectionLockActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        try {
            ctx.startActivity(i)
        } catch (_: Exception) {
        }
    }

    /**
     * With Accessibility on, the lock screen opens from the accessibility service on every app switch.
     * With Accessibility off, Android does not let a background service open screens, so a
     * notification is shown instead.
     */
    fun enforce(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java) ?: return
        if (!needsLock(ctx) || GuardAccessibilityService.instance != null) {
            nm.cancel(NOTIFICATION_ID)
            return
        }
        val open = PendingIntent.getActivity(
            ctx, 1,
            Intent(ctx, ProtectionLockActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(ctx, FamilyShieldApp.CH_ALERTS)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("Family Shield protection is off")
            .setContentText("Tap to turn it back on")
            .setContentIntent(open)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()
        try {
            nm.notify(NOTIFICATION_ID, n)
        } catch (_: Exception) {
        }
    }
}

/** Full-screen page shown while a core protection is off. */
class ProtectionLockActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() = goHome()
        })
        setContent {
            FamilyShieldTheme {
                var missing by remember { mutableStateOf(ProtectionLock.missing(this@ProtectionLockActivity)) }
                LaunchedEffect(Unit) {
                    while (true) {
                        delay(1500)
                        missing = ProtectionLock.missing(this@ProtectionLockActivity)
                        if (!ProtectionLock.needsLock(this@ProtectionLockActivity)) {
                            finish()
                            break
                        }
                    }
                }
                LockScreen(
                    missing = missing,
                    parentName = Prefs(this@ProtectionLockActivity).parentName,
                    onFix = { openFix() },
                    onEmergency = { dial() }
                )
            }
        }
    }

    /** Opens the Settings page for the first protection that is off, for a short time only. */
    private fun openFix() {
        Prefs(this).settingsUnlockUntil = System.currentTimeMillis() + 90_000L
        val intent = when (ProtectionLock.missing(this).firstOrNull()) {
            "usage" -> Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)
            "accessibility" -> Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
            else -> Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
        }.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            startActivity(intent)
        } catch (_: Exception) {
        }
    }

    private fun dial() {
        try {
            startActivity(Intent(Intent.ACTION_DIAL).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {
        }
    }

    private fun goHome() {
        startActivity(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }
}

@Composable
private fun LockScreen(
    missing: List<String>,
    parentName: String,
    onFix: () -> Unit,
    onEmergency: () -> Unit,
) {
    val labels = missing.mapNotNull { ChildInfo.PROTECTION_LABELS[it] }
    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(Icons.Filled.GppBad, contentDescription = null, tint = MaterialTheme.colorScheme.error)
        Spacer(Modifier.height(14.dp))
        Text(
            "Family Shield protection is off",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(10.dp))
        Text(
            "Turn it back on to keep using this phone.",
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        if (labels.isNotEmpty()) {
            Spacer(Modifier.height(10.dp))
            Text(
                "Turned off: " + labels.joinToString(", "),
                textAlign = TextAlign.Center,
                fontWeight = FontWeight.SemiBold
            )
        }
        Spacer(Modifier.height(28.dp))
        Button(onClick = onFix, modifier = Modifier.fillMaxWidth()) { Text("Turn protection back on") }
        Spacer(Modifier.height(10.dp))
        OutlinedButton(onClick = onEmergency, modifier = Modifier.fillMaxWidth()) { Text("Emergency call") }
        Spacer(Modifier.height(16.dp))
        Text(
            if (parentName.isBlank()) "Your parent has been told."
            else "$parentName has been told.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
    }
}
