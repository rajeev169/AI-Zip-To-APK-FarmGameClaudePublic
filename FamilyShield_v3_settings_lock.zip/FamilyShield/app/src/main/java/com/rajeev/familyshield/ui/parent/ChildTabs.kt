package com.rajeev.familyshield.ui.parent

import android.app.TimePickerDialog
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.rajeev.familyshield.data.ChildInfo
import com.rajeev.familyshield.data.Day
import com.rajeev.familyshield.data.Repo
import com.rajeev.familyshield.data.formatAgo
import com.rajeev.familyshield.data.formatClock
import com.rajeev.familyshield.data.formatMinutes
import com.rajeev.familyshield.ui.common.SectionCard
import com.rajeev.familyshield.ui.common.StatusDot
import com.rajeev.familyshield.ui.common.UsageBars
import com.rajeev.familyshield.ui.common.WeekChart
import com.rajeev.familyshield.ui.theme.SafeGreen
import com.rajeev.familyshield.ui.theme.SosRed

private val LIMIT_OPTIONS = listOf(0L, 15L, 30L, 45L, 60L, 90L, 120L, 180L)
private val TOTAL_OPTIONS = listOf(0L, 60L, 120L, 180L, 240L, 300L, 360L)

// ---------------- Overview ----------------

@Composable
fun OverviewTab(d: ChildData, days: List<String>) {
    val ctx = LocalContext.current
    val c = d.child
    val online = System.currentTimeMillis() - c.lastSeen < 6 * 60_000L
    val todayApps = d.today.entries.sortedByDescending { it.value }
    val todayTotal = if (c.todayDate == Day.key()) maxOf(c.todayTotalMin, todayApps.sumOf { it.value })
    else todayApps.sumOf { it.value }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        SectionCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                StatusDot(online)
                Spacer(Modifier.width(8.dp))
                Text(
                    if (online) "Online now" else "Last seen ${formatAgo(c.lastSeen)}",
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(Modifier.weight(1f))
                if (c.battery >= 0) {
                    Icon(
                        if (c.charging) Icons.Filled.BatteryChargingFull else Icons.Filled.BatteryStd, null,
                        Modifier.size(18.dp), tint = if (c.battery <= 15) SosRed else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text("${c.battery}%", style = MaterialTheme.typography.bodyMedium)
                }
            }
            if (c.device.isNotBlank()) {
                Spacer(Modifier.height(4.dp))
                Text(c.device, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (c.currentPlace.isNotBlank()) {
                Spacer(Modifier.height(4.dp))
                Text("At ${c.currentPlace}", color = SafeGreen, style = MaterialTheme.typography.bodyMedium)
            }
        }

        val missing = ChildInfo.PROTECTION_LABELS.filter { c.protection[it.key] == false }
        if (missing.isNotEmpty()) {
            SectionCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Warning, null, tint = SosRed)
                    Spacer(Modifier.width(8.dp))
                    Text("Setup not complete on child's phone", fontWeight = FontWeight.Bold, color = SosRed)
                }
                Spacer(Modifier.height(6.dp))
                missing.values.forEach { Text("• $it is off", style = MaterialTheme.typography.bodyMedium) }
                Spacer(Modifier.height(6.dp))
                Text(
                    "Open Family Shield on the child's phone and turn these on.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // Quick actions
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            ActionTile("Lock phone", Icons.Filled.Lock, Modifier.weight(1f)) {
                Repo.sendCommand(c.uid, "lock")
                Toast.makeText(ctx, "Locking ${c.name}'s phone", Toast.LENGTH_SHORT).show()
            }
            ActionTile("Find now", Icons.Filled.MyLocation, Modifier.weight(1f)) {
                Repo.sendCommand(c.uid, "locate")
                Toast.makeText(ctx, "Asking for current location", Toast.LENGTH_SHORT).show()
            }
            ActionTile(
                if (d.rules.studyOn) "Study: ON" else "Study mode",
                Icons.Filled.MenuBook, Modifier.weight(1f), highlighted = d.rules.studyOn
            ) {
                Repo.updateRules(c.uid, mapOf("studyOn" to !d.rules.studyOn))
            }
        }

        SectionCard {
            Row(verticalAlignment = Alignment.Bottom) {
                Text("Today", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(Modifier.weight(1f))
                Text(formatMinutes(todayTotal), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                if (d.rules.totalLimit > 0) {
                    Text(
                        " / ${formatMinutes(d.rules.totalLimit)}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            if (d.rules.totalLimit > 0) {
                Spacer(Modifier.height(8.dp))
                LinearProgressIndicator(
                    progress = { (todayTotal.toFloat() / d.rules.totalLimit).coerceIn(0f, 1f) },
                    modifier = Modifier.fillMaxWidth().height(8.dp),
                    color = if (todayTotal >= d.rules.totalLimit) SosRed else MaterialTheme.colorScheme.primary,
                )
            }
            Spacer(Modifier.height(16.dp))
            if (todayApps.isEmpty()) {
                Text(
                    "No app usage yet today.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium
                )
            } else {
                val top = todayApps.take(8)
                UsageBars(top.map { d.name(it.key) to it.value }) { i -> d.rules.limits[top[i].key] }
            }
        }

        SectionCard {
            Text("Last 7 days", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
            WeekChart(days.map { Day.shortLabel(it) to (d.usageByDay[it]?.values?.sum() ?: 0L) })
        }
    }
}

@Composable
private fun ActionTile(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier,
    highlighted: Boolean = false,
    onClick: () -> Unit,
) {
    val bg = if (highlighted) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.primaryContainer
    val fg = if (highlighted) MaterialTheme.colorScheme.onSecondary else MaterialTheme.colorScheme.onPrimaryContainer
    Column(
        modifier
            .background(bg, RoundedCornerShape(18.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 14.dp, horizontal = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, null, tint = fg)
        Spacer(Modifier.height(6.dp))
        Text(label, color = fg, style = MaterialTheme.typography.labelLarge, maxLines = 1)
    }
}

// ---------------- Apps ----------------

@Composable
fun AppsTab(d: ChildData) {
    var query by remember { mutableStateOf("") }
    var limitFor by remember { mutableStateOf<String?>(null) }
    val today = d.today
    val list = d.apps
        .filter { query.isBlank() || it.name.contains(query, ignoreCase = true) }
        .sortedWith(compareByDescending<com.rajeev.familyshield.data.AppEntry> { today[it.pkg] ?: 0L }.thenBy { it.name.lowercase() })

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(16.dp, 8.dp, 16.dp, 0.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text("Approve new apps", fontWeight = FontWeight.SemiBold)
                Text(
                    "New installs stay locked until you approve them",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Switch(
                checked = d.rules.approveNew,
                onCheckedChange = { Repo.setApproveNew(d.child.uid, it) }
            )
        }
        OutlinedTextField(
            value = query, onValueChange = { query = it },
            leadingIcon = { Icon(Icons.Filled.Search, null) },
            placeholder = { Text("Search apps") }, singleLine = true,
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp, 12.dp, 16.dp, 4.dp)
        )
        if (d.apps.isEmpty()) {
            Text(
                "The app list will appear here once the child's phone finishes setup.",
                Modifier.padding(16.dp), color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        LazyColumn(contentPadding = PaddingValues(bottom = 24.dp)) {
            items(list, key = { it.pkg }) { app ->
                val blocked = app.pkg in d.rules.blocked
                val awaiting = app.pending && app.pkg !in d.rules.approved
                val limit = d.rules.limits[app.pkg]
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(app.name, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            "${formatMinutes(today[app.pkg] ?: 0L)} today",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        if (awaiting) {
                            Text(
                                "New app - locked until approved",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.secondary
                            )
                            TextButton(
                                onClick = { Repo.approveApp(d.child.uid, app.pkg) },
                                modifier = Modifier.offset(x = (-8).dp),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
                            ) { Text("Approve") }
                        }
                    }
                    AssistChip(
                        onClick = { limitFor = app.pkg },
                        enabled = !blocked,
                        label = { Text(if (limit != null) formatMinutes(limit) else "No limit") },
                        leadingIcon = { Icon(Icons.Filled.Timer, null, Modifier.size(16.dp)) }
                    )
                    Spacer(Modifier.width(8.dp))
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        val locked = awaiting && !blocked
                        Switch(
                            checked = blocked || awaiting,
                            onCheckedChange = {
                                // Turning a locked new app off approves it.
                                if (locked && !it) Repo.approveApp(d.child.uid, app.pkg)
                                else Repo.setBlocked(d.child.uid, app.pkg, it)
                            },
                            colors = SwitchDefaults.colors(
                                checkedTrackColor = if (locked) MaterialTheme.colorScheme.secondary else SosRed
                            )
                        )
                        Text(
                            when {
                                blocked -> "Blocked"
                                locked -> "Locked"
                                else -> "Allowed"
                            },
                            style = MaterialTheme.typography.labelSmall,
                            color = when {
                                blocked -> SosRed
                                locked -> MaterialTheme.colorScheme.secondary
                                else -> MaterialTheme.colorScheme.onSurfaceVariant
                            }
                        )
                    }
                }
                HorizontalDivider(Modifier.padding(horizontal = 16.dp))
            }
        }
    }

    limitFor?.let { pkg ->
        ChoiceDialog(
            title = "Daily limit for ${d.name(pkg)}",
            options = LIMIT_OPTIONS,
            selected = d.rules.limits[pkg] ?: 0L,
            label = { if (it == 0L) "No limit" else formatMinutes(it) + " per day" },
            onPick = { Repo.setLimit(d.child.uid, pkg, it); limitFor = null },
            onDismiss = { limitFor = null }
        )
    }
}

@Composable
private fun ChoiceDialog(
    title: String,
    options: List<Long>,
    selected: Long,
    label: (Long) -> String,
    onPick: (Long) -> Unit,
    onDismiss: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column {
                options.forEach { o ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable { onPick(o) }
                            .padding(vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = o == selected, onClick = { onPick(o) })
                        Text(label(o))
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } }
    )
}

// ---------------- Limits ----------------

@Composable
fun LimitsTab(d: ChildData) {
    val ctx = LocalContext.current
    val r = d.rules
    val uid = d.child.uid
    var pickTotal by remember { mutableStateOf(false) }
    var pickStudyApps by remember { mutableStateOf(false) }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        SectionCard {
            SettingHeader(Icons.Filled.HourglassBottom, "Daily screen time", "Total time allowed on all apps each day")
            Spacer(Modifier.height(10.dp))
            OutlinedButton(onClick = { pickTotal = true }, modifier = Modifier.fillMaxWidth()) {
                Text(if (r.totalLimit > 0) "${formatMinutes(r.totalLimit)} per day" else "No limit")
            }
        }

        SectionCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.weight(1f)) {
                    SettingHeader(Icons.Filled.Bedtime, "Bedtime", "Pause all apps at night")
                }
                Switch(checked = r.bedtimeOn, onCheckedChange = { Repo.updateRules(uid, mapOf("bedtimeOn" to it)) })
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(
                    onClick = {
                        TimePickerDialog(ctx, { _, h, m ->
                            Repo.updateRules(uid, mapOf("bedStart" to h * 60 + m, "bedtimeOn" to true))
                        }, r.bedStart / 60, r.bedStart % 60, false).show()
                    },
                    modifier = Modifier.weight(1f)
                ) { Text("From ${formatClock(r.bedStart)}") }
                OutlinedButton(
                    onClick = {
                        TimePickerDialog(ctx, { _, h, m ->
                            Repo.updateRules(uid, mapOf("bedEnd" to h * 60 + m, "bedtimeOn" to true))
                        }, r.bedEnd / 60, r.bedEnd % 60, false).show()
                    },
                    modifier = Modifier.weight(1f)
                ) { Text("To ${formatClock(r.bedEnd)}") }
            }
        }

        SectionCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.weight(1f)) {
                    SettingHeader(Icons.Filled.MenuBook, "Study mode", "Only the apps you choose can open")
                }
                Switch(checked = r.studyOn, onCheckedChange = { Repo.updateRules(uid, mapOf("studyOn" to it)) })
            }
            Spacer(Modifier.height(10.dp))
            OutlinedButton(onClick = { pickStudyApps = true }, modifier = Modifier.fillMaxWidth()) {
                Text("Allowed study apps: ${r.studyAllowed.size}")
            }
        }

        SectionCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.weight(1f)) {
                    SettingHeader(Icons.Filled.Lock, "Lock Settings", "Pages that can turn off protection need your PIN")
                }
                Switch(checked = r.lockSettings, onCheckedChange = { Repo.updateRules(uid, mapOf("lockSettings" to it)) })
            }
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.weight(1f)) {
                    SettingHeader(Icons.Filled.Settings, "Lock all of Settings", "Every Settings page needs your PIN")
                }
                Switch(checked = r.lockAllSettings, onCheckedChange = { Repo.updateRules(uid, mapOf("lockAllSettings" to it)) })
            }
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.weight(1f)) {
                    SettingHeader(Icons.Filled.GppBad, "Lock if protection is off", "Phone stays locked until protection is back on")
                }
                Switch(checked = r.lockOnProtectionOff, onCheckedChange = { Repo.updateRules(uid, mapOf("lockOnProtectionOff" to it)) })
            }
            if (r.pin.isBlank()) {
                Spacer(Modifier.height(8.dp))
                Text(
                    "Set a parent PIN first. Settings stay unlocked until a PIN exists.",
                    style = MaterialTheme.typography.bodySmall,
                    color = SosRed
                )
            }
        }

        Row(
            Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.primaryContainer, RoundedCornerShape(16.dp))
                .padding(14.dp)
        ) {
            Icon(Icons.Filled.Info, null, tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.width(10.dp))
            Text(
                "Phone calls, contacts and the SOS button always work, even during bedtime or study mode. Settings open normally unless Lock Settings is on. Per-app limits are in the Apps tab.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onPrimaryContainer
            )
        }
    }

    if (pickTotal) {
        ChoiceDialog(
            title = "Daily screen time",
            options = TOTAL_OPTIONS,
            selected = r.totalLimit,
            label = { if (it == 0L) "No limit" else formatMinutes(it) + " per day" },
            onPick = { Repo.updateRules(uid, mapOf("totalLimit" to it)); pickTotal = false },
            onDismiss = { pickTotal = false }
        )
    }

    if (pickStudyApps) {
        var chosen by remember { mutableStateOf(r.studyAllowed) }
        AlertDialog(
            onDismissRequest = { pickStudyApps = false },
            title = { Text("Apps allowed in study mode") },
            text = {
                if (d.apps.isEmpty()) {
                    Text("The app list will appear once the child's phone finishes setup.")
                } else {
                    LazyColumn(Modifier.heightIn(max = 420.dp)) {
                        items(d.apps, key = { it.pkg }) { app ->
                            val on = app.pkg in chosen
                            Row(
                                Modifier
                                    .fillMaxWidth()
                                    .clickable { chosen = if (on) chosen - app.pkg else chosen + app.pkg }
                                    .padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(checked = on, onCheckedChange = {
                                    chosen = if (it) chosen + app.pkg else chosen - app.pkg
                                })
                                Text(app.name, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = { Repo.setStudyAllowed(uid, chosen); pickStudyApps = false }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { pickStudyApps = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun SettingHeader(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, subtitle: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier
                .size(40.dp)
                .background(MaterialTheme.colorScheme.primaryContainer, RoundedCornerShape(12.dp)),
            contentAlignment = Alignment.Center
        ) { Icon(icon, null, tint = MaterialTheme.colorScheme.primary) }
        Spacer(Modifier.width(12.dp))
        Column {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
