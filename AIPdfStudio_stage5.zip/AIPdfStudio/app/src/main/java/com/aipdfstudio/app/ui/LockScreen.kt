package com.aipdfstudio.app.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material.icons.outlined.VisibilityOff
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.lifecycle.viewmodel.compose.viewModel
import com.aipdfstudio.app.data.Outputs
import com.aipdfstudio.app.data.PdfOps

/** Lock (add a password) when [unlock] is false, Unlock (remove it) when true. */
@Composable
fun LockScreen(unlock: Boolean, onBack: () -> Unit, onOpen: (Uri) -> Unit, vm: ToolVm = viewModel(), initial: Uri? = null) {
    Preselect(vm, initial)
    val ctx = LocalContext.current
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.addFiles(listOf(uri), replace = true)
    }
    // Passwords are deliberately not saved across app restarts.
    var pw by remember { mutableStateOf("") }
    var pw2 by remember { mutableStateOf("") }
    var show by remember { mutableStateOf(false) }

    val p = vm.single
    val mismatch = !unlock && pw2.isNotEmpty() && pw != pw2
    val ready = when {
        p == null || p.broken -> false
        unlock -> true
        else -> !p.locked && pw.length >= 4 && pw == pw2
    }

    val eye: @Composable () -> Unit = {
        IconButton(onClick = { show = !show }) {
            Icon(
                if (show) Icons.Outlined.VisibilityOff else Icons.Outlined.Visibility,
                contentDescription = if (show) "Hide password" else "Show password"
            )
        }
    }
    val mask = if (show) VisualTransformation.None else PasswordVisualTransformation()

    ToolPage(
        title = if (unlock) "Unlock PDF" else "Lock PDF",
        vm = vm,
        onBack = onBack,
        actionLabel = if (unlock) "Remove password" else "Add password",
        actionEnabled = ready,
        onAction = act@{
            val src = p ?: return@act
            val password = pw
            if (unlock) {
                vm.run("Unlocking…") {
                    val out = Outputs.newFile(ctx, src.name, "unlocked")
                    PdfOps.unlock(ctx, src.uri, password, out)
                    listOf(out) to "Password removed. The new copy opens without a password."
                }
            } else {
                vm.run("Adding password…") {
                    val out = Outputs.newFile(ctx, src.name, "locked")
                    PdfOps.lock(ctx, src.uri, password, out)
                    listOf(out) to "Password added (AES-256). Keep it safe: it can't be recovered if you forget it."
                }
            }
        }
    ) {
        item(key = "hint") {
            Hint(
                if (unlock) "Make a copy of a password-protected PDF that opens without a password. You need to know the password."
                else "Protect a PDF with a password. A locked copy is made; your original stays as it is."
            )
        }
        item(key = "file") { PickedCard(p, vm.loading) { picker.launch(arrayOf("application/pdf")) } }
        if (p != null && !p.broken) {
            if (!unlock && p.locked) {
                item(key = "already") { MessageCard("This PDF already has a password. Unlock it first if you want to change it.", isError = true) }
            } else {
                item(key = "pw") {
                    OutlinedTextField(
                        value = pw,
                        onValueChange = { pw = it; vm.clearOutcome() },
                        label = { Text(if (unlock) "Current password" else "New password") },
                        supportingText = {
                            Text(
                                if (unlock) {
                                    if (p.locked) "Type the password used to open this file"
                                    else "This file opens without a password. Leave empty to remove its restrictions."
                                } else "At least 4 characters"
                            )
                        },
                        singleLine = true,
                        visualTransformation = mask,
                        trailingIcon = eye,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                if (!unlock) {
                    item(key = "pw2") {
                        OutlinedTextField(
                            value = pw2,
                            onValueChange = { pw2 = it; vm.clearOutcome() },
                            label = { Text("Type it again") },
                            isError = mismatch,
                            supportingText = { if (mismatch) Text("Passwords don't match") },
                            singleLine = true,
                            visualTransformation = mask,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }
        }
        outcome(vm, onOpen)
    }
}
