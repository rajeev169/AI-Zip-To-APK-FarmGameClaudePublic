package com.aipdfstudio.app.data

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import android.text.format.DateUtils
import org.json.JSONArray
import org.json.JSONObject

data class RecentFile(
    val uri: String,
    val name: String,
    val pages: Int,
    val lastPage: Int,
    val openedAt: Long,
    val size: Long
)

class RecentStore(context: Context) {
    private val sp = context.applicationContext.getSharedPreferences("recents", Context.MODE_PRIVATE)

    fun load(): List<RecentFile> {
        return try {
            val arr = JSONArray(sp.getString("list", "[]"))
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                RecentFile(
                    uri = o.getString("uri"),
                    name = o.optString("name", "Document"),
                    pages = o.optInt("pages"),
                    lastPage = o.optInt("lastPage"),
                    openedAt = o.optLong("openedAt"),
                    size = o.optLong("size")
                )
            }.sortedByDescending { it.openedAt }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun find(uri: String): RecentFile? = load().firstOrNull { it.uri == uri }

    fun upsert(file: RecentFile) {
        val list = load().filter { it.uri != file.uri }.toMutableList()
        list.add(0, file)
        save(list.take(50))
    }

    fun remove(uri: String) = save(load().filter { it.uri != uri })

    private fun save(list: List<RecentFile>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject()
                    .put("uri", it.uri).put("name", it.name).put("pages", it.pages)
                    .put("lastPage", it.lastPage).put("openedAt", it.openedAt).put("size", it.size)
            )
        }
        sp.edit().putString("list", arr.toString()).apply()
    }
}

fun queryName(ctx: Context, uri: Uri): String {
    try {
        ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (i >= 0 && c.moveToFirst()) {
                val n = c.getString(i)
                if (!n.isNullOrBlank()) return n
            }
        }
    } catch (ignored: Exception) {
    }
    return uri.lastPathSegment ?: "Document.pdf"
}

fun querySize(ctx: Context, uri: Uri): Long {
    try {
        ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
            val i = c.getColumnIndex(OpenableColumns.SIZE)
            if (i >= 0 && c.moveToFirst() && !c.isNull(i)) return c.getLong(i)
        }
    } catch (ignored: Exception) {
    }
    return 0L
}

fun fmtSize(bytes: Long): String = when {
    bytes <= 0L -> ""
    bytes < 1024L * 1024L -> "${bytes / 1024} KB"
    else -> String.format("%.1f MB", bytes / (1024.0 * 1024.0))
}

fun fmtWhen(ms: Long): String =
    DateUtils.getRelativeTimeSpanString(ms, System.currentTimeMillis(), DateUtils.DAY_IN_MILLIS).toString()
