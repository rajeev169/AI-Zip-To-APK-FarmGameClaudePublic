package com.aipdfstudio.app.data

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import com.tom_roush.pdfbox.cos.COSArray
import com.tom_roush.pdfbox.cos.COSName
import com.tom_roush.pdfbox.cos.COSStream
import com.tom_roush.pdfbox.io.MemoryUsageSetting
import com.tom_roush.pdfbox.multipdf.PDFMergerUtility
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPage
import com.tom_roush.pdfbox.pdmodel.PDResources
import com.tom_roush.pdfbox.pdmodel.encryption.AccessPermission
import com.tom_roush.pdfbox.pdmodel.encryption.InvalidPasswordException
import com.tom_roush.pdfbox.pdmodel.encryption.StandardProtectionPolicy
import com.tom_roush.pdfbox.pdmodel.graphics.form.PDFormXObject
import com.tom_roush.pdfbox.pdmodel.graphics.image.JPEGFactory
import com.tom_roush.pdfbox.pdmodel.graphics.image.PDImageXObject
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.util.IdentityHashMap
import kotlin.math.max
import kotlin.math.min

/** An error with a message that is safe to show to the user as is. */
class UserError(message: String) : Exception(message)

/** One page in the page tools editor: [src] is the 0-based page in the original file. */
data class PageEdit(val src: Int, val rot: Int = 0)

enum class CompressLevel(val label: String, val sub: String, val quality: Int, val maxPx: Int) {
    LIGHT("Light", "Best quality, smaller saving", 80, 2400),
    RECOMMENDED("Recommended", "Good quality, good saving", 60, 1600),
    STRONG("Strong", "Smallest file, lower image quality", 40, 1100)
}

/**
 * All PDF editing work. Every function here is blocking: call it from Dispatchers.IO.
 * Output files are written into the app's private "outputs" folder (see [Outputs]).
 */
object PdfOps {
    private const val MEM = 48L * 1024 * 1024
    private fun mem() = MemoryUsageSetting.setupMixed(MEM)

    private fun open(ctx: Context, uri: Uri): InputStream =
        ctx.contentResolver.openInputStream(uri) ?: throw IOException("Can't open file")

    fun load(ctx: Context, uri: Uri, password: String = ""): PDDocument =
        open(ctx, uri).use { PDDocument.load(it, password, mem()) }

    /** Runs [write] into [out]; deletes the half-written file if anything fails. */
    private inline fun <T> writing(out: File, write: () -> T): T {
        try {
            return write()
        } catch (e: Throwable) {
            out.delete()
            throw e
        }
    }

    // ---------- Merge ----------

    fun merge(ctx: Context, uris: List<Uri>, out: File) {
        if (uris.size < 2) throw UserError("Add at least two PDFs to merge.")
        val streams = ArrayList<InputStream>()
        try {
            uris.forEach { streams.add(open(ctx, it)) }
            writing(out) {
                val m = PDFMergerUtility()
                streams.forEach { m.addSource(it) }
                m.destinationFileName = out.absolutePath
                m.mergeDocuments(mem())
            }
        } finally {
            streams.forEach { s -> try { s.close() } catch (ignored: Exception) {} }
        }
    }

    // ---------- Split / extract ----------

    /**
     * Parses text like "1-3, 5, 8-" into 0-based ranges. "8-" means page 8 to the end,
     * "-3" means pages 1 to 3. Throws [UserError] with a readable message if invalid.
     */
    fun parseRanges(text: String, pageCount: Int): List<IntRange> {
        val parts = text.split(',', ';').map { it.trim() }.filter { it.isNotEmpty() }
        if (parts.isEmpty()) throw UserError("Type the pages you want, for example 1-3, 5")
        return parts.map { p ->
            val bad = UserError("\"$p\" isn't a valid page or range. Use numbers like 2 or 4-7.")
            val (a, b) = if (p.contains('-')) {
                val s = p.split('-').map { it.trim() }
                if (s.size != 2) throw bad
                val start = if (s[0].isEmpty()) 1 else s[0].toIntOrNull() ?: throw bad
                val end = if (s[1].isEmpty()) pageCount else s[1].toIntOrNull() ?: throw bad
                start to end
            } else {
                val n = p.toIntOrNull() ?: throw bad
                n to n
            }
            if (a < 1 || b < 1 || a > pageCount || b > pageCount) {
                throw UserError("Page numbers must be between 1 and $pageCount.")
            }
            if (a > b) throw UserError("\"$p\": the first page must come before the last.")
            (a - 1)..(b - 1)
        }
    }

    private fun copyPages(src: PDDocument, indexes: List<Int>, out: File) {
        val dst = PDDocument(mem())
        try {
            indexes.forEach { dst.importPage(src.getPage(it)) }
            dst.save(out)
        } finally {
            dst.close()
        }
    }

    /** Copies the chosen pages (in the given order) into one new PDF. */
    fun extract(ctx: Context, uri: Uri, ranges: List<IntRange>, out: File) {
        val src = load(ctx, uri)
        try {
            writing(out) { copyPages(src, ranges.flatMap { it.toList() }, out) }
        } finally {
            src.close()
        }
    }

    /** Splits into files of [every] pages each. [makeOut] gets 1-based first/last page numbers. */
    fun splitEvery(
        ctx: Context,
        uri: Uri,
        every: Int,
        makeOut: (first: Int, last: Int) -> File,
        progress: (String) -> Unit
    ): List<File> {
        if (every < 1) throw UserError("Enter how many pages each part should have.")
        val src = load(ctx, uri)
        val made = ArrayList<File>()
        try {
            val n = src.numberOfPages
            val chunks = (0 until n step every).map { it until min(it + every, n) }
            chunks.forEachIndexed { i, r ->
                progress("Making part ${i + 1} of ${chunks.size}")
                val f = makeOut(r.first + 1, r.last + 1)
                writing(f) { copyPages(src, r.toList(), f) }
                made.add(f)
            }
            return made
        } catch (e: Throwable) {
            made.forEach { it.delete() }
            throw e
        } finally {
            src.close()
        }
    }

    // ---------- Page tools ----------

    /** Rebuilds the file with pages in the order of [edits], applying each page's extra rotation. */
    fun organize(ctx: Context, uri: Uri, edits: List<PageEdit>, out: File) {
        if (edits.isEmpty()) throw UserError("Keep at least one page.")
        val doc = load(ctx, uri)
        try {
            val all: List<PDPage> = (0 until doc.numberOfPages).map { doc.getPage(it) }
            // Pages can inherit size, resources and rotation from parent nodes in the page tree.
            // Copy those onto each page before we rebuild the tree so nothing is lost.
            all.forEach { p ->
                p.resources = p.resources
                p.mediaBox = p.mediaBox
                p.cropBox = p.cropBox
                p.rotation = p.rotation
            }
            val keep = edits.map { e ->
                val p = all.getOrNull(e.src) ?: throw UserError("The file changed. Open it again.")
                p.rotation = ((p.rotation + e.rot) % 360 + 360) % 360
                p
            }
            val tree = doc.pages
            val root = tree.cosObject
            root.setItem(COSName.KIDS, COSArray())
            root.setInt(COSName.COUNT, 0)
            keep.forEach { tree.add(it) }
            writing(out) { doc.save(out) }
        } finally {
            doc.close()
        }
    }

    // ---------- Lock / unlock ----------

    fun lock(ctx: Context, uri: Uri, password: String, out: File) {
        if (password.length < 4) throw UserError("Use a password with at least 4 characters.")
        val doc = try {
            load(ctx, uri)
        } catch (e: InvalidPasswordException) {
            throw UserError("This PDF already has a password. Unlock it first.")
        }
        try {
            if (doc.isEncrypted) throw UserError("This PDF already has a password. Unlock it first.")
            val policy = StandardProtectionPolicy(password, password, AccessPermission())
            policy.encryptionKeyLength = 256
            doc.protect(policy)
            writing(out) { doc.save(out) }
        } finally {
            doc.close()
        }
    }

    fun unlock(ctx: Context, uri: Uri, password: String, out: File) {
        val doc = try {
            load(ctx, uri, password)
        } catch (e: InvalidPasswordException) {
            throw UserError(if (password.isEmpty()) "This PDF needs a password. Type it above." else "Wrong password. Try again.")
        }
        try {
            if (!doc.isEncrypted) throw UserError("This PDF has no password, so there's nothing to unlock.")
            doc.isAllSecurityToBeRemoved = true
            writing(out) { doc.save(out) }
        } finally {
            doc.close()
        }
    }

    // ---------- Compress ----------

    /** Re-encodes large photos inside the PDF as smaller JPEGs. Text and vector art are untouched. */
    fun compress(ctx: Context, uri: Uri, level: CompressLevel, out: File, progress: (String) -> Unit) {
        val doc = load(ctx, uri)
        try {
            val done = IdentityHashMap<COSStream, PDImageXObject?>()
            val forms = IdentityHashMap<COSStream, Boolean>()
            val n = doc.numberOfPages
            for (i in 0 until n) {
                progress("Compressing page ${i + 1} of $n")
                val res = try { doc.getPage(i).resources } catch (ignored: Exception) { null } ?: continue
                shrink(doc, res, level, done, forms)
            }
            progress("Saving")
            writing(out) { doc.save(out) }
        } finally {
            doc.close()
        }
    }

    private fun shrink(
        doc: PDDocument,
        res: PDResources,
        level: CompressLevel,
        done: IdentityHashMap<COSStream, PDImageXObject?>,
        forms: IdentityHashMap<COSStream, Boolean>
    ) {
        for (name in res.xObjectNames.toList()) {
            val xo = try { res.getXObject(name) } catch (ignored: Exception) { null } ?: continue
            when (xo) {
                is PDImageXObject -> {
                    val key = xo.cosObject
                    val repl = if (done.containsKey(key)) done[key] else recompress(doc, xo, level).also { done[key] = it }
                    if (repl != null) res.put(name, repl)
                }
                is PDFormXObject -> {
                    val key = xo.cosObject
                    if (forms.put(key, true) == null) {
                        xo.resources?.let { shrink(doc, it, level, done, forms) }
                    }
                }
            }
        }
    }

    private fun recompress(doc: PDDocument, img: PDImageXObject, level: CompressLevel): PDImageXObject? {
        var src: Bitmap? = null
        var scaled: Bitmap? = null
        return try {
            val cos = img.cosObject
            // Skip masks, transparency and tiny images: JPEG can't keep them right or won't help.
            if (img.isStencil || img.bitsPerComponent == 1) return null
            if (cos.containsKey(COSName.SMASK) || cos.containsKey(COSName.MASK)) return null
            val w = img.width
            val h = img.height
            if (w * h < 128 * 128) return null
            val oldLen = cos.length
            if (oldLen <= 0) return null

            src = img.image ?: return null
            val scale = min(1f, level.maxPx / max(w, h).toFloat())
            scaled = if (scale < 1f) {
                Bitmap.createScaledBitmap(src, max(1, (w * scale).toInt()), max(1, (h * scale).toInt()), true)
            } else src
            val bytes = ByteArrayOutputStream()
            scaled.compress(Bitmap.CompressFormat.JPEG, level.quality, bytes)
            // Only swap if it's clearly smaller than what's already there.
            if (bytes.size() >= oldLen * 0.9) return null
            JPEGFactory.createFromStream(doc, ByteArrayInputStream(bytes.toByteArray()))
        } catch (ignored: Exception) {
            null
        } catch (ignored: OutOfMemoryError) {
            null
        } finally {
            if (scaled != null && scaled !== src) scaled.recycle()
            src?.recycle()
        }
    }

    // ---------- Errors ----------

    fun friendly(e: Throwable): String = when (e) {
        is UserError -> e.message ?: "Something went wrong."
        is InvalidPasswordException -> "This PDF is password protected. Unlock it first with the Unlock tool."
        is OutOfMemoryError -> "This file is too big for your phone's memory."
        is SecurityException -> "The app lost access to this file. Please choose it again."
        is IOException -> "Couldn't read or save the file. It may be damaged or your storage may be full."
        else -> "Something went wrong: ${e.message ?: e.javaClass.simpleName}"
    }
}
