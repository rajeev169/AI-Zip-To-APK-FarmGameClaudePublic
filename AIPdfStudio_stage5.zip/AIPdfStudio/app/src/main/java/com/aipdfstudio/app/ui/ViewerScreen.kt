@file:OptIn(ExperimentalMaterial3Api::class)

package com.aipdfstudio.app.ui

import android.graphics.Bitmap
import android.graphics.Color as AColor
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateCentroid
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.Bookmark
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.Bookmarks
import androidx.compose.material.icons.outlined.DarkMode
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.ErrorOutline
import androidx.compose.material.icons.outlined.LightMode
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SmallFloatingActionButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import com.aipdfstudio.app.data.BookmarkStore
import com.aipdfstudio.app.data.Outline
import com.aipdfstudio.app.data.OutlineEntry
import com.aipdfstudio.app.data.Outputs
import com.aipdfstudio.app.data.RecentFile
import com.aipdfstudio.app.data.RecentStore
import com.aipdfstudio.app.data.queryName
import com.aipdfstudio.app.data.querySize
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.IOException
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.roundToInt

private const val MIN_ZOOM = 1f
private const val MAX_ZOOM = 4f
/** Pages are drawn at most this many pixels wide; above that the picture is stretched a little. */
private const val MAX_RENDER_PX = 2200

private class PdfDoc(val renderer: PdfRenderer, val pfd: ParcelFileDescriptor, val pages: Int) {
    val lock = Any()
    @Volatile var closed = false

    fun close() {
        synchronized(lock) {
            if (!closed) {
                closed = true
                try { renderer.close() } catch (ignored: Exception) {}
                try { pfd.close() } catch (ignored: Exception) {}
            }
        }
    }
}

private val InvertFilter = ColorFilter.colorMatrix(
    ColorMatrix(
        floatArrayOf(
            -1f, 0f, 0f, 0f, 255f,
            0f, -1f, 0f, 0f, 255f,
            0f, 0f, -1f, 0f, 255f,
            0f, 0f, 0f, 1f, 0f
        )
    )
)

private fun renderPage(doc: PdfDoc, index: Int, widthPx: Int): Bitmap? = synchronized(doc.lock) {
    if (doc.closed) return null
    val page = doc.renderer.openPage(index)
    try {
        val h = (widthPx.toFloat() * page.height / page.width).toInt().coerceAtLeast(1)
        val bmp = Bitmap.createBitmap(widthPx, h, Bitmap.Config.ARGB_8888)
        bmp.eraseColor(AColor.WHITE)
        page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
        bmp
    } finally {
        page.close()
    }
}

@Composable
fun ViewerScreen(uri: Uri, recents: RecentStore, onBack: () -> Unit, onAskAi: (String) -> Unit, onEdit: () -> Unit = {}) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val name = remember(uri) { queryName(ctx, uri) }
    val size = remember(uri) { querySize(ctx, uri) }
    val bookmarkStore = remember { BookmarkStore(ctx) }
    var doc by remember { mutableStateOf<PdfDoc?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var night by remember { mutableStateOf(false) }
    var zoom by remember { mutableFloatStateOf(1f) }
    var gesture by remember { mutableFloatStateOf(1f) }
    var pivot by remember { mutableStateOf(Offset.Zero) }
    var viewport by remember { mutableStateOf(IntSize(1, 1)) }
    var bookmarks by remember { mutableStateOf(bookmarkStore.get(uri.toString())) }
    var showSheet by remember { mutableStateOf(false) }
    var showGoTo by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()
    val hScroll = rememberScrollState()
    val zoomNow by rememberUpdatedState(zoom)

    LaunchedEffect(uri) {
        val result: Any = withContext(Dispatchers.IO) {
            try {
                val pfd = ctx.contentResolver.openFileDescriptor(uri, "r") ?: throw IOException("open failed")
                try {
                    val r = PdfRenderer(pfd)
                    PdfDoc(r, pfd, r.pageCount)
                } catch (e: Exception) {
                    pfd.close()
                    throw e
                }
            } catch (e: SecurityException) {
                "This PDF is password protected. Use Tools → Unlock to make a copy without the password."
            } catch (e: Exception) {
                "Couldn't open this file. It may be damaged or not a PDF."
            }
        }
        if (result is PdfDoc) {
            doc = result
            val last = recents.find(uri.toString())?.lastPage ?: 0
            recents.upsert(RecentFile(uri.toString(), name, result.pages, last, System.currentTimeMillis(), size))
            if (last in 0 until result.pages) listState.scrollToItem(last)
        } else {
            error = result as String
        }
    }

    DisposableEffect(uri) {
        onDispose {
            val d = doc
            if (d != null) {
                recents.upsert(
                    RecentFile(uri.toString(), name, d.pages, listState.firstVisibleItemIndex, System.currentTimeMillis(), size)
                )
                d.close()
            }
        }
    }

    /** Applies a finished pinch: makes the pages really bigger and keeps the spot under the fingers in place. */
    fun commitZoom(factor: Float, focus: Offset) {
        val old = zoomNow
        val new = (old * factor).coerceIn(MIN_ZOOM, MAX_ZOOM)
        gesture = 1f
        val f = new / old
        if (abs(f - 1f) < 0.01f) return
        val index = listState.firstVisibleItemIndex
        val off = listState.firstVisibleItemScrollOffset
        val hx = hScroll.value
        zoom = new
        scope.launch {
            withFrameNanos { }
            val newOff = (off + focus.y) * f - focus.y
            listState.scrollToItem(index, max(0, newOff.roundToInt()))
            if (newOff < 0) listState.scrollBy(newOff)
            hScroll.scrollTo(((hx + focus.x) * f - focus.x).roundToInt().coerceIn(0, hScroll.maxValue.coerceAtLeast(0)))
            withFrameNanos { }
            hScroll.scrollTo(((hx + focus.x) * f - focus.x).roundToInt().coerceIn(0, hScroll.maxValue.coerceAtLeast(0)))
        }
    }

    fun goTo(page: Int) {
        val d = doc ?: return
        scope.launch { listState.scrollToItem(page.coerceIn(0, d.pages - 1)) }
    }

    val cfg = LocalConfiguration.current
    val density = LocalDensity.current
    val pageWidthDp = (cfg.screenWidthDp * zoom).dp
    val renderPx = with(density) { pageWidthDp.roundToPx() }.coerceAtMost(MAX_RENDER_PX)
    val current by remember { derivedStateOf { listState.firstVisibleItemIndex } }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { showSheet = true }, enabled = doc != null) {
                        Icon(Icons.Outlined.Bookmarks, contentDescription = "Contents and bookmarks")
                    }
                    IconButton(onClick = onEdit, enabled = doc != null) {
                        Icon(Icons.Outlined.Edit, contentDescription = "Edit this PDF")
                    }
                    IconButton(onClick = { night = !night }) {
                        Icon(
                            if (night) Icons.Outlined.LightMode else Icons.Outlined.DarkMode,
                            contentDescription = "Night mode"
                        )
                    }
                    IconButton(onClick = {
                        try {
                            Outputs.shareUri(ctx, uri, name)
                        } catch (e: Exception) {
                            Toast.makeText(ctx, "No app available to share with", Toast.LENGTH_SHORT).show()
                        }
                    }) {
                        Icon(Icons.Outlined.Share, contentDescription = "Share")
                    }
                    IconButton(onClick = { onAskAi(name) }) {
                        Icon(Icons.Outlined.AutoAwesome, contentDescription = "Ask AI about this PDF")
                    }
                }
            )
        }
    ) { pad ->
        Box(
            Modifier.fillMaxSize().padding(pad)
                .background(MaterialTheme.colorScheme.surfaceContainerHigh)
        ) {
            val d = doc
            val err = error
            when {
                err != null -> Column(
                    Modifier.fillMaxSize().padding(32.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(Icons.Outlined.ErrorOutline, contentDescription = null, modifier = Modifier.size(40.dp), tint = MaterialTheme.colorScheme.error)
                    Text(err, textAlign = TextAlign.Center, modifier = Modifier.padding(vertical = 16.dp))
                    Button(onClick = onBack) { Text("Go back") }
                }
                d == null -> CircularProgressIndicator(Modifier.align(Alignment.Center))
                else -> {
                    Box(
                        Modifier
                            .fillMaxSize()
                            .onSizeChanged { viewport = it }
                            // Two fingers: pinch to zoom. Watched before the lists so one-finger scrolling still works.
                            .pointerInput(Unit) {
                                awaitEachGesture {
                                    awaitFirstDown(requireUnconsumed = false)
                                    var pinching = false
                                    var scale = 1f
                                    var center = Offset.Zero
                                    do {
                                        val event = awaitPointerEvent(PointerEventPass.Initial)
                                        if (event.changes.count { it.pressed } >= 2) {
                                            if (!pinching) {
                                                pinching = true
                                                center = event.calculateCentroid(useCurrent = true)
                                                pivot = center
                                            }
                                            scale = (scale * event.calculateZoom())
                                                .coerceIn(MIN_ZOOM / zoomNow, MAX_ZOOM / zoomNow)
                                            gesture = scale
                                            event.changes.forEach { if (it.positionChanged()) it.consume() }
                                        }
                                    } while (event.changes.any { it.pressed })
                                    if (pinching) commitZoom(scale, center)
                                }
                            }
                            .pointerInput(Unit) {
                                detectTapGestures(onDoubleTap = { p ->
                                    if (zoomNow > 1.05f) commitZoom(1f / zoomNow, p) else commitZoom(2.5f, p)
                                })
                            }
                    ) {
                        Box(
                            Modifier
                                .fillMaxSize()
                                .graphicsLayer {
                                    scaleX = gesture
                                    scaleY = gesture
                                    transformOrigin = TransformOrigin(
                                        (pivot.x / viewport.width.coerceAtLeast(1)).coerceIn(0f, 1f),
                                        (pivot.y / viewport.height.coerceAtLeast(1)).coerceIn(0f, 1f)
                                    )
                                }
                                .horizontalScroll(hScroll)
                        ) {
                            LazyColumn(
                                state = listState,
                                modifier = Modifier.width(pageWidthDp).fillMaxHeight(),
                                contentPadding = PaddingValues(vertical = 8.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                items(d.pages) { index -> PageItem(d, index, renderPx, night) }
                            }
                        }
                    }

                    Row(
                        Modifier.align(Alignment.BottomCenter).padding(bottom = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.surfaceContainerHighest,
                            modifier = Modifier.clickable { showGoTo = true }
                        ) {
                            Text(
                                "${current + 1} / ${d.pages}",
                                style = MaterialTheme.typography.labelLarge,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                            )
                        }
                        if (zoom > 1.01f || gesture != 1f) {
                            Surface(
                                shape = CircleShape,
                                color = MaterialTheme.colorScheme.secondaryContainer,
                                modifier = Modifier.clickable { commitZoom(1f / zoom, Offset.Zero) }
                            ) {
                                Text(
                                    "${(zoom * gesture * 100).roundToInt()}%  ✕",
                                    style = MaterialTheme.typography.labelLarge,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }
                    val marked = current in bookmarks
                    SmallFloatingActionButton(
                        onClick = {
                            bookmarks = bookmarkStore.toggle(uri.toString(), current)
                            Toast.makeText(ctx, if (marked) "Bookmark removed" else "Page ${current + 1} bookmarked", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp)
                    ) {
                        Icon(
                            if (marked) Icons.Outlined.Bookmark else Icons.Outlined.BookmarkBorder,
                            contentDescription = if (marked) "Remove bookmark" else "Bookmark this page"
                        )
                    }
                }
            }
        }
    }

    val d = doc
    if (showSheet && d != null) {
        ContentsSheet(
            uri = uri,
            pages = d.pages,
            bookmarks = bookmarks,
            onDismiss = { showSheet = false },
            onGo = { goTo(it); showSheet = false },
            onRemove = { bookmarks = bookmarkStore.toggle(uri.toString(), it) }
        )
    }
    if (showGoTo && d != null) {
        GoToPageDialog(d.pages, onDismiss = { showGoTo = false }) { goTo(it); showGoTo = false }
    }
}

@Composable
private fun ContentsSheet(
    uri: Uri,
    pages: Int,
    bookmarks: List<Int>,
    onDismiss: () -> Unit,
    onGo: (Int) -> Unit,
    onRemove: (Int) -> Unit
) {
    val ctx = LocalContext.current
    var outline by remember { mutableStateOf<List<OutlineEntry>?>(null) }
    LaunchedEffect(uri) { outline = withContext(Dispatchers.IO) { Outline.read(ctx, uri) } }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        LazyColumn(Modifier.fillMaxWidth().navigationBarsPadding(), contentPadding = PaddingValues(bottom = 24.dp)) {
            item {
                Text(
                    "Your bookmarks",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)
                )
            }
            if (bookmarks.isEmpty()) {
                item { Hint("No bookmarks yet. Tap the bookmark button on any page.", Modifier.padding(horizontal = 20.dp)) }
            } else {
                items(bookmarks.filter { it < pages }) { p ->
                    Row(
                        Modifier.fillMaxWidth().clickable { onGo(p) }.padding(start = 20.dp, end = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Outlined.Bookmark, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(12.dp))
                        Text("Page ${p + 1}", modifier = Modifier.weight(1f).padding(vertical = 12.dp))
                        TextButton(onClick = { onRemove(p) }) { Text("Remove") }
                    }
                }
            }
            item { HorizontalDivider(Modifier.padding(vertical = 8.dp)) }
            item {
                Text(
                    "Contents",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)
                )
            }
            val o = outline
            when {
                o == null -> item { CircularProgressIndicator(Modifier.padding(20.dp).size(24.dp)) }
                o.isEmpty() -> item { Hint("This PDF has no table of contents.", Modifier.padding(horizontal = 20.dp)) }
                else -> items(o) { e ->
                    Row(
                        Modifier.fillMaxWidth()
                            .clickable(enabled = e.page >= 0) { onGo(e.page) }
                            .padding(start = (20 + e.level * 16).dp, end = 20.dp, top = 10.dp, bottom = 10.dp)
                    ) {
                        Text(
                            e.title,
                            modifier = Modifier.weight(1f),
                            fontWeight = if (e.level == 0) FontWeight.Medium else FontWeight.Normal,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                        if (e.page >= 0) Text("${e.page + 1}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}

@Composable
private fun GoToPageDialog(pages: Int, onDismiss: () -> Unit, onGo: (Int) -> Unit) {
    var text by remember { mutableStateOf("") }
    val n = text.toIntOrNull()
    val valid = n != null && n in 1..pages
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Go to page") },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { v -> text = v.filter { it.isDigit() }.take(6) },
                label = { Text("Page (1 to $pages)") },
                singleLine = true,
                isError = text.isNotEmpty() && !valid,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
            )
        },
        confirmButton = { TextButton(enabled = valid, onClick = { onGo(n!! - 1) }) { Text("Go") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
private fun PageItem(doc: PdfDoc, index: Int, widthPx: Int, night: Boolean) {
    var bmp by remember(doc, index) { mutableStateOf<Bitmap?>(null) }
    LaunchedEffect(doc, index, widthPx) {
        val fresh = withContext(Dispatchers.IO) { renderPage(doc, index, widthPx) }
        // Keep showing the old picture until the sharper one is ready (no flashing while zooming).
        if (fresh != null) bmp = fresh
    }
    val b = bmp
    if (b == null) {
        Box(
            Modifier.fillMaxWidth().aspectRatio(0.707f).background(Color.White),
            contentAlignment = Alignment.Center
        ) { CircularProgressIndicator(strokeWidth = 2.dp, modifier = Modifier.size(24.dp)) }
    } else {
        Image(
            bitmap = b.asImageBitmap(),
            contentDescription = "Page ${index + 1}",
            modifier = Modifier.fillMaxWidth().aspectRatio(b.width.toFloat() / b.height),
            contentScale = ContentScale.FillWidth,
            colorFilter = if (night) InvertFilter else null
        )
    }
}
