package com.aipdfstudio.app.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPage
import com.tom_roush.pdfbox.pdmodel.PDPageContentStream
import com.tom_roush.pdfbox.pdmodel.common.PDRectangle
import com.tom_roush.pdfbox.pdmodel.graphics.image.JPEGFactory
import com.tom_roush.pdfbox.pdmodel.interactive.form.PDCheckBox
import com.tom_roush.pdfbox.pdmodel.interactive.form.PDChoice
import com.tom_roush.pdfbox.pdmodel.interactive.form.PDField
import com.tom_roush.pdfbox.pdmodel.interactive.form.PDPushButton
import com.tom_roush.pdfbox.pdmodel.interactive.form.PDRadioButton
import com.tom_roush.pdfbox.pdmodel.interactive.form.PDSignatureField
import com.tom_roush.pdfbox.pdmodel.interactive.form.PDTextField
import java.io.File
import java.io.IOException
import kotlin.math.max
import kotlin.math.min

// ---------------------------------------------------------------- Forms

enum class FieldType { TEXT, MULTILINE, CHECKBOX, RADIO, CHOICE }

/** A fillable field. For CHECKBOX the value is "true"/"false". */
data class FormField(
    val name: String,
    val label: String,
    val type: FieldType,
    val value: String,
    val options: List<String> = emptyList(),
    val readOnly: Boolean = false
)

object FormOps {
    private fun label(f: PDField): String =
        (f.alternateFieldName?.takeIf { it.isNotBlank() } ?: f.partialName ?: f.fullyQualifiedName)
            .replace('_', ' ').trim()

    fun fields(doc: PDDocument): List<FormField> {
        val form = doc.documentCatalog.acroForm ?: return emptyList()
        val out = ArrayList<FormField>()
        for (f in form.fieldTree) {
            val name = f.fullyQualifiedName ?: continue
            val ro = f.isReadOnly
            when (f) {
                is PDSignatureField, is PDPushButton -> Unit
                is PDTextField -> out.add(
                    FormField(name, label(f), if (f.isMultiline) FieldType.MULTILINE else FieldType.TEXT, f.value ?: "", readOnly = ro)
                )
                is PDCheckBox -> out.add(FormField(name, label(f), FieldType.CHECKBOX, f.isChecked.toString(), readOnly = ro))
                is PDRadioButton -> {
                    val opts = f.onValues.toList().ifEmpty { f.exportValues }
                    out.add(FormField(name, label(f), FieldType.RADIO, f.value ?: "", opts, ro))
                }
                is PDChoice -> out.add(
                    FormField(name, label(f), FieldType.CHOICE, f.value.firstOrNull() ?: "", f.options, ro)
                )
                else -> Unit
            }
        }
        return out
    }

    /** Sets values (name -> value). Unknown names are ignored. */
    fun fill(doc: PDDocument, values: Map<String, String>, flatten: Boolean) {
        val form = doc.documentCatalog.acroForm ?: throw UserError("This PDF has no fillable fields.")
        for ((name, v) in values) {
            val f = form.getField(name) ?: continue
            if (f.isReadOnly) continue
            when (f) {
                is PDTextField -> f.value = v
                is PDCheckBox -> if (v == "true") f.check() else f.unCheck()
                is PDRadioButton -> if (v.isNotBlank()) f.value = v
                is PDChoice -> if (v.isNotBlank()) f.setValue(v)
                else -> Unit
            }
        }
        if (flatten) form.flatten()
    }

    fun read(ctx: Context, uri: Uri): List<FormField> {
        val doc = PdfOps.load(ctx, uri)
        try {
            val form = doc.documentCatalog.acroForm
            val list = fields(doc)
            if (list.isEmpty()) {
                if (form != null && form.xfa != null) {
                    throw UserError("This form uses a special Adobe format (XFA) that phones can't fill. Use Smart edit to type on it instead.")
                }
                throw UserError("This PDF has no fillable fields. Use Smart edit → Add text to type on it instead.")
            }
            return list
        } finally {
            doc.close()
        }
    }

    fun save(ctx: Context, uri: Uri, values: Map<String, String>, flatten: Boolean, out: File) {
        val doc = PdfOps.load(ctx, uri)
        try {
            fill(doc, values, flatten)
            try {
                doc.save(out)
            } catch (e: Throwable) {
                out.delete()
                throw e
            }
        } finally {
            doc.close()
        }
    }
}

// ---------------------------------------------------------------- Compare

enum class DiffKind { SAME, ADDED, REMOVED }

data class DiffLine(val kind: DiffKind, val text: String)

data class PageDiff(val page: Int, val lines: List<DiffLine>) {
    val added get() = lines.count { it.kind == DiffKind.ADDED }
    val removed get() = lines.count { it.kind == DiffKind.REMOVED }
    val changed get() = added + removed > 0
}

object LineDiff {
    /** Line-by-line difference (longest common subsequence). Whitespace inside lines is normalised. */
    fun diff(a: List<String>, b: List<String>): List<DiffLine> {
        val x = a.map { it.trim().replace(Regex("\\s+"), " ") }.filter { it.isNotEmpty() }
        val y = b.map { it.trim().replace(Regex("\\s+"), " ") }.filter { it.isNotEmpty() }
        val n = x.size
        val m = y.size
        if (n.toLong() * m > 4_000_000L) {
            // Too big to compare line by line: report as fully replaced.
            return x.map { DiffLine(DiffKind.REMOVED, it) } + y.map { DiffLine(DiffKind.ADDED, it) }
        }
        val dp = Array(n + 1) { IntArray(m + 1) }
        for (i in n - 1 downTo 0) for (j in m - 1 downTo 0) {
            dp[i][j] = if (x[i] == y[j]) dp[i + 1][j + 1] + 1 else max(dp[i + 1][j], dp[i][j + 1])
        }
        val out = ArrayList<DiffLine>()
        var i = 0
        var j = 0
        while (i < n && j < m) {
            when {
                x[i] == y[j] -> { out.add(DiffLine(DiffKind.SAME, x[i])); i++; j++ }
                dp[i + 1][j] >= dp[i][j + 1] -> { out.add(DiffLine(DiffKind.REMOVED, x[i])); i++ }
                else -> { out.add(DiffLine(DiffKind.ADDED, y[j])); j++ }
            }
        }
        while (i < n) out.add(DiffLine(DiffKind.REMOVED, x[i++]))
        while (j < m) out.add(DiffLine(DiffKind.ADDED, y[j++]))
        return out
    }
}

object CompareOps {
    /** Compares page N with page N. Extra pages count as fully added/removed. */
    fun compareText(a: PDDocument, b: PDDocument): List<PageDiff> {
        val ta = ConvertOps.pageTexts(a)
        val tb = ConvertOps.pageTexts(b)
        return (0 until max(ta.size, tb.size)).map { i ->
            PageDiff(i, LineDiff.diff(ta.getOrNull(i)?.lines() ?: emptyList(), tb.getOrNull(i)?.lines() ?: emptyList()))
        }
    }

    fun report(nameA: String, nameB: String, diffs: List<PageDiff>): String = buildString {
        append("Comparison\nOriginal: $nameA\nChanged:  $nameB\n\n")
        val changed = diffs.filter { it.changed }
        if (changed.isEmpty()) append("No text differences found.\n")
        changed.forEach { d ->
            append("Page ${d.page + 1}: ${d.added} added, ${d.removed} removed\n")
            d.lines.filter { it.kind != DiffKind.SAME }.forEach {
                append(if (it.kind == DiffKind.ADDED) "  + " else "  - ").append(it.text).append('\n')
            }
            append('\n')
        }
    }

    fun text(ctx: Context, a: Uri, b: Uri): List<PageDiff> {
        val da = PdfOps.load(ctx, a)
        try {
            val db = PdfOps.load(ctx, b)
            try {
                val diffs = compareText(da, db)
                if (ConvertOps.pageTexts(da).all { it.isBlank() } && ConvertOps.pageTexts(db).all { it.isBlank() }) {
                    throw UserError("These PDFs have no text to compare (they look like scans). Turn on the visual comparison instead.")
                }
                return diffs
            } finally {
                db.close()
            }
        } finally {
            da.close()
        }
    }

    /**
     * Makes a PDF where each page shows the changed version with differences marked in red.
     * Returns how many pages had visible differences.
     */
    fun visual(ctx: Context, a: Uri, b: Uri, out: File, progress: (String) -> Unit): Int {
        val pa = ctx.contentResolver.openFileDescriptor(a, "r") ?: throw IOException("Can't open the first file")
        val pb = ctx.contentResolver.openFileDescriptor(b, "r") ?: throw IOException("Can't open the second file")
        val doc = PDDocument()
        var changedPages = 0
        try {
            val ra = PdfRenderer(pa)
            val rb = PdfRenderer(pb)
            try {
                val n = max(ra.pageCount, rb.pageCount)
                for (i in 0 until n) {
                    progress("Comparing page ${i + 1} of $n")
                    val width = 1100
                    val ba = if (i < ra.pageCount) render(ra, i, width) else null
                    val bb = if (i < rb.pageCount) render(rb, i, width) else null
                    val base = bb ?: ba ?: continue
                    val outBmp = base.copy(Bitmap.Config.ARGB_8888, true)
                    var diffPixels = 0
                    if (ba == null || bb == null) {
                        diffPixels = 1
                        tint(outBmp, 0x55FF0000)
                    } else {
                        val w = min(ba.width, bb.width)
                        val h = min(ba.height, bb.height)
                        val rowA = IntArray(w)
                        val rowB = IntArray(w)
                        val rowO = IntArray(w)
                        for (y in 0 until h) {
                            ba.getPixels(rowA, 0, w, 0, y, w, 1)
                            bb.getPixels(rowB, 0, w, 0, y, w, 1)
                            outBmp.getPixels(rowO, 0, w, 0, y, w, 1)
                            var touched = false
                            for (x in 0 until w) {
                                val ca = rowA[x]
                                val cb = rowB[x]
                                val d = Math.abs(Color.red(ca) - Color.red(cb)) + Math.abs(Color.green(ca) - Color.green(cb)) + Math.abs(Color.blue(ca) - Color.blue(cb))
                                if (d > 90) {
                                    diffPixels++
                                    rowO[x] = Color.rgb(230, 20, 20)
                                    touched = true
                                } else {
                                    // Fade unchanged areas so the red stands out.
                                    val c = rowO[x]
                                    rowO[x] = Color.rgb(
                                        255 - (255 - Color.red(c)) * 2 / 5,
                                        255 - (255 - Color.green(c)) * 2 / 5,
                                        255 - (255 - Color.blue(c)) * 2 / 5
                                    )
                                    touched = true
                                }
                            }
                            if (touched) outBmp.setPixels(rowO, 0, w, 0, y, w, 1)
                        }
                    }
                    if (diffPixels > 0) changedPages++
                    val img = JPEGFactory.createFromImage(doc, outBmp, 0.85f)
                    val pw = 595f
                    val ph = pw * outBmp.height / outBmp.width
                    val page = PDPage(PDRectangle(pw, ph))
                    doc.addPage(page)
                    PDPageContentStream(doc, page).use { it.drawImage(img, 0f, 0f, pw, ph) }
                    outBmp.recycle()
                    ba?.recycle()
                    bb?.recycle()
                }
            } finally {
                ra.close()
                rb.close()
            }
            try {
                doc.save(out)
            } catch (e: Throwable) {
                out.delete()
                throw e
            }
            return changedPages
        } catch (e: SecurityException) {
            throw UserError("One of these PDFs is password protected. Unlock it first.")
        } finally {
            doc.close()
            try { pa.close() } catch (ignored: Exception) {}
            try { pb.close() } catch (ignored: Exception) {}
        }
    }

    private fun render(r: PdfRenderer, i: Int, width: Int): Bitmap {
        val p = r.openPage(i)
        try {
            val h = max(1, (width.toFloat() * p.height / p.width).toInt())
            val bmp = Bitmap.createBitmap(width, h, Bitmap.Config.ARGB_8888)
            bmp.eraseColor(Color.WHITE)
            p.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            return bmp
        } finally {
            p.close()
        }
    }

    private fun tint(bmp: Bitmap, argb: Int) {
        android.graphics.Canvas(bmp).drawColor(argb)
    }
}
