package com.aipdfstudio.app.data

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKeys

const val DEFAULT_MODEL = "gemini-flash-latest"

/** Stores the user's own Gemini key encrypted on the device. */
class SecureStore(context: Context) {
    private val sp: SharedPreferences = try {
        // security-crypto 1.0.0 API: master key alias from MasterKeys.
        val alias = MasterKeys.getOrCreate(MasterKeys.AES256_GCM_SPEC)
        EncryptedSharedPreferences.create(
            "secure_prefs",
            alias,
            context.applicationContext,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    } catch (e: Exception) {
        context.applicationContext.getSharedPreferences("secure_prefs_fallback", Context.MODE_PRIVATE)
    }

    var apiKey: String
        get() = sp.getString("gemini_key", "") ?: ""
        set(v) = sp.edit().putString("gemini_key", v.trim()).apply()

    var model: String
        get() = (sp.getString("gemini_model", DEFAULT_MODEL) ?: DEFAULT_MODEL).ifBlank { DEFAULT_MODEL }
        set(v) = sp.edit().putString("gemini_model", v.trim().ifBlank { DEFAULT_MODEL }).apply()
}
