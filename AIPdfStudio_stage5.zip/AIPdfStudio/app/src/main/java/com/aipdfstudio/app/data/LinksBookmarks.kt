package com.aipdfstudio.app.data

import android.content.Context
import android.net.Uri
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.interactive.documentnavigation.outline.PDOutlineItem
import com.tom_roush.pdfbox.pdmodel.interactive.documentnavigation.outline.PDOutlineNode
import org.json.JSONArray
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLDecoder

// ---------------------------------------------------------------- Cloud links

object CloudLinks {
    private const val MAX_BYTES = 200L * 1024 * 1024

    /** Turns share links from Google Drive and Dropbox into direct download links. */
    fun directUrl(link: String): String {
        val s = link.trim()
        Regex("""drive\.google\.com/(?:file/d/|open\?id=|uc\?(?:.*&)?id=)([\w-]{10,})""").find(s)?.let {
            return "https://drive.usercontent.google.com/download?id=${it.groupValues[1]}&export=download&confirm=t"
        }
        Regex("""docs\.google\.com/(?:document|spreadsheets|presentation)/d/([\w-]{10,})""").find(s)?.let {
            val kind = Regex("""docs\.google\.com/(\w+)/""").find(s)!!.groupValues[1]
            return "https://docs.google.com/$kind/d/${it.groupValues[1]}/export?format=pdf"
        }
        if (s.contains("dropbox.com/")) {
            val noDl = s.replace(Regex("""([?&])dl=0"""), "$1dl=1")
            return if (Regex("""[?&]dl=1""").containsMatchIn(noDl)) noDl
            else noDl + (if (noDl.contains('?')) "&" else "?") + "dl=1"
        }
        return s
    }

    fun isWebLink(s: String) = Regex("""^https?://\S+$""", RegexOption.IGNORE_CASE).matches(s.trim())

    /** Picks a file name from the Content-Disposition header or the URL. */
    fun fileName(contentDisposition: String?, url: String): String {
        val fromHeader = contentDisposition?.let { cd ->
            Regex("""filename\*=UTF-8''([^;]+)""", RegexOption.IGNORE_CASE).find(cd)?.groupValues?.get(1)?.let {
                try { URLDecoder.decode(it, "UTF-8") } catch (e: Exception) { it }
            } ?: Regex("""filename="?([^";]+)"?""", RegexOption.IGNORE_CASE).find(cd)?.groupValues?.get(1)
        }
        val fromUrl = url.substringBefore('?').substringAfterLast('/').let {
            try { URLDecoder.decode(it, "UTF-8") } catch (e: Exception) { it }
        }
        val name = (fromHeader ?: fromUrl).replace(Regex("""[\\/:*?"<>|]"""), "_").trim()
        val base = name.ifBlank { "Downloaded" }.take(80)
        return if (base.endsWith(".pdf", ignoreCase = true)) base else "$base.pdf"
    }

    /** Downloads a PDF from a link into the app's storage. Blocking: call on Dispatchers.IO. */
    fun download(ctx: Context, link: String, progress: (String) -> Unit): File {
        if (!isWebLink(link)) throw UserError("Paste a full link that starts with https://")
        var url = directUrl(link)
        var conn: HttpURLConnection? = null
        try {
            var hops = 0
            while (true) {
                val c = URL(url).openConnection() as HttpURLConnection
                c.instanceFollowRedirects = false
                c.connectTimeout = 20000
                c.readTimeout = 30000
                c.setRequestProperty("User-Agent", "AIPdfStudio/1.0 (Android)")
                val code = c.responseCode
                if (code in 300..399) {
                    val next = c.getHeaderField("Location") ?: throw IOException("Bad redirect")
                    c.disconnect()
                    url = URL(URL(url), next).toString()
                    if (++hops > 8) throw UserError("This link redirects too many times.")
                    continue
                }
                if (code == 401 || code == 403) throw UserError("This file is private. Make it shared with \"Anyone with the link\" and try again.")
                if (code == 404) throw UserError("Nothing found at this link. Check that it's correct.")
                if (code !in 200..299) throw UserError("The server answered with error $code. Try again later.")
                conn = c
                break
            }
            val c = conn!!
            val total = c.contentLengthLong
            if (total > MAX_BYTES) throw UserError("This file is bigger than 200 MB.")
            val dir = File(ctx.filesDir, "downloads").apply { mkdirs() }
            var f = File(dir, fileName(c.getHeaderField("Content-Disposition"), url))
            var n = 2
            while (f.exists()) {
                f = File(dir, f.nameWithoutExtension.replace(Regex("""_\d+$"""), "") + "_$n.pdf")
                n++
            }
            try {
                c.inputStream.use { input ->
                    f.outputStream().use { out ->
                        val buf = ByteArray(64 * 1024)
                        var done = 0L
                        var first = true
                        while (true) {
                            val r = input.read(buf)
                            if (r < 0) break
                            if (first) {
                                first = false
                                val head = String(buf, 0, minOf(r, 1024), Charsets.ISO_8859_1)
                                if (!head.contains("%PDF")) {
                                    throw UserError(
                                        "This link doesn't lead to a PDF file. It may need sign-in or not be shared publicly."
                                    )
                                }
                            }
                            out.write(buf, 0, r)
                            done += r
                            if (done > MAX_BYTES) throw UserError("This file is bigger than 200 MB.")
                            progress(
                                if (total > 0) "Downloading ${done * 100 / total}%" else "Downloading ${fmtSize(done)}"
                            )
                        }
                    }
                }
            } catch (e: Throwable) {
                f.delete()
                throw e
            }
            return f
        } catch (e: UserError) {
            throw e
        } catch (e: java.net.UnknownHostException) {
            throw UserError("No internet connection, or the website can't be found.")
        } catch (e: java.net.SocketTimeoutException) {
            throw UserError("The download took too long. Check your internet and try again.")
        } finally {
            conn?.disconnect()
        }
    }

    /** Copies a PDF another app shared with us into our storage (their permission is temporary). */
    fun importShared(ctx: Context, uri: Uri): File {
        val dir = File(ctx.filesDir, "downloads").apply { mkdirs() }
        val name = queryName(ctx, uri).let { if (it.endsWith(".pdf", true)) it else "$it.pdf" }
            .replace(Regex("""[\\/:*?"<>|]"""), "_")
        var f = File(dir, name)
        var n = 2
        while (f.exists()) {
            f = File(dir, name.removeSuffix(".pdf").removeSuffix(".PDF") + "_$n.pdf")
            n++
        }
        val input = ctx.contentResolver.openInputStream(uri) ?: throw IOException("Can't read the shared file")
        input.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
        return f
    }
}

// ---------------------------------------------------------------- Bookmarks and contents

data class OutlineEntry(val title: String, val page: Int, val level: Int)

object Outline {
    /** The PDF's own table of contents, flattened with indent levels. */
    fun read(doc: PDDocument, maxEntries: Int = 500): List<OutlineEntry> {
        val root = doc.documentCatalog.documentOutline ?: return emptyList()
        val out = ArrayList<OutlineEntry>()
        fun walk(node: PDOutlineNode, level: Int) {
            for (item: PDOutlineItem in node.children()) {
                if (out.size >= maxEntries) return
                val page = try {
                    item.findDestinationPage(doc)?.let { doc.pages.indexOf(it) } ?: -1
                } catch (e: Exception) {
                    -1
                }
                val title = item.title?.trim().orEmpty()
                if (title.isNotEmpty()) out.add(OutlineEntry(title, page, level))
                if (level < 6) walk(item, level + 1)
            }
        }
        walk(root, 0)
        return out
    }

    fun read(ctx: Context, uri: Uri): List<OutlineEntry> = try {
        PdfOps.load(ctx, uri).use { read(it) }
    } catch (e: Exception) {
        emptyList()
    }
}

/** Pages the user starred, per file. */
class BookmarkStore(context: Context) {
    private val sp = context.applicationContext.getSharedPreferences("bookmarks", Context.MODE_PRIVATE)

    fun get(uri: String): List<Int> = try {
        val a = JSONArray(sp.getString(uri, "[]"))
        (0 until a.length()).map { a.getInt(it) }.sorted()
    } catch (e: Exception) {
        emptyList()
    }

    fun toggle(uri: String, page: Int): List<Int> {
        val now = get(uri).toMutableList()
        if (!now.remove(page)) now.add(page)
        val a = JSONArray()
        now.sorted().forEach { a.put(it) }
        sp.edit().putString(uri, a.toString()).apply()
        return now.sorted()
    }
}

// ---------------------------------------------------------------- Ads and Premium (switched off)

/**
 * Money switches. Both are OFF: the app shows no ads and every feature is free.
 * See README "Turning on ads and Premium" before changing these.
 */
object Monetization {
    const val ADS_ENABLED = false
    const val PREMIUM_ENABLED = false

    val premiumPerks = listOf(
        "No ads",
        "Batch tools: compress or convert many files at once",
        "Priority support",
        "Support future updates"
    )
}
