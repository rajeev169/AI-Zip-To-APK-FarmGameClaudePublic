@file:OptIn(ExperimentalMaterial3Api::class)

package com.aipdfstudio.app.ui

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateCentroid
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.requiredWidth
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.HelpOutline
import androidx.compose.material.icons.automirrored.outlined.Redo
import androidx.compose.material.icons.automirrored.outlined.Undo
import androidx.compose.material.icons.outlined.AddPhotoAlternate
import androidx.compose.material.icons.outlined.Apps
import androidx.compose.material.icons.outlined.ArrowDropDown
import androidx.compose.material.icons.outlined.BorderColor
import androidx.compose.material.icons.outlined.CalendarToday
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.Circle
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.CropSquare
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Done
import androidx.compose.material.icons.outlined.Draw
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.EditNote
import androidx.compose.material.icons.outlined.FontDownload
import androidx.compose.material.icons.outlined.FormatBold
import androidx.compose.material.icons.outlined.FormatItalic
import androidx.compose.material.icons.outlined.FormatStrikethrough
import androidx.compose.material.icons.outlined.FormatUnderlined
import androidx.compose.material.icons.outlined.Gesture
import androidx.compose.material.icons.outlined.HorizontalRule
import androidx.compose.material.icons.outlined.NorthEast
import androidx.compose.material.icons.outlined.OpenWith
import androidx.compose.material.icons.outlined.TextDecrease
import androidx.compose.material.icons.outlined.TextFields
import androidx.compose.material.icons.outlined.TextIncrease
import androidx.compose.material.icons.outlined.Title
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.aipdfstudio.app.data.EdObj
import com.aipdfstudio.app.data.FBox
import com.aipdfstudio.app.data.Family
import com.aipdfstudio.app.data.ImageObj
import com.aipdfstudio.app.data.InkObj
import com.aipdfstudio.app.data.MarkKind
import com.aipdfstudio.app.data.MarkObj
import com.aipdfstudio.app.data.NoteObj
import com.aipdfstudio.app.data.ParaObj
import com.aipdfstudio.app.data.ShapeKind
import com.aipdfstudio.app.data.ShapeObj
import com.aipdfstudio.app.data.Signatures
import com.aipdfstudio.app.data.TStyle
import com.aipdfstudio.app.data.TextObj
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

private fun col(c: Int, alpha: Float = 1f) = Color(0xFF000000.toInt() or c).copy(alpha = alpha)

private fun family(f: Family) = when (f) {
    Family.SERIF -> FontFamily.Serif
    Family.MONO -> FontFamily.Monospace
    Family.SANS -> FontFamily.SansSerif
}

/** Compose text style matching a PDF style, with [pxPerPt] screen pixels per PDF point. */
private fun textStyle(s: TStyle, pxPerPt: Float, lineGapPt: Float, density: Density) = with(density) {
    TextStyle(
        fontFamily = family(s.family),
        fontWeight = if (s.bold) FontWeight.Bold else FontWeight.Normal,
        fontStyle = if (s.italic) FontStyle.Italic else FontStyle.Normal,
        fontSize = (s.sizePt * pxPerPt).toSp(),
        lineHeight = (lineGapPt * pxPerPt).toSp(),
        color = col(s.color)
    )
}

private const val MIN_Z = 1f
private const val MAX_Z = 4f

@Composable
fun EditorScreen(
    uri: Uri,
    onClose: () -> Unit,
    onOpenTool: (route: String, uri: Uri) -> Unit,
    vm: EditorVm = viewModel()
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    LaunchedEffect(uri) { vm.open(uri) }

    var zoom by remember { mutableFloatStateOf(1f) }
    var gesture by remember { mutableFloatStateOf(1f) }
    var pivot by remember { mutableStateOf(Offset.Zero) }
    var viewport by remember { mutableStateOf(IntSize(1, 1)) }
    val zoomNow by rememberUpdatedState(zoom)
    val listState = rememberLazyListState()
    val hScroll = rememberScrollState()

    var confirmLeave by remember { mutableStateOf<(() -> Unit)?>(null) }
    var showMore by remember { mutableStateOf(false) }
    var showHelp by remember { mutableStateOf(false) }
    var showSaveMenu by remember { mutableStateOf(false) }
    var showSigPad by remember { mutableStateOf(false) }
    var noteEdit by remember { mutableStateOf<NoteObj?>(null) }
    var hint by remember { mutableStateOf<String?>(null) }

    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) scope.launch {
            val path = withContext(Dispatchers.IO) { vm.copyImage(u) }
            vm.pendingImage = path
            vm.tool = EdTool.INSERT_IMAGE
            if (path != null) hint = "Tap the page where the picture should go"
        }
    }

    fun leave(action: () -> Unit) {
        vm.setSelected(null)
        if (vm.dirty) confirmLeave = action else action()
    }
    BackHandler { leave(onClose) }

    // Hints like the "Tap any content to edit" bubble.
    LaunchedEffect(vm.mode, vm.tool) {
        hint = when (vm.tool) {
            EdTool.EDIT_TEXT -> "Tap any content to edit"
            EdTool.INSERT_TEXT, EdTool.FILL_TEXT -> "Tap where the text should go"
            EdTool.HIGHLIGHT, EdTool.UNDERLINE, EdTool.STRIKE -> "Drag over the text. Use two fingers to scroll."
            EdTool.PEN -> "Draw with one finger. Use two fingers to scroll."
            EdTool.RECT, EdTool.OVAL, EdTool.LINE, EdTool.ARROW -> "Drag to draw. Use two fingers to scroll."
            EdTool.NOTE -> "Tap to add a note"
            EdTool.SIGN -> "Tap the page to place your signature"
            EdTool.CHECK, EdTool.CROSS, EdTool.DOT, EdTool.DATE -> "Tap where it should go"
            EdTool.INSERT_IMAGE -> if (vm.pendingImage == null) null else "Tap the page where the picture should go"
        }
    }
    LaunchedEffect(hint) { if (hint != null) { delay(2600); hint = null } }
    LaunchedEffect(vm.toast) { if (vm.toast != null) { delay(2600); vm.toast = null } }
    // A new sticky note asks for its text.
    val sel = vm.selected
    LaunchedEffect(sel?.id) { if (sel is NoteObj && sel.text.isBlank()) noteEdit = sel }

    fun commitZoom(factor: Float, focus: Offset) {
        val old = zoomNow
        val new = (old * factor).coerceIn(MIN_Z, MAX_Z)
        gesture = 1f
        val f = new / old
        if (abs(f - 1f) < 0.01f) return
        val index = listState.firstVisibleItemIndex
        val off = listState.firstVisibleItemScrollOffset
        val hx = hScroll.value
        zoom = new
        scope.launch {
            withFrameNanos { }
            val newOff = (off + focus.y) * f - focus.y
            listState.scrollToItem(index, max(0, newOff.roundToInt()))
            if (newOff < 0) listState.scrollBy(newOff)
            withFrameNanos { }
            hScroll.scrollTo(((hx + focus.x) * f - focus.x).roundToInt().coerceIn(0, hScroll.maxValue.coerceAtLeast(0)))
        }
    }

    val cfg = LocalConfiguration.current
    val density = LocalDensity.current
    val pageWidthDp = (cfg.screenWidthDp * zoom).dp
    val renderPx = with(density) { pageWidthDp.roundToPx() }.coerceAtMost(2200)

    Scaffold(
        topBar = {
            Surface(color = MaterialTheme.colorScheme.surface, shadowElevation = 2.dp) {
                Row(
                    Modifier.fillMaxWidth().statusBarsPadding().height(56.dp).padding(horizontal = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { leave(onClose) }) { Icon(Icons.Outlined.Close, contentDescription = "Close") }
                    IconButton(onClick = { showHelp = true }) { Icon(Icons.AutoMirrored.Outlined.HelpOutline, contentDescription = "Help") }
                    Text(vm.name, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f).padding(horizontal = 4.dp))
                    IconButton(onClick = { vm.setSelected(null); vm.undo() }, enabled = vm.canUndo) {
                        Icon(Icons.AutoMirrored.Outlined.Undo, contentDescription = "Undo")
                    }
                    IconButton(onClick = { vm.redo() }, enabled = vm.canRedo) {
                        Icon(Icons.AutoMirrored.Outlined.Redo, contentDescription = "Redo")
                    }
                    Box {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Button(
                                onClick = { vm.save(asCopy = false) },
                                enabled = vm.dirty && vm.busy == null,
                                contentPadding = PaddingValues(horizontal = 14.dp)
                            ) { Text("Save") }
                            IconButton(onClick = { showSaveMenu = true }) { Icon(Icons.Outlined.ArrowDropDown, contentDescription = "More save options") }
                        }
                        DropdownMenu(expanded = showSaveMenu, onDismissRequest = { showSaveMenu = false }) {
                            DropdownMenuItem(text = { Text("Save") }, enabled = vm.dirty, onClick = { showSaveMenu = false; vm.save(false) })
                            DropdownMenuItem(text = { Text("Save as a copy") }, enabled = vm.dirty, onClick = { showSaveMenu = false; vm.save(true) })
                            DropdownMenuItem(text = { Text("Share") }, onClick = { showSaveMenu = false; leave { vm.share() } })
                        }
                    }
                }
            }
        },
        bottomBar = {
            Surface(color = MaterialTheme.colorScheme.surfaceContainer, shadowElevation = 6.dp) {
                Column(Modifier.fillMaxWidth().navigationBarsPadding().imePadding()) {
                    val s = vm.selected
                    when {
                        s is ParaObj || s is TextObj -> TextFormatBar(vm, s)
                        s != null -> ObjectBar(vm, s, onEditNote = { if (s is NoteObj) noteEdit = s })
                        else -> ToolRow(
                            vm,
                            onPickImage = { imagePicker.launch(arrayOf("image/*")) },
                            onNewSignature = { showSigPad = true },
                            onFormFields = { leave { vm.uri?.let { onOpenTool("forms", it) } } }
                        )
                    }
                    if (s !is ParaObj && s !is TextObj) {
                        HorizontalDivider()
                        ModeBar(vm) { m ->
                            if (m == EdMode.MORE) showMore = true
                            else {
                                vm.setSelected(null)
                                vm.mode = m
                                vm.tool = EdTool.entries.first { it.mode == m }
                            }
                        }
                    }
                }
            }
        }
    ) { pad ->
        Box(Modifier.fillMaxSize().padding(pad).background(MaterialTheme.colorScheme.surfaceContainerHigh)) {
            val err = vm.error
            when {
                err != null -> Column(Modifier.fillMaxSize().padding(32.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(err)
                    Spacer(Modifier.height(16.dp))
                    Button(onClick = onClose) { Text("Go back") }
                }
                vm.aspects.isEmpty() -> CircularProgressIndicator(Modifier.align(Alignment.Center))
                else -> Box(
                    Modifier
                        .fillMaxSize()
                        .onSizeChanged { viewport = it }
                        .pointerInput(Unit) {
                            // Two fingers: zoom and scroll (one finger is for the tools).
                            awaitEachGesture {
                                awaitFirstDown(requireUnconsumed = false)
                                var pinching = false
                                var scale = 1f
                                var center = Offset.Zero
                                do {
                                    val event = awaitPointerEvent(PointerEventPass.Initial)
                                    if (event.changes.count { it.pressed } >= 2) {
                                        if (!pinching) {
                                            pinching = true
                                            center = event.calculateCentroid(useCurrent = true)
                                            pivot = center
                                        }
                                        scale = (scale * event.calculateZoom()).coerceIn(MIN_Z / zoomNow, MAX_Z / zoomNow)
                                        gesture = scale
                                        val pan = event.calculatePan()
                                        listState.dispatchRawDelta(-pan.y)
                                        hScroll.dispatchRawDelta(-pan.x)
                                        event.changes.forEach { if (it.positionChanged()) it.consume() }
                                    }
                                } while (event.changes.any { it.pressed })
                                if (pinching) commitZoom(scale, center)
                            }
                        }
                ) {
                    Box(
                        Modifier
                            .fillMaxSize()
                            .graphicsLayer {
                                scaleX = gesture
                                scaleY = gesture
                                transformOrigin = TransformOrigin(
                                    (pivot.x / viewport.width.coerceAtLeast(1)).coerceIn(0f, 1f),
                                    (pivot.y / viewport.height.coerceAtLeast(1)).coerceIn(0f, 1f)
                                )
                            }
                            .horizontalScroll(hScroll)
                    ) {
                        LazyColumn(
                            state = listState,
                            modifier = Modifier.width(pageWidthDp).fillMaxHeight(),
                            contentPadding = PaddingValues(vertical = 10.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            items(vm.aspects.size) { i -> EditorPage(vm, i, renderPx) }
                        }
                    }
                }
            }

            // Bubbles at the top: hints, results.
            val bubble = vm.toast ?: hint
            if (bubble != null) {
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = if (vm.toast != null) MaterialTheme.colorScheme.inverseSurface else MaterialTheme.colorScheme.primary,
                    modifier = Modifier.align(Alignment.TopCenter).padding(top = 10.dp)
                ) {
                    Row(Modifier.padding(horizontal = 14.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        if (vm.toast?.startsWith("Saved") == true) {
                            Icon(Icons.Outlined.Check, contentDescription = null, tint = MaterialTheme.colorScheme.inverseOnSurface, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                        }
                        Text(
                            bubble,
                            color = if (vm.toast != null) MaterialTheme.colorScheme.inverseOnSurface else MaterialTheme.colorScheme.onPrimary,
                            style = MaterialTheme.typography.labelLarge
                        )
                    }
                }
            }
            if (zoom > 1.01f) {
                Surface(
                    shape = CircleShape,
                    color = MaterialTheme.colorScheme.secondaryContainer,
                    modifier = Modifier.align(Alignment.BottomStart).padding(12.dp).clickable { commitZoom(1f / zoom, Offset.Zero) }
                ) { Text("${(zoom * 100).roundToInt()}%  ✕", modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp), style = MaterialTheme.typography.labelLarge) }
            }
        }
    }

    vm.busy?.let { b ->
        AlertDialog(onDismissRequest = {}, confirmButton = {}, text = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(Modifier.size(28.dp), strokeWidth = 3.dp)
                Spacer(Modifier.width(16.dp))
                Text(b)
            }
        })
    }

    confirmLeave?.let { action ->
        AlertDialog(
            onDismissRequest = { confirmLeave = null },
            title = { Text("Save your changes?") },
            text = { Text("You have changes that aren't saved yet.") },
            confirmButton = {
                TextButton(onClick = { confirmLeave = null; vm.save(false) { action() } }) { Text("Save") }
            },
            dismissButton = {
                Row {
                    TextButton(onClick = { confirmLeave = null; action() }) { Text("Don't save") }
                    TextButton(onClick = { confirmLeave = null }) { Text("Cancel") }
                }
            }
        )
    }

    if (showMore) {
        MoreToolsSheet(onDismiss = { showMore = false }) { route ->
            showMore = false
            if (route == "share") leave { vm.share() } else leave { vm.uri?.let { onOpenTool(route, it) } }
        }
    }
    if (showHelp) HelpSheet { showHelp = false }
    if (showSigPad) {
        SignatureDialog(onDismiss = { showSigPad = false }) { bmp ->
            val f = Signatures.save(ctx, bmp)
            bmp.recycle()
            vm.signature = f
            vm.tool = EdTool.SIGN
            showSigPad = false
        }
    }
    noteEdit?.let { n ->
        var text by remember(n.id) { mutableStateOf(n.text) }
        AlertDialog(
            onDismissRequest = { noteEdit = null },
            title = { Text("Note") },
            text = { OutlinedTextField(value = text, onValueChange = { text = it }, minLines = 3, modifier = Modifier.fillMaxWidth()) },
            confirmButton = {
                TextButton(onClick = {
                    val cur = vm.objs.firstOrNull { it.id == n.id } as? NoteObj
                    if (cur != null) vm.change(cur.copy(text = text))
                    noteEdit = null
                }) { Text("Done") }
            },
            dismissButton = { TextButton(onClick = { noteEdit = null }) { Text("Cancel") } }
        )
    }
}

// ------------------------------------------------------------------ one page

@Composable
private fun EditorPage(vm: EditorVm, index: Int, renderPx: Int) {
    val aspect = vm.aspects.getOrElse(index) { 0.707f }
    var bmp by remember(index) { mutableStateOf<Bitmap?>(null) }
    LaunchedEffect(vm.version, index, renderPx) {
        val b = withContext(Dispatchers.IO) { vm.pageBitmap(index, renderPx) }
        if (b != null) bmp = b
    }
    LaunchedEffect(index, vm.mode, vm.tool) {
        if (vm.mode == EdMode.EDIT) vm.ensureParagraphs(index)
        if (vm.tool == EdTool.HIGHLIGHT || vm.tool == EdTool.UNDERLINE || vm.tool == EdTool.STRIKE) vm.preloadText(index)
    }
    BoxWithConstraints(Modifier.fillMaxWidth().aspectRatio(aspect).background(Color.White)) {
        val density = LocalDensity.current
        val wPx = with(density) { maxWidth.toPx() }
        val hPx = with(density) { maxHeight.toPx() }
        val pageWpt = vm.pageSizes.getOrNull(index)?.first ?: 595f
        val pxPerPt = wPx / pageWpt
        val b = bmp
        if (b != null) Image(b.asImageBitmap(), contentDescription = "Page ${index + 1}", modifier = Modifier.fillMaxSize(), contentScale = ContentScale.FillBounds)
        else CircularProgressIndicator(Modifier.align(Alignment.Center).size(28.dp))

        // Dashed boxes around every paragraph in Edit text mode.
        val paras = vm.paragraphs[index]
        if (vm.tool == EdTool.EDIT_TEXT && vm.selectedId == null && paras != null) {
            val dash = PathEffect.dashPathEffect(floatArrayOf(10f, 8f))
            val c = MaterialTheme.colorScheme.outline
            Canvas(Modifier.fillMaxSize()) {
                paras.forEach { p ->
                    val bx = p.box.pad(0.004f, 0.003f)
                    drawRect(c, Offset(bx.l * size.width, bx.t * size.height), Size(bx.w * size.width, bx.h * size.height), style = Stroke(1.5f, pathEffect = dash))
                }
            }
        }

        // Things changed since the last preview picture, drawn approximately on top.
        val sel = vm.selectedId
        vm.objs.filter { it.page == index && it.id != sel && (it !is ParaObj || it.changed) && vm.inPreview[it.id] != it }.forEach { o ->
            Ghost(o, wPx, hPx, pxPerPt, b)
        }

        // Live drawing while dragging.
        var dragStart by remember { mutableStateOf<Offset?>(null) }
        var dragNow by remember { mutableStateOf<Offset?>(null) }
        val inkPts = remember { mutableStateListOf<Offset>() }
        var liveMarks by remember { mutableStateOf<List<FBox>>(emptyList()) }
        val tool = vm.tool
        Canvas(
            Modifier.fillMaxSize()
                .pointerInput(tool, index, wPx, hPx) {
                    detectTapGestures(onTap = { p -> vm.tap(index, p.x / wPx, p.y / hPx) })
                }
                .then(
                    if (tool.drags) Modifier.pointerInput(tool, index, wPx, hPx) {
                        detectDragGestures(
                            onDragStart = { p ->
                                vm.setSelected(null)
                                dragStart = p; dragNow = p
                                inkPts.clear(); inkPts.add(p)
                            },
                            onDragEnd = {
                                val s = dragStart
                                val e = dragNow
                                if (s != null && e != null) {
                                    when (tool) {
                                        EdTool.HIGHLIGHT, EdTool.UNDERLINE, EdTool.STRIKE -> vm.addMark(index, liveMarks)
                                        EdTool.PEN -> vm.addInk(index, inkPts.map { it.x / wPx to it.y / hPx })
                                        else -> vm.addShape(index, s.x / wPx, s.y / hPx, e.x / wPx, e.y / hPx)
                                    }
                                }
                                dragStart = null; dragNow = null; inkPts.clear(); liveMarks = emptyList()
                            },
                            onDragCancel = { dragStart = null; dragNow = null; inkPts.clear(); liveMarks = emptyList() }
                        ) { change, _ ->
                            change.consume()
                            dragNow = change.position
                            if (tool == EdTool.PEN) inkPts.add(change.position)
                            val s = dragStart
                            if (s != null && (tool == EdTool.HIGHLIGHT || tool == EdTool.UNDERLINE || tool == EdTool.STRIKE)) {
                                liveMarks = vm.selectText(index, s.x / wPx, s.y / hPx, change.position.x / wPx, change.position.y / hPx)
                            }
                        }
                    } else Modifier
                )
        ) {
            val s = dragStart
            val e = dragNow
            when (tool) {
                EdTool.HIGHLIGHT, EdTool.UNDERLINE, EdTool.STRIKE -> liveMarks.forEach { bx ->
                    drawRect(col(if (tool == EdTool.HIGHLIGHT) vm.markColor else vm.inkColor, 0.4f), Offset(bx.l * size.width, bx.t * size.height), Size(bx.w * size.width, bx.h * size.height))
                }
                EdTool.PEN -> if (inkPts.size > 1) {
                    val path = Path().apply { moveTo(inkPts[0].x, inkPts[0].y); inkPts.drop(1).forEach { lineTo(it.x, it.y) } }
                    drawPath(path, col(vm.inkColor), style = Stroke(vm.penWidth * pxPerPt, cap = StrokeCap.Round, join = StrokeJoin.Round))
                }
                else -> if (s != null && e != null) {
                    drawShape(
                        when (tool) { EdTool.OVAL -> ShapeKind.OVAL; EdTool.LINE -> ShapeKind.LINE; EdTool.ARROW -> ShapeKind.ARROW; else -> ShapeKind.RECT },
                        s, e, col(vm.inkColor), vm.penWidth * pxPerPt
                    )
                }
            }
        }

        // The selected item, editable.
        vm.selected?.takeIf { it.page == index }?.let { SelectedOverlay(vm, it, wPx, hPx, pxPerPt, b) }
    }
}

private fun sampleBg(b: Bitmap?, box: FBox): Color {
    if (b == null) return Color.White
    val x = ((box.l - 0.006f) * b.width).toInt().coerceIn(0, b.width - 1)
    val y = (((box.t + box.b) / 2) * b.height).toInt().coerceIn(0, b.height - 1)
    return Color(b.getPixel(x, y))
}

private fun DrawScope.drawShape(kind: ShapeKind, s: Offset, e: Offset, c: Color, w: Float) {
    val tl = Offset(min(s.x, e.x), min(s.y, e.y))
    val sz = Size(abs(e.x - s.x), abs(e.y - s.y))
    val st = Stroke(w, cap = StrokeCap.Round, join = StrokeJoin.Round)
    when (kind) {
        ShapeKind.RECT -> drawRect(c, tl, sz, style = st)
        ShapeKind.OVAL -> drawOval(c, tl, sz, style = st)
        ShapeKind.LINE -> drawLine(c, s, e, w, StrokeCap.Round)
        ShapeKind.ARROW -> {
            drawLine(c, s, e, w, StrokeCap.Round)
            val ang = atan2((e.y - s.y).toDouble(), (e.x - s.x).toDouble())
            val len = max(18f, w * 4f)
            val p = Path().apply {
                moveTo(e.x, e.y)
                lineTo((e.x - len * cos(ang - 0.45)).toFloat(), (e.y - len * sin(ang - 0.45)).toFloat())
                lineTo((e.x - len * cos(ang + 0.45)).toFloat(), (e.y - len * sin(ang + 0.45)).toFloat())
                close()
            }
            drawPath(p, c)
        }
        ShapeKind.CHECK -> drawPath(Path().apply {
            moveTo(tl.x, tl.y + sz.height * 0.55f); lineTo(tl.x + sz.width * 0.38f, tl.y + sz.height); lineTo(tl.x + sz.width, tl.y)
        }, c, style = st)
        ShapeKind.CROSS -> {
            drawLine(c, tl, Offset(tl.x + sz.width, tl.y + sz.height), w, StrokeCap.Round)
            drawLine(c, Offset(tl.x + sz.width, tl.y), Offset(tl.x, tl.y + sz.height), w, StrokeCap.Round)
        }
        ShapeKind.DOT -> drawOval(c, tl, sz)
    }
}

/** Approximate on-screen drawing of an item (the exact result is in the next preview picture). */
@Composable
private fun Ghost(o: EdObj, wPx: Float, hPx: Float, pxPerPt: Float, bmp: Bitmap?) {
    val density = LocalDensity.current
    fun dp(px: Float) = with(density) { px.toDp() }
    when (o) {
        is ParaObj -> {
            val bg = sampleBg(bmp, o.origBox)
            Box(Modifier.offset { IntOffset((o.origBox.l * wPx).roundToInt() - 3, (o.origBox.t * hPx).roundToInt() - 3) }
                .size(dp(o.origBox.w * wPx + 6), dp(o.origBox.h * hPx + 6)).background(bg))
            if (!o.deleted) {
                val gapPx = o.lineGapPt * pxPerPt * o.style.sizePt / o.origStyle.sizePt
                Text(
                    o.text,
                    style = textStyle(o.style, pxPerPt, o.lineGapPt * o.style.sizePt / o.origStyle.sizePt, density),
                    modifier = Modifier.offset { IntOffset((o.origBox.l * wPx).roundToInt(), (o.firstBaseline * hPx - 0.79f * gapPx).roundToInt()) }
                        .requiredWidth(dp(max(o.origBox.w, o.maxW) * wPx + o.style.sizePt * 0.6f * pxPerPt))
                )
            }
        }
        is TextObj -> Text(
            o.text,
            style = textStyle(o.style, pxPerPt, o.style.sizePt * 1.2f, density),
            modifier = Modifier.offset { IntOffset((o.l * wPx).roundToInt(), (o.t * hPx).roundToInt()) }.requiredWidth(dp(o.w * wPx))
        )
        is ImageObj -> {
            val img = remember(o.path) { decodeSmall(o.path) }
            if (img != null) Image(
                img.asImageBitmap(), contentDescription = null, contentScale = ContentScale.FillBounds,
                modifier = Modifier.offset { IntOffset((o.box.l * wPx).roundToInt(), (o.box.t * hPx).roundToInt()) }.size(dp(o.box.w * wPx), dp(o.box.h * hPx))
            )
        }
        is MarkObj -> Canvas(Modifier.fillMaxSize()) {
            o.boxes.forEach { bx ->
                val l = bx.l * size.width; val t = bx.t * size.height; val r = bx.r * size.width; val bt = bx.b * size.height
                when (o.kind) {
                    MarkKind.HIGHLIGHT -> drawRect(col(o.color, 0.45f), Offset(l, t), Size(r - l, bt - t))
                    MarkKind.UNDERLINE -> drawLine(col(o.color), Offset(l, bt - (bt - t) * 0.12f), Offset(r, bt - (bt - t) * 0.12f), max(2f, (bt - t) * 0.07f))
                    MarkKind.STRIKE -> drawLine(col(o.color), Offset(l, (t + bt) / 2), Offset(r, (t + bt) / 2), max(2f, (bt - t) * 0.07f))
                }
            }
        }
        is InkObj -> Canvas(Modifier.fillMaxSize()) {
            val path = Path().apply {
                moveTo(o.points[0].first * size.width, o.points[0].second * size.height)
                o.points.drop(1).forEach { (x, y) -> lineTo(x * size.width, y * size.height) }
            }
            drawPath(path, col(o.color), style = Stroke(o.widthPt * pxPerPt, cap = StrokeCap.Round, join = StrokeJoin.Round))
        }
        is ShapeObj -> Canvas(Modifier.fillMaxSize()) {
            drawShape(o.kind, Offset(o.x1 * size.width, o.y1 * size.height), Offset(o.x2 * size.width, o.y2 * size.height), col(o.color), o.widthPt * pxPerPt)
        }
        is NoteObj -> Box(
            Modifier.offset { IntOffset((o.x * wPx).roundToInt(), (o.y * hPx).roundToInt()) }
                .size(dp(16 * pxPerPt), dp(16 * pxPerPt)).background(col(o.color)).border(1.dp, Color(0xFF795548))
        )
    }
}

private fun decodeSmall(path: String): Bitmap? {
    val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(path, o)
    var s = 1
    while (max(o.outWidth, o.outHeight) / (s * 2) >= 900) s *= 2
    return BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = s })
}

/** The selected item: text you can type into, or a box you can move and resize. */
@Composable
private fun SelectedOverlay(vm: EditorVm, o: EdObj, wPx: Float, hPx: Float, pxPerPt: Float, bmp: Bitmap?) {
    val density = LocalDensity.current
    fun dp(px: Float) = with(density) { px.toDp() }
    val accent = MaterialTheme.colorScheme.primary
    when (o) {
        is ParaObj, is TextObj -> {
            val focus = remember { FocusRequester() }
            val text = if (o is ParaObj) o.text else (o as TextObj).text
            var tfv by remember(o.id) { mutableStateOf(TextFieldValue(text, androidx.compose.ui.text.TextRange(text.length))) }
            if (tfv.text != text) tfv = TextFieldValue(text, androidx.compose.ui.text.TextRange(text.length))
            LaunchedEffect(o.id) { try { focus.requestFocus() } catch (ignored: Exception) {} }
            val left: Float
            val top: Float
            val width: Float
            val style: TextStyle
            if (o is ParaObj) {
                // Hide the old words (the preview removes them for real a moment later).
                val bg = sampleBg(bmp, o.origBox)
                Box(Modifier.offset { IntOffset((o.origBox.l * wPx).roundToInt() - 3, (o.origBox.t * hPx).roundToInt() - 3) }
                    .size(dp(o.origBox.w * wPx + 6), dp(o.origBox.h * hPx + 6)).background(bg))
                val gapPt = o.lineGapPt * o.style.sizePt / o.origStyle.sizePt
                left = o.origBox.l * wPx
                top = o.firstBaseline * hPx - 0.79f * gapPt * pxPerPt
                width = max(o.origBox.w, o.maxW) * wPx + o.style.sizePt * 0.6f * pxPerPt
                style = textStyle(o.style, pxPerPt, gapPt, density)
            } else {
                o as TextObj
                left = o.l * wPx
                top = o.t * hPx
                width = o.w * wPx
                style = textStyle(o.style, pxPerPt, o.style.sizePt * 1.2f, density)
            }
            Box(
                Modifier.offset { IntOffset(left.roundToInt() - 4, top.roundToInt() - 4) }
                    .border(1.5.dp, Color(0xFFE53935), RoundedCornerShape(2.dp))
                    .padding(4.dp)
            ) {
                BasicTextField(
                    value = tfv,
                    onValueChange = { v ->
                        tfv = v
                        val cur = vm.objs.firstOrNull { it.id == o.id } ?: return@BasicTextField
                        when (cur) {
                            is ParaObj -> vm.typed(cur.copy(text = v.text))
                            is TextObj -> vm.typed(cur.copy(text = v.text))
                            else -> Unit
                        }
                    },
                    textStyle = style,
                    cursorBrush = SolidColor(Color(0xFFE53935)),
                    modifier = Modifier.requiredWidth(dp(width)).focusRequester(focus)
                )
            }
            if (o is TextObj) {
                // Move handle (top-left) and width handle (right edge).
                Box(
                    Modifier.offset { IntOffset(left.roundToInt() - 22, top.roundToInt() - 22) }
                        .size(26.dp).background(accent, CircleShape)
                        .pointerInput(o.id) {
                            detectDragGestures(onDragStart = { vm.beginLive() }, onDragEnd = { vm.endLive() }) { c, d ->
                                c.consume()
                                val cur = vm.objs.firstOrNull { it.id == o.id } as? TextObj ?: return@detectDragGestures
                                vm.live(cur.copy(l = (cur.l + d.x / wPx).coerceIn(0f, 0.95f), t = (cur.t + d.y / hPx).coerceIn(0f, 0.97f)))
                            }
                        },
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Outlined.OpenWith, contentDescription = "Move", tint = Color.White, modifier = Modifier.size(16.dp)) }
                Box(
                    Modifier.offset { IntOffset((left + width).roundToInt() - 4, top.roundToInt() + 6) }
                        .size(14.dp, 28.dp).background(accent, RoundedCornerShape(7.dp))
                        .pointerInput(o.id) {
                            detectDragGestures(onDragStart = { vm.beginLive() }, onDragEnd = { vm.endLive() }) { c, d ->
                                c.consume()
                                val cur = vm.objs.firstOrNull { it.id == o.id } as? TextObj ?: return@detectDragGestures
                                vm.live(cur.copy(w = (cur.w + d.x / wPx).coerceIn(0.08f, 1f - cur.l)))
                            }
                        }
                )
            }
        }
        else -> {
            Ghost(o, wPx, hPx, pxPerPt, bmp)
            val b = when (o) {
                is ImageObj -> o.box
                is ShapeObj -> FBox(min(o.x1, o.x2), min(o.y1, o.y2), max(o.x1, o.x2), max(o.y1, o.y2))
                is NoteObj -> FBox(o.x, o.y, o.x + 16 * pxPerPt / wPx, o.y + 16 * pxPerPt / hPx)
                is InkObj -> FBox(o.points.minOf { it.first }, o.points.minOf { it.second }, o.points.maxOf { it.first }, o.points.maxOf { it.second })
                is MarkObj -> o.boxes.reduce { a, c -> a.union(c) }
                else -> return
            }.pad(0.004f, 0.004f)
            val movable = o is ImageObj || o is ShapeObj || o is NoteObj || o is InkObj
            Box(
                Modifier.offset { IntOffset((b.l * wPx).roundToInt(), (b.t * hPx).roundToInt()) }
                    .size(dp(b.w * wPx), dp(b.h * hPx))
                    .border(BorderStroke(1.5.dp, accent))
                    .then(
                        if (movable) Modifier.pointerInput(o.id) {
                            detectDragGestures(onDragStart = { vm.beginLive() }, onDragEnd = { vm.endLive() }) { c, d ->
                                c.consume()
                                val dx = d.x / wPx
                                val dy = d.y / hPx
                                when (val cur = vm.objs.firstOrNull { it.id == o.id }) {
                                    is ImageObj -> vm.live(cur.copy(box = FBox(cur.box.l + dx, cur.box.t + dy, cur.box.r + dx, cur.box.b + dy)))
                                    is ShapeObj -> vm.live(cur.copy(x1 = cur.x1 + dx, y1 = cur.y1 + dy, x2 = cur.x2 + dx, y2 = cur.y2 + dy))
                                    is NoteObj -> vm.live(cur.copy(x = cur.x + dx, y = cur.y + dy))
                                    is InkObj -> vm.live(cur.copy(points = cur.points.map { (x, y) -> x + dx to y + dy }))
                                    else -> Unit
                                }
                            }
                        } else Modifier
                    )
            )
            if (o is ImageObj || o is ShapeObj) {
                // Resize handle (bottom-right). Pictures keep their shape.
                Box(
                    Modifier.offset { IntOffset((b.r * wPx).roundToInt() - 14, (b.b * hPx).roundToInt() - 14) }
                        .size(28.dp).background(accent, CircleShape)
                        .pointerInput(o.id) {
                            detectDragGestures(onDragStart = { vm.beginLive() }, onDragEnd = { vm.endLive() }) { c, d ->
                                c.consume()
                                when (val cur = vm.objs.firstOrNull { it.id == o.id }) {
                                    is ImageObj -> {
                                        val ratio = cur.box.h / cur.box.w
                                        val nw = (cur.box.w + d.x / wPx).coerceIn(0.04f, 1f)
                                        vm.live(cur.copy(box = FBox(cur.box.l, cur.box.t, cur.box.l + nw, cur.box.t + nw * ratio)))
                                    }
                                    is ShapeObj -> vm.live(cur.copy(x2 = cur.x2 + d.x / wPx, y2 = cur.y2 + d.y / hPx))
                                    else -> Unit
                                }
                            }
                        }
                )
            }
        }
    }
}

// ------------------------------------------------------------------ bars

@Composable
private fun BarItem(icon: ImageVector, label: String, selected: Boolean = false, enabled: Boolean = true, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Column(
        Modifier.clickable(enabled = enabled, onClick = onClick)
            .background(if (selected) cs.secondaryContainer else Color.Transparent, RoundedCornerShape(12.dp))
            .padding(horizontal = 10.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, contentDescription = null, tint = if (enabled) cs.onSurface else cs.onSurface.copy(alpha = 0.35f), modifier = Modifier.size(22.dp))
        Text(label, style = MaterialTheme.typography.labelSmall, maxLines = 1, color = if (enabled) cs.onSurface else cs.onSurface.copy(alpha = 0.35f))
    }
}

@Composable
private fun ModeBar(vm: EditorVm, onMode: (EdMode) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
        BarItem(Icons.Outlined.Edit, "Edit", vm.mode == EdMode.EDIT) { onMode(EdMode.EDIT) }
        BarItem(Icons.Outlined.BorderColor, "Annotate", vm.mode == EdMode.ANNOTATE) { onMode(EdMode.ANNOTATE) }
        BarItem(Icons.Outlined.Draw, "Sign", vm.mode == EdMode.SIGN) { onMode(EdMode.SIGN) }
        BarItem(Icons.Outlined.EditNote, "Fill out", vm.mode == EdMode.FILL) { onMode(EdMode.FILL) }
        BarItem(Icons.Outlined.Apps, "More tools") { onMode(EdMode.MORE) }
    }
}

@Composable
private fun ColorDots(colors: List<Int>, current: Int, onPick: (Int) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
        colors.forEach { c ->
            Box(
                Modifier.size(26.dp).background(col(c), CircleShape)
                    .border(if (c == current) 3.dp else 1.dp, if (c == current) MaterialTheme.colorScheme.primary else Color(0x33000000), CircleShape)
                    .clickable { onPick(c) }
            )
        }
    }
}

@Composable
private fun ToolRow(vm: EditorVm, onPickImage: () -> Unit, onNewSignature: () -> Unit, onFormFields: () -> Unit) {
    val ctx = LocalContext.current
    Column(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 6.dp), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
            fun t(tool: EdTool) = vm.tool == tool
            when (vm.mode) {
                EdMode.EDIT -> {
                    BarItem(Icons.Outlined.TextFields, "Edit text", t(EdTool.EDIT_TEXT)) { vm.tool = EdTool.EDIT_TEXT }
                    BarItem(Icons.Outlined.Title, "Insert text", t(EdTool.INSERT_TEXT)) { vm.tool = EdTool.INSERT_TEXT }
                    BarItem(Icons.Outlined.AddPhotoAlternate, "Insert image", t(EdTool.INSERT_IMAGE)) { onPickImage() }
                }
                EdMode.ANNOTATE -> {
                    BarItem(Icons.Outlined.BorderColor, "Highlight", t(EdTool.HIGHLIGHT)) { vm.tool = EdTool.HIGHLIGHT }
                    BarItem(Icons.Outlined.FormatUnderlined, "Underline", t(EdTool.UNDERLINE)) { vm.tool = EdTool.UNDERLINE }
                    BarItem(Icons.Outlined.FormatStrikethrough, "Strike", t(EdTool.STRIKE)) { vm.tool = EdTool.STRIKE }
                    BarItem(Icons.Outlined.Gesture, "Pen", t(EdTool.PEN)) { vm.tool = EdTool.PEN }
                    BarItem(Icons.Outlined.CropSquare, "Box", t(EdTool.RECT)) { vm.tool = EdTool.RECT }
                    BarItem(Icons.Outlined.Circle, "Circle", t(EdTool.OVAL)) { vm.tool = EdTool.OVAL }
                    BarItem(Icons.Outlined.HorizontalRule, "Line", t(EdTool.LINE)) { vm.tool = EdTool.LINE }
                    BarItem(Icons.Outlined.NorthEast, "Arrow", t(EdTool.ARROW)) { vm.tool = EdTool.ARROW }
                    BarItem(Icons.Outlined.ChatBubbleOutline, "Note", t(EdTool.NOTE)) { vm.tool = EdTool.NOTE }
                }
                EdMode.SIGN -> {
                    var saved by remember { mutableStateOf(Signatures.list(ctx)) }
                    LaunchedEffect(vm.signature) { saved = Signatures.list(ctx); if (vm.signature == null) vm.signature = saved.firstOrNull() }
                    Box(Modifier.padding(horizontal = 6.dp)) {
                        SignaturePicker(
                            saved = saved,
                            selected = vm.signature,
                            onSelect = { vm.signature = it; vm.tool = EdTool.SIGN },
                            onNew = onNewSignature,
                            onDelete = { f -> f.delete(); saved = Signatures.list(ctx); if (vm.signature == f) vm.signature = saved.firstOrNull() }
                        )
                    }
                }
                EdMode.FILL -> {
                    BarItem(Icons.Outlined.TextFields, "Text", t(EdTool.FILL_TEXT)) { vm.tool = EdTool.FILL_TEXT }
                    BarItem(Icons.Outlined.Check, "Tick", t(EdTool.CHECK)) { vm.tool = EdTool.CHECK }
                    BarItem(Icons.Outlined.Close, "Cross", t(EdTool.CROSS)) { vm.tool = EdTool.CROSS }
                    BarItem(Icons.Outlined.Circle, "Dot", t(EdTool.DOT)) { vm.tool = EdTool.DOT }
                    BarItem(Icons.Outlined.CalendarToday, "Date", t(EdTool.DATE)) { vm.tool = EdTool.DATE }
                    if (vm.hasForm) BarItem(Icons.Outlined.EditNote, "Form fields") { onFormFields() }
                }
                EdMode.MORE -> Unit
            }
        }
        if (vm.mode == EdMode.ANNOTATE) {
            Row(Modifier.padding(horizontal = 14.dp, vertical = 4.dp).horizontalScroll(rememberScrollState()), verticalAlignment = Alignment.CenterVertically) {
                if (vm.tool == EdTool.HIGHLIGHT) ColorDots(MarkColors, vm.markColor) { vm.markColor = it }
                else if (vm.tool != EdTool.NOTE) {
                    ColorDots(EdColors.filter { it != 0xFFFFFF }, vm.inkColor) { vm.inkColor = it }
                    if (vm.tool != EdTool.UNDERLINE && vm.tool != EdTool.STRIKE) {
                        Spacer(Modifier.width(12.dp))
                        listOf(1f, 2f, 4f).forEach { w ->
                            Box(
                                Modifier.padding(horizontal = 3.dp).size(30.dp)
                                    .background(if (vm.penWidth == w) MaterialTheme.colorScheme.secondaryContainer else Color.Transparent, CircleShape)
                                    .clickable { vm.penWidth = w },
                                contentAlignment = Alignment.Center
                            ) { Box(Modifier.size((4 + w * 3).dp).background(MaterialTheme.colorScheme.onSurface, CircleShape)) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TextFormatBar(vm: EditorVm, o: EdObj) {
    val style = when (o) { is ParaObj -> o.style; is TextObj -> o.style; else -> return }
    var showColors by remember { mutableStateOf(false) }
    fun set(s: TStyle) {
        when (val cur = vm.objs.firstOrNull { it.id == o.id }) {
            is ParaObj -> vm.change(cur.copy(style = s))
            is TextObj -> vm.change(cur.copy(style = s))
            else -> Unit
        }
    }
    Column {
        if (showColors) {
            Row(Modifier.padding(horizontal = 12.dp, vertical = 6.dp)) {
                ColorDots(EdColors, style.color) { set(style.copy(color = it)); showColors = false }
            }
        }
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 4.dp, vertical = 2.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            BarItem(Icons.Outlined.FormatBold, "Bold", style.bold) { set(style.copy(bold = !style.bold)) }
            BarItem(Icons.Outlined.FormatItalic, "Italic", style.italic) { set(style.copy(italic = !style.italic)) }
            BarItem(Icons.Outlined.TextDecrease, "Smaller") { set(style.copy(sizePt = max(4f, style.sizePt - 1f))) }
            Text("${style.sizePt.roundToInt()}", style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(horizontal = 4.dp))
            BarItem(Icons.Outlined.TextIncrease, "Bigger") { set(style.copy(sizePt = min(96f, style.sizePt + 1f))) }
            BarItem(Icons.Outlined.FontDownload, when (style.family) { Family.SANS -> "Sans"; Family.SERIF -> "Serif"; Family.MONO -> "Mono" }) {
                set(style.copy(family = Family.entries[(style.family.ordinal + 1) % Family.entries.size]))
            }
            Box(Modifier.padding(horizontal = 8.dp).size(26.dp).background(col(style.color), CircleShape).border(1.dp, Color(0x55000000), CircleShape).clickable { showColors = !showColors })
            BarItem(Icons.Outlined.ContentCopy, "Duplicate") { vm.duplicate(o.id) }
            BarItem(Icons.Outlined.Delete, "Delete") { vm.delete(o.id) }
            BarItem(Icons.Outlined.Done, "Done") { vm.setSelected(null) }
        }
    }
}

@Composable
private fun ObjectBar(vm: EditorVm, o: EdObj, onEditNote: () -> Unit) {
    Column {
        if (o is ShapeObj || o is InkObj || o is MarkObj) {
            val current = when (o) { is ShapeObj -> o.color; is InkObj -> o.color; is MarkObj -> o.color; else -> 0 }
            val palette = if (o is MarkObj && o.kind == MarkKind.HIGHLIGHT) MarkColors else EdColors.filter { it != 0xFFFFFF }
            Row(Modifier.padding(horizontal = 14.dp, vertical = 6.dp)) {
                ColorDots(palette, current) { c ->
                    when (o) {
                        is ShapeObj -> vm.change(o.copy(color = c))
                        is InkObj -> vm.change(o.copy(color = c))
                        is MarkObj -> vm.change(o.copy(color = c))
                        else -> Unit
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
            if (o is NoteObj) BarItem(Icons.Outlined.Edit, "Edit note") { onEditNote() }
            if (o !is MarkObj) BarItem(Icons.Outlined.ContentCopy, "Duplicate") { vm.duplicate(o.id) }
            BarItem(Icons.Outlined.Delete, "Delete") { vm.delete(o.id) }
            BarItem(Icons.Outlined.Done, "Done") { vm.setSelected(null) }
        }
    }
}

// ------------------------------------------------------------------ sheets

@Composable
private fun MoreToolsSheet(onDismiss: () -> Unit, onPick: (String) -> Unit) {
    val items = listOf(
        "pages" to "Page tools (rotate, delete, reorder)",
        "split" to "Split or extract pages",
        "compress" to "Compress",
        "redact" to "Redact private info",
        "ocr" to "OCR: make scanned text searchable",
        "forms" to "Fill form fields",
        "lock" to "Lock with a password",
        "share" to "Share"
    )
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.fillMaxWidth().navigationBarsPadding().padding(bottom = 16.dp)) {
            Text("More tools", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Medium, modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp))
            items.forEach { (route, label) ->
                Text(label, modifier = Modifier.fillMaxWidth().clickable { onPick(route) }.padding(horizontal = 20.dp, vertical = 14.dp))
            }
        }
    }
}

@Composable
private fun HelpSheet(onDismiss: () -> Unit) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 20.dp).padding(bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("How to edit", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Medium)
            listOf(
                "Edit → Edit text: tap a paragraph and type. Use the bar above the keyboard for bold, size, font and colour.",
                "Edit → Insert text / Insert image: tap the page where it should go. Drag the round handle to move, the side handle to resize.",
                "Annotate: drag over text to highlight, underline or strike it. Draw with the pen, add boxes, circles, arrows or notes.",
                "Sign: create a signature once, then tap the page to place it. Drag to move, use the corner to resize.",
                "Fill out: tap to add text, ticks, crosses or today's date.",
                "Two fingers: zoom and scroll. Undo and Redo are at the top.",
                "Save writes your changes into the file (a backup is kept). Use Save as a copy to keep the original.",
                "Editing works for English and other Latin-script text. The original font is reused when it has all the letters you type."
            ).forEach { Text("• $it", style = MaterialTheme.typography.bodyMedium) }
            FilledTonalButton(onClick = onDismiss) { Text("Got it") }
        }
    }
}
