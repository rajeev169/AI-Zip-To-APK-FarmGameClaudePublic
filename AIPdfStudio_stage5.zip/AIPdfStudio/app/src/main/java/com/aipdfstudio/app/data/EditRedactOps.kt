package com.aipdfstudio.app.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import com.tom_roush.pdfbox.cos.COSName
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDDocumentInformation
import com.tom_roush.pdfbox.pdmodel.PDPage
import com.tom_roush.pdfbox.pdmodel.PDPageContentStream
import com.tom_roush.pdfbox.pdmodel.common.PDRectangle
import com.tom_roush.pdfbox.pdmodel.font.PDType1Font
import com.tom_roush.pdfbox.pdmodel.graphics.color.PDDeviceRGB
import com.tom_roush.pdfbox.pdmodel.graphics.image.JPEGFactory
import com.tom_roush.pdfbox.pdmodel.graphics.image.PDImageXObject
import com.tom_roush.pdfbox.pdmodel.graphics.state.PDExtendedGraphicsState
import com.tom_roush.pdfbox.util.Matrix
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException
import kotlin.math.max
import kotlin.math.min

// ---------------------------------------------------------------- Smart edit

enum class BoxKind { WHITEOUT, HIGHLIGHT, BLACKOUT }

/** Something added to a page in Smart edit. Positions are fractions of the displayed page. */
sealed class EditItem {
    abstract val page: Int

    /** With [removeText] the real text under a whiteout is deleted too (used when editing a line). */
    data class Box(override val page: Int, val box: FBox, val kind: BoxKind, val removeText: Boolean = false) : EditItem()

    /** [top] is the top of the first line; [size] is the font size as a fraction of page height. */
    data class Text(
        override val page: Int,
        val left: Float,
        val top: Float,
        val size: Float,
        val text: String,
        val color: Int
    ) : EditItem()

    data class Image(override val page: Int, val box: FBox, val path: String) : EditItem()
}

object EditOps {
    /** Width of [text] (one line) as a fraction of page width, for the on-screen preview box. */
    fun textWidth(text: String, size: Float, pageAspect: Float): Float {
        val clean = winAnsiOnly(text)
        val w = try { PDType1Font.HELVETICA.getStringWidth(clean) / 1000f } catch (e: Exception) { clean.length * 0.5f }
        // size is relative to page height; convert to page-width fraction.
        return w * size / pageAspect
    }

    /** Draws all items onto [doc]. Images must already be decoded into [images] (path -> PDF image). */
    fun applyTo(doc: PDDocument, items: List<EditItem>, images: Map<String, PDImageXObject> = emptyMap()) {
        val font = PDType1Font.HELVETICA
        for ((pageIndex, list) in items.groupBy { it.page }) {
            if (pageIndex !in 0 until doc.numberOfPages) continue
            val page = doc.getPage(pageIndex)
            val cb = page.cropBox
            val pm = PageMath(cb.lowerLeftX, cb.lowerLeftY, cb.width, cb.height, page.rotation)
            val W = pm.dispW
            val H = pm.dispH
            // Delete the old words first, so search and copy only see the new text.
            val wipe = list.filterIsInstance<EditItem.Box>().filter { it.removeText }.map { it.box }
            if (wipe.isNotEmpty()) TextRemover.remove(doc, pageIndex, wipe)
            PDPageContentStream(doc, page, PDPageContentStream.AppendMode.APPEND, true, true).use { cs ->
                // Boxes first (so new text can sit on a whiteout), then images, then text.
                list.filterIsInstance<EditItem.Box>().forEach { b ->
                    cs.saveGraphicsState()
                    when (b.kind) {
                        BoxKind.WHITEOUT -> cs.setNonStrokingColor(1f, 1f, 1f)
                        BoxKind.BLACKOUT -> cs.setNonStrokingColor(0f, 0f, 0f)
                        BoxKind.HIGHLIGHT -> {
                            val gs = PDExtendedGraphicsState()
                            gs.nonStrokingAlphaConstant = 0.35f
                            cs.setGraphicsStateParameters(gs)
                            cs.setNonStrokingColor(1f, 0.9f, 0f)
                        }
                    }
                    val m = pm.rectMatrix(b.box.l * W, b.box.t * H, b.box.w * W, b.box.h * H)
                    cs.transform(Matrix(m[0], m[1], m[2], m[3], m[4], m[5]))
                    cs.addRect(0f, 0f, 1f, 1f)
                    cs.fill()
                    cs.restoreGraphicsState()
                }
                list.filterIsInstance<EditItem.Image>().forEach { im ->
                    val img = images[im.path] ?: return@forEach
                    val m = pm.rectMatrix(im.box.l * W, im.box.t * H, im.box.w * W, im.box.h * H)
                    cs.drawImage(img, Matrix(m[0], m[1], m[2], m[3], m[4], m[5]))
                }
                list.filterIsInstance<EditItem.Text>().forEach { t ->
                    val size = t.size * H
                    if (size <= 0f) return@forEach
                    cs.setNonStrokingColor(
                        ((t.color shr 16) and 255) / 255f,
                        ((t.color shr 8) and 255) / 255f,
                        (t.color and 255) / 255f
                    )
                    t.text.split('\n').forEachIndexed { i, raw ->
                        val line = winAnsiOnly(raw)
                        if (line.isBlank()) return@forEachIndexed
                        val baseline = t.top * H + size * (0.8f + 1.2f * i)
                        val tm = pm.textMatrix(t.left * W, baseline, 1f)
                        cs.beginText()
                        cs.setFont(font, size)
                        cs.setTextMatrix(Matrix(tm[0], tm[1], tm[2], tm[3], tm[4], tm[5]))
                        cs.showText(line)
                        cs.endText()
                    }
                }
            }
        }
    }

    fun apply(ctx: Context, uri: Uri, items: List<EditItem>, out: File) {
        if (items.isEmpty()) throw UserError("Make at least one change first.")
        val doc = PdfOps.load(ctx, uri)
        val bitmaps = ArrayList<Bitmap>()
        try {
            val images = HashMap<String, PDImageXObject>()
            items.filterIsInstance<EditItem.Image>().map { it.path }.distinct().forEach { path ->
                val bmp = ConvertOps.decodeImage(ctx, Uri.fromFile(File(path)), 2000) ?: return@forEach
                bitmaps.add(bmp)
                images[path] = JPEGFactory.createFromImage(doc, bmp, 0.9f)
            }
            applyTo(doc, items, images)
            try {
                doc.save(out)
            } catch (e: Throwable) {
                out.delete()
                throw e
            }
        } finally {
            doc.close()
            bitmaps.forEach { it.recycle() }
        }
    }
}

// ---------------------------------------------------------------- Redact

object RedactOps {
    enum class Preset(val label: String, val regex: Regex) {
        PHONE("Phone numbers", Regex("""(?<![\d])(?:\+?91[\s-]?)?[6-9]\d{4}[\s-]?\d{5}(?![\d])""")),
        EMAIL("Email addresses", Regex("""[\w.+-]+@[\w-]+(?:\.[\w-]+)+""")),
        AADHAAR("Aadhaar / 12-digit IDs", Regex("""(?<![\d])\d{4}[\s-]?\d{4}[\s-]?\d{4}(?![\d])""")),
        PAN("PAN numbers", Regex("""\b[A-Z]{5}\d{4}[A-Z]\b"""))
    }

    /** Finds every match on every page. Returns page index -> boxes (padded a little). */
    fun find(doc: PDDocument, regexes: List<Regex>): Map<Int, List<FBox>> {
        val out = HashMap<Int, List<FBox>>()
        for (i in 0 until doc.numberOfPages) {
            val pt = try { TextGeometry.read(doc, i) } catch (e: Exception) { continue }
            val boxes = regexes.flatMap { pt.find(it) }.map { it.pad(0.003f, 0.002f) }
            if (boxes.isNotEmpty()) out[i] = boxes
        }
        return out
    }

    fun wordRegex(text: String): Regex = Regex(Regex.escape(text.trim()), RegexOption.IGNORE_CASE)

    /**
     * Replaces page [index] with a picture of itself ([jpeg], [w] x [h] pixels, already blacked out).
     * The new page has the displayed size and no text, links or form fields, so nothing hidden can
     * be copied back out.
     */
    fun replaceWithImage(doc: PDDocument, index: Int, jpeg: ByteArray, w: Int, h: Int) {
        val old = doc.getPage(index)
        val cb = old.cropBox
        val pm = PageMath(cb.lowerLeftX, cb.lowerLeftY, cb.width, cb.height, old.rotation)
        val page = PDPage(PDRectangle(pm.dispW, pm.dispH))
        val img = PDImageXObject(doc, ByteArrayInputStream(jpeg), COSName.DCT_DECODE, w, h, 8, PDDeviceRGB.INSTANCE)
        PDPageContentStream(doc, page).use { it.drawImage(img, 0f, 0f, pm.dispW, pm.dispH) }
        doc.pages.insertBefore(page, old)
        doc.pages.remove(old)
    }

    /** Removes the title/author/keywords etc. that might also contain private text. */
    fun clearInfo(doc: PDDocument) {
        doc.documentInformation = PDDocumentInformation()
        doc.documentCatalog.metadata = null
    }

    fun apply(ctx: Context, uri: Uri, boxes: Map<Int, List<FBox>>, out: File, progress: (String) -> Unit) {
        val marked = boxes.filterValues { it.isNotEmpty() }
        if (marked.isEmpty()) throw UserError("Mark at least one area to hide.")
        val doc = PdfOps.load(ctx, uri)
        try {
            val pfd = ctx.contentResolver.openFileDescriptor(uri, "r") ?: throw IOException("Can't open file")
            try {
                val r = try {
                    PdfRenderer(pfd)
                } catch (e: SecurityException) {
                    throw UserError("This PDF is password protected. Unlock it first with the Unlock tool.")
                }
                try {
                    var n = 0
                    for ((index, list) in marked.toSortedMap()) {
                        n++
                        progress("Hiding on page ${index + 1} ($n of ${marked.size})")
                        val page = r.openPage(index)
                        val bmp: Bitmap
                        try {
                            val scale = min(200f / 72f, 2400f / max(page.width, page.height))
                            bmp = Bitmap.createBitmap(max(1, (page.width * scale).toInt()), max(1, (page.height * scale).toInt()), Bitmap.Config.ARGB_8888)
                            bmp.eraseColor(Color.WHITE)
                            page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_PRINT)
                        } finally {
                            page.close()
                        }
                        val paint = Paint().apply { color = Color.BLACK; style = Paint.Style.FILL }
                        val c = Canvas(bmp)
                        list.forEach { b -> c.drawRect(b.l * bmp.width, b.t * bmp.height, b.r * bmp.width, b.b * bmp.height, paint) }
                        val bytes = ByteArrayOutputStream()
                        bmp.compress(Bitmap.CompressFormat.JPEG, 90, bytes)
                        val w = bmp.width
                        val h = bmp.height
                        bmp.recycle()
                        replaceWithImage(doc, index, bytes.toByteArray(), w, h)
                    }
                } finally {
                    r.close()
                }
            } finally {
                try { pfd.close() } catch (ignored: Exception) {}
            }
            clearInfo(doc)
            progress("Saving")
            try {
                doc.save(out)
            } catch (e: Throwable) {
                out.delete()
                throw e
            }
        } finally {
            doc.close()
        }
    }
}
