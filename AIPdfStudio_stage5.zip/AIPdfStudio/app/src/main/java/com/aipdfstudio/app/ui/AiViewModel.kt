package com.aipdfstudio.app.ui

import android.app.Application
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.aipdfstudio.app.data.GeminiClient
import com.aipdfstudio.app.data.OcrOps
import com.aipdfstudio.app.data.OcrScript
import com.aipdfstudio.app.data.UserError
import com.aipdfstudio.app.data.PdfText
import com.aipdfstudio.app.data.SecureStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ChatMsg(val fromUser: Boolean, val text: String, val isError: Boolean = false)

class AiViewModel(app: Application) : AndroidViewModel(app) {
    val store = SecureStore(app)

    var hasKey by mutableStateOf(store.apiKey.isNotBlank())
        private set
    var docUri by mutableStateOf<Uri?>(null)
        private set
    var docName by mutableStateOf("")
        private set
    var busy by mutableStateOf(false)
        private set
    val messages = mutableStateListOf<ChatMsg>()

    private var docText: String? = null
    private val history = mutableListOf<Pair<String, String>>()

    fun refreshKey() {
        hasKey = store.apiKey.isNotBlank()
    }

    fun setDocument(uri: Uri, name: String) {
        if (uri == docUri) return
        docUri = uri
        docName = name
        docText = null
        messages.clear()
        history.clear()
    }

    fun clearDocument() {
        docUri = null
        docName = ""
        docText = null
        messages.clear()
        history.clear()
    }

    private suspend fun readScan(uri: Uri): String? =
        readScanImpl(getApplication<Application>(), uri) { messages.add(ChatMsg(false, it)) }

    fun ask(display: String, instruction: String) {
        val uri = docUri ?: return
        if (busy) return
        messages.add(ChatMsg(true, display))
        busy = true
        viewModelScope.launch {
            try {
                if (docText == null) {
                    docText = try {
                        PdfText.extract(getApplication<Application>(), uri)
                    } catch (e: Exception) {
                        null
                    }
                }
                if (docText.isNullOrBlank()) docText = readScan(uri)
                val text = docText
                if (text.isNullOrBlank()) {
                    messages.add(
                        ChatMsg(
                            false,
                            "I couldn't read any text in this PDF. If it's password protected, unlock it first with Tools → Unlock. " +
                                "If it's a very blurry scan, try scanning it again.",
                            true
                        )
                    )
                    return@launch
                }
                val system = "You are the assistant inside a PDF app. Answer using only the document below. " +
                    "If the answer isn't in the document, say so. Be clear and concise, and mention page " +
                    "numbers only if the text makes them clear.\n\nDOCUMENT:\n" + text
                val contents = history.takeLast(10) + ("user" to instruction)
                when (val r = GeminiClient.generate(store.apiKey, store.model, system, contents)) {
                    is GeminiClient.Result.Ok -> {
                        history.add("user" to instruction)
                        history.add("model" to r.text)
                        messages.add(ChatMsg(false, cleanMarkdown(r.text)))
                    }
                    is GeminiClient.Result.Err -> messages.add(ChatMsg(false, r.message, true))
                }
            } finally {
                busy = false
            }
        }
    }
}

/** Scanned PDFs have no text: read the first pages with OCR (English, then Hindi if English finds little). */
private suspend fun AiViewModel.readScanImpl(app: Application, uri: Uri, note: (String) -> Unit): String? {
    note("This PDF is a scan. Reading its text on your phone first (first $OCR_PAGES pages)…")
    return withContext(Dispatchers.IO) {
        try {
            val latin = OcrOps.run(app, uri, OcrScript.LATIN, null, {}, OCR_PAGES)
            val letters = latin.count { it.isLetter() }
            if (letters >= 80) latin
            else {
                val hindi = try { OcrOps.run(app, uri, OcrScript.DEVANAGARI, null, {}, OCR_PAGES) } catch (e: Exception) { "" }
                if (hindi.count { it.isLetter() } > letters) hindi else latin
            }
        } catch (e: UserError) {
            null
        } catch (e: Exception) {
            null
        }
    }
}

private const val OCR_PAGES = 25

fun cleanMarkdown(s: String): String = s.lines().joinToString("\n") { line ->
    val l = line.trimEnd().replace("**", "").replace("__", "")
    val t = l.trimStart()
    if (t.startsWith("* ") || t.startsWith("- ")) "• " + t.drop(2)
    else if (t.startsWith("#")) t.trimStart('#').trim()
    else l
}
