# AI PDF Studio (stage 5, version 1.4.0)

Native Android app (Kotlin, Jetpack Compose, Material 3) with a Fresh teal theme, light and dark.

## Built so far
### Stage 1
- App shell: bottom navigation (Files, Tools, AI), teal Material 3 theme with dark mode, adaptive icon
- Files: search, "continue where you left off" card, recent list, open from the file picker or from other apps
- PDF viewer: smooth scrolling, zoom steps, night mode, page counter, remembers last page
- AI studio (Gemini, user's own key): summarize, key points, translate, chat with the document
- AI settings: key entry (encrypted on device), Test key button, model name, privacy note

### Stage 2 (new)
- Merge: pick several PDFs, reorder them, join into one
- Split: pick pages (e.g. `1-3, 5, 8-`) into one file, split every N pages, or one file per page
- Page tools: page thumbnails, select pages, rotate left/right, move earlier/later, delete, undo, reset
- Compress: Light / Recommended / Strong. Re-encodes photos and scans as smaller JPEGs; text stays sharp.
  Shows before → after size, and tells you if the file can't be made smaller
- Lock: add a password (AES-256)
- Unlock: remove a password you know (or remove owner restrictions from a file that opens without one)
- Results screen for every tool: Open, Share, Save to phone; "Save all" to a folder and "Share all" for multiple files
- Viewer: new Share button; locked files now point you to the Unlock tool
- Home: Merge and Compress shortcuts now work
- All processing is done on the phone. Nothing is uploaded. Originals are never changed;
  results are kept in the app's private storage until you save or share them.

### Stage 3 (new)
- Sign: draw or type a signature (black or blue ink), saved for next time. Drag it onto any page,
  resize it, or put it in the same spot on every page. Works on rotated pages.
- Scan to PDF: Google ML Kit document scanner (auto edge detection, crop, rotate, clean-up filters,
  multi-page, import from gallery). Needs Google Play services.
- Convert: Images to PDF (A4 or photo-shaped pages, EXIF rotation fixed, reorder),
  PDF to JPG (one image per page), PDF to Word (.docx, text only), PDF to text (.txt)
- OCR: reads scanned pages on the phone (English/Latin or Hindi/Devanagari). Makes a searchable PDF
  (English) with an invisible text layer, plus a .txt file and copyable text. Pages that already
  have text are not scanned again.
- Results can now be images, Word and text files: Open uses another app for non-PDF files.

### Stage 4 (new)
- Viewer: two-finger pinch zoom (1x to 4x, pages re-drawn sharp after zooming), double-tap to zoom,
  tap the page counter to go to a page, bookmark pages, and the PDF's own table of contents
- Smart edit: tap a line of text to change or delete it (the old words are really removed, not just
  covered), add text (3 sizes, 3 colours), add pictures, erase (white box) and highlight. English text only.
- Redact: find and mark phone numbers, emails, Aadhaar/12-digit IDs, PAN numbers or any word, or draw
  boxes by hand. Marked pages become pictures so hidden text can't be recovered; document info is cleared.
- Fill form: fills PDF form fields (text, multi-line, tick boxes, radio buttons, choices); optional
  "lock the answers" (flatten). Explains when a PDF has no fields or uses Adobe XFA.
- Compare: page-by-page text differences (added/removed lines) plus a .txt report; optional visual
  comparison PDF with changes in red (works for scans too)
- Open from link: Google Drive, Google Docs (as PDF), Dropbox and direct links; checks it's really a PDF
- Share to the app: "Share" a PDF from WhatsApp, Gmail or Files to AI PDF Studio to open it
- AI on scanned PDFs: Summarize/Chat/Translate now read scans with OCR first (first 25 pages,
  English, or Hindi if that reads better)
- Ads and Premium are built in but switched OFF (no ads shown, nothing to pay for)

### Stage 5 (new): full PDF editor
Open it from Tools → Edit PDF, Home → Edit, or the pencil button in the viewer.
- Edit mode: "Tap any content to edit" with dashed boxes around every paragraph. Tap a paragraph and
  type straight on the page; text re-wraps inside the paragraph. Bar above the keyboard: Bold, Italic,
  smaller/bigger, font (Sans/Serif/Mono), colour, Duplicate, Delete, Done.
- The paragraph's own font is reused when it has every letter you type (also for subset fonts from
  Word/LibreOffice/Chrome PDFs); otherwise the closest standard font, with a Unicode font only for
  symbols like ₹. Old words are really removed from the file.
- Insert text and Insert image: tap to place, drag the handle to move, resize from the side/corner.
- Annotate: Highlight / Underline / Strike by dragging over text, Pen, Box, Circle, Line, Arrow,
  sticky Note (also saved as a real PDF comment), colours and line widths.
- Sign: create/pick a signature and tap to place; move and resize.
- Fill out: text, tick, cross, dot, today's date; opens Fill form when the PDF has form fields.
- More tools: page tools, split, compress, redact, OCR, fill form, lock, share — with this file already chosen.
- Undo/Redo, pinch zoom and two-finger scrolling, live preview (what you see is what gets saved).
- Save writes into the original file when allowed (a backup of the last 5 originals is kept in the
  app), otherwise saves a copy. "Save as a copy" keeps the original untouched.
- Limits: existing text can be edited in English and other Latin-script languages (Hindi can be added
  as new text only if a phone font has it, not edited). Long edits don't push the rest of the page down.

## Turning on ads and Premium later
Both switches are in `data/LinksBookmarks.kt` → `Monetization` (ADS_ENABLED, PREMIUM_ENABLED).
- Ads: add the Google Mobile Ads SDK, add your AdMob App ID to AndroidManifest.xml, and replace the
  placeholder inside `AdSlot()` with a real banner. Ad places: bottom of Home and the results panel.
- Premium: needs Google Play Billing and products set up in Play Console. The Premium page is in
  `FormCompareLinkScreens.kt` and appears in Settings when PREMIUM_ENABLED is true.
- Update the privacy policy and Play data safety form before switching either on.

## Not built yet
Searching for words inside the viewer, Hindi app language, smaller release build (code shrinking).

## Build
- JDK 17, Gradle 8.9, Android Gradle Plugin 8.7.3, Kotlin 2.0.21, compileSdk/targetSdk 35, minSdk 26
- Package / applicationId: com.aipdfstudio.app (change before publishing if you want a different id)
- Gradle wrapper (gradlew, Gradle 8.9) is included: run `./gradlew assembleDebug`
- This code was written without an Android SDK to compile against, so the first build may need small fixes.
  Send me the Gradle error text if it fails and I'll fix it.

## Tested before delivery (stage 5)
- Editing engine run on the real pdfbox-android library: paragraph detection (incl. two columns,
  headings, white text on colour), style and colour detection, editing with original-font reuse,
  subset-font fallback, ₹ in a serif paragraph, re-wrapping, highlight/underline/strike, pen, shapes,
  notes: 30 checks passing, plus all stage 2–4 checks. Results rendered and inspected.
- Whole app type-checked against the exact libraries (planted mistakes in every new file caught).

## Tested before delivery (stage 4)
- Whole app type-checked with Kotlin 2.0.21 + Compose against the exact libraries from the stage 3 APK
  (planted mistakes in every new file were all caught, so a clean result is real).
- The PDF engine code was run on a computer with the real pdfbox-android library from the APK:
  merge, split, page tools, lock/unlock (AES-256), PDF to text/Word, smart edit (text really
  replaced in place), redact (finds and leaves no text), forms (8 field types, flatten), compare,
  link handling and table of contents: 47 automatic checks, all passing. Outputs checked with qpdf,
  poppler and LibreOffice.
- Text positions verified on normal, cropped and rotated pages.

## Tested before delivery (stage 3)
- Whole project type-checked with the Kotlin 2.0.21 + Compose compiler against the exact library
  versions from the stage 2 APK (ML Kit checked against its documented API).
- Signature placement and OCR text layer math unit-tested and checked by rendering real PDFs with
  page rotation 0/90/180/270. Word export opened in LibreOffice.

## Before Play Store release
Signing config, AAB build, privacy policy, data safety form (document text is sent to Google Gemini
using the user's own key), real store screenshots.
