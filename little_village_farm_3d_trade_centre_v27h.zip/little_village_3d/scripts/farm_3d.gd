extends Node3D

const GRID_W := 5
const GRID_D := 5
const CELL := 1.45
const SEED_COST := 12
const SEED_PACK := 5
const GROW_SECONDS := 18.0
const WORLD_HALF := 18.0
const CAM_OFFSET := Vector3(10.5, 13.75, 15.5)
const ZOOM_MIN := 9.0
const ZOOM_MAX := 26.0
const PAN_LIMIT := 12.5

var coins: int = 125
var seeds: int = 18
var crop_states: Dictionary = {}
var active_action := "plant"
var shop_open := false
var v27: Node
var toast_text := "Welcome to your village!"
var toast_time := 3.0
var camera: Camera3D
var coin_label: Label
var seed_label: Label
var toast_label: Label
var shop_panel: PanelContainer
var buttons: Dictionary = {}
var plot_centers: Dictionary = {}
var crop_nodes: Dictionary = {}
var crop_stage_cache: Dictionary = {}
var leaf_material: StandardMaterial3D
var tree_sway: Array = []
var sway_clock: float = 0.0
var mat_cache: Dictionary = {}
var xp: int = 0
var level: int = 1
var quest_goal: int = 5
var quest_progress: int = 0
var harvested_total: int = 0
var cam_target: Vector3 = Vector3(0.0, 0.25, 0.0)
var cam_zoom: float = 16.8
var touches: Dictionary = {}
var touch_info: Dictionary = {}
var pinch_last: float = 0.0
var mouse_down: bool = false
var mouse_moved: bool = false
var mouse_start: Vector2 = Vector2.ZERO
var mouse_last: Vector2 = Vector2.ZERO
var xp_bar: ProgressBar
var xp_text: Label
var level_label: Label
var levelup_label: Label
var levelup_tween: Tween
var action_colors: Dictionary = {}
var path_segments: Array = []
var blockers: Array = []
var autosave_timer: float = 0.0
var scenery_root: Node3D
var lh_root: Node3D
var cloud_nodes: Array = []
var boat_nodes: Array = []
var foam_node: MeshInstance3D

func _ready() -> void:
    _build_world()
    _build_world_extras()
    _build_scenery()
    _build_v17()
    _build_v18()
    _build_camera()
    _build_ui()
    _build_v19()
    _build_v23()
    _build_v24()
    _load_game()
    _ensure_daily(true)
    _apply_unlocks(false)
    _refresh_ui()

func _mat(color: Color, roughness: float = 0.9) -> StandardMaterial3D:
    # Materials are shared by colour, which saves memory with hundreds of meshes.
    var key: String = color.to_html(true) + "_" + str(roughness)
    if mat_cache.has(key):
        return mat_cache[key]
    var material := StandardMaterial3D.new()
    material.albedo_color = color
    material.roughness = roughness
    mat_cache[key] = material
    return material

func _build_camera() -> void:
    camera = Camera3D.new()
    camera.name = "IsometricCamera"
    camera.projection = Camera3D.PROJECTION_ORTHOGONAL
    camera.size = cam_zoom
    add_child(camera)
    # look_at() must run after the camera is inside the scene tree.
    camera.current = true
    _update_camera()

func _make_fence() -> void:
    var wood: Color = Color(0.52, 0.30, 0.15)
    var rail_col: Color = Color(0.64, 0.40, 0.20)
    for i in range(9):
        if i == 2:
            continue
        var x := -5.8 + float(i) * 1.45
        _box(self, Vector3(0.12, 0.62, 0.12), Vector3(x, 0.28, 5.8), wood, "FencePost")
    # The front fence has a gate gap where the south road leaves the farm.
    _box(self, Vector3(2.2, 0.12, 0.12), Vector3(-4.7, 0.42, 5.8), rail_col, "FenceRail")
    _box(self, Vector3(7.6, 0.12, 0.12), Vector3(2.0, 0.42, 5.8), rail_col, "FenceRail")
    _box(self, Vector3(0.20, 1.6, 0.20), Vector3(-3.6, 0.78, 5.8), wood, "GatePostLeft")
    _box(self, Vector3(0.20, 1.6, 0.20), Vector3(-1.8, 0.78, 5.8), wood, "GatePostRight")
    _box(self, Vector3(2.15, 0.22, 0.26), Vector3(-2.7, 1.66, 5.8), rail_col, "GateBeam")
    _box(self, Vector3(0.8, 0.34, 0.08), Vector3(-2.7, 1.30, 5.8), Color(0.45, 0.26, 0.12), "GateSign")
    _box(self, Vector3(0.22, 0.14, 0.04), Vector3(-2.7, 1.30, 5.86), Color(0.98, 0.80, 0.25), "GateEmblem")

func _process(delta: float) -> void:
    # Gentle wind: every tree rocks a little around its base (palms the most).
    sway_clock += delta
    _process_v17(delta)
    _process_v18(delta)
    _process_v19(delta)
    _process_v23(delta)
    _process_v24(delta)
    if v27 != null:
        v27.tick(delta)
    for entry in tree_sway:
        var tnode: Node3D = entry["node"]
        var phase: float = entry["phase"]
        var amp: float = entry["amp"]
        tnode.rotation.z = sin(sway_clock * 1.1 + phase) * amp
        tnode.rotation.x = cos(sway_clock * 0.8 + phase * 1.3) * amp * 0.6
    for c in cloud_nodes:
        var cn: Node3D = c["node"]
        var cax: Vector3 = c["axis"]
        var cspeed: float = c["speed"]
        cn.position += cax * cspeed * delta
        if cn.position.dot(cax) > 72.0:
            cn.position -= cax * 144.0
    for b in boat_nodes:
        var bn: Node3D = b["node"]
        var bphase: float = b["phase"]
        bn.position.y = float(b["base_y"]) + sin(sway_clock * 1.3 + bphase) * 0.07
        bn.rotation.z = sin(sway_clock * 0.9 + bphase) * 0.05
    if is_instance_valid(foam_node):
        var pulse: float = 1.0 + sin(sway_clock * 0.8) * 0.018
        foam_node.scale = Vector3(pulse, 1.0, pulse)
    autosave_timer += delta
    if autosave_timer >= 15.0:
        autosave_timer = 0.0
        _save_game()
    for key in crop_states.keys():
        var state: Dictionary = crop_states[key]
        if state.get("planted", false):
            state["age"] = float(state.get("age", 0.0)) + delta * (1.0 + 0.5 * rain) * _season_growth_mult() * (v27.growth_mult(str(key)) if v27 != null else 1.0)
            crop_states[key] = state
            var age := float(state.get("age", 0.0))
            var gtime: float = _grow_time_of(state)
            var stage := 0 if age < gtime * 0.35 else (1 if age < gtime else 2)
            if crop_stage_cache.get(str(key), -1) != stage:
                _update_crop_visual(str(key))
    if toast_time > 0.0:
        toast_time -= delta
        toast_label.visible = toast_time > 0.0

func _box(parent: Node3D, size: Vector3, pos: Vector3, color: Color, mesh_name: String = "Box") -> MeshInstance3D:
    var node := MeshInstance3D.new()
    node.name = mesh_name
    var mesh := BoxMesh.new()
    mesh.size = size
    node.mesh = mesh
    node.position = pos
    node.material_override = _mat(color)
    parent.add_child(node)
    return node

func _sphere(parent: Node3D, radius: float, height: float, pos: Vector3, color: Color, mesh_name: String = "Round") -> MeshInstance3D:
    var node := MeshInstance3D.new()
    node.name = mesh_name
    node.set_meta("nm", mesh_name)
    var mesh := SphereMesh.new()
    mesh.radius = radius
    mesh.height = height
    mesh.radial_segments = 8
    mesh.rings = 5
    node.mesh = mesh
    node.position = pos
    node.material_override = _mat(color)
    parent.add_child(node)
    return node

func _build_world() -> void:
    var environment := WorldEnvironment.new()
    var env := Environment.new()
    env.background_mode = Environment.BG_COLOR
    env.background_color = Color(0.48, 0.75, 0.92)
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color(0.78, 0.84, 0.95)
    env.ambient_light_energy = 0.8
    environment.environment = env
    add_child(environment)

    var sun := DirectionalLight3D.new()
    sun_light = sun
    env_ref = env
    sun.rotation_degrees = Vector3(-48, -32, 0)
    sun.light_energy = 1.25
    sun.shadow_enabled = true
    sun.directional_shadow_max_distance = 60.0
    add_child(sun)

    # v15: a much larger island surrounded by water so the camera can roam.
    _box(self, Vector3(180, 0.1, 180), Vector3(0, -0.66, 0), Color(0.09, 0.36, 0.74), "Water")
    _box(self, Vector3(WORLD_HALF * 2.0 + 0.9, 0.5, WORLD_HALF * 2.0 + 0.9), Vector3(0, -0.45, 0), Color(0.60, 0.44, 0.27), "IslandCliff")
    _box(self, Vector3(WORLD_HALF * 2.0, 0.35, WORLD_HALF * 2.0), Vector3(0, -0.22, 0), Color(0.32, 0.67, 0.28), "Meadow")
    # A pale winding path behind the crop plots.
    # Small grass tufts and subtle ground-cover patches break up the empty green
    # perimeter without obscuring the playable crop plots.
    for i in range(30):
        var gx := -6.4 + float((i * 7) % 20) * 0.66
        var gz := 5.85 if i % 2 == 0 else -5.85
        var tuft := _sphere(self, 0.11, 0.30, Vector3(gx, 0.08, gz), Color(0.20 + float(i % 3) * 0.025, 0.47 + float(i % 4) * 0.035, 0.16), "GrassTuft")
        tuft.rotation_degrees.z = float((i % 5) * 9 - 18)
    # Flat, irregularly spaced ground-cover clumps add color variation to the
    # lawn while remaining lightweight for mobile rendering.
    for i in range(18):
        var side := -1.0 if i % 2 == 0 else 1.0
        var patch_x := side * (4.5 + float((i * 3) % 5) * 0.42)
        var patch_z := -4.9 + float((i * 7) % 11) * 0.91
        if abs(patch_z) < 2.2:
            patch_z = 3.1 * side
        var patch := _sphere(self, 0.30 + float(i % 3) * 0.06, 0.12, Vector3(patch_x, 0.035, patch_z), Color(0.30 + float(i % 3) * 0.025, 0.62 + float(i % 2) * 0.04, 0.25), "GroundCoverPatch")
        patch.scale = Vector3(1.8, 0.22, 1.0 + float(i % 2) * 0.3)

    # v23: rounder, more detailed farmhouse and barn.
    _make_farmhouse()
    _make_barn()

    # Mix broadleaf, pine, palm and fir silhouettes around the farm.
    # The order is deliberate so the same scene has a varied skyline.
    var tree_positions := [
        Vector3(-5.2,0,-6.8), Vector3(6.4,0,-5.4),
        Vector3(-5.6,0,4.8), Vector3(5.7,0,4.5), Vector3(0,0,-5.8)
    ]
    for i in range(tree_positions.size()):
        _make_tree(tree_positions[i], i % 4)
    _make_fence()
    _make_flower_patch(Vector3(-5.0, 0.0, 1.4))
    _make_flower_patch(Vector3(5.0, 0.0, 1.6))
    _make_rock(Vector3(-4.8, 0.0, -1.4), 0.42)
    _make_rock(Vector3(4.7, 0.0, -1.3), 0.32)
    _register_animal(_make_cow(Vector3(5.0, 0.0, -1.7)), Vector2(0.6, 0.5), 0.30)
    _register_animal(_make_chicken(Vector3(-6.0, 0.0, -0.9)), Vector2(0.8, 0.5), 0.45)
    _register_animal(_make_chicken(Vector3(-5.5, 0.0, -0.5)), Vector2(0.8, 0.5), 0.45)
    _make_bush(Vector3(-6.2, 0.0, -2.7), Color(0.20, 0.48, 0.19))
    _make_bush(Vector3(5.0, 0.0, 3.2), Color(0.27, 0.57, 0.20))
    _make_bush(Vector3(-4.7, 0.0, 3.5), Color(0.24, 0.52, 0.18))
    _make_well(Vector3(5.0, 0.0, 0.1))
    _make_barrels(Vector3(5.5, 0.0, -3.0))

    # Crop plots sit in the central play area.
    # One seamless tilled field (no gaps or outlines between the cells).
    var bed_w: float = float(GRID_W) * CELL
    var bed_d: float = float(GRID_D) * CELL
    var bed_c: Vector3 = Vector3(0.3, 0.0, 0.8)
    _box(self, Vector3(bed_w + 0.3, 0.10, bed_d + 0.3), Vector3(bed_c.x, 0.0, bed_c.z), Color(0.50, 0.33, 0.19), "FieldFrame")
    _box(self, Vector3(bed_w, 0.13, bed_d), Vector3(bed_c.x, 0.02, bed_c.z), Color(0.40, 0.24, 0.14), "FieldBed")
    _box(self, Vector3(bed_w - 0.08, 0.04, bed_d - 0.08), Vector3(bed_c.x, 0.09, bed_c.z), Color(0.47, 0.30, 0.17), "FieldSoil")
    # Soft plough ridges running across the whole field.
    for r in range(GRID_D * 3):
        var rz: float = bed_c.z - bed_d * 0.5 + (float(r) + 0.5) * (bed_d / float(GRID_D * 3))
        var ridge: MeshInstance3D = _box(self, Vector3(bed_w - 0.12, 0.03, 0.10), Vector3(bed_c.x, 0.12, rz), Color(0.41, 0.25, 0.14), "FieldRidge")
        ridge.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    for z in range(GRID_D):
        for x in range(GRID_W):
            var key := _plot_key(x, z)
            var px := (float(x) - 2.0) * CELL + 0.3
            var pz := (float(z) - 2.0) * CELL + 0.8
            plot_centers[key] = Vector3(px, 0.0, pz)
            crop_states[key] = {"planted": false, "age": 0.0}
            _update_crop_visual(key)

func _cylinder(parent: Node3D, top_radius: float, bottom_radius: float, height: float, pos: Vector3, color: Color, mesh_name: String = "Cylinder") -> MeshInstance3D:
    var node := MeshInstance3D.new()
    node.name = mesh_name
    var mesh := CylinderMesh.new()
    mesh.top_radius = top_radius
    mesh.bottom_radius = bottom_radius
    mesh.height = height
    mesh.radial_segments = 7
    mesh.rings = 1
    node.mesh = mesh
    node.position = pos
    node.material_override = _mat(color)
    parent.add_child(node)
    return node

# ---------------------------------------------------------------------------
# Natural tree system (v14)
# Foliage is built as many small, double-sided leaf blades merged into ONE mesh
# per tree (vertex colours, flat-shaded normals), so trees look leafy but still
# cost only a couple of draw calls on a phone.
# ---------------------------------------------------------------------------

func _get_leaf_material() -> StandardMaterial3D:
    if leaf_material == null:
        leaf_material = StandardMaterial3D.new()
        leaf_material.vertex_color_use_as_albedo = true
        leaf_material.vertex_color_is_srgb = true
        leaf_material.roughness = 0.85
        leaf_material.cull_mode = BaseMaterial3D.CULL_DISABLED
    return leaf_material

func _tree_rng(pos: Vector3, tree_type: int) -> RandomNumberGenerator:
    # Deterministic: the same tree always grows the same leaves.
    var rng := RandomNumberGenerator.new()
    rng.seed = int(absf(pos.x) * 100.0) * 31 + int(absf(pos.z) * 100.0) * 17 + tree_type * 101 + 7
    return rng

func _tri(st: SurfaceTool, a: Vector3, b: Vector3, c: Vector3, ca: Color, cb: Color, cc: Color) -> void:
    var n: Vector3 = (b - a).cross(c - a)
    if n.length_squared() < 0.000001:
        return
    n = n.normalized()
    st.set_normal(n)
    st.set_color(ca)
    st.add_vertex(a)
    st.set_normal(n)
    st.set_color(cb)
    st.add_vertex(b)
    st.set_normal(n)
    st.set_color(cc)
    st.add_vertex(c)

func _add_leaf(st: SurfaceTool, origin: Vector3, dir: Vector3, side: Vector3, length: float, width: float, col_base: Color, col_tip: Color, fold: float = 0.10) -> void:
    # One folded, lance-shaped leaf blade (4 triangles) growing from `origin`.
    var d: Vector3 = dir.normalized()
    var s: Vector3 = side - d * side.dot(d)
    if s.length_squared() < 0.0001:
        s = d.cross(Vector3.UP)
        if s.length_squared() < 0.0001:
            s = Vector3.RIGHT
    s = s.normalized()
    var nrm: Vector3 = d.cross(s).normalized()
    var half: float = width * 0.5
    var mid: Vector3 = origin + d * length * 0.45
    var tip: Vector3 = origin + d * length
    var left: Vector3 = mid - s * half - nrm * width * fold
    var right: Vector3 = mid + s * half - nrm * width * fold
    var col_mid: Color = col_base.lerp(col_tip, 0.55)
    _tri(st, origin, left, mid, col_base, col_mid, col_mid)
    _tri(st, origin, mid, right, col_base, col_mid, col_mid)
    _tri(st, mid, left, tip, col_mid, col_mid, col_tip)
    _tri(st, mid, tip, right, col_mid, col_tip, col_mid)

func _commit_leaf_mesh(parent: Node3D, st: SurfaceTool, mesh_name: String) -> MeshInstance3D:
    var node := MeshInstance3D.new()
    node.name = mesh_name
    node.mesh = st.commit()
    node.material_override = _get_foliage_material()
    parent.add_child(node)
    return node

func _add_leafy_lobe(st: SurfaceTool, rng: RandomNumberGenerator, center: Vector3, radius: float, count: int, palette: Array) -> void:
    # A rounded mass of leaves. Upper leaves pick lighter tones (sun), lower
    # leaves pick darker tones (shade), and every blade tilts a little differently.
    for i in range(count):
        var out_vec: Vector3 = Vector3(rng.randf_range(-1.0, 1.0), rng.randf_range(-0.6, 1.0), rng.randf_range(-1.0, 1.0))
        if out_vec.length_squared() < 0.05:
            out_vec = Vector3.UP
        out_vec = out_vec.normalized()
        var origin: Vector3 = center + out_vec * radius * rng.randf_range(0.70, 1.0)
        var leaf_dir: Vector3 = (out_vec + Vector3(rng.randf_range(-0.45, 0.45), rng.randf_range(-0.55, 0.15), rng.randf_range(-0.45, 0.45))).normalized()
        var spin: Vector3 = Vector3(rng.randf_range(-1.0, 1.0), rng.randf_range(-1.0, 1.0), rng.randf_range(-1.0, 1.0))
        var light_bias: float = clampf((out_vec.y + 0.6) / 1.6, 0.0, 1.0)
        var idx: int = clampi(int(light_bias * float(palette.size()) + rng.randf_range(-0.8, 0.8)), 0, palette.size() - 1)
        var tone: Color = palette[idx]
        var leaf_len: float = rng.randf_range(0.30, 0.44)
        var leaf_w: float = leaf_len * rng.randf_range(0.50, 0.68)
        _add_leaf(st, origin, leaf_dir, spin, leaf_len, leaf_w, tone.darkened(0.18), tone.lightened(0.10), 0.12)

func _make_tree(pos: Vector3, tree_type: int = 0) -> void:
    # 0 = broadleaf fruit tree, 1 = pine, 2 = palm, 3 = fir/Christmas tree.
    var tree := Node3D.new()
    var names := ["BroadleafTree", "PineTree", "PalmTree", "FirTree"]
    tree.name = names[clampi(tree_type, 0, 3)]
    tree.position = pos
    var variant := int(abs(round(pos.x * 10.0) + round(pos.z * 7.0))) % 4
    tree.scale = [Vector3(0.92, 0.96, 0.94), Vector3(1.08, 1.02, 0.98), Vector3(0.98, 1.12, 1.04), Vector3(1.12, 0.94, 1.08)][variant]
    add_child(tree)
    # Register for the gentle wind sway applied in _process (palms move most).
    var sway_amp: float = [0.012, 0.008, 0.032, 0.008][clampi(tree_type, 0, 3)]
    tree_sway.append({"node": tree, "phase": float(variant) * 1.7 + pos.x, "amp": sway_amp})
    if tree_type == 1:
        _make_pine_tree(tree)
        return
    elif tree_type == 2:
        _make_palm_tree(tree)
        return
    elif tree_type == 3:
        _make_fir_tree(tree)
        return

    var bark := Color(0.34, 0.19, 0.09)
    var bark_light := Color(0.48, 0.29, 0.14)
    _cylinder(tree, 0.12, 0.22, 1.72, Vector3(0, 0.86, 0), bark, "TaperedTrunk")
    # Low roots give the trunk a grounded, natural connection to the soil.
    for root_angle in [0.0, 90.0, 180.0, 270.0]:
        var root := _cylinder(tree, 0.035, 0.09, 0.48, Vector3(0, 0.12, 0), bark_light, "RootFlare")
        root.rotation_degrees.z = 68.0
        root.rotation_degrees.y = root_angle
        root.position.x = cos(deg_to_rad(root_angle)) * 0.12
        root.position.z = sin(deg_to_rad(root_angle)) * 0.12

    # Branches angle out from the trunk and remain visible under the foliage.
    var branch_l := _cylinder(tree, 0.045, 0.095, 0.92, Vector3(-0.30, 1.30, 0.0), bark_light, "BranchLeft")
    branch_l.rotation_degrees.z = 42.0
    var branch_r := _cylinder(tree, 0.04, 0.085, 0.86, Vector3(0.30, 1.42, 0.02), bark, "BranchRight")
    branch_r.rotation_degrees.z = -40.0
    var branch_back := _cylinder(tree, 0.035, 0.075, 0.72, Vector3(0.02, 1.48, -0.24), bark_light, "BranchBack")
    branch_back.rotation_degrees.x = -38.0
    branch_back.rotation_degrees.z = 8.0

    # Crown: twelve lobes, each a dark core plus dozens of individual leaves.
    var rng: RandomNumberGenerator = _tree_rng(pos, 0)
    var palette: Array = [
        Color(0.10, 0.35, 0.14), Color(0.16, 0.46, 0.17), Color(0.23, 0.57, 0.20),
        Color(0.34, 0.67, 0.24), Color(0.46, 0.75, 0.28)
    ]
    var lobes: Array = [
        {"p": Vector3(0.00, 1.85, 0.00), "r": 0.62},
        {"p": Vector3(-0.45, 1.95, 0.05), "r": 0.50},
        {"p": Vector3(0.45, 1.98, 0.00), "r": 0.50},
        {"p": Vector3(-0.24, 2.30, 0.02), "r": 0.48},
        {"p": Vector3(0.26, 2.36, -0.05), "r": 0.44},
        {"p": Vector3(-0.58, 2.22, -0.10), "r": 0.36},
        {"p": Vector3(0.60, 2.22, 0.04), "r": 0.36},
        {"p": Vector3(0.00, 2.60, 0.00), "r": 0.32},
        {"p": Vector3(-0.36, 1.64, 0.30), "r": 0.34},
        {"p": Vector3(0.34, 1.70, 0.30), "r": 0.38},
        {"p": Vector3(0.00, 1.60, -0.30), "r": 0.30},
        {"p": Vector3(0.20, 2.05, 0.42), "r": 0.30}
    ]
    var st := SurfaceTool.new()
    st.begin(Mesh.PRIMITIVE_TRIANGLES)
    var lobe_index: int = 0
    for lobe in lobes:
        var lobe_pos: Vector3 = lobe["p"]
        var lobe_r: float = float(lobe["r"])
        _sphere(tree, lobe_r * 0.80, lobe_r * 1.45, lobe_pos, Color(0.09, 0.30, 0.12), "CrownCore_%02d" % lobe_index)
        _add_leafy_lobe(st, rng, lobe_pos, lobe_r, int(lobe_r * 150.0), palette)
        lobe_index += 1
    _commit_leaf_mesh(tree, st, "BroadleafFoliage")

    # A few tiny red fruits peek through the lower outside edge of the crown.
    for fruit_pos in [Vector3(0.47, 1.75, 0.40), Vector3(-0.43, 1.92, 0.38), Vector3(0.14, 2.08, 0.46)]:
        _sphere(tree, 0.075, 0.11, fruit_pos, Color(0.88, 0.16, 0.10), "AppleFruit")
        _cylinder(tree, 0.012, 0.018, 0.10, fruit_pos + Vector3(0, 0.075, 0), Color(0.28, 0.20, 0.09), "FruitStem")

func _build_conifer(tree: Node3D, tiers: Array, palette: Array, rng: RandomNumberGenerator, branches: int, droop: float, reach: float, foliage_name: String) -> void:
    # Each tier = a dark solid core cone + two rings of drooping branches. Every
    # branch is a 3-blade fan of needle cards, so the silhouette is jagged and
    # feathery instead of a smooth cone.
    var st := SurfaceTool.new()
    st.begin(Mesh.PRIMITIVE_TRIANGLES)
    for t in range(tiers.size()):
        var tier: Dictionary = tiers[t]
        var tier_y: float = float(tier["y"])
        var tier_h: float = float(tier["h"])
        var tier_r: float = float(tier["r"])
        var base_y: float = tier_y - tier_h * 0.5
        var tone: Color = palette[t % palette.size()]
        _cylinder(tree, 0.02, tier_r * 0.80, tier_h, Vector3(0, tier_y, 0), tone.darkened(0.25), "ConiferCore_%d" % t)
        for ring in range(2):
            var ring_count: int = branches if ring == 0 else int(float(branches) * 0.75)
            var ring_len: float = tier_r * (reach if ring == 0 else reach * 0.68)
            var ring_y: float = base_y + tier_h * (0.10 if ring == 0 else 0.48)
            for i in range(ring_count):
                var angle: float = (float(i) + rng.randf_range(-0.25, 0.25) + (0.5 if ring == 1 else 0.0)) * TAU / float(ring_count)
                var horiz: Vector3 = Vector3(cos(angle), 0.0, sin(angle))
                var origin: Vector3 = Vector3(horiz.x * 0.06, ring_y + rng.randf_range(-0.03, 0.05), horiz.z * 0.06)
                var blade_dir: Vector3 = horiz + Vector3(0.0, -droop + rng.randf_range(-0.08, 0.10), 0.0)
                var tone_i: Color = palette[(t + ring + i) % palette.size()]
                for fan in range(3):
                    var yaw_off: float = (float(fan) - 1.0) * 0.38
                    var fan_dir: Vector3 = blade_dir.rotated(Vector3.UP, yaw_off)
                    var len_scale: float = 1.0 if fan == 1 else 0.82
                    var blade_len: float = ring_len * len_scale
                    _add_leaf(st, origin, fan_dir, Vector3.UP.cross(fan_dir), blade_len, blade_len * 0.30, tone_i.darkened(0.20), tone_i.lightened(0.12), 0.14)
    _commit_leaf_mesh(tree, st, foliage_name)

func _make_pine_tree(tree: Node3D) -> void:
    var rng: RandomNumberGenerator = _tree_rng(tree.position, 1)
    var bark := Color(0.34, 0.20, 0.11)
    _cylinder(tree, 0.10, 0.17, 1.95, Vector3(0, 0.98, 0), bark, "PineTrunk")
    var palette: Array = [Color(0.07, 0.30, 0.19), Color(0.10, 0.40, 0.22), Color(0.16, 0.49, 0.26), Color(0.22, 0.57, 0.30)]
    # Pine: fewer, more widely spaced tiers with longer, flatter branches.
    var tiers: Array = [
        {"y": 0.95, "h": 1.18, "r": 0.78},
        {"y": 1.48, "h": 1.12, "r": 0.66},
        {"y": 1.98, "h": 1.02, "r": 0.52},
        {"y": 2.43, "h": 0.88, "r": 0.37}
    ]
    _build_conifer(tree, tiers, palette, rng, 9, 0.14, 1.15, "PineFoliage")
    _cylinder(tree, 0.0, 0.07, 0.34, Vector3(0, 2.92, 0), palette[3], "PineLeader")
    # Small hanging cones add detail near the branch tips.
    for cone_pos in [Vector3(0.52, 1.02, 0.18), Vector3(-0.44, 1.12, -0.32), Vector3(0.10, 1.55, 0.50), Vector3(-0.36, 1.58, 0.22), Vector3(0.30, 2.05, -0.30)]:
        _sphere(tree, 0.045, 0.15, cone_pos, Color(0.45, 0.28, 0.12), "PineCone")

func _make_fir_tree(tree: Node3D) -> void:
    var rng: RandomNumberGenerator = _tree_rng(tree.position, 3)
    var bark := Color(0.39, 0.23, 0.12)
    _cylinder(tree, 0.10, 0.17, 1.85, Vector3(0, 0.92, 0), bark, "FirTrunk")
    var palette: Array = [Color(0.06, 0.27, 0.16), Color(0.09, 0.36, 0.20), Color(0.14, 0.45, 0.23), Color(0.20, 0.53, 0.27)]
    # Fir: fuller and denser, with strongly drooping branches.
    var tiers: Array = [
        {"y": 0.78, "h": 0.96, "r": 0.77},
        {"y": 1.25, "h": 0.92, "r": 0.64},
        {"y": 1.70, "h": 0.86, "r": 0.50},
        {"y": 2.10, "h": 0.78, "r": 0.36},
        {"y": 2.46, "h": 0.65, "r": 0.23}
    ]
    _build_conifer(tree, tiers, palette, rng, 15, 0.42, 1.05, "FirFoliage")
    _cylinder(tree, 0.0, 0.06, 0.30, Vector3(0, 2.86, 0), palette[3], "FirLeader")

func _add_palm_frond(st: SurfaceTool, crown: Vector3, yaw_deg: float, length: float, lift: float, droop: float, dark: Color, light: Color, rng: RandomNumberGenerator) -> void:
    # The frond is laid out in a local frame where +X points along the frond.
    # Rotating about Y by -yaw turns local +X to (cos yaw, 0, sin yaw) in world.
    var frond_basis: Basis = Basis(Vector3.UP, -deg_to_rad(yaw_deg))
    var steps: int = 12
    var pts: Array[Vector3] = []
    for k in range(steps + 1):
        var t: float = float(k) / float(steps)
        var lp: Vector3 = Vector3(length * t, lift * t - droop * t * t, 0.0)
        pts.append(crown + frond_basis * lp)
    var side_axis: Vector3 = frond_basis * Vector3(0.0, 0.0, 1.0)
    var stem_col: Color = dark.lerp(Color(0.45, 0.50, 0.20), 0.5)

    # Central rib: a thin tapered strip along the arching spine.
    for k in range(steps):
        var w0: float = 0.030 * (1.0 - float(k) / float(steps + 2))
        var w1: float = 0.030 * (1.0 - float(k + 1) / float(steps + 2))
        var a: Vector3 = pts[k]
        var b: Vector3 = pts[k + 1]
        _tri(st, a - side_axis * w0, a + side_axis * w0, b + side_axis * w1, stem_col, stem_col, stem_col)
        _tri(st, a - side_axis * w0, b + side_axis * w1, b - side_axis * w1, stem_col, stem_col, stem_col)

    # Paired leaflets sweep forward and down from the rib, longest mid-frond.
    for k in range(2, steps + 1):
        var t: float = float(k) / float(steps)
        var p: Vector3 = pts[k]
        var tangent: Vector3 = (pts[mini(k + 1, steps)] - pts[k - 1]).normalized()
        var leaf_len: float = 0.58 * (1.0 - 0.52 * t) * minf(1.0, 0.45 + t * 1.6)
        var leaf_w: float = 0.105 * (1.0 - 0.3 * t)
        for sign_value in [-1.0, 1.0]:
            var sd: float = sign_value
            var out_dir: Vector3 = side_axis * sd + tangent * 0.55 + Vector3(0.0, -0.50 - 0.40 * t, 0.0)
            var tone: Color = dark.lerp(light, rng.randf_range(0.0, 1.0))
            _add_leaf(st, p, out_dir, tangent, leaf_len, leaf_w, tone.darkened(0.15), tone.lightened(0.15), 0.18)
    # Terminal leaflet continues the line of the rib.
    var end_tangent: Vector3 = (pts[steps] - pts[steps - 1]).normalized()
    _add_leaf(st, pts[steps], end_tangent, side_axis, 0.34, 0.10, dark.darkened(0.1), light.lightened(0.1), 0.18)

func _make_palm_tree(tree: Node3D) -> void:
    var rng: RandomNumberGenerator = _tree_rng(tree.position, 2)
    var bark: Color = Color(0.45, 0.30, 0.17)
    var ring_col: Color = Color(0.31, 0.20, 0.11)

    # Curved, tapering trunk built from short segments with growth rings.
    var segments: int = 7
    var total_h: float = 1.95
    var points: Array[Vector3] = []
    var radii: Array[float] = []
    for i in range(segments + 1):
        var t: float = float(i) / float(segments)
        points.append(Vector3(0.22 * t * t + 0.03 * sin(t * 3.0), total_h * t, 0.0))
        radii.append(lerpf(0.20, 0.10, t))
    _cylinder(tree, 0.20, 0.27, 0.18, Vector3(0.0, 0.09, 0.0), ring_col, "PalmBase")
    for i in range(segments):
        var p0: Vector3 = points[i]
        var p1: Vector3 = points[i + 1]
        var delta_v: Vector3 = p1 - p0
        var seg_len: float = delta_v.length()
        var seg_node: MeshInstance3D = _cylinder(tree, radii[i + 1], radii[i], seg_len * 1.02, (p0 + p1) * 0.5, bark.lightened(0.04 * float(i % 2)), "PalmTrunk_%d" % i)
        seg_node.rotation.z = -atan2(delta_v.x, delta_v.y)
        var ring: MeshInstance3D = _cylinder(tree, radii[i] + 0.022, radii[i] + 0.030, 0.05, p0 + Vector3(0.0, 0.02, 0.0), ring_col, "PalmTrunkRing_%d" % i)
        ring.rotation.z = seg_node.rotation.z

    var crown: Vector3 = points[segments] + Vector3(0.0, 0.05, 0.0)
    _sphere(tree, 0.20, 0.30, crown, Color(0.28, 0.40, 0.14), "PalmCrownBoss")
    # Coconut cluster tucked under the fronds.
    for k in range(4):
        var ca: float = float(k) * TAU / 4.0 + 0.4
        var nut_col: Color = Color(0.36, 0.24, 0.10) if k % 2 == 0 else Color(0.40, 0.45, 0.14)
        _sphere(tree, 0.075, 0.15, crown + Vector3(cos(ca) * 0.15, -0.12, sin(ca) * 0.15), nut_col, "Coconut")

    var dark: Color = Color(0.10, 0.40, 0.17)
    var light: Color = Color(0.34, 0.66, 0.25)
    var st := SurfaceTool.new()
    st.begin(Mesh.PRIMITIVE_TRIANGLES)
    var frond_count: int = 10
    for i in range(frond_count):
        var yaw_deg: float = float(i) * 360.0 / float(frond_count) + rng.randf_range(-9.0, 9.0)
        var is_old: bool = (i % 5 == 3)
        var length: float = rng.randf_range(1.25, 1.55)
        var lift: float = 0.15 if is_old else rng.randf_range(0.55, 0.85)
        var droop: float = 1.90 if is_old else rng.randf_range(1.05, 1.35)
        var f_dark: Color = Color(0.36, 0.42, 0.14) if is_old else dark
        var f_light: Color = Color(0.58, 0.60, 0.22) if is_old else light
        _add_palm_frond(st, crown, yaw_deg, length, lift, droop, f_dark, f_light, rng)
    # Three short, upright young fronds in the centre fill the top of the crown.
    for i in range(3):
        var yaw_deg: float = float(i) * 120.0 + rng.randf_range(0.0, 40.0)
        _add_palm_frond(st, crown, yaw_deg, 0.85, 1.10, 0.85, dark, light.lightened(0.08), rng)
    _commit_leaf_mesh(tree, st, "PalmFoliage")

func _make_farmer(pos: Vector3) -> void:
    # A simple stylized 3D farmer gives the scene a visible sense of scale.
    var farmer := Node3D.new()
    farmer.name = "FarmerCharacter"
    farmer.position = pos
    farmer.rotation_degrees.y = -18
    add_child(farmer)
    _box(farmer, Vector3(0.34, 0.48, 0.24), Vector3(0, 0.70, 0), Color(0.18, 0.39, 0.86), "Overalls")
    _sphere(farmer, 0.20, 0.22, Vector3(0, 1.08, 0), Color(0.91, 0.67, 0.48), "Head")
    _box(farmer, Vector3(0.44, 0.08, 0.34), Vector3(0, 1.23, 0), Color(0.93, 0.63, 0.18), "HatBrim")
    _sphere(farmer, 0.16, 0.10, Vector3(0, 1.28, 0), Color(0.93, 0.63, 0.18), "HatTop")
    var arm_l := _box(farmer, Vector3(0.12, 0.40, 0.13), Vector3(-0.24, 0.72, 0), Color(0.91, 0.67, 0.48), "LeftArm")
    arm_l.rotation_degrees.z = -12
    var arm_r := _box(farmer, Vector3(0.12, 0.40, 0.13), Vector3(0.24, 0.72, 0), Color(0.91, 0.67, 0.48), "RightArm")
    arm_r.rotation_degrees.z = 12
    _box(farmer, Vector3(0.13, 0.34, 0.15), Vector3(-0.10, 0.30, 0), Color(0.28, 0.22, 0.18), "LeftBoot")
    _box(farmer, Vector3(0.13, 0.34, 0.15), Vector3(0.10, 0.30, 0), Color(0.28, 0.22, 0.18), "RightBoot")

func _make_chicken(pos: Vector3) -> Node3D:
    var bird := Node3D.new()
    bird.name = "FarmChicken"
    bird.set_meta("species", 1)
    bird.position = pos
    add_child(bird)
    _sphere(bird, 0.19, 0.30, Vector3(0,0.28,0), Color(0.98,0.94,0.82), "ChickenBody")
    _sphere(bird, 0.12, 0.17, Vector3(0.12,0.43,0.02), Color(0.98,0.94,0.82), "ChickenHead")
    _sphere(bird, 0.045, 0.07, Vector3(0.20,0.42,0.08), Color(0.95,0.32,0.12), "ChickenBeak")
    _sphere(bird, 0.055, 0.07, Vector3(0.12,0.53,0.02), Color(0.90,0.20,0.15), "ChickenComb")
    for x in [-0.07,0.08]:
        _box(bird, Vector3(0.035,0.15,0.035), Vector3(x,0.09,0), Color(0.93,0.47,0.12), "ChickenLeg")
    return bird

func _make_bush(pos: Vector3, color: Color) -> void:
    var bush := Node3D.new()
    bush.name = "GardenBush"
    bush.position = pos
    add_child(bush)
    _sphere(bush, 0.42, 0.55, Vector3(-0.20,0.28,0), color, "BushLeft")
    _sphere(bush, 0.48, 0.62, Vector3(0.18,0.32,0.04), color.lightened(0.08), "BushMiddle")
    _sphere(bush, 0.34, 0.45, Vector3(0.48,0.23,-0.04), color.darkened(0.06), "BushRight")

func _make_well(pos: Vector3) -> void:
    var well := Node3D.new()
    well.name = "StoneWell"
    well.position = pos
    add_child(well)
    _sphere(well, 0.55, 0.25, Vector3(0,0.15,0), Color(0.60,0.62,0.59), "WellBase")
    _disc(well, 0.50, 0.26, Vector3(0, 0.30, 0), Color(0.66, 0.67, 0.62), "WellRing", 0.9, 18, -1.0, true)
    _disc(well, 0.37, 0.02, Vector3(0, 0.44, 0), Color(0.20, 0.45, 0.70), "WellWater", 0.4, 18)
    _disc(well, 0.09, 0.14, Vector3(0, 0.98, 0), Color(0.50, 0.32, 0.16), "WellBucket", 0.9, 10)
    _box(well, Vector3(0.10,0.95,0.10), Vector3(-0.42,0.70,0), Color(0.39,0.24,0.13), "WellPostLeft")
    _box(well, Vector3(0.10,0.95,0.10), Vector3(0.42,0.70,0), Color(0.39,0.24,0.13), "WellPostRight")
    _box(well, Vector3(0.95,0.10,0.12), Vector3(0,1.14,0), Color(0.43,0.27,0.15), "WellBeam")
    var roof_l := _box(well, Vector3(0.66, 0.09, 0.86), Vector3(-0.29, 1.40, 0), Color(0.58, 0.28, 0.18), "WellRoofL")
    roof_l.rotation_degrees.z = 30
    var roof_r := _box(well, Vector3(0.66, 0.09, 0.86), Vector3(0.29, 1.40, 0), Color(0.68, 0.34, 0.22), "WellRoofR")
    roof_r.rotation_degrees.z = -30

func _make_barrels(pos: Vector3) -> void:
    for i in range(2):
        var barrel := _sphere(self, 0.28, 0.55, pos + Vector3(float(i) * 0.48,0.28,0), Color(0.49,0.29,0.15), "WoodenBarrel")
        barrel.scale = Vector3(0.88,1.0,0.88)
        _sphere(self, 0.29, 0.08, pos + Vector3(float(i) * 0.48,0.52,0), Color(0.31,0.19,0.11), "BarrelTop")

func _make_flower_patch(pos: Vector3) -> void:
    for i in range(7):
        var x := float(i % 3) * 0.22 - 0.22
        var z := float(i / 3) * 0.22 - 0.18
        _sphere(self, 0.08, 0.10, pos + Vector3(x, 0.08, z), Color(0.22, 0.55, 0.19), "FlowerStem")
        var petal_color: Color = [Color(1.0,0.82,0.22), Color(1.0,0.46,0.58), Color(0.98,0.95,0.85)][i % 3]
        _sphere(self, 0.07, 0.07, pos + Vector3(x, 0.17, z), petal_color, "Flower")

func _make_rock(pos: Vector3, radius: float) -> void:
    var rock := _sphere(self, radius, radius * 1.4, pos + Vector3(0, radius * 0.42, 0), Color(0.48, 0.55, 0.56), "GardenRock")
    rock.scale = Vector3(1.25, 0.82, 0.95)

func _plot_key(x: int, z: int) -> String:
    return str(x) + "," + str(z)

func _panel_style(color: Color, radius: int) -> StyleBoxFlat:
    var style := StyleBoxFlat.new()
    style.bg_color = color
    style.corner_radius_top_left = radius
    style.corner_radius_top_right = radius
    style.corner_radius_bottom_left = radius
    style.corner_radius_bottom_right = radius
    style.content_margin_left = 14
    style.content_margin_right = 14
    style.content_margin_top = 10
    style.content_margin_bottom = 10
    return style

func _buy_seeds() -> void:
    if coins < SEED_COST:
        _show_toast("You need 12 coins for a seed pack.")
        return
    coins -= SEED_COST
    seeds += SEED_PACK
    _refresh_ui()
    _save_game()
    _refresh_shop()
    _show_toast("Bought 5 seeds!")

func _show_toast(message: String) -> void:
    toast_text = message
    toast_label.text = message
    toast_label.visible = true
    toast_time = 2.8

# ===========================================================================
# v15 — bigger world (roads, ponds, animal pen, buildings, forest)
# ===========================================================================

func _disc(parent: Node3D, radius: float, height: float, pos: Vector3, color: Color, mesh_name: String, roughness: float = 0.9, segments: int = 24, top_radius: float = -1.0, cast_shadows: bool = false) -> MeshInstance3D:
    # A smooth (many-sided) cylinder or cone frustum. `radius` is the bottom.
    var node := MeshInstance3D.new()
    node.name = mesh_name
    var mesh := CylinderMesh.new()
    mesh.bottom_radius = radius
    mesh.top_radius = radius if top_radius < 0.0 else top_radius
    mesh.height = height
    mesh.radial_segments = segments
    mesh.rings = 1
    node.mesh = mesh
    node.position = pos
    node.material_override = _mat(color, roughness)
    if not cast_shadows:
        node.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    parent.add_child(node)
    return node

func _road_piece(a: Vector2, b: Vector2, width: float, color: Color, y: float) -> void:
    var d: Vector2 = b - a
    var seg_len: float = d.length()
    if seg_len < 0.01:
        return
    var mid: Vector2 = (a + b) * 0.5
    var piece: MeshInstance3D = _box(self, Vector3(width, 0.04, seg_len), Vector3(mid.x, y, mid.y), color, "RoadPiece")
    piece.rotation_degrees.y = rad_to_deg(atan2(d.x, d.y))
    piece.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    # Round discs at both ends make the bends of the road look smooth.
    _disc(self, width * 0.5, 0.04, Vector3(a.x, y, a.y), color, "RoadJoint", 0.9, 14)
    _disc(self, width * 0.5, 0.04, Vector3(b.x, y, b.y), color, "RoadJoint", 0.9, 14)

func _build_road(points: Array, width: float) -> void:
    road_polys.append(points)
    # Darker, wider underlay first (soft dirt edge), then the pale sand surface.
    for i in range(points.size() - 1):
        var a: Vector2 = points[i]
        var b: Vector2 = points[i + 1]
        _road_piece(a, b, width + 0.36, Color(0.76, 0.60, 0.38), -0.028)
    for i in range(points.size() - 1):
        var a: Vector2 = points[i]
        var b: Vector2 = points[i + 1]
        _road_piece(a, b, width, Color(0.87, 0.73, 0.50), -0.016)
        path_segments.append([a, b])

func _dist_to_segment(p: Vector2, a: Vector2, b: Vector2) -> float:
    var ab: Vector2 = b - a
    var denom: float = ab.length_squared()
    if denom < 0.0001:
        return p.distance_to(a)
    var t: float = clampf((p - a).dot(ab) / denom, 0.0, 1.0)
    return p.distance_to(a + ab * t)

func _is_clear(p: Vector3, margin: float) -> bool:
    # True when a point is outside the farm island, buildings, ponds and roads.
    if absf(p.x) < 7.8 and absf(p.z) < 7.4:
        return false
    var p2: Vector2 = Vector2(p.x, p.z)
    for blocker in blockers:
        var c: Vector2 = blocker["c"]
        var r: float = float(blocker["r"])
        if p2.distance_to(c) < r + margin:
            return false
    for seg in path_segments:
        var sa: Vector2 = seg[0]
        var sb: Vector2 = seg[1]
        if _dist_to_segment(p2, sa, sb) < 0.85 + margin:
            return false
    return true

func _random_clear_point(rng: RandomNumberGenerator, margin: float, min_edge: float, avoid: Array, avoid_dist: float) -> Vector3:
    for _attempt in range(40):
        var p: Vector3 = Vector3(rng.randf_range(-16.8, 16.8), 0.0, rng.randf_range(-16.8, 16.8))
        if maxf(absf(p.x), absf(p.z)) < min_edge:
            continue
        if not _is_clear(p, margin):
            continue
        var ok: bool = true
        for q in avoid:
            var q2: Vector2 = q
            if Vector2(p.x, p.z).distance_to(q2) < avoid_dist:
                ok = false
                break
        if ok:
            return p
    return Vector3.INF

func _make_pond(pos: Vector3, radius: float, rng: RandomNumberGenerator) -> void:
    _disc(self, radius + 0.5, 0.05, pos + Vector3(0.0, -0.02, 0.0), Color(0.82, 0.72, 0.52), "PondShore", 0.9, 28)
    _disc(self, radius, 0.06, pos, Color(0.24, 0.62, 0.92), "PondWater", 0.25, 28)
    for i in range(7):
        var ang: float = float(i) * TAU / 7.0 + rng.randf_range(-0.2, 0.2)
        _make_rock(pos + Vector3(cos(ang) * (radius + 0.6), 0.0, sin(ang) * (radius + 0.6)), rng.randf_range(0.18, 0.32))
    for i in range(3):
        var pad_pos: Vector3 = pos + Vector3(rng.randf_range(-radius * 0.5, radius * 0.5), 0.035, rng.randf_range(-radius * 0.5, radius * 0.5))
        _disc(self, 0.2, 0.02, pad_pos, Color(0.30, 0.70, 0.28), "LilyPad", 0.9, 10)

func _fence_line(a: Vector2, b: Vector2, post_col: Color, rail_col: Color, post_h: float = 0.62) -> void:
    var d: Vector2 = b - a
    var seg_len: float = d.length()
    if seg_len < 0.05:
        return
    var count: int = maxi(1, int(round(seg_len / 1.1)))
    for i in range(count + 1):
        var p: Vector2 = a + d * (float(i) / float(count))
        _box(self, Vector3(0.12, post_h, 0.12), Vector3(p.x, post_h * 0.5 - 0.02, p.y), post_col, "FencePost")
    var mid: Vector2 = (a + b) * 0.5
    var yaw: float = rad_to_deg(atan2(d.x, d.y))
    for h in [0.24, 0.46]:
        var rail: MeshInstance3D = _box(self, Vector3(0.07, 0.08, seg_len), Vector3(mid.x, float(h), mid.y), rail_col, "FenceRail")
        rail.rotation_degrees.y = yaw

func _make_pen(center: Vector2) -> void:
    var hx: float = 2.8
    var hz: float = 2.0
    var post_col: Color = Color(0.18, 0.42, 0.74)
    var rail_col: Color = Color(0.38, 0.66, 0.93)
    # Soft trampled-grass floor.
    var floor_node: MeshInstance3D = _box(self, Vector3(hx * 2.0, 0.03, hz * 2.0), Vector3(center.x, -0.025, center.y), Color(0.62, 0.80, 0.40), "PenFloor")
    floor_node.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    # North side has a gap for the gate; the road ends right there.
    _fence_line(Vector2(center.x - hx, center.y - hz), Vector2(center.x - 0.7, center.y - hz), post_col, rail_col)
    _fence_line(Vector2(center.x + 0.7, center.y - hz), Vector2(center.x + hx, center.y - hz), post_col, rail_col)
    _fence_line(Vector2(center.x + hx, center.y - hz), Vector2(center.x + hx, center.y + hz), post_col, rail_col)
    _fence_line(Vector2(center.x + hx, center.y + hz), Vector2(center.x - hx, center.y + hz), post_col, rail_col)
    _fence_line(Vector2(center.x - hx, center.y + hz), Vector2(center.x - hx, center.y - hz), post_col, rail_col)
    # Trough, water and hay.
    _box(self, Vector3(1.3, 0.22, 0.42), Vector3(center.x + 0.9, 0.12, center.y - 1.5), Color(0.50, 0.32, 0.17), "FeedTrough")
    _box(self, Vector3(1.1, 0.06, 0.28), Vector3(center.x + 0.9, 0.23, center.y - 1.5), Color(0.35, 0.68, 0.92), "TroughWater")
    _box(self, Vector3(0.7, 0.40, 0.5), Vector3(center.x - 2.0, 0.20, center.y + 1.4), Color(0.93, 0.78, 0.30), "HayBale")
    _box(self, Vector3(0.6, 0.34, 0.45), Vector3(center.x - 1.3, 0.17, center.y + 1.5), Color(0.88, 0.72, 0.26), "HayBale")
    # Animals.
    var pen_ext: Vector2 = Vector2(2.1, 1.3)
    _register_animal(_make_cow(Vector3(center.x - 1.6, 0.0, center.y - 0.7)), pen_ext, 0.32, center)
    _register_animal(_make_cow(Vector3(center.x + 0.9, 0.0, center.y + 0.1)), pen_ext, 0.32, center)
    _register_animal(_make_cow(Vector3(center.x - 0.3, 0.0, center.y + 1.2)), pen_ext, 0.32, center)
    _register_animal(_make_pig(Vector3(center.x + 1.9, 0.0, center.y + 1.2), 200.0), pen_ext, 0.42, center)
    _register_animal(_make_pig(Vector3(center.x - 2.0, 0.0, center.y - 0.6), 40.0), pen_ext, 0.42, center)

func _make_silo(pos: Vector3) -> void:
    var silo := Node3D.new()
    silo.name = "GrainSilo"
    silo.position = pos
    add_child(silo)
    _disc(silo, 0.82, 2.5, Vector3(0.0, 1.25, 0.0), Color(0.80, 0.24, 0.18), "SiloBody", 0.9, 24, 0.78, true)
    for band_y in [0.55, 1.25, 1.95]:
        _disc(silo, 0.82, 0.10, Vector3(0.0, float(band_y), 0.0), Color(0.96, 0.90, 0.78), "SiloBand", 0.9, 16, -1.0, false)
    _ellipsoid(silo, Vector3(0.87, 0.55, 0.87), Vector3(0.0, 2.5, 0.0), Color(0.95, 0.76, 0.25), "SiloDome")
    _box(silo, Vector3(0.5, 0.8, 0.10), Vector3(0.0, 0.4, 0.80), Color(0.42, 0.24, 0.12), "SiloDoor")
    _sphere(silo, 0.12, 0.20, Vector3(0.0, 3.04, 0.0), Color(0.98, 0.84, 0.35), "SiloCap")

func _make_bakery_oven(pos: Vector3) -> void:
    # v27g: a proper bakery shop with a big roof sign (was a small oven).
    var shop := Node3D.new()
    shop.name = "BakeryOven"
    shop.position = pos
    add_child(shop)
    var wall := Color(0.98, 0.90, 0.72)
    var roof := Color(0.72, 0.28, 0.22)
    _box(shop, Vector3(2.6, 1.3, 1.9), Vector3(0, 0.65, 0), wall, "BakeryWall")
    var r1: MeshInstance3D = _box(shop, Vector3(1.7, 0.08, 2.2), Vector3(-0.62, 1.55, 0), roof, "BakeryRoofA")
    r1.rotation_degrees.z = 32.0
    var r2: MeshInstance3D = _box(shop, Vector3(1.7, 0.08, 2.2), Vector3(0.62, 1.55, 0), roof.darkened(0.1), "BakeryRoofB")
    r2.rotation_degrees.z = -32.0
    _box(shop, Vector3(0.5, 0.8, 0.08), Vector3(0.75, 0.4, 0.97), Color(0.45, 0.28, 0.14), "BakeryDoor")
    var win: MeshInstance3D = _box(shop, Vector3(0.8, 0.45, 0.05), Vector3(-0.6, 0.45, 0.96), Color(0.33, 0.76, 0.92), "BakeryWin")
    win.material_override = _window_material()
    for i in range(5):
        var ac: Color = Color(0.86, 0.22, 0.25) if i % 2 == 0 else Color(0.98, 0.95, 0.90)
        var aw: MeshInstance3D = _box(shop, Vector3(0.2, 0.05, 0.55), Vector3(-1.1 + (float(i) + 0.5) * 0.2, 0.82, 1.15), ac, "BakeryAwning")
        aw.rotation_degrees.x = 18.0
    for i in range(4):
        var loaf: MeshInstance3D = _sphere(shop, 0.10, 0.13, Vector3(-0.9 + float(i) * 0.22, 0.22, 1.0), Color(0.88, 0.62, 0.30), "BreadLoaf")
        loaf.scale = Vector3(1.4, 0.8, 0.9)
    _box(shop, Vector3(0.3, 0.7, 0.3), Vector3(-0.9, 2.0, -0.4), Color(0.55, 0.25, 0.18), "BakeryChimney")
    _make_smoke(shop, Vector3(-0.9, 2.45, -0.4))
    # Roof sign, turned to face the camera.
    var pv := Node3D.new()
    pv.name = "BakerySign"
    pv.position = Vector3(0, 2.7, 0)
    pv.rotation_degrees.y = 34.0
    shop.add_child(pv)
    for x in [-0.8, 0.8]:
        _box(pv, Vector3(0.08, 1.0, 0.08), Vector3(x, -0.65, -0.02), Color(0.45, 0.28, 0.14), "BakerySignPost")
    _box(pv, Vector3(2.3, 0.65, 0.12), Vector3.ZERO, Color(0.45, 0.28, 0.14), "SignBoard")
    _box(pv, Vector3(2.18, 0.53, 0.05), Vector3(0, 0, 0.07), Color(0.99, 0.85, 0.45), "SignFace")
    var l: Label3D = _label3d(pv, "BAKERY", Vector3(0, 0, 0.12), 0.0085, Color(0.55, 0.20, 0.10))
    l.billboard = BaseMaterial3D.BILLBOARD_DISABLED
    l.outline_size = 6
    # Same sign on the other side so it reads from the front of the shop too.

func _make_market_tent(pos: Vector3) -> void:
    var tent := Node3D.new()
    tent.name = "MarketTent"
    tent.position = pos
    add_child(tent)
    _disc(tent, 1.3, 0.55, Vector3(0.0, 0.27, 0.0), Color(0.97, 0.93, 0.82), "TentWall", 0.9, 16, -1.0, true)
    var radii: Array = [1.55, 1.2, 0.85, 0.5, 0.06]
    for i in range(4):
        var stripe_col: Color = Color(0.18, 0.62, 0.34) if i % 2 == 0 else Color(0.98, 0.96, 0.90)
        _disc(tent, float(radii[i]), 0.34, Vector3(0.0, 0.72 + float(i) * 0.34, 0.0), stripe_col, "TentStripe", 0.9, 16, float(radii[i + 1]), true)
    _cylinder(tent, 0.03, 0.03, 0.5, Vector3(0.0, 2.3, 0.0), Color(0.45, 0.30, 0.16), "TentPole")
    _box(tent, Vector3(0.30, 0.18, 0.04), Vector3(0.16, 2.42, 0.0), Color(0.90, 0.25, 0.20), "TentFlag")
    _box(tent, Vector3(0.5, 0.4, 0.5), Vector3(1.7, 0.2, 0.5), Color(0.60, 0.40, 0.20), "MarketCrate")
    _box(tent, Vector3(0.45, 0.35, 0.45), Vector3(1.55, 0.58, 0.45), Color(0.66, 0.45, 0.22), "MarketCrate")
    _box(tent, Vector3(0.5, 0.4, 0.5), Vector3(-1.7, 0.2, 0.7), Color(0.60, 0.40, 0.20), "MarketCrate")

func _make_scenery_tree(pos: Vector3, kind: int, size_scale: float, rng: RandomNumberGenerator) -> void:
    # Light-weight background trees: 0 green broadleaf, 1 fir, 2 pine,
    # 3 pink blossom, 4 golden, 5 purple.
    var tree := Node3D.new()
    tree.name = "ScenicTree_%d" % kind
    tree.position = pos
    tree.scale = Vector3.ONE * size_scale
    tree.rotation_degrees.y = rng.randf_range(0.0, 360.0)
    add_child(tree)
    var bark: Color = Color(0.36, 0.22, 0.12)
    if kind == 1 or kind == 2:
        _cylinder(tree, 0.09, 0.15, 1.2, Vector3(0.0, 0.6, 0.0), bark, "ScenicTrunk")
        var greens: Array = [Color(0.07, 0.30, 0.19), Color(0.10, 0.40, 0.22), Color(0.16, 0.49, 0.26), Color(0.22, 0.57, 0.30)]
        if kind == 2:
            greens = [Color(0.12, 0.38, 0.22), Color(0.17, 0.48, 0.26), Color(0.24, 0.57, 0.30), Color(0.32, 0.65, 0.34)]
        var tiers: Array = [
            {"y": 0.75, "h": 0.90, "r": 0.72},
            {"y": 1.30, "h": 0.85, "r": 0.55},
            {"y": 1.80, "h": 0.75, "r": 0.38},
            {"y": 2.20, "h": 0.60, "r": 0.25}
        ]
        var branches: int = 8 if kind == 1 else 7
        var droop: float = 0.40 if kind == 1 else 0.16
        _build_conifer(tree, tiers, greens, rng, branches, droop, 1.05, "ScenicConifer")
        return
    var palette: Array = [
        Color(0.10, 0.35, 0.14), Color(0.16, 0.46, 0.17), Color(0.23, 0.57, 0.20),
        Color(0.34, 0.67, 0.24), Color(0.46, 0.75, 0.28)
    ]
    var core_col: Color = Color(0.09, 0.30, 0.12)
    if kind == 3:
        palette = [Color(0.80, 0.35, 0.55), Color(0.92, 0.50, 0.68), Color(0.98, 0.65, 0.78), Color(1.0, 0.78, 0.86), Color(1.0, 0.88, 0.92)]
        core_col = Color(0.55, 0.20, 0.38)
    elif kind == 4:
        palette = [Color(0.80, 0.58, 0.10), Color(0.92, 0.72, 0.18), Color(0.98, 0.82, 0.28), Color(1.0, 0.90, 0.45), Color(1.0, 0.95, 0.62)]
        core_col = Color(0.55, 0.38, 0.08)
    elif kind == 5:
        palette = [Color(0.40, 0.30, 0.75), Color(0.52, 0.42, 0.86), Color(0.65, 0.55, 0.93), Color(0.78, 0.70, 0.97), Color(0.88, 0.82, 1.0)]
        core_col = Color(0.28, 0.20, 0.55)
    _cylinder(tree, 0.10, 0.17, 1.3, Vector3(0.0, 0.65, 0.0), bark, "ScenicTrunk")
    var lobes: Array = [
        {"p": Vector3(0.0, 1.65, 0.0), "r": 0.62},
        {"p": Vector3(-0.40, 1.50, 0.10), "r": 0.46},
        {"p": Vector3(0.40, 1.55, -0.05), "r": 0.46},
        {"p": Vector3(0.0, 2.10, 0.0), "r": 0.40}
    ]
    var st := SurfaceTool.new()
    st.begin(Mesh.PRIMITIVE_TRIANGLES)
    var lobe_index: int = 0
    for lobe in lobes:
        var lobe_pos: Vector3 = lobe["p"]
        var lobe_r: float = float(lobe["r"])
        _sphere(tree, lobe_r * 0.80, lobe_r * 1.45, lobe_pos, core_col, "ScenicCore_%d" % lobe_index)
        _add_leafy_lobe(st, rng, lobe_pos, lobe_r, int(lobe_r * 85.0), palette)
        lobe_index += 1
    _commit_leaf_mesh(tree, st, "ScenicFoliage")

func _build_world_extras() -> void:
    var rng := RandomNumberGenerator.new()
    rng.seed = 20261012
    blockers = [
        {"c": Vector2(-12.5, 4.5), "r": 4.0},
        {"c": Vector2(-12.0, -6.5), "r": 3.6},
        {"c": Vector2(15.5, 7.0), "r": 3.0},
        {"c": Vector2(9.6, -7.4), "r": 2.2},
        {"c": Vector2(-10.8, -1.4), "r": 2.4},
        {"c": Vector2(8.2, 11.0), "r": 2.4},
        {"c": Vector2(8.7, 0.0), "r": 3.9},
        {"c": Vector2(1.4, -8.25), "r": 3.2},
        {"c": Vector2(-10.0, 12.5), "r": 3.4},
        {"c": Vector2(15.0, -14.6), "r": 4.2},
        {"c": Vector2(17.0, -2.5), "r": 1.8},
        {"c": Vector2(-6.2, -15.0), "r": 3.6},
        {"c": Vector2(-1.0, -15.4), "r": 2.7},
        {"c": Vector2(3.6, -15.4), "r": 2.7},
        {"c": Vector2(8.0, -15.4), "r": 2.7},
        {"c": Vector2(5.5, -18.4), "r": 2.2}
    ]
    # Reserved train corridor (the tracks are built later, trees keep clear of them).
    _train_reserve_corridor()
    # Winding sand roads leave the farm through the south gate and the west side.
    _build_road([Vector2(-2.7, 5.4), Vector2(-3.4, 8.5), Vector2(-2.0, 12.0), Vector2(1.5, 14.5), Vector2(6.0, 15.5)], 1.25)
    _build_road([Vector2(-3.4, 8.5), Vector2(2.0, 9.4), Vector2(7.5, 8.6), Vector2(11.5, 5.5), Vector2(14.5, 1.0), Vector2(16.0, -4.0), Vector2(16.0, -9.0)], 1.25)
    _build_road([Vector2(-2.2, -5.0), Vector2(-3.5, -8.0), Vector2(-6.0, -10.5), Vector2(-10.0, -12.5), Vector2(-14.5, -12.5)], 1.25)
    _build_road([Vector2(-4.2, -2.9), Vector2(-4.2, 0.0), Vector2(-6.5, 0.0), Vector2(-9.5, 1.4), Vector2(-12.5, 1.6), Vector2(-12.5, 2.4)], 1.25)

    _build_road([Vector2(16.0, -9.0), Vector2(16.9, -12.0), Vector2(17.6, -14.6)], 1.25)
    _make_pond(Vector3(-12.0, 0.0, -6.5), 2.6, rng)
    _make_pond(Vector3(15.5, 0.0, 7.0), 2.2, rng)
    _make_pen(Vector2(-12.5, 4.5))
    _make_silo(Vector3(9.6, 0.0, -7.4))
    _make_bakery_oven(Vector3(-10.8, 0.0, -1.4))
    _make_market_tent(Vector3(8.2, 0.0, 11.0))

    # Soft colour variation across the big lawn (flat, no shadows).
    for i in range(26):
        var gp: Vector3 = _random_clear_point(rng, 0.2, 8.0, [], 0.0)
        if gp == Vector3.INF:
            continue
        var tint: Color = Color(0.40, 0.74, 0.32) if i % 2 == 0 else Color(0.27, 0.60, 0.24)
        var patch: MeshInstance3D = _sphere(self, 0.7 + rng.randf_range(0.0, 0.5), 0.12, Vector3(gp.x, 0.03, gp.z), tint, "LawnPatch")
        patch.scale = Vector3(2.4, 0.2, 1.5)
        patch.rotation_degrees.y = rng.randf_range(0.0, 180.0)
        patch.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF

    # Forest: mostly around the rim, then a few trees filling the middle ground.
    var placed: Array = []
    var attempts: int = 0
    while placed.size() < 46 and attempts < 200:
        attempts += 1
        var edge_only: float = 11.0 if placed.size() < 30 else 8.0
        var tp: Vector3 = _random_clear_point(rng, 1.0, edge_only, placed, 1.8)
        if tp == Vector3.INF:
            continue
        placed.append(Vector2(tp.x, tp.z))
        var roll: float = rng.randf()
        var kind: int = 5
        if roll < 0.34:
            kind = 1
        elif roll < 0.46:
            kind = 2
        elif roll < 0.72:
            kind = 0
        elif roll < 0.80:
            kind = 3
        elif roll < 0.88:
            kind = 4
        _make_scenery_tree(tp, kind, rng.randf_range(0.85, 1.25), rng)

    for i in range(9):
        var bp: Vector3 = _random_clear_point(rng, 0.8, 9.0, [], 0.0)
        if bp != Vector3.INF:
            _make_bush(bp, Color(0.20 + rng.randf_range(0.0, 0.1), 0.50 + rng.randf_range(0.0, 0.1), 0.18))
    for i in range(9):
        var rp: Vector3 = _random_clear_point(rng, 0.5, 9.0, [], 0.0)
        if rp != Vector3.INF:
            _make_rock(rp, rng.randf_range(0.25, 0.5))
    for i in range(8):
        var fp: Vector3 = _random_clear_point(rng, 0.5, 9.0, [], 0.0)
        if fp != Vector3.INF:
            _make_flower_patch(fp)
    for i in range(60):
        var tup: Vector3 = _random_clear_point(rng, 0.2, 8.5, [], 0.0)
        if tup == Vector3.INF:
            continue
        var tuft: MeshInstance3D = _sphere(self, 0.11, 0.30, Vector3(tup.x, 0.08, tup.z), Color(0.20 + float(i % 3) * 0.025, 0.47 + float(i % 4) * 0.035, 0.16), "GrassTuft")
        tuft.rotation_degrees.z = float((i % 5) * 9 - 18)
        tuft.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF

# ===========================================================================
# v15 — camera pan and zoom
# ===========================================================================

func _update_camera() -> void:
    camera.size = cam_zoom
    camera.position = cam_target + CAM_OFFSET
    camera.look_at(cam_target, Vector3.UP)

func _ground_hit(screen_pos: Vector2) -> Vector3:
    var origin: Vector3 = camera.project_ray_origin(screen_pos)
    var direction: Vector3 = camera.project_ray_normal(screen_pos)
    if absf(direction.y) < 0.001:
        return Vector3.INF
    var distance: float = -origin.y / direction.y
    if distance < 0.0:
        return Vector3.INF
    return origin + direction * distance

func _pan_between(prev_pos: Vector2, cur_pos: Vector2) -> void:
    # Drag the world with your finger: move the camera by the ground-space
    # difference between where the finger was and where it is now.
    var cur: Vector3 = _ground_hit(cur_pos)
    var prev: Vector3 = _ground_hit(prev_pos)
    if cur == Vector3.INF or prev == Vector3.INF:
        return
    var shift: Vector3 = prev - cur
    cam_target.x = clampf(cam_target.x + shift.x, -PAN_LIMIT, PAN_LIMIT)
    cam_target.z = clampf(cam_target.z + shift.z, -PAN_LIMIT, PAN_LIMIT)
    _update_camera()

func _pinch_distance() -> float:
    var keys: Array = touches.keys()
    if keys.size() < 2:
        return 0.0
    var a: Vector2 = touches[keys[0]]
    var b: Vector2 = touches[keys[1]]
    return a.distance_to(b)

func _unhandled_input(event: InputEvent) -> void:
    if shop_open:
        return
    if event is InputEventScreenTouch:
        if event.pressed:
            touches[event.index] = event.position
            touch_info[event.index] = {"start": event.position, "time": Time.get_ticks_msec(), "moved": false}
            if touches.size() >= 2:
                pinch_last = _pinch_distance()
                for k in touch_info.keys():
                    touch_info[k]["moved"] = true
        else:
            var info: Dictionary = touch_info.get(event.index, {})
            var was_tap: bool = false
            if not info.is_empty():
                var age_ms: int = Time.get_ticks_msec() - int(info["time"])
                was_tap = (not bool(info["moved"])) and age_ms < 500 and touches.size() == 1
            touches.erase(event.index)
            touch_info.erase(event.index)
            pinch_last = 0.0
            if was_tap:
                _tap_at(event.position)
    elif event is InputEventScreenDrag:
        var last_pos: Vector2 = touches.get(event.index, event.position)
        touches[event.index] = event.position
        if touches.size() == 1:
            var drag_info: Dictionary = touch_info.get(event.index, {})
            if not drag_info.is_empty():
                var start: Vector2 = drag_info["start"]
                if not bool(drag_info["moved"]) and event.position.distance_to(start) > 16.0:
                    drag_info["moved"] = true
                if bool(drag_info["moved"]):
                    _pan_between(last_pos, event.position)
        elif touches.size() >= 2:
            var dist: float = _pinch_distance()
            if pinch_last > 1.0 and dist > 1.0:
                cam_zoom = clampf(cam_zoom * pinch_last / dist, ZOOM_MIN, ZOOM_MAX)
                _update_camera()
            pinch_last = dist
    elif event is InputEventMouseButton and not DisplayServer.is_touchscreen_available():
        if event.button_index == MOUSE_BUTTON_LEFT:
            if event.pressed:
                mouse_down = true
                mouse_moved = false
                mouse_start = event.position
                mouse_last = event.position
            else:
                if mouse_down and not mouse_moved:
                    _tap_at(event.position)
                mouse_down = false
        elif event.button_index == MOUSE_BUTTON_WHEEL_UP and event.pressed:
            cam_zoom = clampf(cam_zoom * 0.92, ZOOM_MIN, ZOOM_MAX)
            _update_camera()
        elif event.button_index == MOUSE_BUTTON_WHEEL_DOWN and event.pressed:
            cam_zoom = clampf(cam_zoom * 1.08, ZOOM_MIN, ZOOM_MAX)
            _update_camera()
    elif event is InputEventMouseMotion and mouse_down and not DisplayServer.is_touchscreen_available():
        if event.position.distance_to(mouse_start) > 8.0:
            mouse_moved = true
        if mouse_moved:
            _pan_between(mouse_last, event.position)
        mouse_last = event.position

func _tap_at(screen_pos: Vector2) -> void:
    if _any_panel_open():
        return
    var hit: Vector3 = _ground_hit(screen_pos)
    if hit == Vector3.INF:
        return
    if _tap_buildings(hit):
        return
    # The field is one seamless bed: a tap picks the cell it lands in.
    var closest_key := ""
    var closest_dist := 999.0
    for key in plot_centers.keys():
        var center: Vector3 = plot_centers[key]
        var dist := maxf(absf(hit.x - center.x), absf(hit.z - center.z))
        if dist < closest_dist:
            closest_dist = dist
            closest_key = str(key)
    if closest_key != "" and closest_dist < CELL * 0.5 + 0.02:
        _flash_cell(closest_key)
        _apply_plot_action(closest_key)

# ===========================================================================
# v15 — levels, XP and a starter quest
# ===========================================================================

func _xp_needed(lv: int) -> int:
    return 30 + (lv - 1) * 25

func _add_xp(amount: int) -> void:
    xp += amount
    var leveled: bool = false
    var bonus_coins: int = 0
    while xp >= _xp_needed(level):
        xp -= _xp_needed(level)
        level += 1
        leveled = true
        bonus_coins += 20 + level * 5
        seeds += 3
    if leveled:
        coins += bonus_coins
        _show_level_up(bonus_coins)
        _apply_unlocks(true)
    _refresh_ui()

func _show_level_up(bonus_coins: int) -> void:
    levelup_label.text = "LEVEL UP!  Level %d\n+%d coins   +3 seeds" % [level, bonus_coins]
    levelup_label.visible = true
    _play_named("jingle", -6.0)
    levelup_label.modulate = Color(1.0, 1.0, 1.0, 1.0)
    if levelup_tween != null and levelup_tween.is_valid():
        levelup_tween.kill()
    levelup_tween = create_tween()
    levelup_tween.tween_interval(1.4)
    levelup_tween.tween_property(levelup_label, "modulate:a", 0.0, 1.0)
    levelup_tween.tween_callback(func(): levelup_label.visible = false)

func _show_quest() -> void:
    _show_toast("Quest: harvest %d crops  (%d / %d)" % [quest_goal, quest_progress, quest_goal])

# ===========================================================================
# v15 — HUD styled after the reference game
# ===========================================================================

func _flat(bg: Color, radius: int, border: Color, border_w: int, pad: float = 10.0) -> StyleBoxFlat:
    var style := StyleBoxFlat.new()
    style.bg_color = bg
    style.border_color = border
    style.set_border_width_all(border_w)
    style.set_corner_radius_all(radius)
    style.content_margin_left = pad
    style.content_margin_right = pad
    style.content_margin_top = pad * 0.4
    style.content_margin_bottom = pad * 0.4
    style.shadow_color = Color(0.0, 0.0, 0.0, 0.22)
    style.shadow_size = 4
    style.shadow_offset = Vector2(0.0, 3.0)
    return style

func _icon_button(parent: Control, text: String, pos: Vector2, diameter: float) -> Button:
    var b := Button.new()
    b.text = text
    b.position = pos
    b.custom_minimum_size = Vector2(diameter, diameter)
    b.size = Vector2(diameter, diameter)
    b.add_theme_font_size_override("font_size", int(diameter * 0.48))
    var radius: int = int(diameter * 0.5)
    var border: Color = Color(0.86, 0.66, 0.44)
    b.add_theme_stylebox_override("normal", _flat(Color(0.99, 0.94, 0.83), radius, border, 3, 2.0))
    b.add_theme_stylebox_override("hover", _flat(Color(1.0, 0.97, 0.88), radius, border, 3, 2.0))
    b.add_theme_stylebox_override("pressed", _flat(Color(0.93, 0.85, 0.70), radius, border, 3, 2.0))
    b.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
    var glyph: Color = Color(0.42, 0.24, 0.08)
    b.add_theme_color_override("font_color", glyph)
    b.add_theme_color_override("font_hover_color", glyph)
    b.add_theme_color_override("font_pressed_color", glyph)
    b.add_theme_color_override("font_outline_color", Color(1.0, 0.98, 0.9))
    b.add_theme_constant_override("outline_size", 3)
    parent.add_child(b)
    return b

func _make_pill(parent: Control, icon: String, with_plus: bool) -> Label:
    var pill := PanelContainer.new()
    pill.custom_minimum_size = Vector2(0.0, 40.0)
    pill.add_theme_stylebox_override("panel", _flat(Color(0.99, 0.94, 0.83), 20, Color(0.86, 0.66, 0.44), 3, 12.0))
    parent.add_child(pill)
    var row := HBoxContainer.new()
    row.add_theme_constant_override("separation", 8)
    pill.add_child(row)
    var icon_label := Label.new()
    icon_label.text = icon
    icon_label.add_theme_font_size_override("font_size", 24)
    row.add_child(icon_label)
    var value := Label.new()
    value.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    value.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
    value.add_theme_font_size_override("font_size", 25)
    value.add_theme_color_override("font_color", Color(0.38, 0.24, 0.12))
    row.add_child(value)
    if with_plus:
        var plus := Button.new()
        plus.text = "+"
        plus.custom_minimum_size = Vector2(32.0, 32.0)
        plus.add_theme_font_size_override("font_size", 24)
        plus.add_theme_color_override("font_color", Color.WHITE)
        plus.add_theme_stylebox_override("normal", _flat(Color(0.30, 0.74, 0.28), 16, Color(0.20, 0.55, 0.20), 2, 2.0))
        plus.add_theme_stylebox_override("hover", _flat(Color(0.38, 0.80, 0.34), 16, Color(0.20, 0.55, 0.20), 2, 2.0))
        plus.add_theme_stylebox_override("pressed", _flat(Color(0.22, 0.62, 0.22), 16, Color(0.20, 0.55, 0.20), 2, 2.0))
        plus.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
        plus.pressed.connect(_on_action_pressed.bind("shop"))
        row.add_child(plus)
    return value

func _style_action_button(button: Button, accent: Color, active: bool) -> void:
    var bg: Color = Color(1.0, 0.96, 0.78) if active else Color(0.99, 0.94, 0.83)
    var border: Color = Color(0.96, 0.55, 0.10) if active else accent.darkened(0.1)
    var width: int = 7 if active else 4
    button.add_theme_stylebox_override("normal", _flat(bg, 22, border, width))
    button.add_theme_stylebox_override("hover", _flat(bg.lightened(0.05), 22, border, width))
    button.add_theme_stylebox_override("pressed", _flat(bg.darkened(0.08), 22, border, width))
    button.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
    var ink: Color = Color(0.36, 0.22, 0.10)
    button.add_theme_color_override("font_color", ink)
    button.add_theme_color_override("font_hover_color", ink)
    button.add_theme_color_override("font_pressed_color", ink)

func _refresh_action_buttons() -> void:
    for action in buttons.keys():
        var b: Button = buttons[action]
        var accent: Color = action_colors[action]
        var is_tool: bool = (action == "plant" or action == "harvest")
        _style_action_button(b, accent, is_tool and action == active_action)
    _refresh_crop_bar()

func _build_ui() -> void:
    var layer := CanvasLayer.new()
    add_child(layer)
    var root := Control.new()
    root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    root.mouse_filter = Control.MOUSE_FILTER_PASS
    layer.add_child(root)

    # ---- Top-left: avatar, level badge, XP bar, small round buttons ----
    var hud_left := Control.new()
    hud_left.position = Vector2(14.0, 10.0)
    hud_left.mouse_filter = Control.MOUSE_FILTER_IGNORE
    root.add_child(hud_left)

    xp_bar = ProgressBar.new()
    xp_bar.position = Vector2(80.0, 32.0)
    xp_bar.custom_minimum_size = Vector2(230.0, 30.0)
    xp_bar.size = Vector2(230.0, 30.0)
    xp_bar.show_percentage = false
    xp_bar.min_value = 0.0
    xp_bar.max_value = 100.0
    xp_bar.add_theme_stylebox_override("background", _flat(Color(0.99, 0.88, 0.72), 15, Color(0.85, 0.62, 0.40), 3, 0.0))
    xp_bar.add_theme_stylebox_override("fill", _flat(Color(0.97, 0.55, 0.18), 15, Color(0.97, 0.55, 0.18), 0, 0.0))
    hud_left.add_child(xp_bar)
    xp_text = Label.new()
    xp_text.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    xp_text.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    xp_text.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    xp_text.add_theme_font_size_override("font_size", 17)
    xp_text.add_theme_color_override("font_color", Color(0.30, 0.18, 0.08))
    xp_bar.add_child(xp_text)

    var avatar := PanelContainer.new()
    avatar.position = Vector2(0.0, 0.0)
    avatar.custom_minimum_size = Vector2(84.0, 84.0)
    avatar.size = Vector2(84.0, 84.0)
    avatar.add_theme_stylebox_override("panel", _flat(Color(0.55, 0.86, 0.97), 42, Color.WHITE, 5, 0.0))
    hud_left.add_child(avatar)
    var face := Label.new()
    face.text = "🧑‍🌾"
    face.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    face.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    face.add_theme_font_size_override("font_size", 42)
    avatar.add_child(face)

    var badge := PanelContainer.new()
    badge.position = Vector2(56.0, 4.0)
    badge.custom_minimum_size = Vector2(46.0, 46.0)
    badge.size = Vector2(46.0, 46.0)
    badge.add_theme_stylebox_override("panel", _flat(Color(0.98, 0.74, 0.20), 23, Color.WHITE, 4, 0.0))
    hud_left.add_child(badge)
    level_label = Label.new()
    level_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    level_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    level_label.add_theme_font_size_override("font_size", 26)
    level_label.add_theme_color_override("font_color", Color.WHITE)
    level_label.add_theme_color_override("font_outline_color", Color(0.55, 0.30, 0.05))
    level_label.add_theme_constant_override("outline_size", 6)
    badge.add_child(level_label)

    var gear := _icon_button(hud_left, "⚙", Vector2(4.0, 96.0), 48.0)
    gear.pressed.connect(_toggle_panel.bind("settings", _open_settings_v27))
    var mail := _icon_button(hud_left, "✉", Vector2(60.0, 96.0), 48.0)
    mail.pressed.connect(func(): _show_toast("No new mail."))
    var quest := _icon_button(hud_left, "📋", Vector2(4.0, 154.0), 54.0)
    quest.pressed.connect(_toggle_panel.bind("quests", _open_quests))
    var ord_btn := _icon_button(hud_left, "🧾", Vector2(66.0, 154.0), 54.0)
    ord_btn.pressed.connect(_toggle_panel.bind("orders", _open_orders))
    var exp_btn := _icon_button(hud_left, "🏗", Vector2(128.0, 154.0), 54.0)
    exp_btn.pressed.connect(_toggle_panel.bind("expand", _open_expand))
    trade_btn = _icon_button(hud_left, "🚚", Vector2(190.0, 154.0), 54.0)
    trade_btn.pressed.connect(_toggle_panel.bind("trade", _open_trade))
    hydro_btn = _icon_button(hud_left, "⚡", Vector2(4.0, 216.0), 54.0)
    hydro_btn.pressed.connect(_toggle_panel.bind("hydro", _open_hydro))
    train_btn = _icon_button(hud_left, "🚂", Vector2(66.0, 216.0), 54.0)
    train_btn.pressed.connect(_toggle_panel.bind("train", _open_train))
    carrier_btn = _icon_button(hud_left, "✈", Vector2(128.0, 216.0), 54.0)
    carrier_btn.pressed.connect(_toggle_panel.bind("carrier", _open_carrier))
    var up_btn := _icon_button(hud_left, "🔧", Vector2(190.0, 216.0), 54.0)
    up_btn.pressed.connect(_toggle_panel.bind("upgrades", _open_upgrades_v27))

    # ---- Top-right: coin and seed pills, barn button ----
    var hud_right := HBoxContainer.new()
    hud_right.anchor_left = 1.0
    hud_right.anchor_right = 1.0
    hud_right.anchor_top = 0.0
    hud_right.anchor_bottom = 0.0
    hud_right.offset_left = -330.0
    hud_right.offset_right = -14.0
    hud_right.offset_top = 10.0
    hud_right.offset_bottom = 100.0
    hud_right.add_theme_constant_override("separation", 10)
    root.add_child(hud_right)
    var pills := VBoxContainer.new()
    pills.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    pills.add_theme_constant_override("separation", 8)
    hud_right.add_child(pills)
    coin_label = _make_pill(pills, "🪙", false)
    seed_label = _make_pill(pills, "🌰", true)
    var barn := Button.new()
    barn.text = "📦"
    barn.custom_minimum_size = Vector2(88.0, 88.0)
    barn.add_theme_font_size_override("font_size", 44)
    barn.add_theme_stylebox_override("normal", _flat(Color(0.99, 0.94, 0.83), 22, Color(0.86, 0.66, 0.44), 4, 4.0))
    barn.add_theme_stylebox_override("hover", _flat(Color(1.0, 0.97, 0.88), 22, Color(0.86, 0.66, 0.44), 4, 4.0))
    barn.add_theme_stylebox_override("pressed", _flat(Color(0.93, 0.85, 0.70), 22, Color(0.86, 0.66, 0.44), 4, 4.0))
    barn.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
    barn.pressed.connect(_toggle_panel.bind("market", _open_market))
    hud_right.add_child(barn)

    # ---- Bottom: action buttons ----
    var bottom := HBoxContainer.new()
    bottom.anchor_left = 0.22
    bottom.anchor_right = 0.78
    bottom.anchor_top = 1.0
    bottom.anchor_bottom = 1.0
    bottom.offset_top = -102.0
    bottom.offset_bottom = -14.0
    bottom.add_theme_constant_override("separation", 12)
    root.add_child(bottom)
    _add_action_button(bottom, "🌱 PLANT", "plant", Color(0.25, 0.73, 0.25))
    _add_action_button(bottom, "🧺 HARVEST", "harvest", Color(0.96, 0.63, 0.15))
    _add_action_button(bottom, "🏪 SHOP", "shop", Color(0.16, 0.59, 0.83))
    _add_action_button(bottom, "💾 SAVE", "save", Color(0.45, 0.43, 0.78))
    _refresh_action_buttons()
    _build_crop_bar(root)

    toast_label = Label.new()
    toast_label.anchor_left = 0.15
    toast_label.anchor_right = 0.85
    toast_label.anchor_top = 0.0
    toast_label.anchor_bottom = 0.0
    toast_label.offset_top = 112.0
    toast_label.offset_bottom = 200.0
    toast_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    toast_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    toast_label.add_theme_font_size_override("font_size", 23)
    toast_label.add_theme_color_override("font_color", Color.WHITE)
    toast_label.add_theme_color_override("font_shadow_color", Color(0.1, 0.1, 0.1))
    toast_label.add_theme_constant_override("shadow_offset_x", 2)
    toast_label.add_theme_constant_override("shadow_offset_y", 2)
    toast_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
    root.add_child(toast_label)

    levelup_label = Label.new()
    levelup_label.anchor_left = 0.2
    levelup_label.anchor_right = 0.8
    levelup_label.anchor_top = 0.28
    levelup_label.anchor_bottom = 0.52
    levelup_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    levelup_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    levelup_label.add_theme_font_size_override("font_size", 44)
    levelup_label.add_theme_color_override("font_color", Color(1.0, 0.88, 0.30))
    levelup_label.add_theme_color_override("font_outline_color", Color(0.45, 0.25, 0.05))
    levelup_label.add_theme_constant_override("outline_size", 12)
    levelup_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
    levelup_label.visible = false
    root.add_child(levelup_label)

    shop_panel = PanelContainer.new()
    shop_panel.anchor_left = 0.10
    shop_panel.anchor_right = 0.90
    shop_panel.anchor_top = 0.34
    shop_panel.anchor_bottom = 0.63
    shop_panel.add_theme_stylebox_override("panel", _panel_style(Color(0.12, 0.25, 0.20, 0.98), 24))
    root.add_child(shop_panel)
    var shop_col := VBoxContainer.new()
    shop_col.add_theme_constant_override("separation", 14)
    shop_panel.add_child(shop_col)
    var shop_title := Label.new()
    shop_title.text = "🌾 FARM SUPPLY SHOP"
    shop_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    shop_title.add_theme_font_size_override("font_size", 26)
    shop_title.add_theme_color_override("font_color", Color(1.0, 0.91, 0.45))
    shop_col.add_child(shop_title)
    var buy := Button.new()
    buy.text = "BUY 5 SEEDS  •  12 COINS"
    buy.custom_minimum_size = Vector2(0, 64)
    buy.add_theme_font_size_override("font_size", 20)
    buy.pressed.connect(_buy_seeds)
    shop_col.add_child(buy)
    var close := Button.new()
    close.text = "CLOSE"
    close.custom_minimum_size = Vector2(0, 52)
    close.pressed.connect(func(): shop_open = false; shop_panel.visible = false)
    shop_col.add_child(close)
    shop_panel.visible = false

func _add_action_button(parent: HBoxContainer, caption: String, action: String, color: Color) -> void:
    var button := Button.new()
    button.text = caption
    button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    button.custom_minimum_size = Vector2(0.0, 82.0)
    button.add_theme_font_size_override("font_size", 23)
    button.pressed.connect(_on_action_pressed.bind(action))
    parent.add_child(button)
    buttons[action] = button
    action_colors[action] = color

func _on_action_pressed(action: String) -> void:
    if action == "shop":
        if _any_panel_open() and panel_owner == "shop":
            _close_panels()
            return
        _close_panels()
        shop_open = true
        shop_panel.visible = true
        panel_owner = "shop"
        _refresh_shop()
        _show_toast("Shop opened — buy seeds to keep planting.")
    elif action == "save":
        if _any_panel_open():
            _close_panels()
        _save_game()
        _show_toast("Farm saved on this device.")
    else:
        var had_panel: bool = _any_panel_open()
        if had_panel:
            _close_panels()
        if had_panel:
            crop_bar_dismissed = false
        elif action == "plant" and active_action == "plant" and not crop_bar_dismissed and crop_bar != null and crop_bar.visible:
            crop_bar_dismissed = true
        else:
            crop_bar_dismissed = false
        active_action = action
        _refresh_action_buttons()
        _show_toast("Tap a soil plot to " + action + ".")

func _apply_plot_action(key: String) -> void:
    if v27 != null and v27.on_plot_tap(key):
        return
    var state: Dictionary = crop_states[key]
    if active_action == "plant":
        if state.get("planted", false):
            _show_toast("This plot already has a crop.")
        elif seeds <= 0:
            _show_toast("No seeds left. Visit the shop!")
        else:
            seeds -= 1
            crop_states[key] = {"planted": true, "age": 0.0, "crop": selected_crop}
            _update_crop_visual(key)
            _quest_event("plant", 1)
            _add_xp(2)
            _refresh_ui()
            _save_game()
            _show_toast("Planted %s! +2 XP" % str(crop_defs[selected_crop]["name"]))
    elif active_action == "harvest":
        if not state.get("planted", false):
            _show_toast("Plant a crop here first.")
        elif float(state.get("age", 0.0)) < _grow_time_of(state):
            _show_toast("Not ready yet — give it a little time.")
        else:
            crop_states[key] = {"planted": false, "age": 0.0}
            if v27 != null:
                v27.on_harvest(key)
            var cdef: Dictionary = _crop_of(state)
            var cid: int = clampi(int(state.get("crop", 0)), 0, crop_defs.size() - 1)
            harvested_total += 1
            quest_progress += 1
            var msg: String = ""
            if _stock_total() < _barn_cap():
                stock[cid] = int(stock[cid]) + 1
                msg = "Harvested %s! Stored in the barn (%d/%d)\n+%d XP" % [str(cdef["name"]), _stock_total(), _barn_cap(), int(cdef["xp"])]
                if harvested_total <= 2:
                    msg += "\nTap the barn or the 📦 button to sell."
            else:
                var payout: int = _crop_price(cid)
                coins += payout
                msg = "Barn is full, so %s sold for %d coins! +%d XP" % [str(cdef["name"]), payout, int(cdef["xp"])]
                if v27 != null:
                    v27.alert("barn")
            _quest_event("harvest", 1, cid)
            if quest_progress >= quest_goal:
                var reward: int = 30 + quest_goal * 4
                coins += reward
                msg += "\nQuest complete! +%d coins" % reward
                quest_goal += 2
                quest_progress = 0
                _add_xp(25)
            _add_xp(int(cdef["xp"]))
            _update_crop_visual(key)
            _refresh_ui()
            _save_game()
            _show_toast(msg)

func _refresh_ui() -> void:
    if is_instance_valid(coin_label):
        coin_label.text = "%d" % coins
        seed_label.text = "%d" % seeds
    if is_instance_valid(xp_bar):
        var need: int = _xp_needed(level)
        xp_bar.max_value = float(need)
        xp_bar.value = float(xp)
        xp_text.text = "%d / %d XP" % [xp, need]
        level_label.text = str(level)

func _save_game() -> void:
    if has_meta("skip_save"):
        return
    var config := ConfigFile.new()
    config.set_value("farm", "coins", coins)
    config.set_value("farm", "seeds", seeds)
    config.set_value("farm", "crops", crop_states)
    config.set_value("farm", "level", level)
    config.set_value("farm", "xp", xp)
    config.set_value("farm", "quest_goal", quest_goal)
    config.set_value("farm", "quest_progress", quest_progress)
    config.set_value("farm", "harvested_total", harvested_total)
    config.set_value("farm", "saved_at", Time.get_unix_time_from_system())
    _save_v17(config)
    _save_v23(config)
    _save_v24(config)
    config.save("user://farm_save.cfg")

func _load_game() -> void:
    var config := ConfigFile.new()
    if config.load("user://farm_save.cfg") != OK:
        return
    coins = int(config.get_value("farm", "coins", coins))
    seeds = int(config.get_value("farm", "seeds", seeds))
    level = maxi(1, int(config.get_value("farm", "level", level)))
    xp = maxi(0, int(config.get_value("farm", "xp", xp)))
    quest_goal = maxi(1, int(config.get_value("farm", "quest_goal", quest_goal)))
    quest_progress = maxi(0, int(config.get_value("farm", "quest_progress", quest_progress)))
    harvested_total = maxi(0, int(config.get_value("farm", "harvested_total", harvested_total)))
    _load_v17(config)
    _load_v23(config)
    _load_v24(config)
    # Crops keep growing while the game is closed.
    var saved_at: float = float(config.get_value("farm", "saved_at", 0.0))
    var away: float = 0.0
    if saved_at > 0.0:
        away = maxf(0.0, Time.get_unix_time_from_system() - saved_at)
    var saved: Variant = config.get_value("farm", "crops", {})
    if saved is Dictionary:
        for key in saved.keys():
            if crop_states.has(key) and saved[key] is Dictionary:
                var crop: Dictionary = saved[key].duplicate()
                if crop.get("planted", false):
                    crop["age"] = float(crop.get("age", 0.0)) + away
                crop_states[key] = crop
                _update_crop_visual(str(key))
    if v27 != null:
        v27.load_world(config)

func _notification(what: int) -> void:
    if what == NOTIFICATION_APPLICATION_PAUSED or what == NOTIFICATION_WM_CLOSE_REQUEST:
        _save_game()

# ===========================================================================
# v16 — scenery: mountains, clouds, small islands, boats, deeper sea
# ===========================================================================

func _strip_shadows(node: Node) -> void:
    if node is MeshInstance3D:
        (node as MeshInstance3D).cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    for child in node.get_children():
        _strip_shadows(child)

func _frustum_into(st: SurfaceTool, base: Vector3, r_bot: float, r_top: float, h: float, segs: int, yaw: float, col_bot: Color, col_top: Color) -> void:
    # A low-poly cone or truncated cone added to a shared SurfaceTool.
    for i in range(segs):
        var a0: float = yaw + float(i) * TAU / float(segs)
        var a1: float = yaw + float(i + 1) * TAU / float(segs)
        var b0: Vector3 = base + Vector3(cos(a0) * r_bot, 0.0, sin(a0) * r_bot)
        var b1: Vector3 = base + Vector3(cos(a1) * r_bot, 0.0, sin(a1) * r_bot)
        var t0: Vector3 = base + Vector3(cos(a0) * r_top, h, sin(a0) * r_top)
        var t1: Vector3 = base + Vector3(cos(a1) * r_top, h, sin(a1) * r_top)
        _tri(st, b0, t0, b1, col_bot, col_top, col_bot)
        _tri(st, b1, t0, t1, col_bot, col_top, col_top)

func _add_mountain(st: SurfaceTool, pos: Vector3, h: float, r: float, rock: Color, rng: RandomNumberGenerator) -> void:
    var base_y: float = -0.7
    var yaw: float = rng.randf_range(0.0, TAU)
    var snow: Color = Color(0.97, 0.98, 1.0)
    var snow_shade: Color = Color(0.82, 0.88, 0.97)
    var foot: Vector3 = Vector3(pos.x, base_y, pos.z)
    # Main peak: rock body, snow cap on the top 30 percent.
    _frustum_into(st, foot, r, r * 0.30, h * 0.70, 7, yaw, rock.darkened(0.18), rock.lightened(0.06))
    _frustum_into(st, foot + Vector3(0.0, h * 0.70, 0.0), r * 0.30, 0.0, h * 0.30, 7, yaw, snow_shade, snow)
    # Wooded foothills where the mountain meets the sea.
    _frustum_into(st, foot, r * 1.28, r * 0.66, h * 0.24, 9, yaw * 0.5, Color(0.26, 0.54, 0.31), Color(0.38, 0.66, 0.35))
    if rng.randf() < 0.75:
        var ang: float = rng.randf_range(0.0, TAU)
        var side: float = r * rng.randf_range(0.75, 0.95)
        var ph: float = h * rng.randf_range(0.50, 0.70)
        var pr: float = ph * rng.randf_range(0.65, 0.80)
        var pf: Vector3 = foot + Vector3(cos(ang) * side, 0.0, sin(ang) * side)
        _frustum_into(st, pf, pr, pr * 0.34, ph * 0.72, 6, yaw + 0.4, rock.darkened(0.24), rock)
        _frustum_into(st, pf + Vector3(0.0, ph * 0.72, 0.0), pr * 0.34, 0.0, ph * 0.28, 6, yaw + 0.4, snow_shade, snow)

func _make_small_island(parent: Node3D, c: Vector2, r: float, index: int, rng: RandomNumberGenerator) -> void:
    var isl := Node3D.new()
    isl.name = "SmallIsland_%d" % index
    isl.position = Vector3(c.x, 0.0, c.y)
    parent.add_child(isl)
    _disc(isl, r, 0.85, Vector3(0.0, -0.275, 0.0), Color(0.88, 0.76, 0.52), "IslandSand", 0.95, 14, r * 0.92)
    _disc(isl, r * 0.88, 0.25, Vector3(0.0, 0.275, 0.0), Color(0.38, 0.72, 0.30), "IslandGrass", 0.95, 14, r * 0.80)
    _disc(isl, r * 1.18, 0.05, Vector3(0.0, -0.58, 0.0), Color(0.62, 0.88, 0.96), "IslandFoam", 0.9, 14)

func _decorate_island(c: Vector2, r: float, kind: int, rng: RandomNumberGenerator) -> void:
    var top: float = 0.27
    if kind == 0:
        _make_tree(Vector3(c.x + r * 0.15, top, c.y - r * 0.1), 2)
        _make_bush(Vector3(c.x - r * 0.4, top, c.y + r * 0.3), Color(0.22, 0.52, 0.20))
    elif kind == 1:
        for i in range(3):
            var a: float = float(i) * TAU / 3.0 + 0.5
            _make_scenery_tree(Vector3(c.x + cos(a) * r * 0.45, top, c.y + sin(a) * r * 0.45), 1 if i != 1 else 0, 0.8, rng)
    elif kind == 2:
        _make_lighthouse(Vector3(c.x, top, c.y))
    else:
        _make_scenery_tree(Vector3(c.x - r * 0.2, top, c.y), 4, 0.9, rng)
        _make_scenery_tree(Vector3(c.x + r * 0.3, top, c.y + r * 0.2), 3, 0.8, rng)
        _make_rock(Vector3(c.x + r * 0.1, top, c.y - r * 0.45), 0.35)

func _make_lighthouse(pos: Vector3) -> void:
    var lh := Node3D.new()
    lh.name = "Lighthouse"
    lh.position = pos
    lh_root.add_child(lh)
    var radii: Array = [0.80, 0.68, 0.58, 0.50]
    for i in range(4):
        var col: Color = Color(0.86, 0.22, 0.20) if i % 2 == 0 else Color(0.98, 0.96, 0.92)
        _disc(lh, float(radii[i]), 0.85, Vector3(0.0, 0.43 + float(i) * 0.85, 0.0), col, "LighthouseBand", 0.9, 12, float(radii[i]) - 0.08)
    _box(lh, Vector3(0.9, 0.12, 0.9), Vector3(0.0, 3.46, 0.0), Color(0.30, 0.30, 0.34), "LighthouseDeck")
    _disc(lh, 0.34, 0.5, Vector3(0.0, 3.76, 0.0), Color(1.0, 0.92, 0.45), "LighthouseLamp", 0.4, 10).material_override = _lamp_material()
    _disc(lh, 0.52, 0.45, Vector3(0.0, 4.25, 0.0), Color(0.86, 0.22, 0.20), "LighthouseRoof", 0.9, 10, 0.0)
    _box(lh, Vector3(0.28, 0.5, 0.06), Vector3(0.0, 0.25, 0.80), Color(0.40, 0.24, 0.12), "LighthouseDoor")

func _make_sailboat(pos: Vector3, yaw: float, sail_col: Color, phase: float) -> void:
    var boat := Node3D.new()
    boat.name = "Sailboat"
    boat.position = pos
    boat.rotation_degrees.y = yaw
    scenery_root.add_child(boat)
    _box(boat, Vector3(2.0, 0.38, 0.80), Vector3(0.0, 0.0, 0.0), Color(0.55, 0.32, 0.16), "BoatHull")
    _box(boat, Vector3(2.1, 0.08, 0.90), Vector3(0.0, 0.22, 0.0), Color(0.90, 0.80, 0.55), "BoatDeck")
    _box(boat, Vector3(0.45, 0.30, 0.45), Vector3(-0.55, 0.40, 0.0), Color(0.95, 0.92, 0.85), "BoatCabin")
    _cylinder(boat, 0.04, 0.04, 2.3, Vector3(0.25, 1.35, 0.0), Color(0.40, 0.26, 0.14), "BoatMast")
    var sail: MeshInstance3D = _disc(boat, 0.62, 1.9, Vector3(0.25, 1.45, 0.0), sail_col, "BoatSail", 0.9, 3, 0.0)
    sail.scale = Vector3(1.0, 1.0, 0.35)
    boat_nodes.append({"node": boat, "base_y": pos.y, "phase": phase})

func _make_cloud(pos: Vector3, size_scale: float, axis: Vector3, speed: float) -> void:
    var cloud := MeshInstance3D.new()
    cloud.name = "Cloud"
    cloud.position = pos
    cloud.scale = Vector3.ONE * size_scale
    var ball := SphereMesh.new()
    ball.radius = 1.0
    ball.height = 2.0
    ball.radial_segments = 10
    ball.rings = 5
    var st := SurfaceTool.new()
    st.begin(Mesh.PRIMITIVE_TRIANGLES)
    var parts: Array = [
        [Vector3(0.0, 0.5, 0.0), Vector3(1.5, 1.05, 1.2)],
        [Vector3(-1.5, 0.15, 0.2), Vector3(1.1, 0.8, 0.9)],
        [Vector3(1.6, 0.2, -0.1), Vector3(1.2, 0.85, 0.95)],
        [Vector3(0.3, 0.95, 0.5), Vector3(0.9, 0.65, 0.8)],
        [Vector3(0.1, -0.1, 0.0), Vector3(2.3, 0.5, 1.2)]
    ]
    for part in parts:
        var offset: Vector3 = part[0]
        var scl: Vector3 = part[1]
        st.append_from(ball, 0, Transform3D(Basis.from_scale(scl), offset))
    cloud.mesh = st.commit()
    cloud.material_override = _cloud_material()
    cloud.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    scenery_root.add_child(cloud)
    cloud_nodes.append({"node": cloud, "axis": axis, "speed": speed})

func _build_scenery() -> void:
    var rng := RandomNumberGenerator.new()
    rng.seed = 16101216
    scenery_root = Node3D.new()
    scenery_root.name = "Scenery"
    add_child(scenery_root)
    lh_root = scenery_root

    # Shallow turquoise water and animated foam around the main island.
    _box(scenery_root, Vector3(47.0, 0.04, 47.0), Vector3(0.0, -0.59, 0.0), Color(0.28, 0.66, 0.88), "ShallowWater")
    foam_node = _box(scenery_root, Vector3(38.8, 0.04, 38.8), Vector3(0.0, -0.575, 0.0), Color(0.80, 0.94, 0.99), "ShoreFoam")

    # Small islands (centre, radius, decoration kind).
    var islands: Array = [
        {"c": Vector2(31.0, 23.0), "r": 4.6, "k": 0},
        {"c": Vector2(-27.0, 31.0), "r": 3.8, "k": 1},
        {"c": Vector2(38.0, -11.0), "r": 3.6, "k": 2},
        {"c": Vector2(-40.0, 11.0), "r": 4.3, "k": 3},
        {"c": Vector2(13.0, 41.0), "r": 3.4, "k": 0},
        {"c": Vector2(-30.0, -33.0), "r": 4.0, "k": 1}
    ]
    var keep_clear: Array = []
    for i in range(islands.size()):
        var info: Dictionary = islands[i]
        var ic: Vector2 = info["c"]
        var ir: float = float(info["r"])
        _make_small_island(scenery_root, ic, ir, i, rng)
        _decorate_island(ic, ir, int(info["k"]), rng)
        keep_clear.append(Vector3(ic.x, ic.y, ir + 3.0))

    # Keep mountains and rocks away from the boats.
    for bp in [Vector2(24.5, 5.0), Vector2(-9.0, 27.5), Vector2(-28.0, -12.0), Vector2(19.0, -25.0)]:
        keep_clear.append(Vector3(bp.x, bp.y, 3.0))

    for lz in [-10.0, -16.0, -22.0, -28.0, -34.0, -40.0, -46.0, -52.0]:
        keep_clear.append(Vector3(26.8, lz, 7.0))

    for kp in [Vector3(25.0, -7.0, 3.5), Vector3(28.5, -4.0, 3.5), Vector3(32.0, -1.0, 4.0), Vector3(31.0, 8.0, 4.0), Vector3(27.0, 3.0, 3.5), Vector3(22.5, -10.8, 3.0)]:
        keep_clear.append(kp)

    # Mountain ring: closer to the island, tallest on the far (top-of-screen) side.
    # A mountain hides whatever lies behind it from the camera, so each one is
    # checked: its base and the ground it can cover must stay off the island.
    var rock_palette: Array = [Color(0.47, 0.52, 0.64), Color(0.53, 0.48, 0.60), Color(0.42, 0.54, 0.62), Color(0.58, 0.55, 0.66)]
    var placed: Array = []
    var mst := SurfaceTool.new()
    mst.begin(Mesh.PRIMITIVE_TRIANGLES)
    var tries: int = 0
    while placed.size() < 26 and tries < 900:
        tries += 1
        var ang: float = rng.randf() * TAU
        var dist: float = rng.randf_range(27.0, 64.0)
        var mp: Vector2 = Vector2(cos(ang) * dist, sin(ang) * dist)
        var far: float = (-mp.x - mp.y) / (dist * 1.4142)
        if far < -0.45:
            continue
        var h: float = rng.randf_range(7.0, 14.0) * (0.55 + 0.45 * clampf(far, 0.0, 1.0))
        var r: float = h * rng.randf_range(0.60, 0.82)
        var ok: bool = true
        for step in range(4):
            var f: float = float(step) / 3.0
            var qx: float = mp.x - 0.76 * h * f
            var qz: float = mp.y - 1.13 * h * f
            var rr: float = r * (1.3 if step == 0 else (1.0 - f) + 0.2)
            if maxf(absf(qx), absf(qz)) < 19.5 + rr:
                ok = false
                break
        if not ok:
            continue
        for k in keep_clear:
            var kv: Vector3 = k
            if mp.distance_to(Vector2(kv.x, kv.y)) < kv.z + r * 0.9:
                ok = false
                break
        if not ok:
            continue
        for q in placed:
            var qv: Vector3 = q
            if mp.distance_to(Vector2(qv.x, qv.y)) < (r + qv.z) * 0.70:
                ok = false
                break
        if not ok:
            continue
        placed.append(Vector3(mp.x, mp.y, r))
        _add_mountain(mst, Vector3(mp.x, 0.0, mp.y), h, r, rock_palette[rng.randi() % rock_palette.size()], rng)
    var mountains := MeshInstance3D.new()
    mountains.name = "Mountains"
    mountains.mesh = mst.commit()
    mountains.material_override = _get_leaf_material()
    scenery_root.add_child(mountains)
    print("v16: mountains placed = ", placed.size())

    # Sailboats.
    _make_sailboat(Vector3(24.5, -0.45, 5.0), 20.0, Color(0.98, 0.96, 0.92), 0.0)
    _make_sailboat(Vector3(-9.0, -0.45, 27.5), 100.0, Color(0.95, 0.35, 0.30), 1.7)
    _make_sailboat(Vector3(-28.0, -0.45, -12.0), -40.0, Color(0.98, 0.84, 0.30), 3.1)
    _make_sailboat(Vector3(19.0, -0.45, -25.0), 60.0, Color(0.40, 0.65, 0.95), 4.4)

    # Sea stacks and rocks.
    var rocks: int = 0
    var rock_tries: int = 0
    while rocks < 16 and rock_tries < 200:
        rock_tries += 1
        var rp: Vector2 = Vector2(rng.randf_range(-48.0, 48.0), rng.randf_range(-48.0, 48.0))
        if maxf(absf(rp.x), absf(rp.y)) < 22.0:
            continue
        var clear: bool = true
        for k in keep_clear:
            var kv2: Vector3 = k
            if rp.distance_to(Vector2(kv2.x, kv2.y)) < kv2.z + 1.0:
                clear = false
                break
        if clear:
            for q in placed:
                var qv2: Vector3 = q
                if rp.distance_to(Vector2(qv2.x, qv2.y)) < qv2.z * 1.1:
                    clear = false
                    break
        if not clear:
            continue
        _make_rock(Vector3(rp.x, -0.25, rp.y), rng.randf_range(0.5, 1.2))
        rocks += 1

    # Clouds: placed so none can hide the farm (the camera looks along a fixed
    # slanted ray, so we keep each cloud's ground "shadow point" off the island).
    var made: int = 0
    var cloud_tries: int = 0
    while made < 16 and cloud_tries < 700:
        cloud_tries += 1
        var cy: float = rng.randf_range(6.5, 12.0)
        var cp: Vector3 = Vector3(rng.randf_range(-60.0, 60.0), cy, rng.randf_range(-60.0, 60.0))
        var qx: float = cp.x - 0.76 * cy
        var qz: float = cp.z - 1.13 * cy
        if maxf(absf(qx), absf(qz)) < 22.0:
            continue
        var depth: float = 23.2 + cp.x * -0.452 + cp.y * -0.593 + cp.z * -0.668
        if depth < 3.0:
            continue
        var sx: float = cp.x * 0.828 + cp.z * -0.560
        var sy: float = cp.x * -0.332 + cp.y * 0.806 + cp.z * -0.491
        if absf(sx) > 46.0 or sy < -22.0 or sy > 24.0:
            continue
        var drift_axis: Vector3 = Vector3(1.0, 0.0, 0.0) if absf(qz) >= 22.0 else Vector3(0.0, 0.0, 1.0)
        _make_cloud(cp, rng.randf_range(0.8, 1.45), drift_axis, rng.randf_range(0.25, 0.55))
        made += 1

    _strip_shadows(scenery_root)

# ===========================================================================
# v17 — day/night cycle, birds, windmill, sea port and cargo ship
# ===========================================================================

const WINDMILL_LV := 3
const PORT_LV := 5
const SHIP_LV := 8
const DAY_LENGTH := 240.0
const WM_INTERVAL := 45.0
const WM_INTERVAL_BASE := 45.0
const PORT_INTERVAL := 75.0
const WM_POS := Vector3(-10.0, 0.0, 12.5)
const PORT_POS := Vector3(14.2, 0.0, -14.6)
const PIER_Z := -14.6
const SHIP_X := 26.8
const SHIP_FAR_Z := -46.0

var sun_light: DirectionalLight3D
var env_ref: Environment
var tod: float = 0.16
var clock_label: Label
var hint_label: Label
var lamp_mat: StandardMaterial3D
var window_mat: StandardMaterial3D
var cloud_mat: StandardMaterial3D
var birds: Array = []
var bird_root: Node3D
var wm_built: Node3D
var wm_site: Node3D
var wm_blades: Node3D
var wm_coin: Node3D
var wm_timer: float = 0.0
var port_built: Node3D
var port_site: Node3D
var ship_site: Node3D
var port_coin: Node3D
var port_timer: float = 0.0
var ship: Node3D
var ship_state: int = 0
var ship_timer: float = 0.0
var wm_unlocked: bool = false
var water_items: Array = []
var port_unlocked: bool = false
var ship_unlocked: bool = false

func _lamp_material() -> StandardMaterial3D:
    if lamp_mat == null:
        lamp_mat = StandardMaterial3D.new()
        lamp_mat.albedo_color = Color(1.0, 0.93, 0.62)
        lamp_mat.roughness = 0.4
        lamp_mat.emission_enabled = true
        lamp_mat.emission = Color(1.0, 0.78, 0.30)
        lamp_mat.emission_energy_multiplier = 0.0
    return lamp_mat

func _window_material() -> StandardMaterial3D:
    if window_mat == null:
        window_mat = StandardMaterial3D.new()
        window_mat.albedo_color = Color(0.33, 0.76, 0.92)
        window_mat.roughness = 0.4
        window_mat.emission_enabled = true
        window_mat.emission = Color(1.0, 0.78, 0.35)
        window_mat.emission_energy_multiplier = 0.0
    return window_mat

func _cloud_material() -> StandardMaterial3D:
    if cloud_mat == null:
        cloud_mat = StandardMaterial3D.new()
        cloud_mat.albedo_color = Color(1.0, 1.0, 1.0)
        cloud_mat.roughness = 1.0
    return cloud_mat

# ---------------------------------------------------------------- day / night

func _update_daynight() -> void:
    if sun_light == null or env_ref == null:
        return
    var e: float = sin(tod * TAU)
    var dayf: float = smoothstep(-0.22, 0.28, e)
    var twi: float = clampf(1.0 - absf(e) * 3.5, 0.0, 1.0)
    var sky: Color = Color(0.08, 0.12, 0.28).lerp(Color(0.48, 0.75, 0.92), dayf).lerp(Color(0.98, 0.62, 0.42), twi * 0.55)
    var gray: Color = Color(0.55, 0.60, 0.68).lerp(Color(0.11, 0.14, 0.24), 1.0 - dayf)
    sky = sky.lerp(gray, rain * 0.65).lerp(Color(0.95, 0.97, 1.0), flash_amt * 0.6)
    env_ref.background_color = sky
    env_ref.ambient_light_color = Color(0.55, 0.63, 0.90).lerp(Color(0.78, 0.84, 0.95), dayf).lerp(Color(1.0, 0.76, 0.62), twi * 0.5)
    env_ref.ambient_light_energy = lerpf(1.3, 0.8, dayf) * (1.0 - 0.2 * rain) + flash_amt * 1.4
    var yaw: float = -32.0 - 75.0 * cos(tod * TAU)
    var pitch: float = -(14.0 + 58.0 * e) if e >= 0.0 else -(14.0 + 34.0 * (-e))
    sun_light.rotation_degrees = Vector3(pitch, yaw, 0.0)
    var sun_col: Color = Color(1.0, 0.97, 0.90).lerp(Color(1.0, 0.62, 0.32), twi)
    sun_light.light_color = Color(0.55, 0.66, 1.0).lerp(sun_col, dayf)
    sun_light.light_energy = lerpf(0.9, 0.45 + 0.85 * clampf(e * 2.2, 0.0, 1.0), dayf) * (1.0 - 0.4 * rain)
    var night: float = 1.0 - dayf
    if lamp_mat != null:
        lamp_mat.emission_energy_multiplier = night * 2.2
    if window_mat != null:
        window_mat.albedo_color = Color(0.33, 0.76, 0.92).lerp(Color(1.0, 0.86, 0.45), night)
        window_mat.emission_energy_multiplier = night * 1.6
    if cloud_mat != null:
        cloud_mat.albedo_color = Color(0.42, 0.47, 0.68).lerp(Color(1.0, 1.0, 1.0), dayf).lerp(Color(1.0, 0.80, 0.72), twi * 0.5).lerp(Color(0.45, 0.48, 0.55), rain * 0.8)
    for wi in water_items:
        var wmat: StandardMaterial3D = wi["mat"]
        var wbase: Color = wi["base"]
        wmat.albedo_color = wbase * Color(lerpf(0.45, 1.0, dayf), lerpf(0.52, 1.0, dayf), lerpf(0.72, 1.0, dayf))
    if bird_root != null:
        bird_root.visible = dayf > 0.25 and rain < 0.5
    _apply_season_sky()
    if clock_label != null:
        var hours: float = fposmod(tod * 24.0 + 6.0, 24.0)
        var hh: int = int(hours)
        var mm: int = int((hours - float(hh)) * 60.0)
        var icon: String = "☀" if e > 0.0 else "🌙"
        clock_label.text = "%s  %02d:%02d   %s" % [icon, hh, mm, _season_label()]

# ---------------------------------------------------------------------- birds

func _build_birds() -> void:
    bird_root = Node3D.new()
    bird_root.name = "Birds"
    add_child(bird_root)
    var rng := RandomNumberGenerator.new()
    rng.seed = 17171717
    # Two big white gull flocks over the sea and a few colourful songbirds
    # circling above the island meadow.
    var groups: Array = [
        {"n": 5, "r": 26.0, "h": 9.0, "cx": 0.0, "cz": 0.0, "speed": 3.2, "col": Color(0.97, 0.97, 0.98), "wing": Color(0.97, 0.97, 0.98), "s": 1.9},
        {"n": 4, "r": 17.0, "h": 7.5, "cx": 6.0, "cz": -4.0, "speed": -2.6, "col": Color(0.96, 0.96, 0.97), "wing": Color(0.95, 0.96, 0.98), "s": 1.7},
        {"n": 4, "r": 12.0, "h": 6.0, "cx": -4.0, "cz": 2.0, "speed": 2.4, "col": Color(0.91, 0.30, 0.24), "wing": Color(0.86, 0.30, 0.24), "s": 1.4}
    ]
    for g in groups:
        for i in range(int(g["n"])):
            var info: Dictionary = _make_bird(g["col"], g["wing"], float(g["s"]))
            info["a"] = rng.randf() * TAU
            info["r"] = float(g["r"]) + rng.randf_range(-1.5, 1.5)
            info["h"] = float(g["h"]) + rng.randf_range(-1.0, 1.0)
            info["cx"] = float(g["cx"])
            info["cz"] = float(g["cz"])
            info["speed"] = float(g["speed"]) * rng.randf_range(0.9, 1.1)
            info["phase"] = rng.randf() * TAU
            birds.append(info)
    _strip_shadows(bird_root)

func _update_birds(delta: float) -> void:
    if bird_root == null or not bird_root.visible:
        return
    for b in birds:
        var spd: float = b["speed"]
        var rad: float = b["r"]
        var ang: float = b["a"] + delta * spd / rad
        b["a"] = ang
        var bn: Node3D = b["node"]
        var ph: float = b["phase"]
        var px: float = float(b["cx"]) + cos(ang) * rad
        var pz: float = float(b["cz"]) + sin(ang) * rad
        bn.position = Vector3(px, float(b["h"]) + sin(sway_clock * 0.9 + ph) * 0.35, pz)
        var dir_sign: float = 1.0 if spd >= 0.0 else -1.0
        var dx: float = -sin(ang) * dir_sign
        var dz: float = cos(ang) * dir_sign
        bn.rotation = Vector3(0.0, atan2(-dx, -dz), -0.22 * dir_sign)
        var flap: float = sin(sway_clock * 9.0 + ph) * 0.65
        var wings: Array = b["wings"]
        (wings[0] as Node3D).rotation.z = -flap
        (wings[1] as Node3D).rotation.z = flap

# --------------------------------------------------------------- small helpers

func _make_lamp(pos: Vector3) -> void:
    _cylinder(self, 0.05, 0.07, 1.3, pos + Vector3(0.0, 0.65, 0.0), Color(0.25, 0.22, 0.20), "LampPost")
    var bulb: MeshInstance3D = _sphere(self, 0.17, 0.34, pos + Vector3(0.0, 1.38, 0.0), Color(1.0, 0.93, 0.62), "LampBulb")
    bulb.material_override = _lamp_material()
    bulb.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF

func _prism_into(st: SurfaceTool, pts: Array, y0: float, y1: float, col: Color) -> void:
    var n: int = pts.size()
    for i in range(n):
        var p: Vector2 = pts[i]
        var q: Vector2 = pts[(i + 1) % n]
        var a: Vector3 = Vector3(p.x, y0, p.y)
        var b: Vector3 = Vector3(q.x, y0, q.y)
        var c: Vector3 = Vector3(q.x, y1, q.y)
        var d: Vector3 = Vector3(p.x, y1, p.y)
        _tri(st, a, b, c, col, col, col)
        _tri(st, a, c, d, col, col, col)
    var top: Color = col.lightened(0.12)
    var p0: Vector2 = pts[0]
    for i in range(1, n - 1):
        var pi: Vector2 = pts[i]
        var pj: Vector2 = pts[i + 1]
        _tri(st, Vector3(p0.x, y1, p0.y), Vector3(pi.x, y1, pi.y), Vector3(pj.x, y1, pj.y), top, top, top)

func _make_sign(parent: Node3D, pos: Vector3, text: String) -> void:
    _box(parent, Vector3(0.12, 1.5, 0.12), pos + Vector3(-0.55, 0.75, 0.0), Color(0.45, 0.28, 0.14), "SignPost")
    _box(parent, Vector3(0.12, 1.5, 0.12), pos + Vector3(0.55, 0.75, 0.0), Color(0.45, 0.28, 0.14), "SignPost")
    _box(parent, Vector3(1.5, 0.78, 0.10), pos + Vector3(0.0, 1.25, 0.0), Color(0.86, 0.66, 0.38), "SignBoard")
    var lab := Label3D.new()
    lab.text = text
    lab.font_size = 52
    lab.pixel_size = 0.0100
    lab.billboard = BaseMaterial3D.BILLBOARD_ENABLED
    lab.outline_size = 12
    lab.modulate = Color(0.30, 0.16, 0.05)
    lab.outline_modulate = Color(1.0, 0.95, 0.80)
    lab.position = pos + Vector3(0.0, 1.27, 0.12)
    parent.add_child(lab)

func _make_lock_site(pos: Vector3, text: String, yaw: float, size: float) -> Node3D:
    var site := Node3D.new()
    site.name = "ConstructionSite"
    site.position = pos
    site.rotation_degrees.y = yaw
    add_child(site)
    _disc(site, size, 0.06, Vector3(0.0, 0.0, 0.0), Color(0.62, 0.46, 0.28), "SiteDirt", 0.95, 20)
    var h: float = size * 0.5
    for sx in [-1.0, 1.0]:
        for sz in [-1.0, 1.0]:
            _box(site, Vector3(0.12, 1.5, 0.12), Vector3(float(sx) * h, 0.75, float(sz) * h), Color(0.62, 0.42, 0.22), "ScaffoldPost")
    _box(site, Vector3(size, 0.10, 0.10), Vector3(0.0, 1.1, -h), Color(0.70, 0.50, 0.28), "ScaffoldBeam")
    _box(site, Vector3(size, 0.10, 0.10), Vector3(0.0, 1.1, h), Color(0.70, 0.50, 0.28), "ScaffoldBeam")
    _box(site, Vector3(0.10, 0.10, size), Vector3(-h, 0.8, 0.0), Color(0.70, 0.50, 0.28), "ScaffoldBeam")
    _box(site, Vector3(0.10, 0.10, size), Vector3(h, 0.8, 0.0), Color(0.70, 0.50, 0.28), "ScaffoldBeam")
    _box(site, Vector3(0.9, 0.18, 0.5), Vector3(h * 0.4, 0.12, h * 0.2), Color(0.82, 0.64, 0.38), "PlankPile")
    _box(site, Vector3(0.7, 0.26, 0.5), Vector3(-h * 0.4, 0.14, -h * 0.2), Color(0.74, 0.74, 0.76), "StonePile")
    _make_sign(site, Vector3(0.0, 0.0, h + 0.7), text)
    return site

func _make_coin_bubble(parent: Node3D, pos: Vector3) -> Node3D:
    var spinner := Node3D.new()
    spinner.position = pos
    parent.add_child(spinner)
    var coin: MeshInstance3D = _disc(spinner, 0.42, 0.10, Vector3.ZERO, Color(1.0, 0.80, 0.12), "ReadyCoin", 0.35, 18)
    coin.rotation_degrees.x = 90.0
    _disc(spinner, 0.26, 0.12, Vector3.ZERO, Color(1.0, 0.92, 0.45), "ReadyCoinFace", 0.35, 18).rotation_degrees.x = 90.0
    spinner.visible = false
    return spinner

# ------------------------------------------------------------------- windmill

func _make_windmill() -> void:
    wm_site = _make_lock_site(WM_POS, "Windmill\nLevel %d" % WINDMILL_LV, 35.0, 2.6)
    var w := Node3D.new()
    w.name = "Windmill"
    w.position = WM_POS
    w.rotation_degrees.y = 35.0
    add_child(w)
    wm_built = w
    _disc(w, 1.35, 0.5, Vector3(0.0, 0.25, 0.0), Color(0.62, 0.58, 0.55), "WindmillBase", 0.9, 8, 1.15, true)
    _disc(w, 1.15, 2.9, Vector3(0.0, 1.95, 0.0), Color(0.97, 0.91, 0.78), "WindmillTower", 0.9, 8, 0.74, true)
    _disc(w, 0.98, 1.1, Vector3(0.0, 3.95, 0.0), Color(0.82, 0.24, 0.16), "WindmillRoof", 0.9, 8, 0.0, true)
    _box(w, Vector3(0.55, 0.9, 0.12), Vector3(0.0, 0.95, 1.12), Color(0.42, 0.24, 0.12), "WindmillDoor")
    _box(w, Vector3(0.34, 0.40, 0.10), Vector3(0.0, 2.3, 0.88), Color(0.33, 0.76, 0.92), "WindmillWindow").material_override = _window_material()
    _box(w, Vector3(0.7, 0.55, 0.5), Vector3(-1.5, 0.28, 0.9), Color(0.95, 0.92, 0.84), "FlourSacks")
    _box(w, Vector3(0.6, 0.45, 0.5), Vector3(-1.45, 0.78, 0.95), Color(0.90, 0.86, 0.76), "FlourSacks2")
    var hub: MeshInstance3D = _disc(w, 0.30, 0.5, Vector3(0.0, 3.35, 0.95), Color(0.40, 0.26, 0.14), "WindmillHub", 0.9, 10, -1.0, true)
    hub.rotation_degrees.x = 90.0
    wm_blades = Node3D.new()
    wm_blades.position = Vector3(0.0, 3.35, 1.25)
    w.add_child(wm_blades)
    for i in range(4):
        var arm := Node3D.new()
        arm.rotation_degrees.z = float(i) * 90.0
        wm_blades.add_child(arm)
        _box(arm, Vector3(0.14, 2.7, 0.10), Vector3(0.0, 1.45, 0.0), Color(0.45, 0.28, 0.14), "BladeSpar")
        _box(arm, Vector3(0.62, 1.9, 0.05), Vector3(0.38, 1.7, 0.03), Color(0.99, 0.96, 0.88), "BladeSail")
    wm_coin = _make_coin_bubble(w, Vector3(0.0, 5.7, 0.0))
    _make_lamp(WM_POS + Vector3(2.0, 0.0, 1.9))

# ------------------------------------------------------------------- sea port

func _make_port() -> void:
    port_site = _make_lock_site(PORT_POS + Vector3(1.6, 0.0, 0.0), "Sea Port\nLevel %d" % PORT_LV, -20.0, 3.0)
    var p := Node3D.new()
    p.name = "SeaPort"
    add_child(p)
    port_built = p
    # Warehouse
    var wh := Node3D.new()
    wh.position = PORT_POS
    wh.rotation_degrees.y = -90.0
    p.add_child(wh)
    _box(wh, Vector3(3.2, 1.6, 2.4), Vector3(0.0, 0.8, 0.0), Color(0.55, 0.68, 0.82), "WarehouseWalls")
    var rl: MeshInstance3D = _box(wh, Vector3(1.9, 0.16, 2.7), Vector3(-0.82, 1.82, 0.0), Color(0.22, 0.30, 0.46), "WarehouseRoofL")
    rl.rotation_degrees.z = 26.0
    var rr: MeshInstance3D = _box(wh, Vector3(1.9, 0.16, 2.7), Vector3(0.82, 1.82, 0.0), Color(0.30, 0.40, 0.58), "WarehouseRoofR")
    rr.rotation_degrees.z = -26.0
    _box(wh, Vector3(1.3, 1.1, 0.10), Vector3(0.0, 0.58, 1.22), Color(0.88, 0.62, 0.20), "WarehouseDoor")
    _box(wh, Vector3(1.3, 0.10, 0.12), Vector3(0.0, 0.58, 1.24), Color(0.62, 0.42, 0.12), "WarehouseDoorBar")
    # Crates and barrels beside the warehouse
    _box(p, Vector3(0.8, 0.7, 0.8), PORT_POS + Vector3(2.4, 0.35, 1.7), Color(0.74, 0.52, 0.28), "Crate")
    _box(p, Vector3(0.7, 0.6, 0.7), PORT_POS + Vector3(2.5, 1.0, 1.65), Color(0.66, 0.44, 0.22), "Crate")
    _box(p, Vector3(0.8, 0.7, 0.8), PORT_POS + Vector3(2.0, 0.35, -1.9), Color(0.20, 0.52, 0.62), "Crate")
    _cylinder(p, 0.30, 0.30, 0.7, PORT_POS + Vector3(3.0, 0.35, 1.0), Color(0.45, 0.30, 0.18), "Barrel")
    # Pier into the sea
    _box(p, Vector3(7.4, 0.16, 2.3), Vector3(20.7, 0.05, PIER_Z), Color(0.70, 0.50, 0.30), "PierDeck")
    for i in range(5):
        var px: float = 17.9 + float(i) * 1.7
        _box(p, Vector3(0.22, 1.1, 0.22), Vector3(px, -0.35, PIER_Z - 1.05), Color(0.38, 0.24, 0.12), "PierPost")
        _box(p, Vector3(0.22, 1.1, 0.22), Vector3(px, -0.35, PIER_Z + 1.05), Color(0.38, 0.24, 0.12), "PierPost")
    for i in range(5):
        _box(p, Vector3(0.05, 0.02, 2.3), Vector3(17.9 + float(i) * 1.4, 0.135, PIER_Z), Color(0.56, 0.38, 0.20), "PierPlankLine")
    _cylinder(p, 0.14, 0.18, 0.4, Vector3(24.1, 0.3, PIER_Z - 0.85), Color(0.15, 0.15, 0.17), "Bollard")
    _cylinder(p, 0.14, 0.18, 0.4, Vector3(24.1, 0.3, PIER_Z + 0.85), Color(0.15, 0.15, 0.17), "Bollard")
    # Harbour crane
    var cr := Node3D.new()
    cr.position = Vector3(22.6, 0.13, PIER_Z - 0.75)
    p.add_child(cr)
    _box(cr, Vector3(0.9, 0.3, 0.9), Vector3(0.0, 0.15, 0.0), Color(0.90, 0.62, 0.12), "CraneBase")
    _box(cr, Vector3(0.34, 3.4, 0.34), Vector3(0.0, 1.9, 0.0), Color(0.95, 0.70, 0.15), "CraneMast")
    _box(cr, Vector3(3.6, 0.26, 0.26), Vector3(1.2, 3.55, 0.0), Color(0.95, 0.70, 0.15), "CraneJib")
    _box(cr, Vector3(0.9, 0.5, 0.5), Vector3(-0.8, 3.45, 0.0), Color(0.40, 0.40, 0.44), "CraneWeight")
    _box(cr, Vector3(0.04, 1.4, 0.04), Vector3(2.5, 2.8, 0.0), Color(0.15, 0.15, 0.15), "CraneCable")
    _box(cr, Vector3(0.30, 0.22, 0.30), Vector3(2.5, 2.05, 0.0), Color(0.85, 0.18, 0.15), "CraneHook")
    port_coin = _make_coin_bubble(p, Vector3(PORT_POS.x + 0.2, 3.4, PORT_POS.z))
    _make_lamp(Vector3(17.0, 0.0, PIER_Z + 1.5))
    _make_lamp(Vector3(23.6, 0.1, PIER_Z + 1.4))
    # A sign on the pier end shown until the cargo ship is unlocked.
    ship_site = Node3D.new()
    add_child(ship_site)
    ship_site.position = Vector3(25.6, 0.0, PIER_Z)
    _make_sign(ship_site, Vector3(0.0, 0.0, 0.0), "Cargo Ship\nLevel %d" % SHIP_LV)

# --------------------------------------------------------------------- ship

func _make_ship() -> void:
    ship = Node3D.new()
    ship.name = "CargoShip"
    ship.position = Vector3(SHIP_X, -0.32, PIER_Z)
    add_child(ship)
    var st := SurfaceTool.new()
    st.begin(Mesh.PRIMITIVE_TRIANGLES)
    var red: Color = Color(0.70, 0.17, 0.14)
    var dark: Color = Color(0.16, 0.19, 0.28)
    # Hull: lofted from many cross-sections for a smooth curved shape, pointed bow towards -Z.
    _loft_hull(st, 3.9, -4.7, 1.55, -0.55, 0.45, 0.38, -0.26, red, dark, Color(0.62, 0.62, 0.66))
    # Containers
    var cols: Array = [Color(0.20, 0.50, 0.82), Color(0.92, 0.56, 0.14), Color(0.25, 0.65, 0.36), Color(0.86, 0.26, 0.24), Color(0.95, 0.85, 0.30)]
    var ci: int = 0
    for row in range(4):
        for bay in range(2):
            var cx: float = -0.68 + float(bay) * 1.36
            var cz: float = -1.9 + float(row) * 1.25
            var levels: int = 2 if (row + bay) % 2 == 0 else 1
            for lv in range(levels):
                var cc: Color = cols[ci % cols.size()]
                ci += 1
                _prism_into(st, [Vector2(cx - 0.6, cz - 0.55), Vector2(cx + 0.6, cz - 0.55), Vector2(cx + 0.6, cz + 0.55), Vector2(cx - 0.6, cz + 0.55)], 0.60 + float(lv) * 0.62, 1.20 + float(lv) * 0.62, cc)
    # Bridge tower at the stern + funnel
    _prism_into(st, [Vector2(-1.3, 2.6), Vector2(1.3, 2.6), Vector2(1.3, 3.8), Vector2(-1.3, 3.8)], 0.60, 2.0, Color(0.96, 0.95, 0.92))
    _prism_into(st, [Vector2(-1.4, 2.5), Vector2(1.4, 2.5), Vector2(1.4, 3.9), Vector2(-1.4, 3.9)], 2.0, 2.4, Color(0.96, 0.95, 0.92))
    _prism_into(st, [Vector2(-1.2, 2.45), Vector2(1.2, 2.45), Vector2(1.2, 2.62), Vector2(-1.2, 2.62)], 2.05, 2.30, Color(0.18, 0.34, 0.50))
    var hull := MeshInstance3D.new()
    hull.name = "ShipHull"
    hull.mesh = st.commit()
    hull.material_override = _get_leaf_material()
    ship.add_child(hull)
    _disc(ship, 0.40, 0.85, Vector3(0.0, 2.85, 3.35), Color(0.82, 0.18, 0.14), "Funnel", 0.8, 16, 0.32)
    _disc(ship, 0.33, 0.14, Vector3(0.0, 3.32, 3.35), Color(0.12, 0.12, 0.14), "FunnelTop", 0.8, 16)
    var lamp: MeshInstance3D = _sphere(ship, 0.16, 0.32, Vector3(0.0, 2.55, 2.55), Color(1.0, 0.93, 0.62), "ShipLamp")
    lamp.material_override = _lamp_material()
    _cylinder(ship, 0.04, 0.04, 1.0, Vector3(0.0, 1.0, -3.0), Color(0.3, 0.3, 0.3), "ShipFlagPole")
    _box(ship, Vector3(0.5, 0.3, 0.04), Vector3(0.26, 1.35, -3.0), Color(0.95, 0.80, 0.15), "ShipFlag")
    _strip_shadows(ship)

func _update_ship(delta: float) -> void:
    if ship == null or not ship_unlocked:
        return
    var bob: float = sin(sway_clock * 1.1) * 0.05
    ship.position.y = -0.32 + bob
    ship.rotation.z = sin(sway_clock * 0.8) * 0.02
    match ship_state:
        0:
            ship_timer += delta
            ship.position.z = PIER_Z
            if ship_timer > 35.0:
                ship_state = 1
                ship_timer = 0.0
        1:
            ship.position.z -= 2.4 * delta
            if ship.position.z <= SHIP_FAR_Z:
                ship_state = 2
                ship_timer = 0.0
        2:
            ship_timer += delta
            ship.rotation.y = lerpf(0.0, PI, clampf(ship_timer / 5.0, 0.0, 1.0))
            ship.position.x = SHIP_X + sin(clampf(ship_timer / 5.0, 0.0, 1.0) * PI) * 2.5
            if ship_timer >= 5.0:
                ship_state = 3
                ship.position.x = SHIP_X
        3:
            ship.position.z += 2.4 * delta
            if ship.position.z >= PIER_Z:
                ship.position.z = PIER_Z
                ship_state = 4
                ship_timer = 0.0
        4:
            ship_timer += delta
            ship.rotation.y = lerpf(PI, TAU, clampf(ship_timer / 4.0, 0.0, 1.0))
            ship.position.x = SHIP_X + sin(clampf(ship_timer / 4.0, 0.0, 1.0) * PI) * 2.5
            if ship_timer >= 4.0:
                ship.rotation.y = 0.0
                ship.position.x = SHIP_X
                ship_state = 0
                ship_timer = 0.0

# ----------------------------------------------------------- build + unlocks

func _build_v17() -> void:
    _lamp_material()
    _window_material()
    for wn in [[self, "Water"], [scenery_root, "ShallowWater"], [scenery_root, "ShoreFoam"]]:
        var holder: Node = wn[0]
        var wnode: MeshInstance3D = holder.get_node_or_null(str(wn[1])) as MeshInstance3D
        if wnode != null:
            var base_col: Color = (wnode.material_override as StandardMaterial3D).albedo_color
            var wm2 := StandardMaterial3D.new()
            wm2.albedo_color = base_col
            wm2.roughness = 0.9
            wnode.material_override = wm2
            water_items.append({"mat": wm2, "base": base_col})
    _make_windmill()
    _make_port()
    _make_ship()
    _build_birds()
    _make_lamp(Vector3(-4.3, 0.0, 6.4))
    _make_lamp(Vector3(-1.1, 0.0, 6.4))
    _build_v17_ui()
    _apply_unlocks(false)
    _update_daynight()

func _build_v17_ui() -> void:
    var layer := CanvasLayer.new()
    layer.layer = 2
    add_child(layer)
    var pill := PanelContainer.new()
    pill.position = Vector2(138.0, 80.0)
    pill.mouse_filter = Control.MOUSE_FILTER_IGNORE
    pill.add_theme_stylebox_override("panel", _flat(Color(0.99, 0.94, 0.83, 0.92), 14, Color(0.86, 0.66, 0.44), 3, 10.0))
    layer.add_child(pill)
    var box := VBoxContainer.new()
    box.add_theme_constant_override("separation", 0)
    box.mouse_filter = Control.MOUSE_FILTER_IGNORE
    pill.add_child(box)
    clock_label = Label.new()
    clock_label.add_theme_font_size_override("font_size", 21)
    clock_label.add_theme_color_override("font_color", Color(0.38, 0.24, 0.12))
    clock_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
    box.add_child(clock_label)
    hint_label = Label.new()
    hint_label.add_theme_font_size_override("font_size", 15)
    hint_label.add_theme_color_override("font_color", Color(0.55, 0.36, 0.18))
    hint_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
    box.add_child(hint_label)
    pill_extra = Label.new()
    pill_extra.add_theme_font_size_override("font_size", 16)
    pill_extra.add_theme_color_override("font_color", Color(0.15, 0.40, 0.55))
    pill_extra.mouse_filter = Control.MOUSE_FILTER_IGNORE
    pill_extra.visible = false
    box.add_child(pill_extra)

func _update_unlock_hint() -> void:
    if hint_label == null:
        return
    if raining:
        hint_label.text = "Rain: crops grow 50% faster"
        return
    if level < WINDMILL_LV:
        hint_label.text = "Next: Windmill at Lv %d" % WINDMILL_LV
    elif level < PORT_LV:
        hint_label.text = "Next: Sea Port at Lv %d" % PORT_LV
    elif level < SHIP_LV:
        hint_label.text = "Next: Cargo Ship at Lv %d" % SHIP_LV
    else:
        hint_label.text = _extra_unlock_hint()

func _apply_unlocks(announce: bool) -> void:
    var msgs: Array = []
    if level >= WINDMILL_LV and not wm_unlocked:
        wm_unlocked = true
        if announce:
            wm_timer = _wm_int()
        msgs.append("Windmill unlocked!")
    if level >= PORT_LV and not port_unlocked:
        port_unlocked = true
        if announce:
            port_timer = PORT_INTERVAL
        msgs.append("Sea Port unlocked!")
    if level >= SHIP_LV and not ship_unlocked:
        ship_unlocked = true
        msgs.append("Cargo Ship unlocked!")
    if level >= HYDRO_LV and not hydro_unlocked:
        hydro_unlocked = true
        msgs.append("Tidal Power Station unlocked!")
    if level >= TRADE_LV and not trade_unlocked:
        trade_unlocked = true
        msgs.append("Trade Centre unlocked!")
    if trade_root != null:
        _update_trade_visibility()
    if level >= TRAIN_LV and not train_unlocked:
        train_unlocked = true
        msgs.append("Train Network unlocked!")
    if level >= CARRIER_LV and not carrier_unlocked:
        carrier_unlocked = true
        msgs.append("Aircraft Carrier unlocked!")
    if carrier_root != null:
        _update_carrier_visibility()
    if train_root != null:
        _update_train_visibility()
    if hydro_built != null:
        _update_hydro_visibility()
        _update_pill_extra()
    if wm_built != null:
        wm_built.visible = wm_unlocked
        wm_site.visible = not wm_unlocked
        port_built.visible = port_unlocked
        port_site.visible = not port_unlocked
        ship.visible = ship_unlocked
        ship_site.visible = port_unlocked and not ship_unlocked
    _update_lock_buttons()
    _update_unlock_hint()
    _refresh_shop()
    if announce and msgs.size() > 0:
        _show_toast("\n".join(msgs) + "\nTap it to collect coins!")

func _tap_buildings(hit: Vector3) -> bool:
    var p: Vector2 = Vector2(hit.x, hit.z)
    # Tall buildings are tapped on their body, which projects behind the base.
    if _dist_to_segment(p, Vector2(WM_POS.x, WM_POS.z), Vector2(WM_POS.x - 2.6, WM_POS.z - 3.9)) < 1.7:
        if not wm_unlocked:
            _show_toast("Windmill unlocks at Level %d (you are Level %d)" % [WINDMILL_LV, level])
        elif wm_timer < _wm_int():
            _show_toast("Windmill is grinding... %d s" % int(ceil(_wm_int() - wm_timer)))
        else:
            var pay: int = 14 + level * 2 + (v27.wm_pay_bonus() if v27 != null else 0)
            coins += pay
            wm_timer = 0.0
            _quest_event("collect", 1)
            _play_named("ding")
            _add_xp(4)
            _save_game()
            _show_toast("Windmill flour sold! +%d coins, +4 XP" % pay)
        return true
    if p.x > 12.5 and p.x < 31.5 and absf(p.y - PIER_Z) < 4.3:
        if not port_unlocked:
            _show_toast("Sea Port unlocks at Level %d (you are Level %d)" % [PORT_LV, level])
        elif p.x > 25.0 and not ship_unlocked:
            _show_toast("Cargo Ship unlocks at Level %d" % SHIP_LV)
        elif port_timer < PORT_INTERVAL and fish_crates > 0:
            var fpay: int = fish_crates * 12
            coins += fpay
            _play_named("ding")
            _add_xp(fish_crates)
            _show_toast("Sold %d crates of fresh fish! +%d coins" % [fish_crates, fpay])
            fish_crates = 0
            _save_game()
        elif port_timer < PORT_INTERVAL:
            _show_toast("Port is loading cargo... %d s" % int(ceil(PORT_INTERVAL - port_timer)))
        else:
            var pay2: int = 38 + level * 3
            var note: String = ""
            if fish_crates > 0:
                pay2 += fish_crates * 12
                note += "\n+%d crates of fish" % fish_crates
                fish_crates = 0
            if ship_unlocked:
                pay2 *= 2
                note = "\nCargo ship bonus x2!"
            coins += pay2
            port_timer = 0.0
            _quest_event("collect", 1)
            _play_named("ding")
            _add_xp(6)
            _save_game()
            _show_toast("Water trade shipped! +%d coins, +6 XP%s" % [pay2, note])
        return true
    return _tap_buildings_v23(hit)

func _process_v17(delta: float) -> void:
    tod = fposmod(tod + delta / DAY_LENGTH, 1.0)
    dn_acc += delta
    if dn_acc >= 0.07 or flash_amt > 0.0:
        dn_acc = 0.0
        _update_daynight()
    _update_birds(delta)
    _update_ship(delta)
    if wm_unlocked:
        wm_timer = minf(_wm_int(), wm_timer + delta)
        wm_blades.rotation.z -= delta * (1.1 + 0.4 * sin(sway_clock * 0.3))
        wm_coin.visible = wm_timer >= _wm_int()
        wm_coin.rotation.y += delta * 2.4
        wm_coin.position.y = 5.7 + sin(sway_clock * 3.0) * 0.12
    if port_unlocked:
        port_timer = minf(PORT_INTERVAL, port_timer + delta)
        port_coin.visible = port_timer >= PORT_INTERVAL
        port_coin.rotation.y += delta * 2.4
        port_coin.position.y = 3.4 + sin(sway_clock * 3.0) * 0.12

func _save_v17(config: ConfigFile) -> void:
    config.set_value("farm", "tod", tod)
    config.set_value("farm", "sound_on", sound_on)
    config.set_value("farm", "crop_sel", selected_crop)
    config.set_value("farm", "fish", fish_crates)
    config.set_value("farm", "wm_timer", wm_timer)
    config.set_value("farm", "port_timer", port_timer)

func _load_v17(config: ConfigFile) -> void:
    var saved_at: float = float(config.get_value("farm", "saved_at", 0.0))
    var away: float = 0.0
    if saved_at > 0.0:
        away = maxf(0.0, Time.get_unix_time_from_system() - saved_at)
    sound_on = bool(config.get_value("farm", "sound_on", true))
    selected_crop = clampi(int(config.get_value("farm", "crop_sel", 0)), 0, crop_defs.size() - 1)
    fish_crates = clampi(int(config.get_value("farm", "fish", 0)), 0, 8)
    AudioServer.set_bus_mute(AudioServer.get_bus_index("Master"), not sound_on)
    tod = fposmod(float(config.get_value("farm", "tod", tod)) + away / DAY_LENGTH, 1.0)
    wm_timer = minf(_wm_int(), float(config.get_value("farm", "wm_timer", 0.0)) + away)
    port_timer = minf(PORT_INTERVAL, float(config.get_value("farm", "port_timer", 0.0)) + away)

# ===========================================================================
# v18 — feather-shaped bird wings, road vehicles and a procedural soundscape
# ===========================================================================

var wing_mesh: ArrayMesh
var tail_mesh: ArrayMesh
var bird_mats: Dictionary = {}
var vehicles: Array = []
var sound_on: bool = true
var audio_jobs: Array = []
var wave_player: AudioStreamPlayer
var wind_player: AudioStreamPlayer
var cricket_player: AudioStreamPlayer
var sfx_players: Array = []
var chirp_streams: Array = []
var bell_streams: Array = []
var named_streams: Dictionary = {}
var chirp_timer: float = 1.0
var bell_timer: float = 4.0
var bell_index: int = 2
var audio_rng := RandomNumberGenerator.new()
var amb_wave_db: float = -80.0
var ship_prev_state: int = 0

# ----------------------------------------------------------------- feathers

func _feather_into(st: SurfaceTool, base: Vector3, ang: float, length: float, width: float, droop: float, c_base: Color, c_tip: Color) -> void:
    var d: Vector3 = Vector3(cos(ang), 0.0, sin(ang))
    var pr: Vector3 = Vector3(-sin(ang), 0.0, cos(ang)) * width
    var mid: Vector3 = base + d * length * 0.45 + Vector3(0.0, -droop * 0.3, 0.0)
    var nt: Vector3 = base + d * length * 0.84 + Vector3(0.0, -droop * 0.8, 0.0)
    var tip: Vector3 = base + d * length + Vector3(0.0, -droop, 0.0)
    var cm: Color = c_base.lerp(c_tip, 0.45)
    # A pointed, rounded-tip feather: wide in the middle, tapering to both ends.
    _tri(st, base, mid + pr, mid - pr, c_base, cm, cm)
    _tri(st, mid + pr, nt + pr * 0.55, nt - pr * 0.55, cm, c_tip, c_tip)
    _tri(st, mid + pr, nt - pr * 0.55, mid - pr, cm, c_tip, cm)
    _tri(st, nt + pr * 0.55, tip, nt - pr * 0.55, c_tip, c_tip, c_tip)

func _get_wing_mesh() -> ArrayMesh:
    if wing_mesh == null:
        var st := SurfaceTool.new()
        st.begin(Mesh.PRIMITIVE_TRIANGLES)
        var light: Color = Color(1.0, 1.0, 1.0)
        var dark: Color = Color(0.72, 0.72, 0.75)
        # Short wide coverts near the body.
        for i in range(3):
            var a: float = 0.95 + float(i) * 0.28
            _feather_into(st, Vector3(0.0, 0.010 + float(i) * 0.004, 0.0), a, 0.30, 0.085, 0.01, light, light.darkened(0.08))
        # Long primary feathers fanned out from the shoulder like a hand.
        for i in range(6):
            var f: float = float(i) / 5.0
            var ang: float = lerpf(-0.10, 0.80, f)
            var length: float = lerpf(0.78, 0.46, f)
            _feather_into(st, Vector3(0.0, 0.002 * float(i), -0.02 + 0.015 * float(i)), ang, length, 0.075, 0.05 - 0.02 * f, light, dark)
        wing_mesh = st.commit()
    return wing_mesh

func _get_tail_mesh() -> ArrayMesh:
    if tail_mesh == null:
        var st := SurfaceTool.new()
        st.begin(Mesh.PRIMITIVE_TRIANGLES)
        for i in range(3):
            var a: float = PI * 0.5 + (float(i) - 1.0) * 0.30
            _feather_into(st, Vector3(0.0, 0.0, 0.0), a, 0.34, 0.06, 0.0, Color(1.0, 1.0, 1.0), Color(0.62, 0.62, 0.66))
        tail_mesh = st.commit()
    return tail_mesh

func _bird_material(col: Color) -> StandardMaterial3D:
    var key: String = col.to_html(false)
    if bird_mats.has(key):
        return bird_mats[key]
    var m: StandardMaterial3D = _get_leaf_material().duplicate() as StandardMaterial3D
    m.albedo_color = col
    bird_mats[key] = m
    return m

func _make_bird(col: Color, wing_col: Color, s: float) -> Dictionary:
    var bird := Node3D.new()
    bird.scale = Vector3.ONE * s
    bird_root.add_child(bird)
    var body: MeshInstance3D = _sphere(bird, 0.13, 0.26, Vector3(0.0, 0.0, 0.0), col, "BirdBody")
    body.scale = Vector3(0.9, 0.85, 2.2)
    _sphere(bird, 0.095, 0.19, Vector3(0.0, 0.06, -0.30), col, "BirdHead")
    var beak: MeshInstance3D = _disc(bird, 0.04, 0.17, Vector3(0.0, 0.05, -0.46), Color(0.98, 0.70, 0.18), "BirdBeak", 0.9, 4, 0.0)
    beak.rotation_degrees.x = -90.0
    var tail := MeshInstance3D.new()
    tail.name = "BirdTail"
    tail.mesh = _get_tail_mesh()
    tail.material_override = _bird_material(wing_col)
    tail.position = Vector3(0.0, 0.0, 0.26)
    bird.add_child(tail)
    var wings: Array = []
    for side in [-1.0, 1.0]:
        var pivot := Node3D.new()
        pivot.position = Vector3(float(side) * 0.07, 0.07, -0.02)
        pivot.scale = Vector3(float(side), 1.0, 1.0)
        bird.add_child(pivot)
        var wing := MeshInstance3D.new()
        wing.name = "BirdWing"
        wing.mesh = _get_wing_mesh()
        wing.material_override = _bird_material(wing_col)
        pivot.add_child(wing)
        wings.append(pivot)
    return {"node": bird, "wings": wings}

# ------------------------------------------------------------------ vehicles

func _wheel(parent: Node3D, pos: Vector3, radius: float, width: float, hub: Color) -> Node3D:
    var pivot := Node3D.new()
    pivot.position = pos
    parent.add_child(pivot)
    var tyre: MeshInstance3D = _disc(pivot, radius, width, Vector3.ZERO, Color(0.12, 0.12, 0.14), "Tyre", 0.9, 14, -1.0, false)
    tyre.rotation_degrees.z = 90.0
    var cap: MeshInstance3D = _disc(pivot, radius * 0.5, width + 0.02, Vector3.ZERO, hub, "Hub", 0.6, 10)
    cap.rotation_degrees.z = 90.0
    return pivot

func _headlights(parent: Node3D, z: float, y: float, x: float) -> void:
    for sx in [-1.0, 1.0]:
        var hl: MeshInstance3D = _sphere(parent, 0.07, 0.14, Vector3(float(sx) * x, y, z), Color(1.0, 0.95, 0.7), "Headlight")
        hl.material_override = _lamp_material()
        hl.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF

func _make_tractor() -> Dictionary:
    var t := Node3D.new()
    t.name = "Tractor"
    add_child(t)
    var green: Color = Color(0.25, 0.62, 0.28)
    _box(t, Vector3(0.62, 0.42, 1.0), Vector3(0.0, 0.52, 0.15), green, "TractorBody")
    _ellipsoid(t, Vector3(0.27, 0.21, 0.46), Vector3(0.0, 0.52, 0.72), green.lightened(0.08), "TractorHood")
    _ellipsoid(t, Vector3(0.22, 0.14, 0.05), Vector3(0.0, 0.50, 1.15), Color(0.30, 0.30, 0.34), "TractorGrill")
    _box(t, Vector3(0.62, 0.62, 0.52), Vector3(0.0, 1.0, -0.20), Color(0.20, 0.50, 0.24), "TractorCab")
    _ellipsoid(t, Vector3(0.42, 0.07, 0.38), Vector3(0.0, 1.34, -0.20), Color(0.16, 0.38, 0.20), "TractorRoof")
    _box(t, Vector3(0.52, 0.34, 0.04), Vector3(0.0, 1.02, 0.07), Color(0.60, 0.86, 0.96), "TractorGlass")
    _cylinder(t, 0.035, 0.035, 0.55, Vector3(0.18, 0.95, 0.72), Color(0.45, 0.45, 0.48), "Exhaust")
    _box(t, Vector3(0.18, 0.2, 0.4), Vector3(0.0, 0.40, -0.62), Color(0.55, 0.40, 0.18), "Hitch")
    _headlights(t, 0.98, 0.52, 0.2)
    var wheels: Array = []
    wheels.append(_wheel(t, Vector3(-0.46, 0.42, -0.30), 0.42, 0.26, Color(0.96, 0.78, 0.18)))
    wheels.append(_wheel(t, Vector3(0.46, 0.42, -0.30), 0.42, 0.26, Color(0.96, 0.78, 0.18)))
    wheels.append(_wheel(t, Vector3(-0.36, 0.26, 0.75), 0.26, 0.18, Color(0.96, 0.78, 0.18)))
    wheels.append(_wheel(t, Vector3(0.36, 0.26, 0.75), 0.26, 0.18, Color(0.96, 0.78, 0.18)))
    return {"node": t, "wheels": wheels, "wr": [0.42, 0.42, 0.26, 0.26], "light": []}

func _make_ambulance() -> Dictionary:
    var a := Node3D.new()
    a.name = "Ambulance"
    add_child(a)
    var white: Color = Color(0.98, 0.98, 0.98)
    _box(a, Vector3(0.95, 0.90, 1.7), Vector3(0.0, 0.70, -0.20), white, "AmbBody")
    _box(a, Vector3(0.92, 0.50, 0.55), Vector3(0.0, 0.50, 0.95), white, "AmbNose")
    _box(a, Vector3(0.80, 0.34, 0.05), Vector3(0.0, 0.92, 0.68), Color(0.55, 0.82, 0.95), "AmbGlass")
    _box(a, Vector3(0.02, 0.12, 1.7), Vector3(0.48, 0.48, -0.20), Color(0.86, 0.16, 0.16), "AmbStripe")
    _box(a, Vector3(0.02, 0.12, 1.7), Vector3(-0.48, 0.48, -0.20), Color(0.86, 0.16, 0.16), "AmbStripe")
    for sx in [-1.0, 1.0]:
        _box(a, Vector3(0.02, 0.15, 0.50), Vector3(float(sx) * 0.48, 0.84, -0.20), Color(0.86, 0.16, 0.16), "AmbCrossH")
        _box(a, Vector3(0.02, 0.50, 0.15), Vector3(float(sx) * 0.48, 0.84, -0.20), Color(0.86, 0.16, 0.16), "AmbCrossV")
    _box(a, Vector3(0.50, 0.04, 0.50), Vector3(0.0, 1.17, -0.15), Color(0.86, 0.16, 0.16), "AmbRoofCross")
    var red_l: MeshInstance3D = _box(a, Vector3(0.22, 0.12, 0.2), Vector3(-0.2, 1.22, 0.35), Color(1.0, 0.2, 0.2), "AmbLightRed")
    var blue_l: MeshInstance3D = _box(a, Vector3(0.22, 0.12, 0.2), Vector3(0.2, 1.22, 0.35), Color(0.2, 0.4, 1.0), "AmbLightBlue")
    var rm := StandardMaterial3D.new()
    rm.albedo_color = Color(1.0, 0.2, 0.2)
    rm.emission_enabled = true
    rm.emission = Color(1.0, 0.1, 0.1)
    rm.emission_energy_multiplier = 0.0
    red_l.material_override = rm
    var bm := StandardMaterial3D.new()
    bm.albedo_color = Color(0.2, 0.4, 1.0)
    bm.emission_enabled = true
    bm.emission = Color(0.1, 0.3, 1.0)
    bm.emission_energy_multiplier = 0.0
    blue_l.material_override = bm
    _headlights(a, 1.22, 0.5, 0.3)
    var wheels: Array = []
    wheels.append(_wheel(a, Vector3(-0.50, 0.27, -0.75), 0.27, 0.18, Color(0.8, 0.8, 0.82)))
    wheels.append(_wheel(a, Vector3(0.50, 0.27, -0.75), 0.27, 0.18, Color(0.8, 0.8, 0.82)))
    wheels.append(_wheel(a, Vector3(-0.50, 0.27, 0.95), 0.27, 0.18, Color(0.8, 0.8, 0.82)))
    wheels.append(_wheel(a, Vector3(0.50, 0.27, 0.95), 0.27, 0.18, Color(0.8, 0.8, 0.82)))
    return {"node": a, "wheels": wheels, "wr": [0.27, 0.27, 0.27, 0.27], "light": [rm, bm]}

func _make_pickup() -> Dictionary:
    var p := Node3D.new()
    p.name = "Pickup"
    add_child(p)
    var red: Color = Color(0.84, 0.22, 0.18)
    _box(p, Vector3(0.85, 0.50, 0.85), Vector3(0.0, 0.58, 0.55), red, "PickupCab")
    _box(p, Vector3(0.80, 0.30, 0.04), Vector3(0.0, 0.76, 0.98), Color(0.55, 0.82, 0.95), "PickupGlass")
    _box(p, Vector3(0.86, 0.28, 0.55), Vector3(0.0, 0.40, 1.05), red.darkened(0.1), "PickupNose")
    _box(p, Vector3(0.85, 0.12, 1.0), Vector3(0.0, 0.40, -0.45), Color(0.40, 0.40, 0.44), "PickupBedFloor")
    _box(p, Vector3(0.05, 0.28, 1.0), Vector3(0.43, 0.56, -0.45), red, "PickupBedSide")
    _box(p, Vector3(0.05, 0.28, 1.0), Vector3(-0.43, 0.56, -0.45), red, "PickupBedSide")
    _box(p, Vector3(0.85, 0.28, 0.05), Vector3(0.0, 0.56, -0.95), red, "PickupTailgate")
    _box(p, Vector3(0.55, 0.38, 0.55), Vector3(0.0, 0.65, -0.40), Color(0.95, 0.80, 0.30), "HayBale")
    _headlights(p, 1.33, 0.42, 0.28)
    var wheels: Array = []
    wheels.append(_wheel(p, Vector3(-0.46, 0.25, -0.55), 0.25, 0.17, Color(0.85, 0.85, 0.88)))
    wheels.append(_wheel(p, Vector3(0.46, 0.25, -0.55), 0.25, 0.17, Color(0.85, 0.85, 0.88)))
    wheels.append(_wheel(p, Vector3(-0.46, 0.25, 0.95), 0.25, 0.17, Color(0.85, 0.85, 0.88)))
    wheels.append(_wheel(p, Vector3(0.46, 0.25, 0.95), 0.25, 0.17, Color(0.85, 0.85, 0.88)))
    return {"node": p, "wheels": wheels, "wr": [0.25, 0.25, 0.25, 0.25], "light": []}

func _add_vehicle(info: Dictionary, route: Array, speed: float, start_s: float) -> void:
    var cum: Array = [0.0]
    var total: float = 0.0
    for i in range(route.size() - 1):
        var a: Vector2 = route[i]
        var b: Vector2 = route[i + 1]
        total += a.distance_to(b)
        cum.append(total)
    info["route"] = route
    info["cum"] = cum
    info["total"] = total
    info["s"] = start_s
    info["dir"] = 1.0
    info["speed"] = speed
    info["pause"] = 0.0
    vehicles.append(info)

func _build_vehicles() -> void:
    var route_a: Array = [Vector2(-2.7, 5.4), Vector2(-3.4, 8.5), Vector2(-2.0, 12.0), Vector2(1.5, 14.5), Vector2(6.0, 15.5)]
    var route_b: Array = [Vector2(2.0, 9.4), Vector2(7.5, 8.6), Vector2(11.5, 5.5), Vector2(14.5, 1.0), Vector2(16.0, -4.0), Vector2(16.0, -9.0), Vector2(16.9, -12.0)]
    var route_c: Array = [Vector2(-2.2, -5.0), Vector2(-3.5, -8.0), Vector2(-6.0, -10.5), Vector2(-10.0, -12.5), Vector2(-14.5, -12.5)]
    _add_vehicle(_make_tractor(), route_a, 1.7, 2.0)
    _add_vehicle(_make_ambulance(), route_b, 3.0, 6.0)
    _add_vehicle(_make_pickup(), route_c, 2.3, 4.0)
    _update_vehicles(0.0)

func _update_vehicles(delta: float) -> void:
    for v in vehicles:
        var node: Node3D = v["node"]
        var route: Array = v["route"]
        var cum: Array = v["cum"]
        var total: float = v["total"]
        var dir: float = v["dir"]
        var s: float = v["s"]
        var moving: bool = true
        if float(v["pause"]) > 0.0:
            v["pause"] = float(v["pause"]) - delta
            moving = false
        else:
            s += dir * float(v["speed"]) * delta
            if s >= total:
                s = total
                v["dir"] = -1.0
                v["pause"] = 2.0
            elif s <= 0.0:
                s = 0.0
                v["dir"] = 1.0
                v["pause"] = 2.0
            v["s"] = s
        # Find the road segment under distance s.
        var idx: int = 0
        while idx < route.size() - 2 and s > float(cum[idx + 1]):
            idx += 1
        var pa: Vector2 = route[idx]
        var pb: Vector2 = route[idx + 1]
        var seg_len: float = maxf(0.001, float(cum[idx + 1]) - float(cum[idx]))
        var f: float = clampf((s - float(cum[idx])) / seg_len, 0.0, 1.0)
        var pos: Vector2 = pa.lerp(pb, f)
        var fwd: Vector2 = (pb - pa).normalized() * float(v["dir"])
        node.position = Vector3(pos.x, 0.0, pos.y)
        var target_yaw: float = atan2(fwd.x, fwd.y)
        if delta <= 0.0:
            node.rotation.y = target_yaw
        else:
            node.rotation.y = lerp_angle(node.rotation.y, target_yaw, clampf(delta * 6.0, 0.0, 1.0))
        if moving and delta > 0.0:
            var wheels: Array = v["wheels"]
            var wr: Array = v["wr"]
            for i in range(wheels.size()):
                (wheels[i] as Node3D).rotation.x += float(v["speed"]) * delta / float(wr[i])
        var lights: Array = v["light"]
        if lights.size() == 2:
            var flip: bool = int(sway_clock * 4.0) % 2 == 0
            (lights[0] as StandardMaterial3D).emission_energy_multiplier = 2.5 if (flip and moving) else 0.0
            (lights[1] as StandardMaterial3D).emission_energy_multiplier = 2.5 if (not flip and moving) else 0.0

# --------------------------------------------------------------------- audio

func _pcm_to_wav(data: PackedFloat32Array, rate: int, loop: bool) -> AudioStreamWAV:
    var n: int = data.size()
    var bytes := PackedByteArray()
    bytes.resize(n * 2)
    for i in range(n):
        bytes.encode_s16(i * 2, int(clampf(data[i], -1.0, 1.0) * 30000.0))
    var w := AudioStreamWAV.new()
    w.format = AudioStreamWAV.FORMAT_16_BITS
    w.mix_rate = rate
    w.stereo = false
    w.data = bytes
    if loop:
        w.loop_mode = AudioStreamWAV.LOOP_FORWARD
        w.loop_begin = 0
        w.loop_end = n
    return w

func _normalize(data: PackedFloat32Array, peak: float) -> void:
    var m: float = 0.0001
    for i in range(data.size()):
        m = maxf(m, absf(data[i]))
    var g: float = peak / m
    for i in range(data.size()):
        data[i] = data[i] * g

func _loop_blend(raw: PackedFloat32Array, n: int, fade: int) -> PackedFloat32Array:
    # raw has n + fade samples; blend the tail into the head so the loop is seamless.
    var out := PackedFloat32Array()
    out.resize(n)
    for i in range(n):
        out[i] = raw[i]
    for i in range(fade):
        out[i] = lerpf(raw[n + i], raw[i], float(i) / float(fade))
    return out

func _gen_wave() -> AudioStreamWAV:
    var rate: int = 11025
    var n: int = rate * 9
    var fade: int = 4000
    var raw := PackedFloat32Array()
    raw.resize(n + fade)
    var lo: float = 0.0
    var lo2: float = 0.0
    var hf: float = 0.0
    for i in range(n + fade):
        var t: float = float(i) / float(rate)
        var swell: float = 0.5 + 0.5 * sin(TAU * t / 9.0 - 1.2)
        var swell2: float = 0.5 + 0.5 * sin(TAU * t / 4.5 + 0.7)
        var env: float = pow(0.15 + 0.65 * swell + 0.20 * swell2, 1.7)
        var x: float = audio_rng.randf_range(-1.0, 1.0)
        lo += (x - lo) * 0.10
        lo2 += (lo - lo2) * 0.35
        hf += (x - hf) * 0.55
        var hiss: float = x - hf
        raw[i] = (lo2 * 7.0 * env) + (hiss * 0.10 * env * env)
    var out: PackedFloat32Array = _loop_blend(raw, n, fade)
    _normalize(out, 0.8)
    return _pcm_to_wav(out, rate, true)

func _gen_wind() -> AudioStreamWAV:
    var rate: int = 11025
    var n: int = rate * 8
    var fade: int = 4000
    var raw := PackedFloat32Array()
    raw.resize(n + fade)
    var a1: float = 0.0
    var a2: float = 0.0
    for i in range(n + fade):
        var t: float = float(i) / float(rate)
        var gust: float = 0.55 + 0.30 * sin(TAU * t / 8.0 + 0.5) + 0.15 * sin(TAU * t / 2.6667 + 2.0)
        var x: float = audio_rng.randf_range(-1.0, 1.0)
        a1 += (x - a1) * (0.045 + 0.04 * gust)
        a2 += (x - a2) * 0.012
        raw[i] = (a1 - a2) * gust * 3.0
    var out: PackedFloat32Array = _loop_blend(raw, n, fade)
    _normalize(out, 0.7)
    return _pcm_to_wav(out, rate, true)

func _gen_crickets() -> AudioStreamWAV:
    var rate: int = 16000
    var n: int = rate * 3
    var out := PackedFloat32Array()
    out.resize(n)
    for i in range(n):
        var t: float = float(i) / float(rate)
        var v: float = 0.0
        for k in range(2):
            var f: float = 3300.0 + float(k) * 420.0
            var off: float = float(k) * 0.21
            var tt: float = fposmod(t - off, 0.75)
            if tt < 0.2:
                var pulse: float = fposmod(tt, 0.04)
                if pulse < 0.022:
                    var pe: float = sin(PI * pulse / 0.022)
                    v += sin(TAU * f * t) * pe * 0.5
        out[i] = v
    _normalize(out, 0.5)
    return _pcm_to_wav(out, rate, true)

func _gen_chirp(variant: int) -> AudioStreamWAV:
    var rate: int = 16000
    var notes: Array = []
    # Each note: [start_freq, end_freq, duration, gap_after]
    if variant == 0:
        notes = [[2800.0, 3900.0, 0.09, 0.05], [2900.0, 4100.0, 0.10, 0.0]]
    elif variant == 1:
        for i in range(7):
            notes.append([3500.0 if i % 2 == 0 else 4300.0, 3600.0 if i % 2 == 0 else 4200.0, 0.045, 0.02])
    elif variant == 2:
        notes = [[4300.0, 3000.0, 0.13, 0.03], [3000.0, 3900.0, 0.10, 0.04], [3900.0, 3300.0, 0.14, 0.0]]
    else:
        notes = [[4600.0, 4000.0, 0.07, 0.04], [4200.0, 3600.0, 0.07, 0.04], [3800.0, 3200.0, 0.09, 0.0]]
    var total: float = 0.05
    for nt in notes:
        total += float(nt[2]) + float(nt[3])
    var n: int = int(total * float(rate))
    var out := PackedFloat32Array()
    out.resize(n)
    var cursor: float = 0.02
    for nt in notes:
        var f0: float = nt[0]
        var f1: float = nt[1]
        var dur: float = nt[2]
        var s0: int = int(cursor * float(rate))
        var cnt: int = int(dur * float(rate))
        var phase: float = 0.0
        for j in range(cnt):
            var u: float = float(j) / float(cnt)
            var f: float = lerpf(f0, f1, u) + sin(u * 40.0) * 60.0
            phase += TAU * f / float(rate)
            var env: float = sin(PI * u)
            env = env * env
            if s0 + j < n:
                out[s0 + j] += (sin(phase) + 0.3 * sin(phase * 2.0)) * env * 0.6
        cursor += dur + float(nt[3])
    _normalize(out, 0.7)
    return _pcm_to_wav(out, rate, false)

func _gen_bell(freq: float) -> AudioStreamWAV:
    var rate: int = 11025
    var n: int = int(2.2 * float(rate))
    var out := PackedFloat32Array()
    out.resize(n)
    for i in range(n):
        var t: float = float(i) / float(rate)
        var att: float = minf(1.0, t / 0.006)
        var v: float = sin(TAU * freq * t) * exp(-t * 2.2)
        v += 0.28 * sin(TAU * freq * 2.0 * t) * exp(-t * 4.0)
        v += 0.10 * sin(TAU * freq * 3.01 * t) * exp(-t * 6.0)
        out[i] = v * att
    _normalize(out, 0.7)
    return _pcm_to_wav(out, rate, false)

func _gen_horn() -> AudioStreamWAV:
    var rate: int = 11025
    var n: int = int(1.4 * float(rate))
    var out := PackedFloat32Array()
    out.resize(n)
    for i in range(n):
        var t: float = float(i) / float(rate)
        var env: float = minf(1.0, t / 0.12) * minf(1.0, (1.4 - t) / 0.35)
        var v: float = 0.0
        for fr in [98.0, 123.5]:
            for h in range(1, 6):
                v += sin(TAU * fr * float(h) * t) / float(h)
        out[i] = v * env
    _normalize(out, 0.8)
    return _pcm_to_wav(out, rate, false)

func _gen_ding() -> AudioStreamWAV:
    var rate: int = 11025
    var n: int = int(0.7 * float(rate))
    var out := PackedFloat32Array()
    out.resize(n)
    for i in range(n):
        var t: float = float(i) / float(rate)
        var v: float = sin(TAU * 1568.0 * t) * exp(-t * 7.0) + 0.4 * sin(TAU * 2349.0 * t) * exp(-t * 9.0)
        out[i] = v * minf(1.0, t / 0.003)
    _normalize(out, 0.8)
    return _pcm_to_wav(out, rate, false)

func _gen_jingle() -> AudioStreamWAV:
    var rate: int = 11025
    var n: int = int(1.6 * float(rate))
    var out := PackedFloat32Array()
    out.resize(n)
    var notes: Array = [523.25, 659.25, 783.99, 1046.5]
    for k in range(notes.size()):
        var s0: int = int(float(k) * 0.13 * float(rate))
        var f: float = notes[k]
        for i in range(int(1.0 * float(rate))):
            if s0 + i >= n:
                break
            var t: float = float(i) / float(rate)
            out[s0 + i] += (sin(TAU * f * t) * exp(-t * 3.0) + 0.25 * sin(TAU * f * 2.0 * t) * exp(-t * 5.0)) * minf(1.0, t / 0.005)
    _normalize(out, 0.8)
    return _pcm_to_wav(out, rate, false)

func _queue_audio(label: String, maker: Callable) -> void:
    audio_jobs.append({"label": label, "maker": maker})

func _run_audio_job() -> void:
    if audio_jobs.is_empty():
        return
    var job: Dictionary = audio_jobs.pop_front()
    var label: String = job["label"]
    var maker: Callable = job["maker"]
    var stream: AudioStreamWAV = maker.call()
    if label == "wave":
        wave_player.stream = stream
        wave_player.play()
    elif label == "wind":
        wind_player.stream = stream
        wind_player.play()
    elif label == "crickets":
        cricket_player.stream = stream
        cricket_player.play()
    elif label.begins_with("chirp"):
        chirp_streams.append(stream)
    elif label.begins_with("bell"):
        bell_streams.append(stream)
    else:
        named_streams[label] = stream

func _make_player(db: float) -> AudioStreamPlayer:
    var p := AudioStreamPlayer.new()
    p.volume_db = db
    add_child(p)
    return p

func _build_audio() -> void:
    audio_rng.seed = 424242
    wave_player = _make_player(-80.0)
    wind_player = _make_player(-80.0)
    cricket_player = _make_player(-80.0)
    for i in range(5):
        sfx_players.append(_make_player(-10.0))
    _queue_audio("wave", Callable(self, "_gen_wave"))
    _queue_audio("wind", Callable(self, "_gen_wind"))
    for v in range(4):
        _queue_audio("chirp%d" % v, _gen_chirp.bind(v))
    for f in [523.25, 587.33, 659.25, 783.99, 880.0]:
        _queue_audio("bell", _gen_bell.bind(f))
    _queue_audio("crickets", Callable(self, "_gen_crickets"))
    _queue_audio("ding", Callable(self, "_gen_ding"))
    _queue_audio("jingle", Callable(self, "_gen_jingle"))
    _queue_audio("horn", Callable(self, "_gen_horn"))

func _play_stream(stream: AudioStream, db: float, pitch: float) -> void:
    if stream == null:
        return
    for p in sfx_players:
        var pl: AudioStreamPlayer = p
        if not pl.playing:
            pl.stream = stream
            pl.volume_db = db
            pl.pitch_scale = pitch
            pl.play()
            return

func _play_named(label: String, db: float = -8.0) -> void:
    if named_streams.has(label):
        _play_stream(named_streams[label], db, 1.0)

func _toggle_sound() -> void:
    sound_on = not sound_on
    AudioServer.set_bus_mute(AudioServer.get_bus_index("Master"), not sound_on)
    _show_toast("Sound ON" if sound_on else "Sound OFF")

func _update_audio(delta: float) -> void:
    _run_audio_job()
    var e: float = sin(tod * TAU)
    var dayf: float = smoothstep(-0.22, 0.28, e)
    var night: float = 1.0 - dayf
    var edge: float = clampf(maxf(absf(cam_target.x), absf(cam_target.z)) / PAN_LIMIT, 0.0, 1.0)
    var zoom_f: float = clampf((ZOOM_MAX - cam_zoom) / (ZOOM_MAX - ZOOM_MIN), 0.0, 1.0)
    if wave_player.playing:
        wave_player.volume_db = lerpf(-20.0, -9.0, edge) + zoom_f * 2.0
    if wind_player.playing:
        wind_player.volume_db = -25.0 + sin(sway_clock * 0.25) * 2.5 + edge * 3.0
    if cricket_player.playing:
        cricket_player.volume_db = lerpf(-60.0, -23.0, clampf(night * 1.4 - 0.2, 0.0, 1.0))
    # Birdsong: busiest in the morning, calmer at noon and evening, silent at night.
    if dayf > 0.3 and rain < 0.4 and chirp_streams.size() > 0:
        chirp_timer -= delta
        if chirp_timer <= 0.0:
            var morning: bool = e >= 0.0 and tod < 0.12
            chirp_timer = audio_rng.randf_range(0.5, 1.6) if morning else audio_rng.randf_range(2.0, 6.0)
            var cs: AudioStream = chirp_streams[audio_rng.randi() % chirp_streams.size()]
            var cdb: float = -17.0 + zoom_f * 4.0 + (3.0 if morning else 0.0)
            _play_stream(cs, cdb, audio_rng.randf_range(0.85, 1.25))
    # Soft music-box melody, slower and an octave lower at night.
    if bell_streams.size() >= 5:
        bell_timer -= delta
        if bell_timer <= 0.0:
            var step: int = audio_rng.randi_range(-2, 2)
            bell_index = clampi(bell_index + step, 0, bell_streams.size() - 1)
            bell_timer = audio_rng.randf_range(0.7, 1.5) if night < 0.5 else audio_rng.randf_range(1.6, 2.8)
            if audio_rng.randf() < 0.18:
                bell_timer += 1.8
            var pitch: float = 1.0 if night < 0.5 else 0.5
            _play_stream(bell_streams[bell_index], -19.0 - night * 3.0, pitch)

func _process_v18(delta: float) -> void:
    _update_vehicles(delta)
    _update_audio(delta)
    if ship != null and ship_unlocked and ship_state != ship_prev_state:
        if ship_state == 1 or ship_state == 4:
            _play_named("horn", -10.0)
        ship_prev_state = ship_state

func _build_v18() -> void:
    _build_vehicles()
    _build_audio()

# ===========================================================================
# v19 — crops and shop, wandering animals, rain weather, fishing boats
# ===========================================================================

var crop_defs: Array = [
    {"name": "Tomato", "lv": 1, "grow": 18.0, "pay": 7, "xp": 10, "icon": "🍅"},
    {"name": "Wheat", "lv": 2, "grow": 12.0, "pay": 5, "xp": 7, "icon": "🌾"},
    {"name": "Carrot", "lv": 4, "grow": 26.0, "pay": 13, "xp": 16, "icon": "🥕"},
    {"name": "Corn", "lv": 6, "grow": 40.0, "pay": 24, "xp": 28, "icon": "🌽"},
    {"name": "Rice", "lv": 8, "grow": 30.0, "pay": 17, "xp": 22, "icon": "🍚"}
]
var selected_crop: int = 0
var crop_buttons: Array = []
var crop_info_label: Label
var shop_coin_label: Label

var animals: Array = []
var raining: bool = false
var rain: float = 0.0
var weather_timer: float = 55.0
var rain_particles: CPUParticles3D
var rain_mat: StandardMaterial3D
var rain_player: AudioStreamPlayer
var thunder_timer: float = 20.0
var thunder_delay: float = -1.0
var flash_amt: float = 0.0
var rainbow: MeshInstance3D
var rainbow_mat: StandardMaterial3D
var rainbow_time: float = 0.0
var moo_timer: float = 20.0
var fish_crates: int = 0
var fishing_boats: Array = []

# ------------------------------------------------------------ crops and shop

func _crop_of(state: Dictionary) -> Dictionary:
    var id: int = clampi(int(state.get("crop", 0)), 0, crop_defs.size() - 1)
    return crop_defs[id]

func _grow_time_of(state: Dictionary) -> float:
    return float(_crop_of(state)["grow"])

func _stalk(parent: Node3D, pos: Vector3, h: float, col: Color) -> void:
    _box(parent, Vector3(0.05, h, 0.05), pos + Vector3(0.0, h * 0.5, 0.0), col, "Stalk")

func _update_crop_visual(key: String) -> void:
    if crop_nodes.has(key):
        var old: Node = crop_nodes[key]
        if is_instance_valid(old):
            old.queue_free()
        crop_nodes.erase(key)
    if not crop_states.has(key):
        return
    var state: Dictionary = crop_states[key]
    if not state.get("planted", false):
        crop_stage_cache.erase(key)
        return
    var gt: float = _grow_time_of(state)
    var age: float = float(state.get("age", 0.0))
    var stage: int = 0 if age < gt * 0.35 else (1 if age < gt else 2)
    crop_stage_cache[key] = stage
    var id: int = clampi(int(state.get("crop", 0)), 0, crop_defs.size() - 1)
    var center: Vector3 = plot_centers[key]
    var crop := Node3D.new()
    crop.name = "CropVisual_" + key
    crop.position = center + Vector3(0, 0.13, 0)
    add_child(crop)
    _build_plant_mesh(crop, id, stage, key)
    crop_nodes[key] = crop

func _build_shop_v19() -> void:
    shop_panel.anchor_left = 0.08
    shop_panel.anchor_right = 0.92
    shop_panel.anchor_top = 0.16
    shop_panel.anchor_bottom = 0.78
    var col: VBoxContainer = shop_panel.get_child(0) as VBoxContainer
    for c in col.get_children():
        c.queue_free()
    col.add_theme_constant_override("separation", 10)
    var title := Label.new()
    title.text = "🌾 FARM SUPPLY SHOP"
    title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    title.add_theme_font_size_override("font_size", 26)
    title.add_theme_color_override("font_color", Color(1.0, 0.91, 0.45))
    _panel_header(col, title)
    shop_coin_label = Label.new()
    shop_coin_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    shop_coin_label.add_theme_font_size_override("font_size", 18)
    shop_coin_label.add_theme_color_override("font_color", Color(0.95, 0.95, 0.85))
    col.add_child(shop_coin_label)
    var hint := Label.new()
    hint.text = "Choose what to plant:"
    hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    hint.add_theme_font_size_override("font_size", 18)
    hint.add_theme_color_override("font_color", Color(0.85, 0.95, 0.85))
    col.add_child(hint)
    var row := HBoxContainer.new()
    row.add_theme_constant_override("separation", 8)
    col.add_child(row)
    crop_buttons.clear()
    for i in range(crop_defs.size()):
        var b := Button.new()
        b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        b.custom_minimum_size = Vector2(0, 66)
        b.add_theme_font_size_override("font_size", 19)
        b.pressed.connect(_select_crop.bind(i))
        row.add_child(b)
        crop_buttons.append(b)
    crop_info_label = Label.new()
    crop_info_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    crop_info_label.add_theme_font_size_override("font_size", 19)
    crop_info_label.add_theme_color_override("font_color", Color(1.0, 0.95, 0.75))
    col.add_child(crop_info_label)
    var buy := Button.new()
    buy.text = "BUY 5 SEEDS  •  12 COINS"
    buy.custom_minimum_size = Vector2(0, 58)
    buy.add_theme_font_size_override("font_size", 20)
    buy.pressed.connect(_buy_seeds)
    col.add_child(buy)
    var buy2 := Button.new()
    buy2.text = "BUY 20 SEEDS  •  40 COINS"
    buy2.custom_minimum_size = Vector2(0, 58)
    buy2.add_theme_font_size_override("font_size", 20)
    buy2.pressed.connect(_buy_seeds_bulk)
    col.add_child(buy2)
    var close := Button.new()
    close.text = "CLOSE"
    close.custom_minimum_size = Vector2(0, 50)
    close.pressed.connect(func(): shop_open = false; shop_panel.visible = false)
    col.add_child(close)
    _refresh_shop()

func _refresh_shop() -> void:
    if crop_buttons.is_empty():
        return
    for i in range(crop_defs.size()):
        var d: Dictionary = crop_defs[i]
        var b: Button = crop_buttons[i]
        var locked: bool = level < int(d["lv"])
        b.disabled = locked
        if locked:
            b.text = "🔒 Lv %d" % int(d["lv"])
        else:
            b.text = "%s\n%s" % [d["icon"], d["name"]]
        if i == selected_crop and not locked:
            b.add_theme_stylebox_override("normal", _flat(Color(1.0, 0.92, 0.55), 14, Color(0.96, 0.55, 0.10), 4, 6.0))
            b.add_theme_color_override("font_color", Color(0.30, 0.16, 0.05))
        else:
            b.remove_theme_stylebox_override("normal")
            b.remove_theme_color_override("font_color")
    var cd: Dictionary = crop_defs[selected_crop]
    crop_info_label.text = "%s: grows in %d s  •  sells for %d coins  •  +%d XP" % [cd["name"], int(cd["grow"]), int(cd["pay"]) + level, int(cd["xp"])]
    shop_coin_label.text = "Your coins: %d    Seeds: %d" % [coins, seeds]
    _refresh_crop_bar()

func _select_crop(i: int) -> void:
    var d: Dictionary = crop_defs[i]
    if level < int(d["lv"]):
        _show_toast("%s unlocks at Level %d" % [d["name"], int(d["lv"])])
        return
    selected_crop = i
    _refresh_shop()
    _show_toast("Now planting %s" % d["name"])

func _buy_seeds_bulk() -> void:
    if coins < 40:
        _show_toast("You need 40 coins for 20 seeds.")
        return
    coins -= 40
    seeds += 20
    _refresh_ui()
    _refresh_shop()
    _save_game()
    _show_toast("Bought 20 seeds!")

# ------------------------------------------------------------------- animals

func _register_animal(node: Node3D, ext: Vector2, speed: float, home_override: Vector2 = Vector2(9999.0, 9999.0)) -> void:
    var hm: Vector2 = Vector2(node.position.x, node.position.z) if home_override.x > 9000.0 else home_override
    animals.append({"node": node, "home": hm, "ext": ext, "speed": speed, "state": 0, "timer": audio_rng.randf_range(0.5, 3.0), "target": Vector2(node.position.x, node.position.z), "phase": audio_rng.randf() * TAU})
    if node.has_meta("species"):
        _add_producer(node, int(node.get_meta("species")))

func _update_animals(delta: float) -> void:
    for a in animals:
        var n: Node3D = a["node"]
        var cur: Vector2 = Vector2(n.position.x, n.position.z)
        if int(a["state"]) == 0:
            a["timer"] = float(a["timer"]) - delta
            n.position.y = lerpf(n.position.y, 0.0, clampf(delta * 8.0, 0.0, 1.0))
            if float(a["timer"]) <= 0.0:
                var home: Vector2 = a["home"]
                var ext: Vector2 = a["ext"]
                var tgt: Vector2 = home + Vector2(audio_rng.randf_range(-ext.x, ext.x), audio_rng.randf_range(-ext.y, ext.y))
                if tgt.distance_to(cur) < 0.4:
                    a["timer"] = 1.0
                else:
                    a["target"] = tgt
                    a["state"] = 1
        else:
            var tg: Vector2 = a["target"]
            var to: Vector2 = tg - cur
            var dist: float = to.length()
            if dist < 0.08:
                a["state"] = 0
                a["timer"] = audio_rng.randf_range(1.5, 5.0)
            else:
                var dirv: Vector2 = to / dist
                var spd: float = float(a["speed"]) * (0.6 if raining else 1.0)
                var step: float = minf(dist, spd * delta)
                n.position.x += dirv.x * step
                n.position.z += dirv.y * step
                var yaw: float = atan2(-dirv.y, dirv.x)
                n.rotation.y = lerp_angle(n.rotation.y, yaw, clampf(delta * 5.0, 0.0, 1.0))
                var ph: float = float(a["phase"])
                n.position.y = absf(sin(sway_clock * 9.0 + ph)) * 0.035
                n.rotation.z = sin(sway_clock * 9.0 + ph) * 0.035

# -------------------------------------------------------------------- weather

func _build_weather() -> void:
    rain_particles = CPUParticles3D.new()
    rain_particles.name = "Rain"
    rain_particles.amount = 650
    rain_particles.lifetime = 0.75
    rain_particles.preprocess = 0.8
    rain_particles.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
    rain_particles.emission_box_extents = Vector3(15.0, 0.1, 15.0)
    rain_particles.direction = Vector3(0.0, -1.0, 0.0)
    rain_particles.spread = 0.0
    rain_particles.gravity = Vector3.ZERO
    rain_particles.initial_velocity_min = 17.0
    rain_particles.initial_velocity_max = 21.0
    rain_particles.local_coords = false
    var streak := BoxMesh.new()
    streak.size = Vector3(0.04, 1.1, 0.04)
    rain_particles.mesh = streak
    rain_mat = StandardMaterial3D.new()
    rain_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    rain_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    rain_mat.albedo_color = Color(0.82, 0.90, 1.0, 0.0)
    rain_particles.material_override = rain_mat
    rain_particles.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    rain_particles.emitting = false
    add_child(rain_particles)
    rain_player = _make_player(-80.0)
    # Rainbow: seven translucent bands on a vertical arc facing the camera.
    var st := SurfaceTool.new()
    st.begin(Mesh.PRIMITIVE_TRIANGLES)
    var cols: Array = [Color(0.95, 0.25, 0.25), Color(0.98, 0.58, 0.20), Color(0.99, 0.90, 0.30), Color(0.35, 0.80, 0.35), Color(0.30, 0.60, 0.95), Color(0.40, 0.35, 0.85), Color(0.65, 0.35, 0.80)]
    var radius: float = 9.5
    var bw: float = 0.42
    var segs: int = 36
    for bi in range(cols.size()):
        var r0: float = radius - float(bi) * bw
        var r1: float = r0 - bw
        var c: Color = cols[bi]
        for k in range(segs):
            var a0: float = PI * float(k) / float(segs)
            var a1: float = PI * float(k + 1) / float(segs)
            var p00: Vector3 = Vector3(cos(a0) * r0, sin(a0) * r0, 0.0)
            var p01: Vector3 = Vector3(cos(a1) * r0, sin(a1) * r0, 0.0)
            var p10: Vector3 = Vector3(cos(a0) * r1, sin(a0) * r1, 0.0)
            var p11: Vector3 = Vector3(cos(a1) * r1, sin(a1) * r1, 0.0)
            _tri(st, p00, p01, p10, c, c, c)
            _tri(st, p01, p11, p10, c, c, c)
    rainbow = MeshInstance3D.new()
    rainbow.name = "Rainbow"
    rainbow.mesh = st.commit()
    rainbow_mat = StandardMaterial3D.new()
    rainbow_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    rainbow_mat.vertex_color_use_as_albedo = true
    rainbow_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    rainbow_mat.cull_mode = BaseMaterial3D.CULL_DISABLED
    rainbow_mat.albedo_color = Color(1.0, 1.0, 1.0, 0.0)
    rainbow.material_override = rainbow_mat
    rainbow.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    rainbow.position = Vector3(0.0, -0.3, -2.0)
    rainbow.rotation.y = atan2(CAM_OFFSET.x, CAM_OFFSET.z)
    rainbow.visible = false
    add_child(rainbow)

func _update_weather(delta: float) -> void:
    weather_timer -= delta
    if weather_timer <= 0.0:
        raining = not raining
        if raining:
            weather_timer = audio_rng.randf_range(45.0, 80.0)
            _show_toast("Rain is coming!\nCrops grow 50% faster in the rain.")
        else:
            weather_timer = audio_rng.randf_range(80.0, 150.0)
            _show_toast("The rain has stopped.")
            if sin(tod * TAU) > 0.15:
                rainbow_time = 40.0
        _update_unlock_hint()
    rain = move_toward(rain, 1.0 if raining else 0.0, delta / 6.0)
    if rain_particles != null:
        rain_particles.emitting = rain > 0.03
        rain_particles.global_position = Vector3(cam_target.x, 13.0, cam_target.z)
        rain_mat.albedo_color = Color(0.85, 0.92, 1.0, 0.85 * rain)
    # Lightning and thunder in heavy rain.
    if rain > 0.8:
        thunder_timer -= delta
        if thunder_timer <= 0.0:
            thunder_timer = audio_rng.randf_range(16.0, 38.0)
            flash_amt = 1.0
            thunder_delay = audio_rng.randf_range(0.6, 1.8)
    flash_amt = maxf(0.0, flash_amt - delta * 4.0)
    if thunder_delay > 0.0:
        thunder_delay -= delta
        if thunder_delay <= 0.0:
            _play_named("thunder", -6.0)
    # Rainbow fades in after the rain and drifts out again.
    if rainbow_time > 0.0:
        rainbow_time -= delta
    var rb: float = clampf(minf(rainbow_time, 40.0 - rainbow_time) / 6.0, 0.0, 1.0)
    if rainbow_time > 0.0 and rain < 0.2:
        rainbow.visible = true
        rainbow_mat.albedo_color = Color(1.0, 1.0, 1.0, 0.55 * rb)
    else:
        rainbow.visible = false

func _gen_rain() -> AudioStreamWAV:
    var rate: int = 11025
    var n: int = rate * 6
    var fade: int = 3000
    var raw := PackedFloat32Array()
    raw.resize(n + fade)
    var lp: float = 0.0
    var lp2: float = 0.0
    for i in range(n + fade):
        var x: float = audio_rng.randf_range(-1.0, 1.0)
        lp += (x - lp) * 0.35
        lp2 += (x - lp2) * 0.06
        var drop: float = 0.0
        if audio_rng.randf() < 0.004:
            drop = audio_rng.randf_range(0.4, 1.0)
        raw[i] = (x - lp) * 0.5 + lp2 * 1.6 + drop
    var out: PackedFloat32Array = _loop_blend(raw, n, fade)
    _normalize(out, 0.8)
    return _pcm_to_wav(out, rate, true)

func _gen_thunder() -> AudioStreamWAV:
    var rate: int = 11025
    var n: int = int(4.0 * float(rate))
    var out := PackedFloat32Array()
    out.resize(n)
    var a: float = 0.0
    var b: float = 0.0
    for i in range(n):
        var t: float = float(i) / float(rate)
        var x: float = audio_rng.randf_range(-1.0, 1.0)
        a += (x - a) * 0.03
        b += (a - b) * 0.2
        var env: float = minf(1.0, t / 0.08) * exp(-t * 0.9) * (0.65 + 0.35 * sin(t * 11.0))
        out[i] = b * env * 14.0
    _normalize(out, 0.9)
    return _pcm_to_wav(out, rate, false)

func _gen_moo() -> AudioStreamWAV:
    var rate: int = 11025
    var n: int = int(1.1 * float(rate))
    var out := PackedFloat32Array()
    out.resize(n)
    var phase: float = 0.0
    for i in range(n):
        var t: float = float(i) / float(rate)
        var u: float = t / 1.1
        var f: float = lerpf(150.0, 105.0, u) * (1.0 + 0.02 * sin(TAU * 5.0 * t))
        phase += TAU * f / float(rate)
        var env: float = minf(1.0, t / 0.08) * minf(1.0, (1.1 - t) / 0.3)
        var v: float = 0.0
        for h in range(1, 7):
            v += sin(phase * float(h)) / float(h) * (1.4 if h == 2 or h == 3 else 1.0)
        out[i] = v * env
    _normalize(out, 0.8)
    return _pcm_to_wav(out, rate, false)

# ------------------------------------------------------------- fishing boats

func _make_fishing_boat(col: Color) -> Node3D:
    var b := Node3D.new()
    b.name = "FishingBoat"
    add_child(b)
    var st := SurfaceTool.new()
    st.begin(Mesh.PRIMITIVE_TRIANGLES)
    _loft_hull(st, -0.9, 1.4, 0.48, -0.22, 0.24, 0.22, -0.12, col, col.darkened(0.45), Color(0.90, 0.80, 0.60))
    var hull := MeshInstance3D.new()
    hull.mesh = st.commit()
    hull.material_override = _get_leaf_material()
    b.add_child(hull)
    _box(b, Vector3(0.62, 0.50, 0.50), Vector3(0.0, 0.58, -0.55), Color(0.97, 0.97, 0.95), "FishCabin")
    _box(b, Vector3(0.70, 0.07, 0.58), Vector3(0.0, 0.86, -0.55), Color(0.85, 0.25, 0.20), "FishCabinRoof")
    _box(b, Vector3(0.42, 0.20, 0.04), Vector3(0.0, 0.62, -0.29), Color(0.55, 0.82, 0.95), "FishCabinGlass")
    _cylinder(b, 0.025, 0.025, 1.3, Vector3(0.0, 0.9, 0.25), Color(0.4, 0.28, 0.16), "FishMast")
    _box(b, Vector3(0.9, 0.03, 0.03), Vector3(0.0, 1.45, 0.25), Color(0.4, 0.28, 0.16), "FishBoom")
    var crate := _box(b, Vector3(0.36, 0.2, 0.3), Vector3(0.0, 0.42, 0.35), Color(0.95, 0.60, 0.20), "FishCrate")
    crate.name = "FishCrate"
    _strip_shadows(b)
    return b

func _build_fishing() -> void:
    var docks: Array = [Vector2(21.4, -11.4), Vector2(22.9, -10.3)]
    var grounds: Array = [Vector2(32.0, -1.0), Vector2(31.0, 8.0)]
    var cols: Array = [Color(0.20, 0.40, 0.72), Color(0.78, 0.30, 0.22)]
    for i in range(2):
        var node: Node3D = _make_fishing_boat(cols[i])
        var d: Vector2 = docks[i]
        node.position = Vector3(d.x, -0.45, d.y)
        fishing_boats.append({"node": node, "dock": d, "ground": grounds[i], "state": 0, "timer": 6.0 + float(i) * 9.0, "phase": float(i) * 2.0})
    _update_fishing(0.0)

func _update_fishing(delta: float) -> void:
    for f in fishing_boats:
        var n: Node3D = f["node"]
        n.visible = port_unlocked
        if not port_unlocked:
            continue
        var dock: Vector2 = f["dock"]
        var ground: Vector2 = f["ground"]
        var cur: Vector2 = Vector2(n.position.x, n.position.z)
        var crate: Node3D = n.get_node_or_null("FishCrate") as Node3D
        var state: int = f["state"]
        n.position.y = -0.45 + sin(sway_clock * 1.3 + float(f["phase"])) * 0.05
        n.rotation.z = sin(sway_clock * 0.9 + float(f["phase"])) * 0.04
        if state == 0:
            if crate != null:
                crate.visible = false
            f["timer"] = float(f["timer"]) - delta
            if float(f["timer"]) <= 0.0:
                f["state"] = 1
        elif state == 1 or state == 3:
            var tgt: Vector2 = ground if state == 1 else dock
            var to: Vector2 = tgt - cur
            var dist: float = to.length()
            if dist < 0.15:
                if state == 1:
                    f["state"] = 2
                    f["timer"] = 18.0
                else:
                    f["state"] = 0
                    f["timer"] = audio_rng.randf_range(10.0, 25.0)
                    fish_crates = mini(8, fish_crates + 1)
                    if crate != null:
                        crate.visible = false
            else:
                var dirv: Vector2 = to / dist
                n.position.x += dirv.x * minf(dist, 1.7 * delta)
                n.position.z += dirv.y * minf(dist, 1.7 * delta)
                n.rotation.y = lerp_angle(n.rotation.y, atan2(dirv.x, dirv.y), clampf(delta * 3.0, 0.0, 1.0))
        elif state == 2:
            f["timer"] = float(f["timer"]) - delta
            n.rotation.y += delta * 0.15
            if float(f["timer"]) <= 0.0:
                f["state"] = 3
                if crate != null:
                    crate.visible = true

# ------------------------------------------------------------ audio additions

func _update_audio19(delta: float) -> void:
    if rain_player != null:
        if rain_player.stream == null and named_streams.has("rain"):
            rain_player.stream = named_streams["rain"]
            rain_player.play()
        if rain_player.playing:
            rain_player.volume_db = lerpf(-60.0, -13.0, clampf(rain * 1.2, 0.0, 1.0))
    # Cows moo now and then in the daytime.
    var e: float = sin(tod * TAU)
    if e > 0.0 and rain < 0.4 and named_streams.has("moo"):
        moo_timer -= delta
        if moo_timer <= 0.0:
            moo_timer = audio_rng.randf_range(22.0, 55.0)
            var zoom_f: float = clampf((ZOOM_MAX - cam_zoom) / (ZOOM_MAX - ZOOM_MIN), 0.0, 1.0)
            _play_stream(named_streams["moo"], -20.0 + zoom_f * 6.0, audio_rng.randf_range(0.85, 1.15))

func _process_v19(delta: float) -> void:
    _update_animals(delta)
    _update_weather(delta)
    _update_fishing(delta)
    _update_audio19(delta)

func _build_v19() -> void:
    _build_weather()
    _build_fishing()
    _build_shop_v19()
    _queue_audio("rain", Callable(self, "_gen_rain"))
    _queue_audio("thunder", Callable(self, "_gen_thunder"))
    _queue_audio("moo", Callable(self, "_gen_moo"))

# ===========================================================================
# v20 — smoother hulls and rounder animals
# ===========================================================================

func _hull_ring(u: float, z_stern: float, z_bow: float, half_w: float, y_keel: float, y_deck: float, sheer: float, k_count: int) -> Array:
    var t: float = clampf((u - 0.55) / 0.45, 0.0, 1.0)
    var w: float = half_w * pow(maxf(0.0, 1.0 - t * t), 0.6)
    var ts: float = clampf((0.12 - u) / 0.12, 0.0, 1.0)
    w *= 1.0 - 0.18 * ts * ts
    var yk: float = y_keel + 0.34 * t * t + 0.20 * ts * ts
    var yd: float = y_deck + sheer * t * t
    var z: float = lerpf(z_stern, z_bow, u)
    var pts: Array = []
    for k in range(k_count + 1):
        var a: float = PI * float(k) / float(k_count)
        var f: float = pow(sin(a), 0.5)
        pts.append(Vector3(w * cos(a), yd - (yd - yk) * f, z))
    return pts

func _loft_hull(st: SurfaceTool, z_stern: float, z_bow: float, half_w: float, y_keel: float, y_deck: float, sheer: float, waterline: float, hull_col: Color, bottom_col: Color, deck_col: Color) -> void:
    var n_sec: int = 22
    var k_count: int = 14
    var prev: Array = _hull_ring(0.0, z_stern, z_bow, half_w, y_keel, y_deck, sheer, k_count)
    var cen: Vector3 = Vector3(0.0, (y_deck + y_keel) * 0.5, z_stern)
    for k in range(k_count):
        _tri(st, cen, prev[k + 1], prev[k], hull_col, hull_col, hull_col)
    for i in range(1, n_sec + 1):
        var ring: Array = _hull_ring(float(i) / float(n_sec), z_stern, z_bow, half_w, y_keel, y_deck, sheer, k_count)
        for k in range(k_count):
            var a: Vector3 = prev[k]
            var b: Vector3 = prev[k + 1]
            var c: Vector3 = ring[k + 1]
            var d: Vector3 = ring[k]
            var my: float = (a.y + b.y + c.y + d.y) * 0.25
            var col: Color = hull_col if my > waterline else bottom_col
            _tri(st, a, b, c, col, col, col)
            _tri(st, a, c, d, col, col, col)
        # Deck strip between the two gunwales.
        var pl: Vector3 = prev[0]
        var pr: Vector3 = prev[k_count]
        var rl: Vector3 = ring[0]
        var rr: Vector3 = ring[k_count]
        _tri(st, pl, pr, rr, deck_col, deck_col, deck_col)
        _tri(st, pl, rr, rl, deck_col, deck_col, deck_col)
        prev = ring

func _ellipsoid(parent: Node3D, radii: Vector3, pos: Vector3, color: Color, mesh_name: String = "Ellipsoid") -> MeshInstance3D:
    var node := MeshInstance3D.new()
    node.name = mesh_name
    var mesh := SphereMesh.new()
    mesh.radius = 1.0
    mesh.height = 2.0
    mesh.radial_segments = 14
    mesh.rings = 8
    node.mesh = mesh
    node.scale = radii
    node.position = pos
    node.material_override = _mat(color)
    parent.add_child(node)
    return node

func _limb(parent: Node3D, r_top: float, r_bot: float, h: float, pos: Vector3, color: Color, mesh_name: String = "Limb") -> MeshInstance3D:
    return _disc(parent, r_bot, h, pos, color, mesh_name, 0.9, 10, r_top, true)

func _make_cow(pos: Vector3) -> Node3D:
    var cow := Node3D.new()
    cow.name = "PastureCow"
    cow.set_meta("species", 0)
    cow.position = pos
    cow.rotation_degrees.y = -24
    add_child(cow)
    var hide: Color = Color(0.96, 0.93, 0.86)
    var dark: Color = Color(0.22, 0.19, 0.17)
    var pink: Color = Color(0.93, 0.66, 0.64)
    # Barrel body made of overlapping ellipsoids so it reads as one rounded shape.
    _ellipsoid(cow, Vector3(0.60, 0.34, 0.32), Vector3(0.0, 0.70, 0.0), hide, "CowBody")
    _ellipsoid(cow, Vector3(0.34, 0.34, 0.33), Vector3(0.34, 0.72, 0.0), hide, "CowChest")
    _ellipsoid(cow, Vector3(0.34, 0.33, 0.32), Vector3(-0.34, 0.72, 0.0), hide, "CowRump")
    # Neck, head, muzzle, ears, horns, eyes.
    var neck: MeshInstance3D = _ellipsoid(cow, Vector3(0.26, 0.20, 0.20), Vector3(0.62, 0.84, 0.0), hide, "CowNeck")
    neck.rotation_degrees.z = 25.0
    _ellipsoid(cow, Vector3(0.24, 0.20, 0.19), Vector3(0.82, 0.88, 0.0), hide, "CowHead")
    _ellipsoid(cow, Vector3(0.14, 0.12, 0.15), Vector3(1.00, 0.80, 0.0), pink, "CowMuzzle")
    for sz in [-1.0, 1.0]:
        _ellipsoid(cow, Vector3(0.025, 0.025, 0.025), Vector3(1.10, 0.82, float(sz) * 0.06), dark, "CowNostril")
        _ellipsoid(cow, Vector3(0.035, 0.04, 0.03), Vector3(0.92, 0.97, float(sz) * 0.14), Color(0.05, 0.05, 0.05), "CowEye")
        var ear: MeshInstance3D = _ellipsoid(cow, Vector3(0.10, 0.04, 0.07), Vector3(0.74, 0.98, float(sz) * 0.24), hide.darkened(0.04), "CowEar")
        ear.rotation_degrees.x = float(sz) * 25.0
        var horn: MeshInstance3D = _disc(cow, 0.04, 0.16, Vector3(0.76, 1.12, float(sz) * 0.13), Color(0.94, 0.88, 0.70), "CowHorn", 0.8, 8, 0.0)
        horn.rotation_degrees.x = float(sz) * 20.0
    # Coat patches hugging the sides.
    for spot in [[Vector3(-0.15, 0.80, 0.27), Vector3(0.20, 0.14, 0.07)], [Vector3(0.18, 0.66, 0.30), Vector3(0.15, 0.17, 0.07)], [Vector3(-0.30, 0.64, -0.28), Vector3(0.17, 0.16, 0.07)], [Vector3(0.12, 0.84, -0.27), Vector3(0.20, 0.12, 0.07)], [Vector3(0.82, 0.92, 0.0), Vector3(0.10, 0.06, 0.20)]]:
        _ellipsoid(cow, spot[1], spot[0], dark, "CowSpot")
    # Legs with hooves, udder and a tufted tail.
    for lx in [-0.34, 0.36]:
        for lz in [-0.17, 0.17]:
            _limb(cow, 0.085, 0.06, 0.42, Vector3(float(lx), 0.24, float(lz)), hide.darkened(0.03), "CowLeg")
            _limb(cow, 0.065, 0.07, 0.07, Vector3(float(lx), 0.035, float(lz)), dark, "CowHoof")
    _ellipsoid(cow, Vector3(0.12, 0.09, 0.12), Vector3(-0.22, 0.45, 0.0), pink, "CowUdder")
    var tail: MeshInstance3D = _limb(cow, 0.02, 0.02, 0.5, Vector3(-0.68, 0.70, 0.0), hide.darkened(0.05), "CowTail")
    tail.rotation_degrees.z = 20.0
    _ellipsoid(cow, Vector3(0.05, 0.09, 0.05), Vector3(-0.74, 0.44, 0.0), dark, "CowTailTuft")
    return cow

func _make_pig(pos: Vector3, yaw: float) -> Node3D:
    var pig := Node3D.new()
    pig.name = "FarmPig"
    pig.set_meta("species", 2)
    pig.position = pos
    pig.rotation_degrees.y = yaw
    add_child(pig)
    var pink: Color = Color(0.98, 0.72, 0.75)
    var deep: Color = Color(0.94, 0.55, 0.60)
    _ellipsoid(pig, Vector3(0.46, 0.33, 0.33), Vector3(0.0, 0.40, 0.0), pink, "PigBody")
    _ellipsoid(pig, Vector3(0.24, 0.24, 0.23), Vector3(0.42, 0.44, 0.0), pink.lightened(0.03), "PigHead")
    var snout: MeshInstance3D = _disc(pig, 0.11, 0.12, Vector3(0.64, 0.40, 0.0), deep, "PigSnout", 0.8, 12, 0.10)
    snout.rotation_degrees.z = 90.0
    for sz in [-1.0, 1.0]:
        _ellipsoid(pig, Vector3(0.02, 0.025, 0.02), Vector3(0.70, 0.40, float(sz) * 0.04), Color(0.55, 0.25, 0.30), "PigNostril")
        _ellipsoid(pig, Vector3(0.03, 0.035, 0.03), Vector3(0.58, 0.52, float(sz) * 0.13), Color(0.05, 0.05, 0.05), "PigEye")
        var ear: MeshInstance3D = _disc(pig, 0.08, 0.10, Vector3(0.40, 0.66, float(sz) * 0.15), deep, "PigEar", 0.9, 3, 0.0)
        ear.rotation_degrees.x = float(sz) * 35.0
    for lx in [-0.26, 0.28]:
        for lz in [-0.13, 0.13]:
            _limb(pig, 0.075, 0.06, 0.24, Vector3(float(lx), 0.12, float(lz)), pink.darkened(0.06), "PigLeg")
            _limb(pig, 0.06, 0.065, 0.04, Vector3(float(lx), 0.02, float(lz)), Color(0.45, 0.30, 0.30), "PigHoof")
    var curl: MeshInstance3D = _disc(pig, 0.05, 0.04, Vector3(-0.50, 0.52, 0.0), deep, "PigTail", 0.9, 10)
    curl.rotation_degrees.z = 90.0
    return pig

# ===========================================================================
# v23 (part A) — tap highlight, daily quests, barn/market/bakery, new buildings
# ===========================================================================

var season_idx: int = 0   # 0 spring, 1 summer, 2 autumn, 3 winter (set by the season system)
var stock: Array = [0, 0, 0, 0, 0]
var goods: Array = [0, 0, 0, 0]
var bake_queue: Array = []
var bake_remaining: float = 0.0
var recipes: Array = [
    {"name": "Bread", "icon": "🍞", "src": 1, "n": 2, "time": 15.0},
    {"name": "Tomato Soup", "icon": "🍲", "src": 0, "n": 3, "time": 20.0},
    {"name": "Carrot Cake", "icon": "🍰", "src": 2, "n": 2, "time": 25.0},
    {"name": "Popcorn", "icon": "🍿", "src": 3, "n": 2, "time": 30.0}
]
const BARN_CAPACITY := 60
const BAKERY_LV := 2
const BARN_POS := Vector3(3.7, 0.0, -4.1)
const OVEN_POS := Vector3(-10.8, 0.0, -1.4)
const MARKET_POS := Vector3(8.2, 0.0, 11.0)
const SILO_POS := Vector3(9.6, 0.0, -7.4)

var ui_root: Control
var extra_panels: Array = []
var market_panel: PanelContainer
var bakery_panel: PanelContainer
var quest_panel: PanelContainer
var market_rows: Array = []
var market_coin_label: Label
var market_cap_label: Label
var bakery_rows: Array = []
var bakery_status: Label
var bakery_coin_label: Label
var quest_rows: Array = []
var streak_label: Label
var chain_label: Label
var bonus_button: Button
var daily_day: int = -1
var daily_quests: Array = []
var login_streak: int = 0
var last_login_day: int = -1
var daily_bonus_taken: bool = false
var highlight_node: MeshInstance3D
var highlight_mat: StandardMaterial3D
var highlight_time: float = 0.0
var panel_refresh_timer: float = 0.0

# --------------------------------------------------------------- season hooks

func _season_price_mult() -> float:
    return 1.15 if season_idx == 2 else 1.0

func _season_growth_mult() -> float:
    var m: float = 1.0
    if season_idx == 0:
        m = 1.10
    elif season_idx == 3:
        m = 0.75
    return m * power_growth_mult()

# ------------------------------------------------------------ tap highlight

func _build_highlight() -> void:
    highlight_node = MeshInstance3D.new()
    highlight_node.name = "TapHighlight"
    var m := BoxMesh.new()
    m.size = Vector3(CELL * 0.98, 0.03, CELL * 0.98)
    highlight_node.mesh = m
    highlight_mat = StandardMaterial3D.new()
    highlight_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    highlight_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    highlight_mat.albedo_color = Color(1.0, 1.0, 1.0, 0.0)
    highlight_node.material_override = highlight_mat
    highlight_node.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    highlight_node.visible = false
    add_child(highlight_node)

func _flash_cell(key: String) -> void:
    if highlight_node == null or not plot_centers.has(key):
        return
    var c: Vector3 = plot_centers[key]
    highlight_node.position = Vector3(c.x, 0.135, c.z)
    var col: Color = Color(0.55, 1.0, 0.45)
    if active_action == "harvest":
        col = Color(1.0, 0.78, 0.25)
    highlight_mat.albedo_color = Color(col.r, col.g, col.b, 0.6)
    highlight_node.visible = true
    highlight_time = 0.7

func _update_highlight(delta: float) -> void:
    if highlight_time > 0.0:
        highlight_time -= delta
        var a: float = clampf(highlight_time / 0.7, 0.0, 1.0)
        var col: Color = highlight_mat.albedo_color
        highlight_mat.albedo_color = Color(col.r, col.g, col.b, 0.6 * a)
        var s: float = 1.0 + (1.0 - a) * 0.08
        highlight_node.scale = Vector3(s, 1.0, s)
        if highlight_time <= 0.0:
            highlight_node.visible = false

# ------------------------------------------------------------- panel helpers

func _new_panel(title_text: String, a_top: float, a_bottom: float) -> Array:
    var panel := PanelContainer.new()
    panel.anchor_left = 0.06
    panel.anchor_right = 0.94
    panel.anchor_top = a_top
    panel.anchor_bottom = a_bottom
    panel.add_theme_stylebox_override("panel", _panel_style(Color(0.12, 0.25, 0.20, 0.98), 24))
    ui_root.add_child(panel)
    var col := VBoxContainer.new()
    col.add_theme_constant_override("separation", 8)
    panel.add_child(col)
    var title := Label.new()
    title.text = title_text
    title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    title.add_theme_font_size_override("font_size", 26)
    title.add_theme_color_override("font_color", Color(1.0, 0.91, 0.45))
    _panel_header(col, title)
    panel.visible = false
    return [panel, col]

func _panel_label(parent: Control, size: int, color: Color = Color(0.95, 0.95, 0.85)) -> Label:
    var l := Label.new()
    l.add_theme_font_size_override("font_size", size)
    l.add_theme_color_override("font_color", color)
    l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    parent.add_child(l)
    return l

func _panel_button(parent: Control, text: String, h: float, size: int = 19) -> Button:
    var b := Button.new()
    b.text = text
    b.custom_minimum_size = Vector2(0, h)
    b.add_theme_font_size_override("font_size", size)
    parent.add_child(b)
    return b

var panel_owner: String = ""

func _toggle_panel(name: String, opener: Callable) -> void:
    if _any_panel_open() and panel_owner == name:
        _close_panels()
        return
    opener.call()
    panel_owner = name if _any_panel_open() else ""

func _close_panels() -> void:
    panel_owner = ""
    shop_open = false
    if shop_panel != null:
        shop_panel.visible = false
    for p in [market_panel, bakery_panel, quest_panel]:
        if p != null:
            (p as Control).visible = false
    for p2 in extra_panels:
        if p2 != null:
            (p2 as Control).visible = false

func _any_panel_open() -> bool:
    for p in [shop_panel, market_panel, bakery_panel, quest_panel]:
        if p != null and (p as Control).visible:
            return true
    for p2 in extra_panels:
        if p2 != null and (p2 as Control).visible:
            return true
    return false

func _crop_price(id: int) -> int:
    return int(round(float(int(crop_defs[id]["pay"]) + level) * _season_price_mult() * (1.0 + train_bonus())))

func _good_price(rid: int) -> int:
    var r: Dictionary = recipes[rid]
    var src: int = int(r["src"])
    return int(round(float(int(r["n"]) * (int(crop_defs[src]["pay"]) + level)) * 1.8 * _season_price_mult() * (1.0 + train_bonus())))

func _build_market_panel() -> void:
    var made: Array = _new_panel("🏪 BARN & MARKET", 0.05, 0.95)
    market_panel = made[0]
    var col: VBoxContainer = made[1]
    market_coin_label = _panel_label(col, 18)
    market_cap_label = _panel_label(col, 16, Color(0.80, 0.90, 0.80))
    var sc := ScrollContainer.new()
    sc.size_flags_vertical = Control.SIZE_EXPAND_FILL
    sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
    col.add_child(sc)
    var box := VBoxContainer.new()
    box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    box.add_theme_constant_override("separation", 6)
    sc.add_child(box)
    market_rows.clear()
    for kind in ["crop", "good", "prod"]:
        for i in range(crop_defs.size() if kind == "crop" else 4):
            var row := HBoxContainer.new()
            row.add_theme_constant_override("separation", 6)
            box.add_child(row)
            var lab := Label.new()
            lab.size_flags_horizontal = Control.SIZE_EXPAND_FILL
            lab.add_theme_font_size_override("font_size", 17)
            lab.add_theme_color_override("font_color", Color(0.95, 0.95, 0.85))
            lab.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
            row.add_child(lab)
            var b1 := Button.new()
            b1.text = "SELL 1"
            b1.custom_minimum_size = Vector2(92, 44)
            b1.add_theme_font_size_override("font_size", 16)
            b1.pressed.connect(_sell_item.bind(kind, i, 1))
            row.add_child(b1)
            var b2 := Button.new()
            b2.text = "ALL"
            b2.custom_minimum_size = Vector2(76, 44)
            b2.add_theme_font_size_override("font_size", 16)
            b2.pressed.connect(_sell_item.bind(kind, i, 999))
            row.add_child(b2)
            market_rows.append({"kind": kind, "id": i, "label": lab, "b1": b1, "b2": b2, "row": row})
    var all_b: Button = _panel_button(col, "SELL EVERYTHING", 50, 20)
    all_b.pressed.connect(_sell_everything)
    var close: Button = _panel_button(col, "CLOSE", 44, 18)
    close.pressed.connect(_close_panels)

func _refresh_market() -> void:
    if market_panel == null:
        return
    market_coin_label.text = "Your coins: %d" % coins
    market_cap_label.text = "Barn: %d / %d items" % [_stock_total(), _barn_cap()]
    if season_idx == 2:
        market_cap_label.text += "   •   Autumn festival: prices +15%"
    if train_bonus() > 0.0:
        market_cap_label.text += "   •   Rail bonus +%d%%" % int(round(train_bonus() * 100.0))
    for r in market_rows:
        var kind: String = r["kind"]
        var i: int = r["id"]
        var lab: Label = r["label"]
        var have: int = _item_have(kind, i)
        var row: Control = r["row"]
        var show: bool = true
        if kind == "crop":
            show = level >= int(crop_defs[i]["lv"]) or have > 0
        elif kind == "good":
            show = level >= BAKERY_LV or have > 0
        else:
            show = have > 0
        lab.text = "%s   x%d   •   %d coins each" % [_item_label(kind, i), have, _item_price(kind, i)]
        row.visible = show
        (r["b1"] as Button).disabled = have <= 0
        (r["b2"] as Button).disabled = have <= 0

func _sell_item(kind: String, id: int, count: int) -> void:
    var have: int = _item_have(kind, id)
    var n: int = mini(have, count)
    if n <= 0:
        return
    var total: int = _item_price(kind, id) * n
    _item_take(kind, id, n)
    coins += total
    _quest_event("sell", n)
    _play_named("ding")
    _refresh_ui()
    _refresh_market()
    _show_toast("Sold %d for %d coins" % [n, total])
    _save_game()

func _sell_everything() -> void:
    var total: int = 0
    var count: int = 0
    for kind in ["crop", "good", "prod"]:
        for i in range(crop_defs.size() if kind == "crop" else 4):
            var c: int = _item_have(kind, i)
            if c > 0:
                total += c * _item_price(kind, i)
                count += c
                _item_take(kind, i, c)
    if count == 0:
        _show_toast("Nothing to sell yet.")
        return
    coins += total
    _quest_event("sell", count)
    _play_named("ding")
    _refresh_ui()
    _refresh_market()
    _show_toast("Sold %d items for %d coins!" % [count, total])
    _save_game()

func _open_market() -> void:
    _close_panels()
    market_panel.visible = true
    _refresh_market()

# -------------------------------------------------------------------- bakery

func _build_bakery_panel() -> void:
    var made: Array = _new_panel("🥖 VILLAGE BAKERY", 0.10, 0.90)
    bakery_panel = made[0]
    var col: VBoxContainer = made[1]
    bakery_coin_label = _panel_label(col, 17)
    bakery_status = _panel_label(col, 18, Color(1.0, 0.95, 0.70))
    bakery_rows.clear()
    for i in range(recipes.size()):
        var b: Button = _panel_button(col, "", 78, 17)
        b.pressed.connect(_start_cooking.bind(i))
        bakery_rows.append(b)
    var hint: Label = _panel_label(col, 15, Color(0.75, 0.88, 0.78))
    hint.text = "Baked goods go to the barn and sell for about 1.8x the crops used."
    var close: Button = _panel_button(col, "CLOSE", 46, 18)
    close.pressed.connect(_close_panels)

func _refresh_bakery() -> void:
    if bakery_panel == null:
        return
    bakery_coin_label.text = "Your coins: %d" % coins
    for i in range(recipes.size()):
        var r: Dictionary = recipes[i]
        var src: int = int(r["src"])
        var b: Button = bakery_rows[i]
        b.text = "%s %s\n%d %s  (you have %d)  •  %d s  •  sells %d" % [r["icon"], r["name"], int(r["n"]), crop_defs[src]["name"], int(stock[src]), int(r["time"]), _good_price(i)]
        b.disabled = int(stock[src]) < int(r["n"]) or bake_queue.size() >= 3
    if bake_queue.is_empty():
        bakery_status.text = "The oven is warm and waiting."
    else:
        var cur: Dictionary = recipes[int(bake_queue[0])]
        bakery_status.text = "Baking %s... %d s   (queue %d / 3)" % [cur["name"], int(ceil(bake_remaining)), bake_queue.size()]

func _start_cooking(rid: int) -> void:
    var r: Dictionary = recipes[rid]
    var src: int = int(r["src"])
    if int(stock[src]) < int(r["n"]):
        _show_toast("Not enough %s." % str(crop_defs[src]["name"]))
        return
    if bake_queue.size() >= 3:
        _show_toast("The oven queue is full.")
        return
    stock[src] = int(stock[src]) - int(r["n"])
    if bake_queue.is_empty():
        bake_remaining = float(r["time"])
    bake_queue.append(rid)
    _refresh_bakery()
    _show_toast("Cooking %s!" % str(r["name"]))
    _save_game()

func _open_bakery() -> void:
    if level < BAKERY_LV:
        _show_toast("The bakery opens at Level %d" % BAKERY_LV)
        return
    _close_panels()
    bakery_panel.visible = true
    _refresh_bakery()

func _update_bakery(delta: float) -> void:
    if bake_queue.is_empty():
        return
    bake_remaining -= delta
    while bake_remaining <= 0.0 and not bake_queue.is_empty():
        var rid: int = int(bake_queue.pop_front())
        goods[rid] = int(goods[rid]) + 1
        _quest_event("bake", 1)
        _play_named("ding", -10.0)
        _show_toast("Fresh %s is ready in the barn!" % str(recipes[rid]["name"]))
        if bake_queue.is_empty():
            bake_remaining = 0.0
        else:
            bake_remaining += float(recipes[int(bake_queue[0])]["time"])

# -------------------------------------------------------------- daily quests

func _today_id() -> int:
    var bias_min: float = float(Time.get_time_zone_from_system().get("bias", 0))
    return int(floor((Time.get_unix_time_from_system() + bias_min * 60.0) / 86400.0))

func _quest_text(q: Dictionary) -> String:
    var t: String = q["type"]
    var g: int = int(q["goal"])
    if t == "harvest":
        return "Harvest %d crops" % g
    if t == "plant":
        return "Plant %d seeds" % g
    if t == "sell":
        return "Sell %d items at the market" % g
    if t == "bake":
        return "Bake %d goods at the bakery" % g
    if t == "collect":
        return "Collect from the windmill or port %d times" % g
    if t == "crop":
        return "Harvest %d %s" % [g, str(crop_defs[int(q.get("crop", 0))]["name"])]
    return "Quest"

func _ensure_daily(announce: bool) -> void:
    var today: int = _today_id()
    if daily_day == today and daily_quests.size() > 0:
        return
    if last_login_day != today:
        if last_login_day == today - 1:
            login_streak += 1
        else:
            login_streak = 1
        last_login_day = today
        var gift: int = 20 + 10 * mini(login_streak, 7)
        coins += gift
        var msg: String = "Day %d login bonus: +%d coins" % [login_streak, gift]
        if login_streak % 3 == 0:
            seeds += 5
            msg += " and +5 seeds"
        if announce:
            _show_toast(msg)
        _refresh_ui()
    var rng := RandomNumberGenerator.new()
    rng.seed = today * 7919 + 17
    var types: Array = ["harvest", "plant", "sell"]
    if level >= BAKERY_LV:
        types.append("bake")
    if level >= WINDMILL_LV:
        types.append("collect")
    types.append("crop")
    # Shuffle and keep three kinds.
    for i in range(types.size() - 1, 0, -1):
        var j: int = rng.randi_range(0, i)
        var tmp: Variant = types[i]
        types[i] = types[j]
        types[j] = tmp
    daily_quests.clear()
    var extra: int = level / 2
    for k in range(3):
        var t: String = types[k]
        var q: Dictionary = {"type": t, "progress": 0, "claimed": false}
        if t == "harvest":
            q["goal"] = 6 + extra + rng.randi_range(0, 4)
            q["coins"] = 25 + int(q["goal"]) * 5
        elif t == "plant":
            q["goal"] = 8 + extra + rng.randi_range(0, 6)
            q["coins"] = 20 + int(q["goal"]) * 3
        elif t == "sell":
            q["goal"] = 6 + extra + rng.randi_range(0, 4)
            q["coins"] = 25 + int(q["goal"]) * 4
        elif t == "bake":
            q["goal"] = 2 + rng.randi_range(0, 2)
            q["coins"] = 60 + int(q["goal"]) * 20
        elif t == "collect":
            q["goal"] = 2 + rng.randi_range(0, 1)
            q["coins"] = 50 + int(q["goal"]) * 15
        else:
            var unlocked: Array = []
            for ci in range(crop_defs.size()):
                if level >= int(crop_defs[ci]["lv"]):
                    unlocked.append(ci)
            q["crop"] = unlocked[rng.randi_range(0, unlocked.size() - 1)]
            q["goal"] = 4 + rng.randi_range(0, 4)
            q["coins"] = 30 + int(q["goal"]) * 6
        q["xp"] = 12 + int(q["goal"])
        daily_quests.append(q)
    daily_day = today
    daily_bonus_taken = false
    _refresh_quest_panel()

func _quest_event(kind: String, amount: int = 1, crop_id: int = -1) -> void:
    var changed: bool = false
    for q in daily_quests:
        if bool(q["claimed"]) or int(q["progress"]) >= int(q["goal"]):
            continue
        var t: String = q["type"]
        var hit: bool = (t == kind) or (t == "crop" and kind == "harvest" and int(q.get("crop", -1)) == crop_id)
        if hit:
            q["progress"] = mini(int(q["goal"]), int(q["progress"]) + amount)
            changed = true
            if int(q["progress"]) >= int(q["goal"]):
                _show_toast("Daily quest done: %s\nOpen the 📋 button to claim." % _quest_text(q))
    if changed:
        _refresh_quest_panel()

func _build_quest_panel() -> void:
    var made: Array = _new_panel("📋 DAILY QUESTS", 0.08, 0.92)
    quest_panel = made[0]
    var col: VBoxContainer = made[1]
    streak_label = _panel_label(col, 18, Color(1.0, 0.95, 0.70))
    quest_rows.clear()
    for i in range(3):
        var row := VBoxContainer.new()
        row.add_theme_constant_override("separation", 4)
        col.add_child(row)
        var lab: Label = _panel_label(row, 19)
        var btn: Button = _panel_button(row, "CLAIM", 46, 18)
        btn.pressed.connect(_claim_quest.bind(i))
        quest_rows.append({"label": lab, "button": btn})
    bonus_button = _panel_button(col, "", 50, 18)
    bonus_button.pressed.connect(_claim_daily_bonus)
    chain_label = _panel_label(col, 16, Color(0.80, 0.92, 0.80))
    var close: Button = _panel_button(col, "CLOSE", 44, 18)
    close.pressed.connect(_close_panels)

func _refresh_quest_panel() -> void:
    if quest_panel == null:
        return
    streak_label.text = "Login streak: %d day%s  •  next bonus %d coins" % [login_streak, "" if login_streak == 1 else "s", 20 + 10 * mini(login_streak + 1, 7)]
    var all_claimed: bool = daily_quests.size() > 0
    for i in range(3):
        var r: Dictionary = quest_rows[i]
        var lab: Label = r["label"]
        var btn: Button = r["button"]
        if i >= daily_quests.size():
            lab.text = "..."
            btn.disabled = true
            continue
        var q: Dictionary = daily_quests[i]
        lab.text = "%s   (%d / %d)\nReward: %d coins + %d XP" % [_quest_text(q), int(q["progress"]), int(q["goal"]), int(q["coins"]), int(q["xp"])]
        var done: bool = int(q["progress"]) >= int(q["goal"])
        if bool(q["claimed"]):
            btn.text = "CLAIMED"
            btn.disabled = true
        else:
            all_claimed = false
            btn.text = "CLAIM REWARD" if done else "IN PROGRESS"
            btn.disabled = not done
    if all_claimed and not daily_bonus_taken:
        bonus_button.text = "ALL DONE! CLAIM BONUS: 60 coins + 5 seeds"
        bonus_button.disabled = false
    elif daily_bonus_taken:
        bonus_button.text = "Daily bonus collected"
        bonus_button.disabled = true
    else:
        bonus_button.text = "Finish all 3 quests for a bonus"
        bonus_button.disabled = true
    chain_label.text = "Farm quest: harvest %d crops  (%d / %d)" % [quest_goal, quest_progress, quest_goal]

func _claim_quest(i: int) -> void:
    if i >= daily_quests.size():
        return
    var q: Dictionary = daily_quests[i]
    if bool(q["claimed"]) or int(q["progress"]) < int(q["goal"]):
        return
    q["claimed"] = true
    coins += int(q["coins"])
    _add_xp(int(q["xp"]))
    _play_named("ding")
    _refresh_ui()
    _refresh_quest_panel()
    _show_toast("Quest reward: +%d coins, +%d XP" % [int(q["coins"]), int(q["xp"])])
    _save_game()

func _claim_daily_bonus() -> void:
    if daily_bonus_taken:
        return
    for q in daily_quests:
        if not bool(q["claimed"]):
            return
    daily_bonus_taken = true
    coins += 60
    seeds += 5
    _play_named("jingle", -6.0)
    _refresh_ui()
    _refresh_quest_panel()
    _show_toast("Daily bonus: +60 coins, +5 seeds")
    _save_game()

func _open_quests() -> void:
    _ensure_daily(true)
    _close_panels()
    quest_panel.visible = true
    _refresh_quest_panel()

# ------------------------------------------------------------- building taps

func _tap_buildings_v23(hit: Vector3) -> bool:
    var p: Vector2 = Vector2(hit.x, hit.z)
    if _dist_to_segment(p, Vector2(OVEN_POS.x, OVEN_POS.z), Vector2(OVEN_POS.x - 1.2, OVEN_POS.z - 1.7)) < 2.1:
        _open_bakery()
        return true
    if _dist_to_segment(p, Vector2(BARN_POS.x, BARN_POS.z), Vector2(BARN_POS.x - 1.5, BARN_POS.z - 2.2)) < 1.4:
        _open_market()
        return true
    if _dist_to_segment(p, Vector2(MARKET_POS.x, MARKET_POS.z), Vector2(MARKET_POS.x - 1.8, MARKET_POS.z - 2.7)) < 2.0:
        _open_market()
        return true
    if _dist_to_segment(p, Vector2(SILO_POS.x, SILO_POS.z), Vector2(SILO_POS.x - 2.2, SILO_POS.z - 3.3)) < 1.5:
        _open_market()
        return true
    return _tap_buildings_v24(hit)

# ----------------------------------------------------------------- geometry

func _extrude_xy(st: SurfaceTool, pts: Array, z0: float, z1: float, edge_cols: Array, cap_col: Color) -> void:
    var n: int = pts.size()
    for i in range(n):
        var p: Vector2 = pts[i]
        var q: Vector2 = pts[(i + 1) % n]
        var c: Color = edge_cols[i % edge_cols.size()]
        var a: Vector3 = Vector3(p.x, p.y, z0)
        var b: Vector3 = Vector3(q.x, q.y, z0)
        var cc: Vector3 = Vector3(q.x, q.y, z1)
        var d: Vector3 = Vector3(p.x, p.y, z1)
        _tri(st, a, b, cc, c, c, c)
        _tri(st, a, cc, d, c, c, c)
    # Caps (fan triangulation works for the convex or near-convex outlines used here).
    var p0: Vector2 = pts[0]
    for i in range(1, n - 1):
        var pi: Vector2 = pts[i]
        var pj: Vector2 = pts[i + 1]
        _tri(st, Vector3(p0.x, p0.y, z1), Vector3(pi.x, pi.y, z1), Vector3(pj.x, pj.y, z1), cap_col, cap_col, cap_col)
        _tri(st, Vector3(p0.x, p0.y, z0), Vector3(pj.x, pj.y, z0), Vector3(pi.x, pi.y, z0), cap_col, cap_col, cap_col)

func _mesh_node(parent: Node3D, st: SurfaceTool, mesh_name: String, y: float = 0.0, shadows: bool = true) -> MeshInstance3D:
    var node := MeshInstance3D.new()
    node.name = mesh_name
    node.mesh = st.commit()
    node.material_override = _get_leaf_material()
    node.position = Vector3(0.0, y, 0.0)
    if not shadows:
        node.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    parent.add_child(node)
    return node

func _make_smoke(parent: Node3D, pos: Vector3) -> void:
    var sm := CPUParticles3D.new()
    sm.name = "Smoke"
    sm.position = pos
    sm.amount = 9
    sm.lifetime = 3.2
    sm.preprocess = 3.0
    sm.emission_shape = CPUParticles3D.EMISSION_SHAPE_POINT
    sm.direction = Vector3(0.25, 1.0, 0.1)
    sm.spread = 12.0
    sm.gravity = Vector3(0.12, 0.0, 0.0)
    sm.initial_velocity_min = 0.35
    sm.initial_velocity_max = 0.55
    sm.scale_amount_min = 0.7
    sm.scale_amount_max = 1.5
    var ball := SphereMesh.new()
    ball.radius = 0.12
    ball.height = 0.24
    ball.radial_segments = 8
    ball.rings = 4
    sm.mesh = ball
    var m := StandardMaterial3D.new()
    m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    m.albedo_color = Color(0.92, 0.92, 0.95, 0.55)
    sm.material_override = m
    var grad := Gradient.new()
    grad.set_color(0, Color(1.0, 1.0, 1.0, 0.7))
    grad.set_color(1, Color(1.0, 1.0, 1.0, 0.0))
    sm.color_ramp = grad
    sm.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    parent.add_child(sm)

func _make_farmhouse() -> void:
    var house := Node3D.new()
    house.name = "Farmhouse"
    house.position = Vector3(-4.2, 0.0, -4.1)
    add_child(house)
    var wall: Color = Color(0.99, 0.88, 0.68)
    var trim: Color = Color(1.0, 0.97, 0.90)
    _box(house, Vector3(2.55, 0.18, 2.05), Vector3(0.0, 0.09, 0.0), Color(0.58, 0.58, 0.60), "HousePlinth")
    _box(house, Vector3(2.3, 1.32, 1.8), Vector3(0.0, 0.84, 0.0), wall, "HouseWalls")
    for cx in [-1.15, 1.15]:
        for cz in [-0.9, 0.9]:
            _box(house, Vector3(0.12, 1.34, 0.12), Vector3(float(cx), 0.85, float(cz)), trim, "HouseCorner")
    # Roof: thick gabled slab with overhang, wall-coloured gable ends, ridge cap.
    var st := SurfaceTool.new()
    st.begin(Mesh.PRIMITIVE_TRIANGLES)
    var red: Color = Color(0.88, 0.30, 0.16)
    var red2: Color = Color(0.96, 0.40, 0.22)
    var hw: float = 1.15
    var o: float = 0.26
    var rise: float = 0.95
    var roof_pts: Array = [Vector2(-hw - o, 0.0), Vector2(0.0, rise), Vector2(hw + o, 0.0), Vector2(hw + o - 0.05, -0.13), Vector2(0.0, rise - 0.16), Vector2(-hw - o + 0.05, -0.13)]
    _extrude_xy(st, roof_pts, -0.9 - o, 0.9 + o, [red, red2, red.darkened(0.3), red.darkened(0.25), red.darkened(0.25), red.darkened(0.3)], red.darkened(0.2))
    _extrude_xy(st, [Vector2(-hw, 0.0), Vector2(hw, 0.0), Vector2(0.0, rise - 0.12)], -0.88, 0.88, [wall, wall, wall], wall)
    _mesh_node(house, st, "HouseRoof", 1.50)
    _box(house, Vector3(0.14, 0.12, 2.3), Vector3(0.0, 1.50 + rise - 0.02, 0.0), red.darkened(0.15), "RoofRidge")
    # Chimney with a cap and smoke.
    _box(house, Vector3(0.30, 0.85, 0.30), Vector3(-0.72, 2.05, -0.35), Color(0.66, 0.40, 0.32), "Chimney")
    _box(house, Vector3(0.38, 0.08, 0.38), Vector3(-0.72, 2.50, -0.35), Color(0.52, 0.52, 0.55), "ChimneyCap")
    _make_smoke(house, Vector3(-0.72, 2.6, -0.35))
    # Door with arch, frame, porch roof and step.
    _box(house, Vector3(0.62, 0.98, 0.07), Vector3(0.0, 0.68, 0.91), trim, "DoorFrame")
    _box(house, Vector3(0.46, 0.84, 0.08), Vector3(0.0, 0.62, 0.93), Color(0.42, 0.22, 0.11), "Door")
    var arch: MeshInstance3D = _disc(house, 0.23, 0.08, Vector3(0.0, 1.04, 0.93), Color(0.42, 0.22, 0.11), "DoorArch", 0.9, 14)
    arch.rotation_degrees.x = 90.0
    _sphere(house, 0.03, 0.06, Vector3(0.14, 0.62, 0.99), Color(0.95, 0.80, 0.30), "DoorKnob")
    _box(house, Vector3(0.9, 0.07, 0.55), Vector3(0.0, 1.30, 1.15), Color(0.74, 0.26, 0.15), "PorchRoof")
    for px in [-0.40, 0.40]:
        _box(house, Vector3(0.07, 1.05, 0.07), Vector3(float(px), 0.70, 1.38), trim, "PorchPost")
    _box(house, Vector3(0.80, 0.12, 0.45), Vector3(0.0, 0.12, 1.20), Color(0.70, 0.66, 0.60), "FrontStep")
    # Front windows with frames, shutters and flower boxes.
    for wx in [-0.74, 0.74]:
        _box(house, Vector3(0.50, 0.50, 0.06), Vector3(float(wx), 0.98, 0.92), trim, "WindowFrame")
        _box(house, Vector3(0.36, 0.36, 0.08), Vector3(float(wx), 0.98, 0.94), Color(0.33, 0.76, 0.92), "Window").material_override = _window_material()
        for sx in [-0.31, 0.31]:
            _box(house, Vector3(0.12, 0.46, 0.05), Vector3(float(wx) + float(sx), 0.98, 0.93), Color(0.25, 0.56, 0.36), "Shutter")
        _box(house, Vector3(0.52, 0.12, 0.16), Vector3(float(wx), 0.66, 1.0), Color(0.45, 0.28, 0.14), "FlowerBox")
        for fi in range(3):
            var fc: Color = [Color(0.95, 0.35, 0.45), Color(0.98, 0.85, 0.30), Color(0.95, 0.55, 0.85)][fi]
            _sphere(house, 0.07, 0.14, Vector3(float(wx) - 0.17 + float(fi) * 0.17, 0.76, 1.0), fc, "Flower")
    # Side windows.
    for sx2 in [-1.16, 1.16]:
        _box(house, Vector3(0.06, 0.36, 0.36), Vector3(float(sx2), 1.0, 0.0), Color(0.33, 0.76, 0.92), "SideWindow").material_override = _window_material()

func _make_barn() -> void:
    var barn := Node3D.new()
    barn.name = "Barn"
    barn.position = BARN_POS
    add_child(barn)
    var red: Color = Color(0.80, 0.20, 0.17)
    var white: Color = Color(0.98, 0.95, 0.90)
    _box(barn, Vector3(2.2, 0.16, 2.0), Vector3(0.0, 0.08, 0.0), Color(0.55, 0.55, 0.57), "BarnPlinth")
    _box(barn, Vector3(2.0, 1.30, 1.8), Vector3(0.0, 0.81, 0.0), red, "BarnWalls")
    # Gambrel roof: steep lower slopes, shallow upper slopes, with overhang.
    var st := SurfaceTool.new()
    st.begin(Mesh.PRIMITIVE_TRIANGLES)
    var blue1: Color = Color(0.18, 0.28, 0.46)
    var blue2: Color = Color(0.26, 0.40, 0.62)
    var w: float = 1.0
    var o: float = 0.2
    var roof_pts: Array = [Vector2(-w - o, -0.1), Vector2(-w * 0.72, 0.62), Vector2(0.0, 1.05), Vector2(w * 0.72, 0.62), Vector2(w + o, -0.1), Vector2(w + o - 0.04, -0.22), Vector2(w * 0.72 - 0.04, 0.50), Vector2(0.0, 0.92), Vector2(-w * 0.72 + 0.04, 0.50), Vector2(-w - o + 0.04, -0.22)]
    _extrude_xy(st, roof_pts, -0.9 - o, 0.9 + o, [blue1, blue2, blue2, blue1, blue1.darkened(0.3), blue1.darkened(0.2), blue2.darkened(0.2), blue2.darkened(0.2), blue1.darkened(0.2), blue1.darkened(0.3)], blue1.darkened(0.2))
    _extrude_xy(st, [Vector2(-w, 0.0), Vector2(-w * 0.72 + 0.02, 0.58), Vector2(0.0, 0.98), Vector2(w * 0.72 - 0.02, 0.58), Vector2(w, 0.0)], -0.88, 0.88, [red, red, red, red, red], red)
    _mesh_node(barn, st, "BarnRoof", 1.46)
    # Big double door with white trim and cross braces, hayloft door above.
    _box(barn, Vector3(0.86, 1.05, 0.06), Vector3(0.0, 0.70, 0.92), white, "BarnDoorFrame")
    _box(barn, Vector3(0.76, 0.96, 0.08), Vector3(0.0, 0.68, 0.94), Color(0.52, 0.17, 0.13), "BarnDoor")
    for sgn in [-1.0, 1.0]:
        var brace: MeshInstance3D = _box(barn, Vector3(0.05, 1.05, 0.03), Vector3(0.0, 0.68, 0.99), white, "BarnBrace")
        brace.rotation_degrees.z = float(sgn) * 38.0
    _box(barn, Vector3(0.05, 0.96, 0.03), Vector3(0.0, 0.68, 0.99), white, "BarnDoorSplit")
    _box(barn, Vector3(0.46, 0.40, 0.06), Vector3(0.0, 1.78, 0.92), white, "HayloftFrame")
    _box(barn, Vector3(0.36, 0.30, 0.08), Vector3(0.0, 1.78, 0.94), Color(0.28, 0.14, 0.10), "HayloftDoor")
    _box(barn, Vector3(0.10, 0.10, 0.5), Vector3(0.0, 2.05, 1.05), Color(0.40, 0.26, 0.14), "HayBeam")
    for cx in [-1.0, 1.0]:
        _box(barn, Vector3(0.10, 1.32, 0.10), Vector3(float(cx), 0.82, 0.9), white, "BarnCornerTrim")
    var wind: MeshInstance3D = _box(barn, Vector3(0.30, 0.30, 0.06), Vector3(1.01, 1.0, 0.0), Color(0.33, 0.76, 0.92), "BarnWindow")
    wind.material_override = _window_material()

# -------------------------------------------------------------- build + loop

func _build_v23_ui() -> void:
    ui_root = shop_panel.get_parent() as Control
    _build_market_panel()
    _build_bakery_panel()
    _build_quest_panel()
    shop_panel.visible = false

func _build_v23() -> void:
    adaptive_quality = OS.get_environment("LV_NOADAPT") == ""
    _build_highlight()
    _build_v23_ui()
    _build_seasons()
    if OS.get_environment("LV_NOMERGE") == "":
        _merge_static_world()

func _process_v23(delta: float) -> void:
    if clock_label != null:
        var pill: Control = clock_label.get_parent().get_parent() as Control
        if pill != null:
            pill.visible = not _any_panel_open()
    _update_seasons(delta)
    _update_quality(delta)
    _update_highlight(delta)
    _update_bakery(delta * power_oven_mult())
    panel_refresh_timer -= delta
    if panel_refresh_timer <= 0.0:
        panel_refresh_timer = 0.5
        if bakery_panel != null and bakery_panel.visible:
            _refresh_bakery()
        _ensure_daily(true)

func _save_v23(config: ConfigFile) -> void:
    config.set_value("farm", "stock", stock)
    config.set_value("farm", "goods", goods)
    config.set_value("farm", "bake_queue", bake_queue)
    config.set_value("farm", "bake_remaining", bake_remaining)
    config.set_value("farm", "daily_day", daily_day)
    config.set_value("farm", "daily_quests", daily_quests)
    config.set_value("farm", "login_streak", login_streak)
    config.set_value("farm", "last_login_day", last_login_day)
    config.set_value("farm", "daily_bonus_taken", daily_bonus_taken)
    _save_v23b(config)

func _load_v23(config: ConfigFile) -> void:
    var s: Variant = config.get_value("farm", "stock", [0, 0, 0, 0, 0])
    if s is Array and (s as Array).size() >= 4:
        stock = (s as Array).duplicate()
        while stock.size() < crop_defs.size():
            stock.append(0)
    var gd: Variant = config.get_value("farm", "goods", [0, 0, 0, 0])
    if gd is Array and (gd as Array).size() == 4:
        goods = (gd as Array).duplicate()
    var bq: Variant = config.get_value("farm", "bake_queue", [])
    if bq is Array:
        bake_queue = (bq as Array).duplicate()
    bake_remaining = float(config.get_value("farm", "bake_remaining", 0.0))
    daily_day = int(config.get_value("farm", "daily_day", -1))
    var dq: Variant = config.get_value("farm", "daily_quests", [])
    if dq is Array:
        daily_quests = (dq as Array).duplicate(true)
    login_streak = int(config.get_value("farm", "login_streak", 0))
    last_login_day = int(config.get_value("farm", "last_login_day", -1))
    daily_bonus_taken = bool(config.get_value("farm", "daily_bonus_taken", false))
    _load_v23b(config)
    # The oven keeps working while the game is closed.
    var saved_at: float = float(config.get_value("farm", "saved_at", 0.0))
    if saved_at > 0.0 and not bake_queue.is_empty():
        _update_bakery_offline(maxf(0.0, Time.get_unix_time_from_system() - saved_at))

func _update_bakery_offline(away: float) -> void:
    var left: float = away
    while left > 0.0 and not bake_queue.is_empty():
        if left >= bake_remaining:
            left -= bake_remaining
            var rid: int = int(bake_queue.pop_front())
            goods[rid] = int(goods[rid]) + 1
            bake_remaining = float(recipes[int(bake_queue[0])]["time"]) if not bake_queue.is_empty() else 0.0
        else:
            bake_remaining -= left
            left = 0.0


# ===========================================================================
# v23 (part B) — seasons and the performance pass
# ===========================================================================

const SEASON_LEN := 300.0
const SEASON_NAMES: Array = ["Spring", "Summer", "Autumn", "Winter"]
const SEASON_ICONS: Array = ["🌸", "🌞", "🍂", "❄"]

var season_time: float = 60.0
var foliage_mat: ShaderMaterial
var meadow_mat: StandardMaterial3D
var island_mat: StandardMaterial3D
var season_fx: CPUParticles3D
var season_fx_mat: StandardMaterial3D
var season_fx_kind: int = -1
var season_sky: Color = Color(1, 1, 1)
var season_vals: Vector3 = Vector3.ZERO
var season_tick: float = 0.0
var grass_hide_nodes: Array = []
var lawn_nodes: Array = []
var lawn_light_mat: StandardMaterial3D
var lawn_dark_mat: StandardMaterial3D
var dn_acc: float = 0.0
var fps_time: float = 0.0
var fps_frames: int = 0
var quality_level: int = 0
var run_time: float = 0.0
var adaptive_quality: bool = true
var merge_stats: String = ""

const FOLIAGE_SHADER := """
shader_type spatial;
render_mode cull_disabled;
uniform float blossom = 0.0;
uniform float autumn = 0.0;
uniform float snow = 0.0;

vec3 to_lin(vec3 c) {
    return mix(pow((c + vec3(0.055)) / 1.055, vec3(2.4)), c / 12.92, step(c, vec3(0.04045)));
}

void fragment() {
    vec3 c = to_lin(COLOR.rgb);
    float l = dot(c, vec3(0.30, 0.55, 0.15));
    float greenish = smoothstep(0.0, 0.03, c.g - max(c.r, c.b));
    // Spring: the lighter leaves burst into pink and white blossom.
    vec3 pink = vec3(0.92, 0.42, 0.58) * (0.75 + l * 1.3);
    float bl = blossom * greenish * smoothstep(0.10, 0.26, l) * smoothstep(0.30, 0.38, COLOR.r) * 0.9;
    c = mix(c, pink, bl);
    // Autumn: dark leaves go red, middle ones orange, the sunny ones gold.
    float t = smoothstep(0.04, 0.34, l);
    vec3 red = vec3(0.50, 0.08, 0.04);
    vec3 orange = vec3(0.85, 0.30, 0.04);
    vec3 gold = vec3(0.95, 0.62, 0.07);
    vec3 fall = t < 0.5 ? mix(red, orange, t * 2.0) : mix(orange, gold, (t - 0.5) * 2.0);
    c = mix(c, fall, autumn * greenish * 0.92);
    // Winter: snow settles on the lit leaves, darker ones stay a cold green.
    vec3 white = vec3(0.80, 0.86, 0.92) * (0.80 + l * 0.9);
    float sn = snow * (0.50 + 0.45 * smoothstep(0.04, 0.28, l));
    c = mix(c, white, sn);
    ALBEDO = c;
    ROUGHNESS = 0.85;
}
"""

func _get_foliage_material() -> ShaderMaterial:
    if foliage_mat == null:
        var sh := Shader.new()
        sh.code = FOLIAGE_SHADER
        foliage_mat = ShaderMaterial.new()
        foliage_mat.shader = sh
    return foliage_mat

# -------------------------------------------------------------------- seasons

func _season_vec(idx: int) -> Vector3:
    # x = blossom, y = autumn colour, z = snow
    if idx == 0:
        return Vector3(1.0, 0.0, 0.0)
    if idx == 2:
        return Vector3(0.0, 1.0, 0.0)
    if idx == 3:
        return Vector3(0.0, 0.0, 1.0)
    return Vector3.ZERO

func _season_ground(idx: int) -> Color:
    if idx == 0:
        return Color(0.36, 0.72, 0.31)
    if idx == 2:
        return Color(0.45, 0.42, 0.19)
    if idx == 3:
        return Color(0.90, 0.93, 0.97)
    return Color(0.32, 0.67, 0.28)

func _season_lawn(idx: int, light: bool) -> Color:
    if idx == 0:
        return Color(0.46, 0.82, 0.38) if light else Color(0.32, 0.66, 0.28)
    if idx == 2:
        return Color(0.52, 0.42, 0.18) if light else Color(0.40, 0.32, 0.14)
    if idx == 3:
        return Color(0.97, 0.98, 1.0) if light else Color(0.84, 0.88, 0.94)
    return Color(0.40, 0.74, 0.32) if light else Color(0.27, 0.60, 0.24)

func _season_island(idx: int) -> Color:
    if idx == 0:
        return Color(0.42, 0.77, 0.34)
    if idx == 2:
        return Color(0.48, 0.43, 0.19)
    if idx == 3:
        return Color(0.93, 0.95, 0.98)
    return Color(0.38, 0.72, 0.30)

func _season_tint(idx: int) -> Color:
    if idx == 0:
        return Color(1.02, 1.0, 1.04)
    if idx == 2:
        return Color(1.06, 0.93, 0.82)
    if idx == 3:
        return Color(0.88, 0.94, 1.05)
    return Color(1, 1, 1)

func _build_seasons() -> void:
    _get_foliage_material()
    var meadow: MeshInstance3D = get_node_or_null("Meadow") as MeshInstance3D
    if meadow != null:
        meadow_mat = StandardMaterial3D.new()
        meadow_mat.roughness = 0.95
        meadow_mat.albedo_color = _season_ground(season_idx)
        meadow.material_override = meadow_mat
    island_mat = StandardMaterial3D.new()
    island_mat.roughness = 0.95
    island_mat.albedo_color = _season_island(season_idx)
    for isl in find_children("IslandGrass", "MeshInstance3D", true, false):
        (isl as MeshInstance3D).material_override = island_mat
    # Grass tufts, ground-cover and flowers disappear under the winter snow.
    grass_hide_nodes.clear()
    lawn_light_mat = StandardMaterial3D.new()
    lawn_light_mat.roughness = 0.95
    lawn_dark_mat = StandardMaterial3D.new()
    lawn_dark_mat.roughness = 0.95
    lawn_nodes.clear()
    _collect_named(self, ["LawnPatch"], lawn_nodes)
    for ln in lawn_nodes:
        var lm: MeshInstance3D = ln
        var oc: Color = (lm.material_override as StandardMaterial3D).albedo_color
        lm.material_override = lawn_light_mat if oc.g > 0.7 else lawn_dark_mat
    _collect_named(self, ["GrassTuft", "GroundCoverPatch", "Flower", "FlowerStem"], grass_hide_nodes)
    # Falling petals / leaves / snow follow the camera.
    season_fx = CPUParticles3D.new()
    season_fx.name = "SeasonFX"
    season_fx.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
    season_fx.emission_box_extents = Vector3(14.0, 0.3, 12.0)
    season_fx.direction = Vector3(0.0, -1.0, 0.0)
    season_fx.spread = 18.0
    season_fx.local_coords = false
    season_fx_mat = StandardMaterial3D.new()
    season_fx_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    season_fx_mat.vertex_color_use_as_albedo = true
    season_fx_mat.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
    season_fx_mat.cull_mode = BaseMaterial3D.CULL_DISABLED
    var quad := QuadMesh.new()
    quad.size = Vector2(0.2, 0.2)
    quad.material = season_fx_mat
    season_fx.mesh = quad
    season_fx.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    season_fx.emitting = false
    add_child(season_fx)
    _configure_season_fx()
    _apply_season_visuals()

func _base_name(n: Node) -> String:
    if n.has_meta("nm"):
        return str(n.get_meta("nm"))
    var nm: String = str(n.name).lstrip("@").split("@")[0]
    return nm.rstrip("0123456789")

func _collect_named(node: Node, names: Array, out: Array) -> void:
    for c in node.get_children():
        if c is MeshInstance3D and names.has(_base_name(c)):
            out.append(c)
        _collect_named(c, names, out)

func _configure_season_fx() -> void:
    if season_fx == null:
        return
    var k: float = 1.0 if quality_level < 2 else 0.5
    season_fx_kind = season_idx
    if season_idx == 1:
        season_fx.emitting = false
        return
    var grad := Gradient.new()
    if season_idx == 0:
        season_fx.amount = int(70.0 * k)
        season_fx.lifetime = 6.0
        season_fx.gravity = Vector3(0.55, -0.55, 0.20)
        season_fx.initial_velocity_min = 0.2
        season_fx.initial_velocity_max = 0.6
        (season_fx.mesh as QuadMesh).size = Vector2(0.16, 0.16)
        grad.set_color(0, Color(1.0, 0.72, 0.82))
        grad.set_color(1, Color(1.0, 0.92, 0.95))
    elif season_idx == 2:
        season_fx.amount = int(90.0 * k)
        season_fx.lifetime = 6.5
        season_fx.gravity = Vector3(0.70, -0.60, 0.30)
        season_fx.initial_velocity_min = 0.2
        season_fx.initial_velocity_max = 0.7
        (season_fx.mesh as QuadMesh).size = Vector2(0.22, 0.17)
        grad.set_color(0, Color(0.92, 0.35, 0.08))
        grad.set_color(1, Color(0.98, 0.78, 0.15))
    else:
        season_fx.amount = int(230.0 * k)
        season_fx.lifetime = 7.5
        season_fx.gravity = Vector3(0.18, -0.75, 0.05)
        season_fx.initial_velocity_min = 0.1
        season_fx.initial_velocity_max = 0.4
        (season_fx.mesh as QuadMesh).size = Vector2(0.11, 0.11)
        grad.set_color(0, Color(0.95, 0.97, 1.0))
        grad.set_color(1, Color(1.0, 1.0, 1.0))
    season_fx.color_initial_ramp = grad
    season_fx.preprocess = season_fx.lifetime
    season_fx.restart()
    season_fx.emitting = true

func _apply_season_visuals() -> void:
    var prev: int = (season_idx + 3) % 4
    var f: float = smoothstep(0.0, 0.16, season_time / SEASON_LEN)
    season_vals = _season_vec(prev).lerp(_season_vec(season_idx), f)
    if foliage_mat != null:
        foliage_mat.set_shader_parameter("blossom", season_vals.x)
        foliage_mat.set_shader_parameter("autumn", season_vals.y)
        foliage_mat.set_shader_parameter("snow", season_vals.z)
    if meadow_mat != null:
        meadow_mat.albedo_color = _season_ground(prev).lerp(_season_ground(season_idx), f)
    if island_mat != null:
        island_mat.albedo_color = _season_island(prev).lerp(_season_island(season_idx), f)
    season_sky = _season_tint(prev).lerp(_season_tint(season_idx), f)
    lawn_light_mat.albedo_color = _season_lawn(prev, true).lerp(_season_lawn(season_idx, true), f)
    lawn_dark_mat.albedo_color = _season_lawn(prev, false).lerp(_season_lawn(season_idx, false), f)
    var show_grass: bool = season_vals.z < 0.5
    for n in grass_hide_nodes:
        if is_instance_valid(n) and (n as Node3D).visible != show_grass:
            (n as Node3D).visible = show_grass

func _apply_season_sky() -> void:
    if env_ref == null:
        return
    env_ref.background_color = env_ref.background_color * season_sky
    env_ref.ambient_light_color = env_ref.ambient_light_color * season_sky
    if season_idx == 3 and sun_light != null:
        sun_light.light_energy *= 0.92

func _season_message() -> String:
    if season_idx == 0:
        return "Spring has arrived!\nBlossoms bloom and crops grow 10% faster."
    if season_idx == 1:
        return "Summer is here!\nLong sunny days on the farm."
    if season_idx == 2:
        return "Autumn has arrived!\nHarvest festival: market prices +15%."
    return "Winter has come!\nSnow covers the farm; crops grow 25% slower."

func _update_seasons(delta: float) -> void:
    season_time += delta
    if season_time >= SEASON_LEN:
        season_time -= SEASON_LEN
        season_idx = (season_idx + 1) % 4
        _configure_season_fx()
        _apply_season_visuals()
        _show_toast(_season_message())
        _save_game()
    season_tick -= delta
    if season_tick <= 0.0:
        season_tick = 0.15
        _apply_season_visuals()
    if season_fx != null and season_fx.emitting:
        season_fx.global_position = Vector3(cam_target.x, 8.5, cam_target.z)

func _season_label() -> String:
    return "%s %s" % [SEASON_ICONS[season_idx], SEASON_NAMES[season_idx]]

# ------------------------------------------------------------- performance

func _node_refs(v: Variant, out: Dictionary, depth: int = 0) -> void:
    if depth > 4:
        return
    if v is Node:
        if is_instance_valid(v):
            out[(v as Node).get_instance_id()] = v
    elif v is Array:
        for e in (v as Array):
            _node_refs(e, out, depth + 1)
    elif v is Dictionary:
        for k in (v as Dictionary).keys():
            _node_refs(k, out, depth + 1)
            _node_refs((v as Dictionary)[k], out, depth + 1)

func _protected_nodes() -> Dictionary:
    # Every node the game code keeps a reference to may move, hide or change later,
    # so those subtrees are never merged into the static world mesh.
    var prot: Dictionary = {}
    var skip: Array = [scenery_root, lh_root, ui_root, shop_panel]
    for p in get_property_list():
        if (int(p["usage"]) & PROPERTY_USAGE_SCRIPT_VARIABLE) == 0:
            continue
        if ["grass_hide_nodes", "lawn_nodes"].has(str(p["name"])):
            continue
        var v: Variant = get(str(p["name"]))
        if v is Node and skip.has(v):
            continue
        _node_refs(v, prot)
    return prot

func _under_protected(n: Node, prot: Dictionary) -> bool:
    var cur: Node = n
    while cur != null and cur != self:
        if prot.has(cur.get_instance_id()):
            return true
        cur = cur.get_parent()
    return false

func _gather_static(node: Node, prot: Dictionary, out: Array) -> void:
    for c in node.get_children():
        if prot.has(c.get_instance_id()):
            continue
        if c is MeshInstance3D:
            var mi: MeshInstance3D = c
            if mi.mesh != null and mi.material_override != null and mi.visible and mi.get_child_count() == 0:
                out.append(mi)
        if c is CPUParticles3D or c is Camera3D or c is Light3D or c is CanvasLayer or c is AudioStreamPlayer or c is WorldEnvironment:
            continue
        _gather_static(c, prot, out)

func _merge_nodes(nodes: Array, label: String, into: Node3D = null) -> Array:
    var groups: Dictionary = {}
    var done: Array = []
    var host: Node3D = into if into != null else self
    var inv: Transform3D = host.global_transform.affine_inverse()
    for n in nodes:
        var mi: MeshInstance3D = n
        var got: bool = false
        var mat: Material = mi.material_override
        var shadow: bool = mi.cast_shadow != GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
        var xf: Transform3D = inv * mi.global_transform
        var nb: Basis = xf.basis.inverse().transposed()
        var flip: bool = xf.basis.determinant() < 0.0
        for s in range(mi.mesh.get_surface_count()):
            var arr: Array = mi.mesh.surface_get_arrays(s)
            if arr.size() <= Mesh.ARRAY_VERTEX or arr[Mesh.ARRAY_VERTEX] == null:
                continue
            var verts: PackedVector3Array = arr[Mesh.ARRAY_VERTEX]
            if verts.is_empty():
                continue
            got = true
            var norms: Variant = arr[Mesh.ARRAY_NORMAL]
            var cols: Variant = arr[Mesh.ARRAY_COLOR]
            var idx: Variant = arr[Mesh.ARRAY_INDEX]
            var has_col: bool = cols is PackedColorArray and (cols as PackedColorArray).size() == verts.size()
            var gmat: Material = mat
            var flat: bool = false
            if into != null and not has_col and bake_flat.has(mat.get_instance_id()):
                flat = true
                gmat = _bake_vc_material()
            var key: String = "%d_%d_%d" % [gmat.get_instance_id(), 1 if shadow else 0, 1 if (has_col or flat) else 0]
            if not groups.has(key):
                groups[key] = {"mat": gmat, "shadow": shadow, "col": has_col or flat, "v": PackedVector3Array(), "n": PackedVector3Array(), "c": PackedColorArray(), "i": PackedInt32Array()}
            var g: Dictionary = groups[key]
            var gv: PackedVector3Array = g["v"]
            var gn: PackedVector3Array = g["n"]
            var gc: PackedColorArray = g["c"]
            var gi: PackedInt32Array = g["i"]
            var base: int = gv.size()
            for k in range(verts.size()):
                gv.append(xf * verts[k])
                if norms is PackedVector3Array and (norms as PackedVector3Array).size() == verts.size():
                    gn.append((nb * (norms as PackedVector3Array)[k]).normalized())
                else:
                    gn.append(Vector3.UP)
                if has_col:
                    gc.append((cols as PackedColorArray)[k])
                elif flat:
                    gc.append((mat as StandardMaterial3D).albedo_color)
            if idx is PackedInt32Array and (idx as PackedInt32Array).size() > 0:
                var ia: PackedInt32Array = idx
                var t: int = 0
                while t + 2 < ia.size():
                    if flip:
                        gi.append(base + ia[t])
                        gi.append(base + ia[t + 2])
                        gi.append(base + ia[t + 1])
                    else:
                        gi.append(base + ia[t])
                        gi.append(base + ia[t + 1])
                        gi.append(base + ia[t + 2])
                    t += 3
            else:
                var t2: int = 0
                while t2 + 2 < verts.size():
                    if flip:
                        gi.append(base + t2)
                        gi.append(base + t2 + 2)
                        gi.append(base + t2 + 1)
                    else:
                        gi.append(base + t2)
                        gi.append(base + t2 + 1)
                        gi.append(base + t2 + 2)
                    t2 += 3
            g["v"] = gv
            g["n"] = gn
            g["c"] = gc
            g["i"] = gi
        if got:
            done.append(mi)
    var made: Array = []
    var gcount: int = 0
    for key in groups.keys():
        var g2: Dictionary = groups[key]
        var arrays: Array = []
        arrays.resize(Mesh.ARRAY_MAX)
        arrays[Mesh.ARRAY_VERTEX] = g2["v"]
        arrays[Mesh.ARRAY_NORMAL] = g2["n"]
        if bool(g2["col"]):
            arrays[Mesh.ARRAY_COLOR] = g2["c"]
        arrays[Mesh.ARRAY_INDEX] = g2["i"]
        var am := ArrayMesh.new()
        am.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
        var out := MeshInstance3D.new()
        out.name = "%s_%d" % [label, gcount]
        gcount += 1
        out.mesh = am
        out.material_override = g2["mat"]
        if not bool(g2["shadow"]):
            out.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
        host.add_child(out)
        made.append(out)
    for n in done:
        var old: Node = n
        old.get_parent().remove_child(old)
        old.queue_free()
    return made

func _merge_static_world() -> void:
    var before: int = 0
    var prot: Dictionary = _protected_nodes()
    # Seasonal grass is merged on its own so it can be hidden under snow.
    var grass: Array = []
    for g in grass_hide_nodes:
        if is_instance_valid(g) and not _under_protected(g, prot):
            grass.append(g)
    var rest: Array = []
    _gather_static(self, prot, rest)
    var grass_ids: Dictionary = {}
    for g in grass:
        grass_ids[(g as Node).get_instance_id()] = true
    var rest2: Array = []
    for r in rest:
        if not grass_ids.has((r as Node).get_instance_id()):
            rest2.append(r)
    before = rest2.size() + grass.size()
    var grass_made: Array = []
    if grass.size() > 0:
        grass_made = _merge_nodes(grass, "SeasonalGrass")
    grass_hide_nodes = grass_made
    var made: Array = _merge_nodes(rest2, "StaticWorld")
    merge_stats = "merged %d meshes into %d (+%d seasonal)" % [before, made.size(), grass_made.size()]

func _apply_quality() -> void:
    if sun_light != null:
        if quality_level >= 3:
            sun_light.shadow_enabled = false
        elif quality_level >= 1:
            sun_light.shadow_enabled = true
            sun_light.directional_shadow_max_distance = 36.0 if quality_level == 1 else 26.0
    _configure_season_fx()

func _update_quality(delta: float) -> void:
    run_time += delta
    if not adaptive_quality or run_time < 8.0:
        return
    fps_time += delta
    fps_frames += 1
    if fps_time >= 3.0:
        var fps: float = float(fps_frames) / fps_time
        fps_time = 0.0
        fps_frames = 0
        if fps < 32.0 and quality_level < 3:
            quality_level += 1
            _apply_quality()

# -------------------------------------------------------------- v23 save hooks

func _save_v23b(config: ConfigFile) -> void:
    config.set_value("farm", "season_idx", season_idx)
    config.set_value("farm", "season_time", season_time)

func _load_v23b(config: ConfigFile) -> void:
    season_idx = clampi(int(config.get_value("farm", "season_idx", 0)), 0, 3)
    season_time = float(config.get_value("farm", "season_time", 60.0))
    var saved_at: float = float(config.get_value("farm", "saved_at", 0.0))
    if saved_at > 0.0:
        season_time += maxf(0.0, Time.get_unix_time_from_system() - saved_at)
    while season_time >= SEASON_LEN:
        season_time -= SEASON_LEN
        season_idx = (season_idx + 1) % 4
    if meadow_mat != null:
        meadow_mat.albedo_color = _season_ground(season_idx)
    _configure_season_fx()
    _apply_season_visuals()

# ===========================================================================
# v24 (stage 1) — animal & orchard products, orders board, farm expansion
# ===========================================================================

const PROD_NAMES: Array = ["Milk", "Eggs", "Truffles", "Apples"]
const PROD_ICONS: Array = ["🥛", "🥚", "🍄", "🍎"]
const PROD_BASE: Array = [14, 9, 22, 18]
const PROD_TIME: Array = [100.0, 70.0, 150.0, 180.0]
const PROD_HEIGHT: Array = [1.65, 1.05, 1.3, 3.0]
const BOARD_POS := Vector3(1.5, 0.0, 6.9)
const FIELDB_C := Vector3(8.7, 0.0, 0.0)
const ORCHARD_C := Vector3(1.4, 0.0, -8.25)
const FIELDB_LV := 4
const FIELDB_COST := 600
const ORCHARD_LV := 6
const ORCHARD_COST := 900
const BARN_LV := 5
const ORDER_NAMES: Array = ["Farmer Joe", "Granny May", "Baker Tom", "Captain Sam", "Dr. Asha", "Mayor Lily", "Chef Ravi", "Little Tara", "Fisher Ben", "Teacher Noor"]

var products: Array = [0, 0, 0, 0]
var producers: Array = []
var bubble_mat: StandardMaterial3D
var orders: Array = [{}, {}, {}]
var order_cool: Array = [2.0, 10.0, 22.0]
var order_panel: PanelContainer
var order_rows: Array = []
var order_coin_label: Label
var board_alert: Label3D
var exp_panel: PanelContainer
var exp_buttons: Array = []
var exp_coin_label: Label
var field_b_owned: bool = false
var orchard_owned: bool = false
var barn_bonus: int = 0
var field_b_node: Node3D
var orchard_node: Node3D
var exp_signs: Dictionary = {}
var order_tick: float = 0.0

func _barn_cap() -> int:
    return BARN_CAPACITY + barn_bonus

func _prod_price(i: int) -> int:
    return int(round(float(PROD_BASE[i]) * _season_price_mult() * (1.0 + train_bonus())))

func _item_have(k: String, id: int) -> int:
    if k == "crop":
        return int(stock[id])
    if k == "good":
        return int(goods[id])
    if k == "energy":
        return energy
    return int(products[id])

func _item_take(k: String, id: int, n: int) -> void:
    if k == "crop":
        stock[id] = int(stock[id]) - n
    elif k == "good":
        goods[id] = int(goods[id]) - n
    elif k == "energy":
        energy = maxi(0, energy - n)
    else:
        products[id] = int(products[id]) - n

func _item_price(k: String, id: int) -> int:
    if k == "crop":
        return _crop_price(id)
    if k == "good":
        return _good_price(id)
    if k == "energy":
        return maxi(2, _energy_sell_value() / 20)
    return _prod_price(id)

func _item_label(k: String, id: int) -> String:
    if k == "crop":
        return "%s %s" % [crop_defs[id]["icon"], crop_defs[id]["name"]]
    if k == "good":
        return "%s %s" % [recipes[id]["icon"], recipes[id]["name"]]
    if k == "energy":
        return "⚡ Energy"
    return "%s %s" % [PROD_ICONS[id], PROD_NAMES[id]]

func _stock_total() -> int:
    var t: int = 0
    for i in range(4):
        t += int(goods[i]) + int(products[i])
    for i in range(crop_defs.size()):
        t += int(stock[i])
    return t

func _label3d(parent: Node3D, text: String, pos: Vector3, px: float = 0.011, col: Color = Color(1, 1, 1)) -> Label3D:
    var l := Label3D.new()
    l.text = text
    l.position = pos
    l.pixel_size = px
    l.font_size = 48
    l.outline_size = 12
    l.outline_modulate = Color(0.22, 0.12, 0.05)
    l.modulate = col
    l.billboard = BaseMaterial3D.BILLBOARD_ENABLED
    l.shaded = false
    l.double_sided = true
    l.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    parent.add_child(l)
    return l

# ------------------------------------------------------------------ producers

func _add_producer(node: Node3D, kind: int) -> void:
    producers.append({"node": node, "kind": kind, "timer": audio_rng.randf_range(8.0, float(PROD_TIME[kind])), "ready": false, "bubble": null})

func _make_bubble(kind: int) -> Node3D:
    if bubble_mat == null:
        bubble_mat = StandardMaterial3D.new()
        bubble_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
        bubble_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
        bubble_mat.albedo_color = Color(1.0, 1.0, 1.0, 0.62)
    var root := Node3D.new()
    root.name = "ProdBubble"
    root.scale = Vector3.ONE * 1.45
    var ball := MeshInstance3D.new()
    var sm := SphereMesh.new()
    sm.radius = 0.30
    sm.height = 0.60
    sm.radial_segments = 12
    sm.rings = 6
    ball.mesh = sm
    ball.material_override = bubble_mat
    ball.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    root.add_child(ball)
    if kind == 0:
        _box(root, Vector3(0.14, 0.22, 0.14), Vector3(0.0, -0.03, 0.0), Color(0.97, 0.97, 1.0), "Milk")
        _box(root, Vector3(0.10, 0.07, 0.10), Vector3(0.0, 0.13, 0.0), Color(0.25, 0.55, 0.95), "MilkCap")
    elif kind == 1:
        _ellipsoid(root, Vector3(0.10, 0.14, 0.10), Vector3(0.0, 0.0, 0.0), Color(0.99, 0.93, 0.78), "Egg")
    elif kind == 2:
        _ellipsoid(root, Vector3(0.14, 0.11, 0.12), Vector3(0.0, 0.0, 0.0), Color(0.42, 0.28, 0.18), "Truffle")
        _sphere(root, 0.04, 0.08, Vector3(0.05, 0.07, 0.04), Color(0.55, 0.40, 0.28), "Bump")
    else:
        _sphere(root, 0.12, 0.24, Vector3(0.0, -0.01, 0.0), Color(0.90, 0.16, 0.14), "Apple")
        _box(root, Vector3(0.10, 0.03, 0.06), Vector3(0.05, 0.13, 0.0), Color(0.25, 0.65, 0.22), "AppleLeaf")
    return root

func _update_producers(delta: float) -> void:
    var i: int = 0
    for p in producers:
        var node: Node3D = p["node"]
        if not is_instance_valid(node):
            continue
        if not bool(p["ready"]):
            if not bool(p.get("hungry", false)):
                p["timer"] = float(p["timer"]) - delta
            if float(p["timer"]) <= 0.0:
                p["ready"] = true
                var b: Node3D = _make_bubble(int(p["kind"]))
                b.position = Vector3(0.0, float(PROD_HEIGHT[int(p["kind"])]), 0.0)
                node.add_child(b)
                p["bubble"] = b
        else:
            var bb: Node3D = p["bubble"]
            if is_instance_valid(bb):
                bb.position.y = float(PROD_HEIGHT[int(p["kind"])]) + sin(sway_clock * 3.0 + float(i)) * 0.07
                bb.rotation.y += delta * 1.6
        i += 1

func _collect_producer(p: Dictionary) -> void:
    var kind: int = int(p["kind"])
    if _stock_total() >= _barn_cap():
        _show_toast("The barn is full! Sell something first.")
        if v27 != null:
            v27.alert("barn")
        return
    products[kind] = int(products[kind]) + 1
    p["ready"] = false
    p["timer"] = float(PROD_TIME[kind]) * audio_rng.randf_range(0.9, 1.15)
    if v27 != null:
        v27.after_collect(p)
    var b: Variant = p["bubble"]
    if b != null and is_instance_valid(b):
        (b as Node).queue_free()
    p["bubble"] = null
    if kind == 0:
        _play_named("moo", -10.0)
    else:
        _play_named("ding", -12.0)
    _add_xp(2)
    _refresh_ui()
    _show_toast("%s +1 %s  (barn %d / %d)" % [PROD_ICONS[kind], PROD_NAMES[kind], _stock_total(), _barn_cap()])
    _refresh_market()
    _refresh_orders()

func _tap_producer(p2: Vector2) -> bool:
    var best: Dictionary = {}
    var best_d: float = 0.9
    for p in producers:
        if not bool(p["ready"]):
            continue
        var node: Node3D = p["node"]
        if not is_instance_valid(node):
            continue
        var base: Vector2 = Vector2(node.global_position.x, node.global_position.z)
        var h: float = float(PROD_HEIGHT[int(p["kind"])])
        var top: Vector2 = base + Vector2(-0.76 * h, -1.13 * h)
        var d: float = _dist_to_segment(p2, base, top)
        if d < best_d:
            best_d = d
            best = p
    if best.is_empty():
        return false
    _collect_producer(best)
    return true

# --------------------------------------------------------------- orders board

func _make_orders_board() -> void:
    var b := Node3D.new()
    b.name = "OrdersBoard"
    b.position = BOARD_POS
    b.rotation_degrees.y = -18.0
    add_child(b)
    var wood: Color = Color(0.55, 0.36, 0.18)
    for sx in [-0.78, 0.78]:
        _box(b, Vector3(0.14, 2.0, 0.14), Vector3(float(sx), 1.0, 0.0), wood.darkened(0.15), "BoardPost")
    _box(b, Vector3(1.8, 1.05, 0.10), Vector3(0.0, 1.45, 0.0), Color(0.80, 0.62, 0.38), "BoardPlank")
    _box(b, Vector3(1.9, 0.08, 0.14), Vector3(0.0, 1.99, 0.0), wood, "BoardTop")
    _box(b, Vector3(1.9, 0.08, 0.14), Vector3(0.0, 0.92, 0.0), wood, "BoardBottom")
    var papers: Array = [Color(1.0, 0.97, 0.85), Color(0.98, 0.88, 0.60), Color(0.88, 0.95, 0.88), Color(1.0, 0.92, 0.92), Color(0.90, 0.93, 1.0)]
    for i in range(5):
        var px: float = -0.66 + float(i) * 0.33
        var py: float = 1.55 if i % 2 == 0 else 1.30
        var paper: MeshInstance3D = _box(b, Vector3(0.28, 0.36, 0.02), Vector3(px, py, 0.07), papers[i], "BoardPaper")
        paper.rotation_degrees.z = float((i * 7) % 9) - 4.0
        _sphere(b, 0.03, 0.06, Vector3(px, py + 0.15, 0.10), Color(0.85, 0.2, 0.2), "BoardPin")
    _box(b, Vector3(2.1, 0.07, 0.55), Vector3(0.0, 2.22, -0.05), Color(0.62, 0.24, 0.16), "BoardRoof")
    _label3d(b, "ORDERS", Vector3(0.0, 2.7, 0.0), 0.010, Color(1.0, 0.95, 0.7))
    board_alert = _label3d(b, "!", Vector3(0.0, 3.25, 0.0), 0.022, Color(1.0, 0.85, 0.2))
    board_alert.visible = false

func _make_order(slot: int) -> void:
    var rng := RandomNumberGenerator.new()
    rng.randomize()
    var pool: Array = []
    for ci in range(crop_defs.size()):
        if level >= int(crop_defs[ci]["lv"]):
            pool.append({"k": "crop", "id": ci, "max": 3})
    if level >= BAKERY_LV:
        for ri in range(recipes.size()):
            pool.append({"k": "good", "id": ri, "max": 2})
    for pi in range(3):
        pool.append({"k": "prod", "id": pi, "max": 2})
    if orchard_owned:
        pool.append({"k": "prod", "id": 3, "max": 2})
    var lines: int = 1 + (1 if rng.randf() < 0.55 else 0) + (1 if level >= 6 and rng.randf() < 0.4 else 0)
    var items: Array = []
    var used: Dictionary = {}
    var value: int = 0
    for i in range(lines):
        var pick: Dictionary = pool[rng.randi_range(0, pool.size() - 1)]
        var key: String = "%s%d" % [pick["k"], int(pick["id"])]
        if used.has(key):
            continue
        used[key] = true
        var n: int = rng.randi_range(1, int(pick["max"]))
        items.append({"k": pick["k"], "id": int(pick["id"]), "n": n})
        value += n * _item_price(str(pick["k"]), int(pick["id"]))
    orders[slot] = {"who": ORDER_NAMES[rng.randi_range(0, ORDER_NAMES.size() - 1)], "items": items, "coins": int(round(float(value) * 1.5)) + 10, "xp": 8 + items.size() * 5, "left": 720.0}

func _order_ready(o: Dictionary) -> bool:
    for it in o["items"]:
        if _item_have(str(it["k"]), int(it["id"])) < int(it["n"]):
            return false
    return true

func _any_order_ready() -> bool:
    for o in orders:
        var od: Dictionary = o
        if not od.is_empty() and _order_ready(od):
            return true
    return false

func _build_orders_panel() -> void:
    var made: Array = _new_panel("🧾 VILLAGE ORDERS", 0.08, 0.92)
    order_panel = made[0]
    var col: VBoxContainer = made[1]
    order_coin_label = _panel_label(col, 17)
    order_rows.clear()
    for i in range(3):
        var card := PanelContainer.new()
        card.add_theme_stylebox_override("panel", _panel_style(Color(0.08, 0.17, 0.14, 0.95), 16))
        col.add_child(card)
        var cv := VBoxContainer.new()
        cv.add_theme_constant_override("separation", 4)
        card.add_child(cv)
        var lab: Label = _panel_label(cv, 17)
        var row := HBoxContainer.new()
        row.add_theme_constant_override("separation", 8)
        cv.add_child(row)
        var deliver := Button.new()
        deliver.text = "DELIVER"
        deliver.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        deliver.custom_minimum_size = Vector2(0, 46)
        deliver.add_theme_font_size_override("font_size", 18)
        deliver.pressed.connect(_deliver_order.bind(i))
        row.add_child(deliver)
        var skip := Button.new()
        skip.text = "SKIP"
        skip.custom_minimum_size = Vector2(96, 46)
        skip.add_theme_font_size_override("font_size", 16)
        skip.pressed.connect(_skip_order.bind(i))
        row.add_child(skip)
        order_rows.append({"label": lab, "deliver": deliver, "skip": skip})
    var hint: Label = _panel_label(col, 15, Color(0.75, 0.88, 0.78))
    hint.text = "Orders come from the barn. New ones arrive when you finish or skip. They expire after 12 minutes."
    var close: Button = _panel_button(col, "CLOSE", 44, 18)
    close.pressed.connect(_close_panels)

func _refresh_orders() -> void:
    if order_panel == null:
        return
    order_coin_label.text = "Your coins: %d" % coins
    for i in range(3):
        var r: Dictionary = order_rows[i]
        var lab: Label = r["label"]
        var dbtn: Button = r["deliver"]
        var sbtn: Button = r["skip"]
        var o: Dictionary = orders[i]
        if o.is_empty():
            lab.text = "A villager is coming with a new order..."
            dbtn.disabled = true
            sbtn.disabled = true
            dbtn.text = "WAITING"
            continue
        var parts: Array = []
        for it in o["items"]:
            parts.append("%s %d/%d" % [_item_label(str(it["k"]), int(it["id"])), mini(_item_have(str(it["k"]), int(it["id"])), int(it["n"])), int(it["n"])])
        var secs: int = int(o["left"])
        lab.text = "%s wants:\n%s\nReward: %d coins + %d XP   •   %d:%02d left" % [o["who"], "   ".join(parts), int(o["coins"]), int(o["xp"]), secs / 60, secs % 60]
        var ok: bool = _order_ready(o)
        dbtn.disabled = not ok
        dbtn.text = "DELIVER" if ok else "NEED MORE"
        sbtn.disabled = false

func _deliver_order(slot: int) -> void:
    var o: Dictionary = orders[slot]
    if o.is_empty() or not _order_ready(o):
        return
    for it in o["items"]:
        _item_take(str(it["k"]), int(it["id"]), int(it["n"]))
    coins += int(o["coins"])
    _add_xp(int(o["xp"]))
    orders[slot] = {}
    order_cool[slot] = 40.0
    _play_named("jingle", -8.0)
    _quest_event("sell", 1)
    _refresh_ui()
    _refresh_orders()
    _refresh_market()
    _show_toast("%s says thanks!  +%d coins, +%d XP" % [o["who"], int(o["coins"]), int(o["xp"])])
    _save_game()

func _skip_order(slot: int) -> void:
    orders[slot] = {}
    order_cool[slot] = 12.0
    _refresh_orders()

func _open_orders() -> void:
    _close_panels()
    order_panel.visible = true
    _refresh_orders()

func _update_orders(delta: float) -> void:
    for i in range(3):
        var o: Dictionary = orders[i]
        if o.is_empty():
            order_cool[i] = float(order_cool[i]) - delta
            if float(order_cool[i]) <= 0.0:
                _make_order(i)
                if order_panel != null and order_panel.visible:
                    _refresh_orders()
        else:
            o["left"] = float(o["left"]) - delta
            if float(o["left"]) <= 0.0:
                _show_toast("%s's order expired." % str(o["who"]))
                orders[i] = {}
                order_cool[i] = 30.0
    order_tick -= delta
    if order_tick <= 0.0:
        order_tick = 0.5
        if board_alert != null:
            board_alert.visible = _any_order_ready()
            board_alert.position.y = 3.25 + sin(sway_clock * 4.0) * 0.12
        if order_panel != null and order_panel.visible:
            _refresh_orders()

# ------------------------------------------------------------ farm expansion

func _build_expand_panel() -> void:
    var made: Array = _new_panel("🏗 FARM EXPANSION", 0.14, 0.86)
    exp_panel = made[0]
    var col: VBoxContainer = made[1]
    exp_coin_label = _panel_label(col, 18)
    exp_buttons.clear()
    for i in range(3):
        var b: Button = _panel_button(col, "", 92, 18)
        b.pressed.connect(_buy_expand.bind(i))
        exp_buttons.append(b)
    var close: Button = _panel_button(col, "CLOSE", 46, 18)
    close.pressed.connect(_close_panels)

func _barn_upgrade_cost() -> int:
    return 500 * (barn_bonus / 30 + 1)

func _refresh_expand() -> void:
    if exp_panel == null:
        return
    exp_coin_label.text = "Your coins: %d" % coins
    var b0: Button = exp_buttons[0]
    var b1: Button = exp_buttons[1]
    var b2: Button = exp_buttons[2]
    if field_b_owned:
        b0.text = "🌾 Second Field (12 plots)\nOWNED"
        b0.disabled = true
    else:
        b0.text = "🌾 Second Field (12 more plots)\nLevel %d  •  %d coins" % [FIELDB_LV, FIELDB_COST]
        b0.disabled = level < FIELDB_LV or coins < FIELDB_COST
    if orchard_owned:
        b1.text = "🍎 Apple Orchard (6 trees)\nOWNED"
        b1.disabled = true
    else:
        b1.text = "🍎 Apple Orchard (6 trees, apples every 3 min)\nLevel %d  •  %d coins" % [ORCHARD_LV, ORCHARD_COST]
        b1.disabled = level < ORCHARD_LV or coins < ORCHARD_COST
    if barn_bonus >= 90:
        b2.text = "📦 Bigger Barn (+30 space)\nMAXED OUT (%d items)" % _barn_cap()
        b2.disabled = true
    else:
        b2.text = "📦 Bigger Barn (+30 space, now %d)\nLevel %d  •  %d coins" % [_barn_cap(), BARN_LV, _barn_upgrade_cost()]
        b2.disabled = level < BARN_LV or coins < _barn_upgrade_cost()

func _buy_expand(i: int) -> void:
    if i == 0 and not field_b_owned and level >= FIELDB_LV and coins >= FIELDB_COST:
        coins -= FIELDB_COST
        field_b_owned = true
        _build_field_b()
        _show_toast("Second field ready! 12 new plots.")
    elif i == 1 and not orchard_owned and level >= ORCHARD_LV and coins >= ORCHARD_COST:
        coins -= ORCHARD_COST
        orchard_owned = true
        _build_orchard()
        _show_toast("Apple orchard planted! Tap the apple bubbles.")
    elif i == 2 and barn_bonus < 90 and level >= BARN_LV and coins >= _barn_upgrade_cost():
        coins -= _barn_upgrade_cost()
        barn_bonus += 30
        _show_toast("Barn enlarged! Space for %d items." % _barn_cap())
    else:
        return
    _play_named("jingle", -8.0)
    _refresh_ui()
    _refresh_expand()
    _save_game()

func _open_expand() -> void:
    _close_panels()
    exp_panel.visible = true
    _refresh_expand()

func _make_expand_sign(key: String, c: Vector3, size: Vector2, title: String) -> void:
    var s := Node3D.new()
    s.name = "ExpandSign_" + key
    s.position = c
    add_child(s)
    var dry: MeshInstance3D = _box(s, Vector3(size.x, 0.03, size.y), Vector3(0.0, 0.02, 0.0), Color(0.66, 0.58, 0.38), "DryLand")
    dry.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    for sx in [-0.5, 0.5]:
        for sz in [-0.5, 0.5]:
            _box(s, Vector3(0.12, 0.7, 0.12), Vector3(float(sx) * size.x, 0.35, float(sz) * size.y), Color(0.58, 0.38, 0.20), "Stake")
            _sphere(s, 0.07, 0.14, Vector3(float(sx) * size.x, 0.72, float(sz) * size.y), Color(0.95, 0.80, 0.25), "StakeTop")
    _box(s, Vector3(0.12, 1.3, 0.12), Vector3(-0.5, 0.65, 0.0), Color(0.45, 0.28, 0.14), "SignPost")
    _box(s, Vector3(0.12, 1.3, 0.12), Vector3(0.5, 0.65, 0.0), Color(0.45, 0.28, 0.14), "SignPost")
    _box(s, Vector3(1.5, 0.6, 0.08), Vector3(0.0, 1.3, 0.0), Color(0.95, 0.88, 0.62), "SignBoard")
    _label3d(s, title, Vector3(0.0, 2.0, 0.0), 0.010, Color(1.0, 0.95, 0.7))
    _label3d(s, "FOR SALE", Vector3(0.0, 1.32, 0.12), 0.007, Color(0.55, 0.15, 0.10))
    exp_signs[key] = s

func _remove_sign(key: String) -> void:
    if exp_signs.has(key):
        var s: Node = exp_signs[key]
        if is_instance_valid(s):
            s.queue_free()
        exp_signs.erase(key)

func _build_field_b() -> void:
    if field_b_node != null:
        return
    _remove_sign("field")
    field_b_node = Node3D.new()
    field_b_node.name = "FieldB"
    add_child(field_b_node)
    var cols: int = 3
    var rows: int = 4
    var w: float = float(cols) * CELL
    var d: float = float(rows) * CELL
    var c: Vector3 = FIELDB_C
    _box(field_b_node, Vector3(w + 0.3, 0.10, d + 0.3), Vector3(c.x, 0.0, c.z), Color(0.50, 0.33, 0.19), "FieldFrame")
    _box(field_b_node, Vector3(w, 0.13, d), Vector3(c.x, 0.02, c.z), Color(0.40, 0.24, 0.14), "FieldBed")
    _box(field_b_node, Vector3(w - 0.08, 0.04, d - 0.08), Vector3(c.x, 0.09, c.z), Color(0.47, 0.30, 0.17), "FieldSoil")
    for r in range(rows * 3):
        var rz: float = c.z - d * 0.5 + (float(r) + 0.5) * (d / float(rows * 3))
        var ridge: MeshInstance3D = _box(field_b_node, Vector3(w - 0.12, 0.03, 0.10), Vector3(c.x, 0.12, rz), Color(0.41, 0.25, 0.14), "FieldRidge")
        ridge.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    for r in range(rows):
        for cc in range(cols):
            var key: String = "b%d,%d" % [cc, r]
            plot_centers[key] = Vector3(c.x + (float(cc) - 1.0) * CELL, 0.0, c.z + (float(r) - 1.5) * CELL)
            if not crop_states.has(key):
                crop_states[key] = {"planted": false, "age": 0.0}

func _build_orchard() -> void:
    if orchard_node != null:
        return
    _remove_sign("orchard")
    orchard_node = Node3D.new()
    orchard_node.name = "Orchard"
    add_child(orchard_node)
    var rng := RandomNumberGenerator.new()
    rng.seed = 4242
    var palette: Array = [Color(0.14, 0.42, 0.16), Color(0.22, 0.55, 0.20), Color(0.32, 0.64, 0.24), Color(0.44, 0.74, 0.28), Color(0.52, 0.80, 0.32)]
    var soil: MeshInstance3D = _box(orchard_node, Vector3(6.0, 0.03, 3.4), Vector3(ORCHARD_C.x, 0.02, ORCHARD_C.z), Color(0.55, 0.62, 0.34), "OrchardGround")
    soil.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    for zrow in [-0.65, 0.65]:
        for xc in [-1.8, 0.0, 1.8]:
            var tree := Node3D.new()
            tree.name = "AppleTree"
            tree.position = Vector3(ORCHARD_C.x + float(xc), 0.0, ORCHARD_C.z + float(zrow))
            orchard_node.add_child(tree)
            _cylinder(tree, 0.09, 0.15, 1.1, Vector3(0.0, 0.55, 0.0), Color(0.40, 0.25, 0.12), "AppleTrunk")
            var st := SurfaceTool.new()
            st.begin(Mesh.PRIMITIVE_TRIANGLES)
            _ellipsoid(tree, Vector3(0.62, 0.50, 0.62), Vector3(0.0, 1.55, 0.0), Color(0.12, 0.38, 0.14), "AppleCore")
            _add_leafy_lobe(st, rng, Vector3(0.0, 1.55, 0.0), 0.62, 70, palette)
            _add_leafy_lobe(st, rng, Vector3(0.0, 1.95, 0.0), 0.42, 40, palette)
            _commit_leaf_mesh(tree, st, "AppleFoliage")
            for k in range(6):
                var ang: float = float(k) * TAU / 6.0
                _sphere(tree, 0.07, 0.14, Vector3(cos(ang) * 0.56, 1.45 + float(k % 2) * 0.25, sin(ang) * 0.56), Color(0.90, 0.16, 0.14), "TreeApple")
            _add_producer(tree, 3)

func _build_expand_signs() -> void:
    if not field_b_owned:
        _make_expand_sign("field", FIELDB_C, Vector2(4.5, 5.9), "SECOND FIELD")
    if not orchard_owned:
        _make_expand_sign("orchard", ORCHARD_C, Vector2(5.4, 2.8), "APPLE ORCHARD")

# --------------------------------------------------------- taps, build, loop

func _tap_buildings_v24(hit: Vector3) -> bool:
    var p: Vector2 = Vector2(hit.x, hit.z)
    if v27 != null and v27.tap_hungry(p):
        return true
    if _tap_producer(p):
        return true
    if _dist_to_segment(p, Vector2(BOARD_POS.x, BOARD_POS.z), Vector2(BOARD_POS.x - 0.9, BOARD_POS.z - 1.5)) < 1.0:
        _open_orders()
        return true
    if not field_b_owned and absf(p.x - FIELDB_C.x) < 2.5 and absf(p.y - FIELDB_C.z) < 3.1:
        _open_expand()
        return true
    if not orchard_owned and absf(p.x - ORCHARD_C.x) < 3.0 and absf(p.y - ORCHARD_C.z) < 1.5:
        _open_expand()
        return true
    # TAP_CHAIN_START
    if _tap_trade(Vector2(hit.x, hit.z)):
        return true
    if _tap_carrier(Vector2(hit.x, hit.z)):
        return true
    if _tap_train(Vector2(hit.x, hit.z)):
        return true
    if _tap_hydro(Vector2(hit.x, hit.z)):
        return true
    # TAP_CHAIN_END
    return false

func _build_v24() -> void:
    _make_orders_board()
    _build_orders_panel()
    _build_expand_panel()
    extra_panels = [order_panel, exp_panel]
    _build_expand_signs()
    _build_hydro()
    _build_hydro_panel()
    extra_panels.append(hydro_panel)
    _update_hydro_visibility()
    _build_train()
    _build_train_panel()
    extra_panels.append(train_panel)
    _update_train_visibility()
    _build_carrier()
    _build_carrier_panel()
    extra_panels.append(carrier_panel)
    _update_carrier_visibility()
    _build_trade()
    _build_trade_panel()
    extra_panels.append(trade_panel)
    _update_trade_visibility()
    _build_farm_decor()
    _bake_v24()
    _update_lock_buttons()
    v27 = (load("res://scripts/farm_v27.gd") as GDScript).new()
    v27.g = self
    add_child(v27)
    v27.build()
    # BUILD_CHAIN

func _process_v24(delta: float) -> void:
    _update_producers(delta * power_feed_mult())
    _update_orders(delta)
    _update_hydro(delta)
    _update_crop_bar_visibility()
    _update_train(delta)
    _update_carrier(delta)
    _update_trade(delta)
    # PROC_CHAIN

func _save_v24(config: ConfigFile) -> void:
    config.set_value("farm", "products", products)
    config.set_value("farm", "orders", orders)
    config.set_value("farm", "order_cool", order_cool)
    config.set_value("farm", "field_b", field_b_owned)
    config.set_value("farm", "orchard", orchard_owned)
    config.set_value("farm", "barn_bonus", barn_bonus)
    var pt: Array = []
    for p in producers:
        pt.append([float(p["timer"]), bool(p["ready"])])
    config.set_value("farm", "producers", pt)
    _save_hydro(config)
    _save_train(config)
    _save_carrier(config)
    _save_trade(config)
    if v27 != null:
        v27.save(config)
    # SAVE_CHAIN

func _load_v24(config: ConfigFile) -> void:
    if v27 != null:
        v27.load_levels(config)
    var pr: Variant = config.get_value("farm", "products", [0, 0, 0, 0])
    if pr is Array and (pr as Array).size() == 4:
        products = (pr as Array).duplicate()
    var od: Variant = config.get_value("farm", "orders", [{}, {}, {}])
    if od is Array and (od as Array).size() == 3:
        orders = (od as Array).duplicate(true)
    var oc: Variant = config.get_value("farm", "order_cool", [2.0, 10.0, 22.0])
    if oc is Array and (oc as Array).size() == 3:
        order_cool = (oc as Array).duplicate()
    barn_bonus = clampi(int(config.get_value("farm", "barn_bonus", 0)), 0, 90)
    field_b_owned = bool(config.get_value("farm", "field_b", false))
    orchard_owned = bool(config.get_value("farm", "orchard", false))
    if field_b_owned:
        _build_field_b()
        _remove_sign("field")
    if orchard_owned:
        _build_orchard()
        _remove_sign("orchard")
    var saved_at: float = float(config.get_value("farm", "saved_at", 0.0))
    var away: float = 0.0
    if saved_at > 0.0:
        away = maxf(0.0, Time.get_unix_time_from_system() - saved_at)
    for o in orders:
        var od2: Dictionary = o
        if not od2.is_empty():
            od2["left"] = maxf(30.0, float(od2["left"]) - away)
    var pt: Variant = config.get_value("farm", "producers", [])
    if pt is Array:
        var arr: Array = pt
        for i in range(mini(arr.size(), producers.size())):
            var e: Array = arr[i]
            var p: Dictionary = producers[i]
            p["timer"] = float(e[0]) - away
            if bool(e[1]):
                p["timer"] = 0.0
    _load_hydro(config)
    _load_train(config)
    _load_carrier(config)
    _load_trade(config)
    # LOAD_CHAIN



# ===========================================================================
# v24 (stage 2) — tidal / wave power station out at sea
# ===========================================================================

const HYDRO_LV := 8
const TRAIN_LV := 9
const CARRIER_LV := 10
const SUBSTATION_POS := Vector3(16.9, 0.0, -2.6)
const HYDRO_POS := Vector3(23.6, 0.0, -2.6)
const HYDRO_RATE: Array = [0.10, 0.20, 0.33]
const HYDRO_CAP: Array = [100, 160, 240]
const BATTERY_CAP := 500
const BATTERY_CAP_BASE := 500

var hydro_unlocked: bool = false
var hydro_level: int = 1
var energy: int = 0
var energy_store: float = 0.0
var boost_irrig: float = 0.0
var boost_oven: float = 0.0
var boost_feed: float = 0.0
var hydro_built: Node3D
var hydro_site: Node3D
var hydro_rotors: Array = []
var hydro_turbines: Array = []
var hydro_buoys: Array = []
var hydro_orb: MeshInstance3D
var hydro_orb_mat: StandardMaterial3D
var hydro_panel: PanelContainer
var hydro_info: Label
var hydro_buttons: Array = []
var hydro_btn: Button
var pill_extra: Label
var hydro_tick: float = 0.0

func power_growth_mult() -> float:
    return 1.3 if boost_irrig > 0.0 else 1.0

func power_oven_mult() -> float:
    return 2.0 if boost_oven > 0.0 else 1.0

func power_feed_mult() -> float:
    return 2.0 if boost_feed > 0.0 else 1.0

func _hydro_rate() -> float:
    return float(HYDRO_RATE[hydro_level - 1]) * (1.0 + 0.5 * rain)

func _hydro_cap() -> int:
    return int(HYDRO_CAP[hydro_level - 1])

func _wire(parent: Node3D, a: Vector3, b: Vector3, th: float, col: Color) -> void:
    var n := Node3D.new()
    parent.add_child(n)
    n.position = a
    var l: float = (b - a).length()
    n.look_at(parent.to_global(b), Vector3.UP)
    _box(n, Vector3(th, th, l), Vector3(0.0, 0.0, -l * 0.5), col, "Wire")

func _build_hydro() -> void:
    # ---- finished station ----
    hydro_built = Node3D.new()
    hydro_built.name = "TidalStation"
    hydro_built.position = HYDRO_POS
    add_child(hydro_built)
    var steel: Color = Color(0.66, 0.68, 0.72)
    var yellow: Color = Color(0.97, 0.80, 0.18)
    for px in [-1.4, 1.4]:
        for pz in [-1.0, 1.0]:
            _cylinder(hydro_built, 0.15, 0.17, 1.7, Vector3(float(px), -0.25, float(pz)), Color(0.45, 0.47, 0.52), "Pile")
    _box(hydro_built, Vector3(3.5, 0.22, 2.7), Vector3(0.0, 0.50, 0.0), steel, "Deck")
    _box(hydro_built, Vector3(3.5, 0.06, 2.7), Vector3(0.0, 0.38, 0.0), Color(0.40, 0.42, 0.46), "DeckUnder")
    for rx in [-1.7, 1.7]:
        for rz in [-1.3, 1.3]:
            _box(hydro_built, Vector3(0.08, 0.5, 0.08), Vector3(float(rx), 0.85, float(rz)), yellow, "RailPost")
    _box(hydro_built, Vector3(3.5, 0.06, 0.06), Vector3(0.0, 1.08, 1.3), yellow, "Rail")
    _box(hydro_built, Vector3(3.5, 0.06, 0.06), Vector3(0.0, 1.08, -1.3), yellow, "Rail")
    _box(hydro_built, Vector3(0.06, 0.06, 2.6), Vector3(1.7, 1.08, 0.0), yellow, "Rail")
    # Control hut with gabled roof, door and window.
    _box(hydro_built, Vector3(1.35, 0.95, 1.15), Vector3(-0.75, 1.07, -0.35), Color(0.96, 0.97, 0.98), "Hut")
    var rl: MeshInstance3D = _box(hydro_built, Vector3(0.95, 0.09, 1.35), Vector3(-1.07, 1.72, -0.35), Color(0.20, 0.45, 0.72), "HutRoofL")
    rl.rotation_degrees.z = 28.0
    var rr: MeshInstance3D = _box(hydro_built, Vector3(0.95, 0.09, 1.35), Vector3(-0.43, 1.72, -0.35), Color(0.26, 0.55, 0.82), "HutRoofR")
    rr.rotation_degrees.z = -28.0
    _box(hydro_built, Vector3(0.36, 0.62, 0.05), Vector3(-0.45, 0.88, 0.25), Color(0.25, 0.30, 0.38), "HutDoor")
    var hw: MeshInstance3D = _box(hydro_built, Vector3(0.36, 0.30, 0.05), Vector3(-1.1, 1.15, 0.25), Color(0.33, 0.76, 0.92), "HutWindow")
    hw.material_override = _window_material()
    var lamp: MeshInstance3D = _sphere(hydro_built, 0.09, 0.18, Vector3(-0.75, 2.05, -0.35), Color(1.0, 0.95, 0.7), "HutLamp")
    lamp.material_override = _lamp_material()
    # Transformer and cable drum on the deck.
    _box(hydro_built, Vector3(0.6, 0.55, 0.5), Vector3(0.95, 0.88, -0.6), Color(0.55, 0.58, 0.62), "Transformer")
    for cx in [0.8, 1.1]:
        _cylinder(hydro_built, 0.07, 0.07, 0.3, Vector3(float(cx), 1.28, -0.6), Color(0.88, 0.88, 0.9), "Insulator")
    _box(hydro_built, Vector3(0.6, 0.08, 0.08), Vector3(0.95, 1.0, -0.33), yellow, "TransformerStripe")
    # Three turbines on the south side (the level decides how many are fitted).
    hydro_turbines.clear()
    hydro_rotors.clear()
    for i in range(3):
        var tx: float = -1.2 + float(i) * 1.2
        var unit := Node3D.new()
        unit.name = "Turbine_%d" % i
        unit.position = Vector3(tx, 0.0, 2.55)
        unit.rotation_degrees.y = 45.0
        hydro_built.add_child(unit)
        _box(hydro_built, Vector3(0.26, 0.10, 1.25), Vector3(tx, 0.52, 1.95), steel.darkened(0.15), "Catwalk_%d" % i).set_meta("unit", i)
        _cylinder(unit, 0.13, 0.17, 2.5, Vector3(0.0, 0.25, 0.0), Color(0.45, 0.47, 0.52), "TurbinePile")
        _ellipsoid(unit, Vector3(0.30, 0.26, 0.60), Vector3(0.0, 1.45, 0.0), Color(0.97, 0.97, 0.98), "Nacelle")
        _sphere(unit, 0.12, 0.24, Vector3(0.0, 1.45, 0.62), Color(0.97, 0.55, 0.15), "Hub")
        var rotor := Node3D.new()
        rotor.name = "Rotor"
        rotor.position = Vector3(0.0, 1.45, 0.70)
        unit.add_child(rotor)
        for k in range(3):
            var pivot := Node3D.new()
            pivot.rotation_degrees.z = float(k) * 120.0
            rotor.add_child(pivot)
            _box(pivot, Vector3(0.20, 1.05, 0.05), Vector3(0.0, 0.62, 0.0), Color(0.97, 0.97, 0.98), "Blade")
            _box(pivot, Vector3(0.20, 0.22, 0.055), Vector3(0.0, 1.06, 0.0), Color(0.97, 0.55, 0.15), "BladeTip")
        hydro_rotors.append(rotor)
        hydro_turbines.append(unit)
    # Wave buoys bobbing around the station.
    hydro_buoys.clear()
    var buoy_pos: Array = [Vector3(-2.8, -0.45, 1.8), Vector3(-3.6, -0.45, -0.6), Vector3(-2.7, -0.45, -2.6), Vector3(1.0, -0.45, -3.4)]
    for bi in range(buoy_pos.size()):
        var buoy := Node3D.new()
        buoy.name = "WaveBuoy"
        buoy.position = buoy_pos[bi]
        hydro_built.add_child(buoy)
        _ellipsoid(buoy, Vector3(0.36, 0.30, 0.36), Vector3(0.0, 0.0, 0.0), Color(0.97, 0.55, 0.15), "BuoyBody")
        _cylinder(buoy, 0.37, 0.37, 0.10, Vector3(0.0, 0.05, 0.0), Color(0.98, 0.98, 0.98), "BuoyBand")
        _cylinder(buoy, 0.03, 0.03, 0.55, Vector3(0.0, 0.52, 0.0), Color(0.45, 0.47, 0.52), "BuoyMast")
        var bl: MeshInstance3D = _sphere(buoy, 0.07, 0.14, Vector3(0.0, 0.82, 0.0), Color(1.0, 0.95, 0.7), "BuoyLamp")
        bl.material_override = _lamp_material()
        hydro_buoys.append({"node": buoy, "phase": float(bi) * 1.7, "base": -0.45})
    # Power line on poles back to a small substation on the island.
    var line_x: Array = [-5.8, -4.4, -3.0, -1.8]
    var tops: Array = []
    for lx in line_x:
        var h: float = 1.9
        _cylinder(hydro_built, 0.07, 0.10, h, Vector3(float(lx), 0.35, 0.0), Color(0.45, 0.30, 0.16), "PowerPole")
        _box(hydro_built, Vector3(0.08, 0.08, 0.6), Vector3(float(lx), 1.25, 0.0), Color(0.40, 0.26, 0.14), "CrossArm")
        tops.append(float(lx))
    for i in range(tops.size() - 1):
        for zz in [-0.25, 0.25]:
            var a: Vector3 = Vector3(float(tops[i]), 1.27, float(zz))
            var b: Vector3 = Vector3(float(tops[i + 1]), 1.27, float(zz))
            var mid: Vector3 = (a + b) * 0.5 + Vector3(0.0, -0.18, 0.0)
            _wire(hydro_built, a, mid, 0.035, Color(0.12, 0.12, 0.14))
            _wire(hydro_built, mid, b, 0.035, Color(0.12, 0.12, 0.14))
    _wire(hydro_built, Vector3(-1.8, 1.27, -0.25), Vector3(-0.0, 1.1, -0.5), 0.035, Color(0.12, 0.12, 0.14))
    # Substation on land.
    var sub := Node3D.new()
    sub.name = "Substation"
    sub.position = Vector3(SUBSTATION_POS.x - HYDRO_POS.x, 0.0, SUBSTATION_POS.z - HYDRO_POS.z)
    hydro_built.add_child(sub)
    _box(sub, Vector3(1.1, 0.14, 1.0), Vector3(0.0, 0.07, 0.0), Color(0.60, 0.60, 0.62), "SubBase")
    _box(sub, Vector3(0.9, 0.9, 0.7), Vector3(0.0, 0.58, 0.0), Color(0.70, 0.74, 0.78), "SubBox")
    _box(sub, Vector3(0.94, 0.07, 0.74), Vector3(0.0, 1.06, 0.0), Color(0.30, 0.32, 0.36), "SubLid")
    _box(sub, Vector3(0.92, 0.12, 0.72), Vector3(0.0, 0.62, 0.0), yellow, "SubStripe")
    for sx in [-0.28, 0.0, 0.28]:
        _cylinder(sub, 0.06, 0.07, 0.4, Vector3(float(sx), 1.3, 0.0), Color(0.88, 0.88, 0.9), "SubInsulator")
    _cylinder(hydro_built, 0.07, 0.10, 1.9, Vector3(sub.position.x + 0.95, 0.35, 0.0), Color(0.45, 0.30, 0.16), "PowerPole")
    # Ready-to-collect energy orb.
    hydro_orb = MeshInstance3D.new()
    hydro_orb.name = "EnergyOrb"
    var om := SphereMesh.new()
    om.radius = 0.30
    om.height = 0.60
    om.radial_segments = 12
    om.rings = 6
    hydro_orb.mesh = om
    hydro_orb_mat = StandardMaterial3D.new()
    hydro_orb_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    hydro_orb_mat.albedo_color = Color(0.45, 0.95, 1.0)
    hydro_orb_mat.emission_enabled = true
    hydro_orb_mat.emission = Color(0.4, 0.9, 1.0)
    hydro_orb.material_override = hydro_orb_mat
    hydro_orb.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    hydro_orb.position = Vector3(0.0, 3.0, 0.0)
    hydro_orb.visible = false
    hydro_built.add_child(hydro_orb)
    _label3d(hydro_built, "TIDAL POWER", Vector3(0.0, 3.7, 0.0), 0.011, Color(0.75, 0.97, 1.0))
    # ---- construction site (shown until unlocked) ----
    hydro_site = Node3D.new()
    hydro_site.name = "TidalSite"
    hydro_site.position = HYDRO_POS
    add_child(hydro_site)
    for px in [-1.4, 1.4]:
        for pz in [-1.0, 1.0]:
            _cylinder(hydro_site, 0.15, 0.17, 1.2, Vector3(float(px), -0.05, float(pz)), Color(0.50, 0.40, 0.28), "SitePile")
    _box(hydro_site, Vector3(1.8, 0.1, 0.5), Vector3(0.0, 0.6, 0.0), Color(0.80, 0.62, 0.38), "SitePlank")
    var cone: MeshInstance3D = _cylinder(hydro_site, 0.02, 0.2, 0.5, Vector3(0.0, 0.9, 0.0), Color(0.98, 0.50, 0.12), "SiteCone")
    cone.rotation_degrees.z = 0.0
    _label3d(hydro_site, "Tidal Power Station\nUnlocks at Level %d" % HYDRO_LV, Vector3(0.0, 2.0, 0.0), 0.010, Color(1.0, 0.95, 0.7))
    _update_hydro_visibility()

func _update_hydro_visibility() -> void:
    if hydro_built == null:
        return
    hydro_built.visible = hydro_unlocked
    hydro_site.visible = not hydro_unlocked
    for i in range(hydro_turbines.size()):
        (hydro_turbines[i] as Node3D).visible = i < hydro_level
    for c in hydro_built.get_children():
        if c is MeshInstance3D and str(c.name).begins_with("Catwalk_"):
            (c as MeshInstance3D).visible = int(c.get_meta("unit", 0)) < hydro_level
    _update_lock_buttons()

func _update_hydro(delta: float) -> void:
    boost_irrig = maxf(0.0, boost_irrig - delta)
    boost_oven = maxf(0.0, boost_oven - delta)
    boost_feed = maxf(0.0, boost_feed - delta)
    if not hydro_unlocked or hydro_built == null:
        return
    energy_store = minf(float(_hydro_cap()), energy_store + _hydro_rate() * delta)
    var spin: float = 1.6 + 0.8 * rain
    for r in hydro_rotors:
        (r as Node3D).rotation.z -= spin * delta
    for b in hydro_buoys:
        var bn: Node3D = b["node"]
        bn.position.y = float(b["base"]) + sin(sway_clock * 1.5 + float(b["phase"])) * 0.12
        bn.rotation.z = sin(sway_clock * 1.1 + float(b["phase"])) * 0.12
    var ready: bool = energy_store >= 10.0
    hydro_orb.visible = ready
    if ready:
        hydro_orb.position.y = 3.0 + sin(sway_clock * 3.0) * 0.15
        var pulse: float = 0.75 + 0.25 * sin(sway_clock * 5.0)
        hydro_orb.scale = Vector3.ONE * pulse
    hydro_tick -= delta
    if hydro_tick <= 0.0:
        hydro_tick = 0.5
        _update_pill_extra()
        if hydro_panel != null and hydro_panel.visible:
            _refresh_hydro()

func _update_pill_extra() -> void:
    if pill_extra == null:
        return
    if not hydro_unlocked:
        pill_extra.visible = false
        return
    pill_extra.visible = true
    var t: String = "⚡ %d" % energy
    if boost_irrig > 0.0:
        t += "  💧%d:%02d" % [int(boost_irrig) / 60, int(boost_irrig) % 60]
    if boost_oven > 0.0:
        t += "  🔥%d:%02d" % [int(boost_oven) / 60, int(boost_oven) % 60]
    if boost_feed > 0.0:
        t += "  🌿%d:%02d" % [int(boost_feed) / 60, int(boost_feed) % 60]
    pill_extra.text = t

func _build_hydro_panel() -> void:
    var made: Array = _new_panel("⚡ TIDAL POWER STATION", 0.06, 0.94)
    hydro_panel = made[0]
    var col: VBoxContainer = made[1]
    hydro_info = _panel_label(col, 17, Color(0.85, 0.97, 1.0))
    hydro_buttons.clear()
    for i in range(7):
        var b: Button = _panel_button(col, "", 58, 17)
        b.pressed.connect(_hydro_action.bind(i))
        hydro_buttons.append(b)
    var close: Button = _panel_button(col, "CLOSE", 44, 18)
    close.pressed.connect(_close_panels)

func _energy_sell_value() -> int:
    return int(round(float(20 * (4 + level)) * 0.5))

func _hydro_upgrade_cost() -> int:
    return 700 if hydro_level == 1 else 1800

func _refresh_hydro() -> void:
    if hydro_panel == null:
        return
    hydro_info.text = "Station: %d / %d energy   (+%d per minute%s)\nYour batteries: %d / %d energy" % [int(energy_store), _hydro_cap(), int(round(_hydro_rate() * 60.0)), ", storm bonus" if rain > 0.3 else "", energy, _batt_cap()]
    var labels: Array = [
        "⚡ COLLECT ENERGY (%d)" % int(energy_store),
        "💧 Irrigation Pumps  •  25 energy\nCrops grow 30%% faster for 3 min%s" % ("   [ON %ds]" % int(boost_irrig) if boost_irrig > 0.0 else ""),
        "🔥 Turbo Oven  •  20 energy\nBakery works twice as fast for 3 min%s" % ("   [ON %ds]" % int(boost_oven) if boost_oven > 0.0 else ""),
        "🌿 Feed Boost  •  30 energy\nAnimals and trees produce 2x faster for 3 min%s" % ("   [ON %ds]" % int(boost_feed) if boost_feed > 0.0 else ""),
        "💰 Sell Energy  •  20 energy = %d coins" % _energy_sell_value(),
        "",
        ""
    ]
    if hydro_level == 1:
        labels[5] = "🔧 Upgrade Turbines to Level 2\n%d coins  •  2 turbines, 2x power" % _hydro_upgrade_cost()
    elif hydro_level == 2:
        labels[5] = "🔧 Upgrade Turbines to Level 3\n%d coins  •  3 turbines, 3x power" % _hydro_upgrade_cost()
    else:
        labels[5] = "🔧 Turbines fully upgraded (Level 3)"
    labels[6] = "Tip: storms and rain make the waves stronger."
    for i in range(7):
        var b: Button = hydro_buttons[i]
        b.text = labels[i]
    (hydro_buttons[0] as Button).disabled = int(energy_store) < 1 or energy >= _batt_cap()
    (hydro_buttons[1] as Button).disabled = energy < 25
    (hydro_buttons[2] as Button).disabled = energy < 20
    (hydro_buttons[3] as Button).disabled = energy < 30
    (hydro_buttons[4] as Button).disabled = energy < 20
    (hydro_buttons[5] as Button).disabled = hydro_level >= 3 or coins < _hydro_upgrade_cost() or (hydro_level == 1 and level < 9) or (hydro_level == 2 and level < 11)
    (hydro_buttons[6] as Button).disabled = true

func _hydro_action(i: int) -> void:
    if i == 0:
        var take: int = mini(int(energy_store), _batt_cap() - energy)
        if take <= 0:
            return
        energy += take
        energy_store -= float(take)
        _play_named("ding", -10.0)
        _show_toast("Collected %d energy" % take)
    elif i == 1 and energy >= 25:
        energy -= 25
        boost_irrig = 180.0
        _show_toast("Irrigation pumps ON: crops grow 30% faster")
    elif i == 2 and energy >= 20:
        energy -= 20
        boost_oven = 180.0
        _show_toast("Turbo oven ON: baking is twice as fast")
    elif i == 3 and energy >= 30:
        energy -= 30
        boost_feed = 180.0
        _show_toast("Feed boost ON: animals and trees produce faster")
    elif i == 4 and energy >= 20:
        energy -= 20
        coins += _energy_sell_value()
        _play_named("ding")
        _refresh_ui()
        _show_toast("Sold 20 energy for %d coins" % _energy_sell_value())
    elif i == 5 and hydro_level < 3 and coins >= _hydro_upgrade_cost():
        if (hydro_level == 1 and level < 9) or (hydro_level == 2 and level < 11):
            _show_toast("Reach a higher level to upgrade.")
            return
        coins -= _hydro_upgrade_cost()
        hydro_level += 1
        _update_hydro_visibility()
        _play_named("jingle", -8.0)
        _refresh_ui()
        _show_toast("Turbines upgraded to Level %d!" % hydro_level)
    else:
        return
    _update_pill_extra()
    _refresh_hydro()
    _save_game()

func _open_hydro() -> void:
    if not hydro_unlocked:
        _show_toast("Tidal Power Station unlocks at Level %d (you are Level %d)" % [HYDRO_LV, level])
        return
    _close_panels()
    hydro_panel.visible = true
    _refresh_hydro()

func _tap_hydro(p: Vector2) -> bool:
    var base: Vector2 = Vector2(HYDRO_POS.x, HYDRO_POS.z)
    var hit_station: bool = _dist_to_segment(p, base, base + Vector2(-2.3, -3.4)) < 2.3
    var sb: Vector2 = Vector2(SUBSTATION_POS.x, SUBSTATION_POS.z)
    var hit_sub: bool = _dist_to_segment(p, sb, sb + Vector2(-0.8, -1.2)) < 1.1
    if hit_station or hit_sub:
        _open_hydro()
        return true
    return false

func _extra_unlock_hint() -> String:
    if level < HYDRO_LV:
        return "Next: Tidal Power at Lv %d" % HYDRO_LV
    if level < TRAIN_LV:
        return "Next: Train Network at Lv %d" % TRAIN_LV
    if level < CARRIER_LV:
        return "Next: Aircraft Carrier at Lv %d" % CARRIER_LV
    if level < TRADE_LV:
        return "Next: Trade Centre at Lv %d" % TRADE_LV
    return "All buildings unlocked"

func _save_hydro(config: ConfigFile) -> void:
    config.set_value("farm", "hydro_level", hydro_level)
    config.set_value("farm", "energy", energy)
    config.set_value("farm", "energy_store", energy_store)
    config.set_value("farm", "boosts", [boost_irrig, boost_oven, boost_feed])

func _load_hydro(config: ConfigFile) -> void:
    hydro_level = clampi(int(config.get_value("farm", "hydro_level", 1)), 1, 3)
    energy = clampi(int(config.get_value("farm", "energy", 0)), 0, _batt_cap())
    var saved_at: float = float(config.get_value("farm", "saved_at", 0.0))
    var away: float = 0.0
    if saved_at > 0.0:
        away = maxf(0.0, Time.get_unix_time_from_system() - saved_at)
    energy_store = minf(float(_hydro_cap()), float(config.get_value("farm", "energy_store", 0.0)) + float(HYDRO_RATE[hydro_level - 1]) * away)
    var bs: Variant = config.get_value("farm", "boosts", [0.0, 0.0, 0.0])
    if bs is Array and (bs as Array).size() == 3:
        boost_irrig = maxf(0.0, float((bs as Array)[0]) - away)
        boost_oven = maxf(0.0, float((bs as Array)[1]) - away)
        boost_feed = maxf(0.0, float((bs as Array)[2]) - away)

# =========================================================================
# v24 stage 4: aircraft carrier with auto take-off / landing
# =========================================================================

const CARRIER_POS := Vector3(23.4, -0.55, 14.2)
const HELI_COOLDOWN := 120.0
const DECK_Y := 1.0
const PARK_Y := 1.07

var carrier_unlocked: bool = false
var carrier_root: Node3D
var carrier_site: Node3D
var carrier_btn: Button
var carrier_panel: PanelContainer
var carrier_info: Label
var carrier_buttons: Array = []
var aircraft: Array = []
var carrier_radar: Node3D
var carrier_beacon: MeshInstance3D
var heli_cool: float = 0.0
var heli_request: bool = false
var carrier_tick: float = 0.0
var strobe_mat: StandardMaterial3D

# ------------------------------------------------------------------ paths

func _air_build(wps: Array, deck: bool = true) -> Dictionary:
    var pts := PackedVector3Array()
    var spd := PackedFloat32Array()
    var n: int = wps.size()
    for i in range(n - 1):
        var p0: Vector3 = wps[maxi(i - 1, 0)][0]
        var p1: Vector3 = wps[i][0]
        var p2: Vector3 = wps[i + 1][0]
        var p3: Vector3 = wps[mini(i + 2, n - 1)][0]
        var s1: float = float(wps[i][1])
        var s2: float = float(wps[i + 1][1])
        var steps: int = maxi(2, int(ceil(p1.distance_to(p2) / 0.25)))
        for k in range(steps):
            var t: float = float(k) / float(steps)
            var t2: float = t * t
            var t3: float = t2 * t
            var q: Vector3 = ((p1 * 2.0) + (p2 - p0) * t + (p0 * 2.0 - p1 * 5.0 + p2 * 4.0 - p3) * t2 + (p1 * 3.0 - p0 - p2 * 3.0 + p3) * t3) * 0.5
            # Keep everything above the flight deck while over it.
            if deck and absf(q.x) <= 2.3 and q.z >= -6.9 and q.z <= 6.6 and q.y < PARK_Y:
                q.y = PARK_Y
            pts.append(q)
            spd.append(lerpf(s1, s2, t))
    pts.append(wps[n - 1][0])
    spd.append(float(wps[n - 1][1]))
    var cum := PackedFloat32Array()
    var total: float = 0.0
    for i in range(pts.size()):
        cum.append(total)
        if i + 1 < pts.size():
            total += pts[i].distance_to(pts[i + 1])
    return {"pts": pts, "spd": spd, "cum": cum, "len": total}

func _air_index(path: Dictionary, t: float) -> int:
    var cum: PackedFloat32Array = path["cum"]
    var lo: int = 0
    var hi: int = cum.size() - 1
    while lo < hi:
        var mid: int = (lo + hi + 1) / 2
        if cum[mid] <= t:
            lo = mid
        else:
            hi = mid - 1
    return lo

func _air_at(path: Dictionary, t: float) -> Vector3:
    var pts: PackedVector3Array = path["pts"]
    var cum: PackedFloat32Array = path["cum"]
    var tt: float = clampf(t, 0.0, float(path["len"]))
    var i: int = _air_index(path, tt)
    if i >= pts.size() - 1:
        return pts[pts.size() - 1]
    var seg: float = maxf(0.0001, cum[i + 1] - cum[i])
    return pts[i].lerp(pts[i + 1], (tt - cum[i]) / seg)

func _air_speed(path: Dictionary, t: float) -> float:
    var spd: PackedFloat32Array = path["spd"]
    return spd[mini(_air_index(path, t), spd.size() - 1)]

func _jet_wps(pz: float, wide: float, alt: float) -> Array:
    var w: float = wide
    var up: float = alt
    return [
        [Vector3(-1.5, PARK_Y, pz), 0.5], [Vector3(-1.3, PARK_Y, pz + 0.9), 1.0], [Vector3(-0.6, PARK_Y, pz + 1.9), 2.0],
        [Vector3(-0.3, PARK_Y, pz + 3.3), 3.6], [Vector3(-0.3, PARK_Y, 1.5), 6.0], [Vector3(-0.3, PARK_Y, 4.3), 8.5],
        [Vector3(-0.3, 1.3, 6.8), 9.5], [Vector3(-0.3, 2.2 + up * 0.3, 9.6), 9.5], [Vector3(0.4, 3.6 + up * 0.6, 13.5), 9.0],
        [Vector3(3.0, 4.4 + up, 18.0 + w * 0.5), 8.5], [Vector3(8.0 + w, 5.0 + up, 19.5 + w), 8.5], [Vector3(13.0 + w, 5.2 + up, 14.0 + w * 0.5), 8.5],
        [Vector3(14.0 + w, 5.2 + up, 5.0), 8.5], [Vector3(11.0 + w, 4.9 + up, -5.0), 8.5], [Vector3(5.0 + w * 0.5, 4.6 + up, -14.0 - w * 0.5), 8.0],
        [Vector3(-1.8, 4.0 + up * 0.5, -17.0 - w * 0.5), 7.0], [Vector3(-4.0, 3.5 + up * 0.3, -13.5), 6.0], [Vector3(-1.5, 3.0, -11.5), 5.5],
        [Vector3(-0.5, 2.2, -9.0), 4.6], [Vector3(-0.3, 1.4, -7.4), 3.8], [Vector3(-0.3, PARK_Y, -6.2), 3.2],
        [Vector3(-0.3, PARK_Y, -5.0), 2.2], [Vector3(-0.8, PARK_Y, pz - 0.8), 1.0], [Vector3(-1.5, PARK_Y, pz - 0.2), 0.6], [Vector3(-1.5, PARK_Y, pz), 0.3]
    ]

func _supply_plane_wps() -> Array:
    return [
        [Vector3(-1.5, PARK_Y, 0.8), 0.5], [Vector3(-1.2, PARK_Y, 1.6), 1.0], [Vector3(-0.3, PARK_Y, 2.6), 2.0],
        [Vector3(-0.3, PARK_Y, 4.5), 3.5], [Vector3(-0.3, 1.2, 6.7), 5.0], [Vector3(-0.3, 1.9, 8.7), 5.2],
        [Vector3(1.5, 3.0, 12.5), 5.0], [Vector3(5.5, 3.8, 16.0), 4.8], [Vector3(10.0, 4.2, 14.0), 4.8],
        [Vector3(11.0, 4.2, 6.0), 4.8], [Vector3(8.0, 4.0, -4.0), 4.8], [Vector3(2.0, 3.8, -12.5), 4.6],
        [Vector3(-2.0, 3.4, -14.0), 4.2], [Vector3(-1.0, 2.6, -11.0), 3.6], [Vector3(-0.3, 1.8, -9.0), 3.2],
        [Vector3(-0.3, 1.2, -7.0), 2.8], [Vector3(-0.3, PARK_Y, -6.0), 2.4], [Vector3(-0.3, PARK_Y, -3.0), 1.8],
        [Vector3(-0.5, PARK_Y, -0.5), 1.2], [Vector3(-1.3, PARK_Y, 0.3), 0.8], [Vector3(-1.5, PARK_Y, 0.8), 0.3]
    ]

func _heli_patrol_wps() -> Array:
    return [
        [Vector3(0.95, PARK_Y, 4.0), 0.5], [Vector3(0.95, 2.0, 4.0), 1.4], [Vector3(1.5, 3.4, 4.5), 2.2],
        [Vector3(5.0, 4.0, 9.0), 3.0], [Vector3(9.0, 4.2, 6.0), 3.0], [Vector3(8.0, 4.2, -2.0), 3.0],
        [Vector3(3.0, 3.9, -6.0), 3.0], [Vector3(-2.0, 3.6, -3.0), 2.6], [Vector3(-1.0, 3.5, 1.0), 2.2],
        [Vector3(0.95, 3.0, 3.8), 1.6], [Vector3(0.95, 2.0, 4.0), 1.0], [Vector3(0.95, PARK_Y, 4.0), 0.5]
    ]

func _heli_supply_wps() -> Array:
    return [
        [Vector3(0.95, PARK_Y, 4.0), 0.5], [Vector3(0.95, 2.0, 4.0), 1.4], [Vector3(0.95, 3.4, 4.0), 2.4],
        [Vector3(-3.0, 3.8, 1.0), 3.4], [Vector3(-7.0, 3.6, -2.0), 3.4], [Vector3(-9.8, 3.2, -3.4), 1.6],
        [Vector3(-10.4, 3.1, -3.6), 0.35], [Vector3(-10.4, 3.1, -3.6), 0.35], [Vector3(-8.0, 3.5, -2.0), 1.4],
        [Vector3(-4.0, 3.7, 1.0), 3.2], [Vector3(-0.5, 3.4, 3.4), 2.4], [Vector3(0.95, 3.0, 4.0), 1.6],
        [Vector3(0.95, 2.0, 4.0), 1.0], [Vector3(0.95, PARK_Y, 4.0), 0.5]
    ]

# ------------------------------------------------------------------ models

func _strobe_material() -> StandardMaterial3D:
    if strobe_mat == null:
        strobe_mat = StandardMaterial3D.new()
        strobe_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
        strobe_mat.albedo_color = Color(1.0, 0.95, 0.9)
    return strobe_mat

func _build_jet(body: Color, stripe: Color) -> Dictionary:
    var j := Node3D.new()
    j.name = "Jet"
    var glass: Color = Color(0.33, 0.62, 0.86)
    _ellipsoid(j, Vector3(0.44, 0.07, 0.07), Vector3(0.0, 0.2, 0.0), body, "JetBody")
    _ellipsoid(j, Vector3(0.14, 0.05, 0.05), Vector3(0.44, 0.2, 0.0), body.darkened(0.15), "JetNose")
    var cp: MeshInstance3D = _ellipsoid(j, Vector3(0.15, 0.05, 0.05), Vector3(0.14, 0.26, 0.0), glass, "JetCanopy")
    cp.material_override = _window_material()
    for s in [-1.0, 1.0]:
        var wing: MeshInstance3D = _box(j, Vector3(0.34, 0.02, 0.52), Vector3(-0.05, 0.19, float(s) * 0.30), body.lightened(0.05), "JetWing")
        wing.rotation_degrees.y = -float(s) * 32.0
        _box(j, Vector3(0.16, 0.02, 0.05), Vector3(-0.07, 0.205, float(s) * 0.52), stripe, "JetWingTip")
        var fin: MeshInstance3D = _box(j, Vector3(0.18, 0.2, 0.02), Vector3(-0.36, 0.31, float(s) * 0.05), stripe, "JetFin")
        fin.rotation_degrees.x = float(s) * 14.0
        _box(j, Vector3(0.12, 0.015, 0.2), Vector3(-0.38, 0.2, float(s) * 0.14), body.darkened(0.1), "JetStab")
    var glow: MeshInstance3D = _sphere(j, 0.05, 0.1, Vector3(-0.48, 0.2, 0.0), Color(1.0, 0.65, 0.2), "JetGlow")
    glow.material_override = _strobe_material()
    glow.visible = false
    var strobe: MeshInstance3D = _sphere(j, 0.03, 0.06, Vector3(-0.32, 0.4, 0.0), Color(1, 1, 1), "JetStrobe")
    strobe.material_override = _strobe_material()
    var gear := Node3D.new()
    gear.name = "Gear"
    j.add_child(gear)
    for gp in [Vector3(0.22, 0.07, 0.0), Vector3(-0.14, 0.07, 0.1), Vector3(-0.14, 0.07, -0.1)]:
        _cylinder(gear, 0.035, 0.035, 0.05, gp, Color(0.12, 0.12, 0.14), "JetWheel").rotation.x = PI * 0.5
    j.scale = Vector3.ONE * 1.2
    return {"node": j, "glow": glow, "strobe": strobe, "gear": gear}

func _build_supply_plane() -> Dictionary:
    var pl := Node3D.new()
    pl.name = "SupplyPlane"
    var white: Color = Color(0.96, 0.95, 0.92)
    var orange: Color = Color(0.95, 0.52, 0.16)
    _ellipsoid(pl, Vector3(0.46, 0.11, 0.11), Vector3(0.0, 0.22, 0.0), white, "PlaneBody")
    _ellipsoid(pl, Vector3(0.14, 0.10, 0.10), Vector3(0.40, 0.22, 0.0), orange, "PlaneNose")
    var wing: MeshInstance3D = _box(pl, Vector3(0.30, 0.025, 1.36), Vector3(0.05, 0.37, 0.0), orange, "PlaneWing")
    wing.rotation_degrees.z = 0.0
    for s in [-1.0, 1.0]:
        _box(pl, Vector3(0.03, 0.15, 0.03), Vector3(0.1, 0.30, float(s) * 0.15), Color(0.5, 0.5, 0.55), "PlaneStrut")
        var wn: MeshInstance3D = _box(pl, Vector3(0.14, 0.09, 0.012), Vector3(0.2, 0.27, float(s) * 0.112), Color(0.33, 0.76, 0.92), "PlaneWin")
        wn.material_override = _window_material()
    _box(pl, Vector3(0.20, 0.28, 0.025), Vector3(-0.44, 0.38, 0.0), orange, "PlaneFin")
    _box(pl, Vector3(0.16, 0.02, 0.52), Vector3(-0.44, 0.26, 0.0), white, "PlaneStab")
    var prop := Node3D.new()
    prop.name = "Prop"
    prop.position = Vector3(0.54, 0.22, 0.0)
    pl.add_child(prop)
    _box(prop, Vector3(0.02, 0.56, 0.05), Vector3.ZERO, Color(0.15, 0.15, 0.17), "Blade")
    _box(prop, Vector3(0.02, 0.05, 0.56), Vector3.ZERO, Color(0.15, 0.15, 0.17), "Blade")
    var strobe: MeshInstance3D = _sphere(pl, 0.03, 0.06, Vector3(-0.42, 0.55, 0.0), Color(1, 1, 1), "PlaneStrobe")
    strobe.material_override = _strobe_material()
    var gear := Node3D.new()
    gear.name = "Gear"
    pl.add_child(gear)
    for gp in [Vector3(0.2, 0.08, 0.1), Vector3(0.2, 0.08, -0.1), Vector3(-0.38, 0.08, 0.0)]:
        _cylinder(gear, 0.04, 0.04, 0.04, gp, Color(0.12, 0.12, 0.14), "PlaneWheel").rotation.x = PI * 0.5
    pl.scale = Vector3.ONE * 1.1
    return {"node": pl, "prop": prop, "strobe": strobe, "gear": gear}

func _build_heli() -> Dictionary:
    var h := Node3D.new()
    h.name = "Helicopter"
    var navy: Color = Color(0.30, 0.36, 0.46)
    var orange: Color = Color(0.96, 0.55, 0.15)
    _ellipsoid(h, Vector3(0.36, 0.21, 0.21), Vector3(0.0, 0.36, 0.0), navy, "HeliBody")
    _ellipsoid(h, Vector3(0.20, 0.14, 0.215), Vector3(0.0, 0.30, 0.0), orange, "HeliStripe")
    var ws: MeshInstance3D = _ellipsoid(h, Vector3(0.15, 0.13, 0.17), Vector3(0.24, 0.40, 0.0), Color(0.33, 0.76, 0.92), "HeliGlass")
    ws.material_override = _window_material()
    var boom: MeshInstance3D = _box(h, Vector3(0.72, 0.07, 0.07), Vector3(-0.56, 0.44, 0.0), navy, "HeliBoom")
    boom.rotation_degrees.z = 4.0
    _box(h, Vector3(0.10, 0.24, 0.02), Vector3(-0.92, 0.52, 0.0), orange, "HeliTailFin")
    var trot := Node3D.new()
    trot.name = "TailRotor"
    trot.position = Vector3(-0.94, 0.56, 0.04)
    h.add_child(trot)
    _box(trot, Vector3(0.03, 0.30, 0.012), Vector3.ZERO, Color(0.15, 0.15, 0.17), "TailBlade")
    _cylinder(h, 0.03, 0.04, 0.16, Vector3(0.0, 0.62, 0.0), Color(0.2, 0.2, 0.24), "HeliMast")
    var rotor := Node3D.new()
    rotor.name = "MainRotor"
    rotor.position = Vector3(0.0, 0.72, 0.0)
    h.add_child(rotor)
    _box(rotor, Vector3(1.3, 0.015, 0.075), Vector3.ZERO, Color(0.15, 0.15, 0.17), "RotorBlade")
    var rb2: MeshInstance3D = _box(rotor, Vector3(1.3, 0.015, 0.075), Vector3.ZERO, Color(0.15, 0.15, 0.17), "RotorBlade")
    rb2.rotation_degrees.y = 90.0
    for s in [-1.0, 1.0]:
        _box(h, Vector3(0.62, 0.025, 0.03), Vector3(0.0, 0.07, float(s) * 0.16), Color(0.2, 0.2, 0.24), "Skid")
        _box(h, Vector3(0.03, 0.2, 0.03), Vector3(0.16, 0.17, float(s) * 0.15), Color(0.2, 0.2, 0.24), "SkidStrut")
        _box(h, Vector3(0.03, 0.2, 0.03), Vector3(-0.16, 0.17, float(s) * 0.15), Color(0.2, 0.2, 0.24), "SkidStrut")
    var strobe: MeshInstance3D = _sphere(h, 0.03, 0.06, Vector3(-0.9, 0.66, 0.0), Color(1, 1, 1), "HeliStrobe")
    strobe.material_override = _strobe_material()
    # Supply crate hanging below on a short rope (shown on delivery runs).
    var crate := Node3D.new()
    crate.name = "SupplyCrate"
    h.add_child(crate)
    _box(crate, Vector3(0.015, 0.34, 0.015), Vector3(0.0, -0.05, 0.0), Color(0.25, 0.25, 0.25), "Rope")
    _box(crate, Vector3(0.34, 0.26, 0.34), Vector3(0.0, -0.30, 0.0), Color(0.86, 0.62, 0.30), "Crate")
    _box(crate, Vector3(0.36, 0.05, 0.36), Vector3(0.0, -0.30, 0.0), Color(0.55, 0.38, 0.20), "CrateBand")
    crate.visible = false
    h.scale = Vector3.ONE * 0.95
    return {"node": h, "rotor": rotor, "trot": trot, "strobe": strobe, "crate": crate}

func _build_carrier() -> void:
    carrier_root = Node3D.new()
    carrier_root.name = "AircraftCarrier"
    carrier_root.position = CARRIER_POS
    add_child(carrier_root)
    var grey: Color = Color(0.56, 0.60, 0.66)
    var dark: Color = Color(0.24, 0.12, 0.12)
    var st := SurfaceTool.new()
    st.begin(Mesh.PRIMITIVE_TRIANGLES)
    _loft_hull(st, -6.8, 6.7, 2.0, -0.9, 0.85, 0.12, -0.12, grey, dark, Color(0.34, 0.36, 0.40))
    # Flight deck slab overhanging the hull.
    var deck_pts: Array = [Vector2(-2.3, -6.9), Vector2(2.3, -6.9), Vector2(2.3, 3.6), Vector2(1.1, 6.6), Vector2(-1.1, 6.6), Vector2(-2.3, 3.6)]
    _prism_into(st, deck_pts, 0.84, DECK_Y, Color(0.34, 0.36, 0.40))
    # Deck markings: runway edges, dashed centre line, arrester-wire stripes.
    for lx in [-0.88, 0.28]:
        _prism_into(st, [Vector2(float(lx) - 0.025, -6.5), Vector2(float(lx) + 0.025, -6.5), Vector2(float(lx) + 0.025, 5.4), Vector2(float(lx) - 0.025, 5.4)], DECK_Y, DECK_Y + 0.012, Color(0.95, 0.80, 0.18))
    var zc: float = -6.0
    while zc < 5.6:
        _prism_into(st, [Vector2(-0.33, zc), Vector2(-0.27, zc), Vector2(-0.27, zc + 0.5), Vector2(-0.33, zc + 0.5)], DECK_Y, DECK_Y + 0.012, Color(0.95, 0.95, 0.95))
        zc += 1.0
    for wz in [-5.7, -5.2, -4.7]:
        _prism_into(st, [Vector2(-0.88, float(wz)), Vector2(0.28, float(wz)), Vector2(0.28, float(wz) + 0.04), Vector2(-0.88, float(wz) + 0.04)], DECK_Y, DECK_Y + 0.012, Color(0.85, 0.85, 0.88))
    # Island superstructure on the starboard side.
    _prism_into(st, [Vector2(1.15, -3.9), Vector2(2.25, -3.9), Vector2(2.25, -1.2), Vector2(1.15, -1.2)], DECK_Y, 1.85, Color(0.64, 0.67, 0.72))
    _prism_into(st, [Vector2(1.25, -3.6), Vector2(2.2, -3.6), Vector2(2.2, -1.5), Vector2(1.25, -1.5)], 1.85, 2.35, Color(0.92, 0.93, 0.95))
    _prism_into(st, [Vector2(1.35, -3.2), Vector2(2.0, -3.2), Vector2(2.0, -1.9), Vector2(1.35, -1.9)], 2.35, 2.65, Color(0.64, 0.67, 0.72))
    var hull_node := MeshInstance3D.new()
    hull_node.name = "CarrierHull"
    hull_node.mesh = st.commit()
    var hm := StandardMaterial3D.new()
    hm.vertex_color_use_as_albedo = true
    hm.roughness = 0.85
    hm.cull_mode = BaseMaterial3D.CULL_DISABLED
    hull_node.material_override = hm
    carrier_root.add_child(hull_node)
    # Helipad.
    _disc(carrier_root, 0.64, 0.02, Vector3(0.95, DECK_Y + 0.012, 4.0), Color(0.95, 0.95, 0.95), "PadRing", 0.9, 20)
    _disc(carrier_root, 0.56, 0.02, Vector3(0.95, DECK_Y + 0.024, 4.0), Color(0.28, 0.30, 0.34), "PadInner", 0.9, 20)
    _box(carrier_root, Vector3(0.07, 0.02, 0.46), Vector3(0.82, DECK_Y + 0.045, 4.0), Color(0.95, 0.95, 0.95), "PadH")
    _box(carrier_root, Vector3(0.07, 0.02, 0.46), Vector3(1.08, DECK_Y + 0.045, 4.0), Color(0.95, 0.95, 0.95), "PadH")
    _box(carrier_root, Vector3(0.26, 0.02, 0.07), Vector3(0.95, DECK_Y + 0.045, 4.0), Color(0.95, 0.95, 0.95), "PadH")
    # Bridge windows, mast, radar, beacon.
    for wz in [-1.46, -3.64]:
        var bw: MeshInstance3D = _box(carrier_root, Vector3(0.8, 0.14, 0.02), Vector3(1.72, 2.12, float(wz)), Color(0.33, 0.76, 0.92), "BridgeWin")
        bw.material_override = _window_material()
    var sw: MeshInstance3D = _box(carrier_root, Vector3(0.02, 0.14, 1.4), Vector3(1.19, 2.12, -2.55), Color(0.33, 0.76, 0.92), "BridgeWin")
    sw.material_override = _window_material()
    _cylinder(carrier_root, 0.035, 0.045, 1.1, Vector3(1.7, 3.15, -2.55), Color(0.78, 0.78, 0.8), "Mast")
    carrier_radar = Node3D.new()
    carrier_radar.position = Vector3(1.7, 3.5, -2.55)
    carrier_root.add_child(carrier_radar)
    _box(carrier_radar, Vector3(0.55, 0.07, 0.05), Vector3.ZERO, Color(0.85, 0.86, 0.88), "RadarArm")
    _box(carrier_radar, Vector3(0.08, 0.1, 0.1), Vector3(0.0, -0.06, 0.0), Color(0.5, 0.5, 0.55), "RadarHub")
    carrier_beacon = _sphere(carrier_root, 0.06, 0.12, Vector3(1.7, 3.75, -2.55), Color(1.0, 0.2, 0.15), "Beacon")
    var bm := StandardMaterial3D.new()
    bm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    bm.albedo_color = Color(1.0, 0.2, 0.15)
    carrier_beacon.material_override = bm
    _box(carrier_root, Vector3(0.5, 0.3, 0.02), Vector3(1.96, 3.35, -2.55), Color(0.85, 0.15, 0.15), "Pennant")
    # Funnel.
    _disc(carrier_root, 0.20, 0.55, Vector3(2.0, 2.9, -1.7), Color(0.40, 0.42, 0.46), "CarrierFunnel", 0.8, 12, 0.17)
    # Radomes, orange boats and deck-edge lights.
    for sp in [Vector3(-2.0, 1.12, -6.2), Vector3(2.0, 1.12, 4.8), Vector3(-2.0, 1.12, 4.0)]:
        _sphere(carrier_root, 0.20, 0.34, sp, Color(0.95, 0.95, 0.97), "Radome")
    for bz in [0.6, 2.2]:
        _ellipsoid(carrier_root, Vector3(0.14, 0.09, 0.45), Vector3(2.12, 0.72, float(bz)), Color(0.96, 0.55, 0.14), "Lifeboat")
    var lz: float = -6.4
    while lz < 5.0:
        for lx in [-2.25, 2.25]:
            var ls: MeshInstance3D = _sphere(carrier_root, 0.045, 0.09, Vector3(float(lx), DECK_Y + 0.05, lz), Color(1.0, 0.93, 0.62), "DeckLight")
            ls.material_override = _lamp_material()
        lz += 1.6
    for pz in range(-5, 6, 2):
        for ps in [-1.0, 1.0]:
            _box(carrier_root, Vector3(0.04, 0.07, 0.12), Vector3(float(ps) * 1.99, 0.55, float(pz)), Color(0.15, 0.17, 0.22), "Porthole")
    # Foam around the hull and a short wake.
    _ellipsoid(carrier_root, Vector3(2.5, 0.015, 7.3), Vector3(0.0, -0.05, 0.0), Color(0.93, 0.98, 1.0), "CarrierFoam")
    _ellipsoid(carrier_root, Vector3(1.0, 0.015, 3.2), Vector3(0.0, -0.05, -9.8), Color(0.88, 0.96, 1.0), "CarrierWake")
    _label3d(carrier_root, "CARRIER", Vector3(0.0, 4.4, 0.0), 0.011, Color(0.85, 0.95, 1.0))
    # Aircraft.
    aircraft.clear()
    var ja: Dictionary = _build_jet(Color(0.62, 0.68, 0.76), Color(0.85, 0.20, 0.18))
    var jb: Dictionary = _build_jet(Color(0.70, 0.72, 0.74), Color(0.20, 0.42, 0.82))
    var sp_a: Dictionary = _build_supply_plane()
    var he: Dictionary = _build_heli()
    for d in [ja, jb, sp_a, he]:
        carrier_root.add_child(d["node"])
    var p_ja: Dictionary = _air_build(_jet_wps(-4.0, 0.0, 0.0))
    var p_jb: Dictionary = _air_build(_jet_wps(-1.6, 1.6, 0.7))
    var p_sp: Dictionary = _air_build(_supply_plane_wps())
    var p_hp: Dictionary = _air_build(_heli_patrol_wps())
    var p_hs: Dictionary = _air_build(_heli_supply_wps())
    aircraft.append({"kind": 0, "d": ja, "node": ja["node"], "path": p_ja, "state": 0, "t": 0.0, "speed": 0.0, "timer": 6.0, "pre": 0.0, "rot": 0.0, "yaw": -PI * 0.5, "cool": 28.0})
    aircraft.append({"kind": 0, "d": jb, "node": jb["node"], "path": p_jb, "state": 0, "t": 0.0, "speed": 0.0, "timer": 21.0, "pre": 0.0, "rot": 0.0, "yaw": -PI * 0.5, "cool": 34.0})
    aircraft.append({"kind": 1, "d": sp_a, "node": sp_a["node"], "path": p_sp, "state": 0, "t": 0.0, "speed": 0.0, "timer": 34.0, "pre": 0.0, "rot": 0.0, "yaw": -PI * 0.5, "cool": 55.0})
    aircraft.append({"kind": 2, "d": he, "node": he["node"], "path": p_hp, "patrol": p_hp, "supply": p_hs, "state": 0, "t": 0.0, "speed": 0.0, "timer": 12.0, "pre": 0.0, "rot": 0.0, "yaw": -PI * 0.5, "cool": 65.0, "mission": 0, "paid": false})
    for a in aircraft:
        _air_pose(a, 0.0)
    # Locked-site marker out at sea.
    carrier_site = Node3D.new()
    carrier_site.name = "CarrierSite"
    carrier_site.position = Vector3(CARRIER_POS.x, -0.5, CARRIER_POS.z)
    add_child(carrier_site)
    for bp in [Vector3(-2.2, 0.0, -6.0), Vector3(2.2, 0.0, -6.0), Vector3(-2.2, 0.0, 6.0), Vector3(2.2, 0.0, 6.0)]:
        _sphere(carrier_site, 0.28, 0.44, bp, Color(0.92, 0.28, 0.20), "SiteBuoy")
    _make_sign(carrier_site, Vector3(0.0, -0.1, 0.0), "Aircraft Carrier\nLevel %d" % CARRIER_LV)
    carrier_root.visible = false

# ------------------------------------------------------------------ motion

func _air_pose(a: Dictionary, delta: float) -> void:
    var path: Dictionary = a["path"]
    var t: float = float(a["t"])
    var p: Vector3 = _air_at(path, t)
    var p2: Vector3 = _air_at(path, t + 0.4)
    var d: Vector3 = p2 - p
    var node: Node3D = a["node"]
    var hl: float = Vector2(d.x, d.z).length()
    var yaw: float = float(a["yaw"])
    if hl > 0.03:
        var ty: float = atan2(-d.z, d.x)
        yaw = ty if delta <= 0.0 else lerp_angle(yaw, ty, clampf(delta * (3.0 if int(a["kind"]) == 2 else 8.0), 0.0, 1.0))
    a["yaw"] = yaw
    var pitch: float = 0.0
    var roll: float = 0.0
    if int(a["kind"]) == 3:
        roll = sin(sway_clock * 1.3) * 0.04
        pitch = sin(sway_clock * 1.1) * 0.03
    elif int(a["kind"]) == 2:
        pitch = -0.16 * clampf(float(a["speed"]) / 3.0, 0.0, 1.0)
        var p3: Vector3 = _air_at(path, t + 1.6)
        var h3: float = atan2(-(p3.z - p2.z), p3.x - p2.x)
        roll = clampf(-wrapf(h3 - yaw, -PI, PI) * 0.35, -0.3, 0.3) if hl > 0.03 else 0.0
    else:
        if hl > 0.03:
            pitch = clampf(atan2(d.y, hl), -0.45, 0.45)
        var p3: Vector3 = _air_at(path, t + 1.4)
        var h3: float = atan2(-(p3.z - p2.z), p3.x - p2.x)
        var h2: float = atan2(-(p2.z - p.z), p2.x - p.x)
        if p.y > PARK_Y + 0.25:
            roll = clampf(wrapf(h3 - h2, -PI, PI) * 1.1, -0.65, 0.65)
    node.position = p
    node.rotation = Vector3(roll, yaw, pitch)
    var high: bool = p.y > PARK_Y + 0.5
    var dd: Dictionary = a["d"]
    if dd.has("gear"):
        (dd["gear"] as Node3D).visible = not high or float(a["speed"]) < 4.0 and p.y < 2.0
    if dd.has("glow"):
        (dd["glow"] as Node3D).visible = float(a["state"]) == 1.0 and float(a["speed"]) > 4.0

func _start_flight(a: Dictionary, mission: int) -> void:
    a["state"] = 2
    a["pre"] = 2.4 if int(a["kind"]) == 2 else 1.4
    a["t"] = 0.0
    a["speed"] = 0.0
    if int(a["kind"]) == 2:
        a["mission"] = mission
        a["path"] = a["supply"] if mission == 1 else a["patrol"]
        a["paid"] = false
        (a["d"]["crate"] as Node3D).visible = mission == 1
    if int(a["kind"]) == 1 or int(a["kind"]) == 0:
        _play_named("bell", -22.0)

func _launch_all() -> void:
    for a in aircraft:
        if int(a["state"]) == 0 and int(a["kind"]) != 2:
            a["timer"] = float(randi() % 4) * 1.8

func _heli_supply_request() -> bool:
    if heli_cool > 0.0:
        return false
    var he: Dictionary = aircraft[3]
    if int(he["state"]) != 0:
        heli_request = true
        return true
    _start_flight(he, 1)
    heli_cool = HELI_COOLDOWN
    return true

func _update_carrier(delta: float) -> void:
    heli_cool = maxf(0.0, heli_cool - delta)
    if not carrier_unlocked or carrier_root == null:
        return
    carrier_radar.rotation.y += 2.2 * delta
    carrier_beacon.visible = fmod(sway_clock, 1.4) < 0.7
    var strobe_on: bool = fmod(sway_clock, 1.2) < 0.12
    _strobe_material().albedo_color = Color(1, 1, 1) if strobe_on else Color(0.35, 0.2, 0.2)
    for a in aircraft:
        var st: int = int(a["state"])
        var kind: int = int(a["kind"])
        var dd: Dictionary = a["d"]
        if st == 0:
            a["timer"] = float(a["timer"]) - delta
            a["rot"] = move_toward(float(a["rot"]), 0.0, delta * 0.5)
            if kind == 2 and heli_request and heli_cool <= 0.0:
                heli_request = false
                _start_flight(a, 1)
                heli_cool = HELI_COOLDOWN
            elif float(a["timer"]) <= 0.0:
                _start_flight(a, 0)
        elif st == 2:
            a["pre"] = float(a["pre"]) - delta
            a["rot"] = move_toward(float(a["rot"]), 1.0, delta * 0.6)
            if float(a["pre"]) <= 0.0:
                a["state"] = 1
        else:
            var path: Dictionary = a["path"]
            var tgt: float = _air_speed(path, float(a["t"]))
            a["speed"] = move_toward(float(a["speed"]), tgt, 6.0 * delta)
            a["t"] = float(a["t"]) + float(a["speed"]) * delta
            a["rot"] = move_toward(float(a["rot"]), 1.0, delta)
            if kind == 2 and int(a["mission"]) == 1:
                var drop_t: float = float(path["len"]) * 0.50
                var crate: Node3D = dd["crate"]
                crate.visible = float(a["t"]) < drop_t
                if not bool(a["paid"]) and float(a["t"]) >= drop_t:
                    a["paid"] = true
                    _heli_reward()
            if float(a["t"]) >= float(path["len"]):
                a["state"] = 0
                a["t"] = 0.0
                a["speed"] = 0.0
                a["timer"] = float(a["cool"]) * randf_range(0.7, 1.3)
                if kind == 2:
                    (dd["crate"] as Node3D).visible = false
                    a["path"] = a["patrol"]
        _air_pose(a, delta)
        if dd.has("prop"):
            (dd["prop"] as Node3D).rotation.x += 45.0 * float(a["rot"]) * delta
        if dd.has("rotor"):
            (dd["rotor"] as Node3D).rotation.y += 34.0 * float(a["rot"]) * delta
            (dd["trot"] as Node3D).rotation.z += 40.0 * float(a["rot"]) * delta
    carrier_tick -= delta
    if carrier_tick <= 0.0:
        carrier_tick = 0.5
        if carrier_panel != null and carrier_panel.visible:
            _refresh_carrier()

func _heli_reward() -> void:
    var pay: int = 40 + 8 * level
    var sd: int = 2 + level / 3
    coins += pay
    seeds += sd
    _add_xp(8)
    _quest_event("collect", 1)
    _play_named("ding")
    _refresh_ui()
    _show_toast("Supply helicopter delivered!\n+%d coins, +%d seeds, +8 XP" % [pay, sd])
    _save_game()

# ------------------------------------------------------------------ panel

func _update_carrier_visibility() -> void:
    if carrier_root == null:
        return
    carrier_root.visible = carrier_unlocked
    carrier_site.visible = not carrier_unlocked
    _update_lock_buttons()

func _build_carrier_panel() -> void:
    var made: Array = _new_panel("✈ AIRCRAFT CARRIER", 0.10, 0.90)
    carrier_panel = made[0]
    var col: VBoxContainer = made[1]
    carrier_info = _panel_label(col, 17, Color(0.86, 0.95, 1.0))
    carrier_buttons.clear()
    for i in range(3):
        var b: Button = _panel_button(col, "", 62, 17)
        b.pressed.connect(_carrier_action.bind(i))
        carrier_buttons.append(b)
    var close: Button = _panel_button(col, "CLOSE", 44, 18)
    close.pressed.connect(_close_panels)

func _refresh_carrier() -> void:
    if carrier_panel == null:
        return
    carrier_info.text = "Peaceful rescue carrier\nAir wing: 2 jets, 1 supply plane, 1 helicopter\nPlanes take off and land by themselves."
    var he: Dictionary = aircraft[3]
    var busy: bool = int(he["state"]) != 0
    var b0: Button = carrier_buttons[0]
    if heli_cool > 0.0:
        b0.text = "🚁 Supply helicopter is resting (%d s)" % int(ceil(heli_cool))
    elif busy:
        b0.text = "🚁 Send supply run (helicopter will go after landing)"
    else:
        b0.text = "🚁 Send supply helicopter to the farm\n+%d coins and +%d seeds" % [40 + 8 * level, 2 + level / 3]
    b0.disabled = heli_cool > 0.0
    (carrier_buttons[1] as Button).text = "✈ Launch the air wing now"
    (carrier_buttons[2] as Button).text = "📷 Show me the carrier"
    (carrier_buttons[2] as Button).disabled = false

func _carrier_action(i: int) -> void:
    if i == 0:
        if _heli_supply_request():
            _show_toast("Helicopter is taking off with supplies!")
            _close_panels()
    elif i == 1:
        _launch_all()
        _play_named("horn", -12.0)
        _show_toast("Air wing launching!")
        _close_panels()
    elif i == 2:
        cam_target = Vector3(CARRIER_POS.x - 1.5, 0.25, CARRIER_POS.z)
        cam_zoom = 13.0
        _update_camera()
        _close_panels()
    _refresh_carrier()

func _open_carrier() -> void:
    if not carrier_unlocked:
        _show_toast("Aircraft Carrier unlocks at Level %d (you are Level %d)" % [CARRIER_LV, level])
        return
    _close_panels()
    carrier_panel.visible = true
    _refresh_carrier()

func _tap_carrier(p: Vector2) -> bool:
    var dx: float = absf(p.x - CARRIER_POS.x)
    var dz: float = absf(p.y - CARRIER_POS.z)
    if dx < 3.2 and dz < 8.0:
        _open_carrier()
        return true
    return false

func _save_carrier(config: ConfigFile) -> void:
    config.set_value("farm", "heli_cool", heli_cool)

func _load_carrier(config: ConfigFile) -> void:
    heli_cool = clampf(float(config.get_value("farm", "heli_cool", 0.0)), 0.0, HELI_COOLDOWN)

# ------------------------------------------------------------ v24 draw-call bake

func _collect_meshes(n: Node, skip: Dictionary, out: Array) -> void:
    if skip.has(n.get_instance_id()):
        return
    if n is MeshInstance3D and (n as MeshInstance3D).mesh != null and (n as MeshInstance3D).material_override != null:
        out.append(n)
    for c in n.get_children():
        _collect_meshes(c, skip, out)

func _bake_local(root: Node3D, protect: Array, label: String) -> void:
    # Merge a feature's static meshes into one mesh per material (in the node's own space).
    var skip: Dictionary = {}
    for pn in protect:
        if pn != null and is_instance_valid(pn):
            skip[(pn as Node).get_instance_id()] = true
    var list: Array = []
    _collect_meshes(root, skip, list)
    if list.size() < 3:
        return
    _merge_nodes(list, label, root)

var bake_flat: Dictionary = {}
var bake_vc: StandardMaterial3D

func _bake_vc_material() -> StandardMaterial3D:
    if bake_vc == null:
        bake_vc = StandardMaterial3D.new()
        bake_vc.vertex_color_use_as_albedo = true
        bake_vc.vertex_color_is_srgb = true
        bake_vc.roughness = 0.9
    return bake_vc

func _bake_v24() -> void:
    bake_flat.clear()
    for m in mat_cache.values():
        bake_flat[(m as Object).get_instance_id()] = true
    var hp: Array = []
    hp.append_array(hydro_turbines)
    hp.append_array(hydro_rotors)
    hp.append(hydro_orb)
    for b in hydro_buoys:
        hp.append(b["node"])
    for c in hydro_built.get_children():
        if str(c.name).begins_with("Catwalk_"):
            hp.append(c)
    _bake_local(hydro_built, hp, "HydroBake")
    for s in train_stops:
        _bake_local(s["node"], [], "StationBake")
    for car in train_cars:
        _bake_local(car, [], "CarBake")
    var cp: Array = [carrier_radar, carrier_beacon]
    for a in aircraft:
        cp.append(a["node"])
    _bake_local(carrier_root, cp, "CarrierBake")
    for a in aircraft:
        var dd: Dictionary = a["d"]
        var ap: Array = []
        for k in ["glow", "strobe", "gear", "prop", "rotor", "trot", "crate"]:
            if dd.has(k):
                ap.append(dd[k])
        _bake_local(a["node"], ap, "AirBake")
    _bake_local(trade_built, [trade_beacon], "TradeBake")
    _bake_local(trade_root.get_node("Runway"), [trade_windsock], "RunwayBake")
    for m in range(1, 5):
        var tv: Dictionary = trade_veh[m]
        var td: Dictionary = tv["d"]
        var tp: Array = []
        for k in ["rotors", "rotor", "trot", "strobe", "crate", "prop", "gear"]:
            if td.has(k):
                if td[k] is Array:
                    tp.append_array(td[k])
                else:
                    tp.append(td[k])
        _bake_local(tv["node"], tp, "TradeVehBake")

# ------------------------------------------------------------ crop picker bar

var crop_bar: PanelContainer
var crop_bar_buttons: Array = []
var crop_bar_seeds: Label

func _build_crop_bar(root: Control) -> void:
    crop_bar = PanelContainer.new()
    crop_bar.anchor_left = 0.14
    crop_bar.anchor_right = 0.86
    crop_bar.anchor_top = 1.0
    crop_bar.anchor_bottom = 1.0
    crop_bar.offset_top = -196.0
    crop_bar.offset_bottom = -110.0
    crop_bar.add_theme_stylebox_override("panel", _flat(Color(0.99, 0.94, 0.83, 0.95), 18, Color(0.86, 0.66, 0.44), 3, 6.0))
    crop_bar.visible = false
    root.add_child(crop_bar)
    var row := HBoxContainer.new()
    row.add_theme_constant_override("separation", 8)
    crop_bar.add_child(row)
    crop_bar_seeds = Label.new()
    crop_bar_seeds.add_theme_font_size_override("font_size", 18)
    crop_bar_seeds.add_theme_color_override("font_color", Color(0.38, 0.24, 0.12))
    crop_bar_seeds.custom_minimum_size = Vector2(96.0, 0.0)
    crop_bar_seeds.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    crop_bar_seeds.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    row.add_child(crop_bar_seeds)
    crop_bar_buttons.clear()
    for i in range(crop_defs.size()):
        var b := Button.new()
        b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        b.custom_minimum_size = Vector2(0.0, 70.0)
        b.add_theme_font_size_override("font_size", 17)
        b.pressed.connect(_pick_crop_bar.bind(i))
        row.add_child(b)
        crop_bar_buttons.append(b)
    var cx := _make_close_x()
    cx.pressed.disconnect(_close_panels)
    cx.pressed.connect(_dismiss_crop_bar)
    cx.size_flags_vertical = Control.SIZE_SHRINK_BEGIN
    row.add_child(cx)
    _refresh_crop_bar()

var crop_bar_dismissed: bool = true

func _dismiss_crop_bar() -> void:
    crop_bar_dismissed = true
    _update_crop_bar_visibility()

func _pick_crop_bar(i: int) -> void:
    _select_crop(i)

func _refresh_crop_bar() -> void:
    if crop_bar == null:
        return
    for i in range(crop_defs.size()):
        var d: Dictionary = crop_defs[i]
        var b: Button = crop_bar_buttons[i]
        var locked: bool = level < int(d["lv"])
        b.disabled = locked
        if locked:
            b.text = "🔒 Lv %d" % int(d["lv"])
        else:
            b.text = "%s %s\n%d s • %d🪙" % [d["icon"], d["name"], int(d["grow"]), int(d["pay"]) + level]
        if i == selected_crop and not locked:
            b.add_theme_stylebox_override("normal", _flat(Color(1.0, 0.92, 0.55), 14, Color(0.96, 0.55, 0.10), 4, 6.0))
            b.add_theme_color_override("font_color", Color(0.30, 0.16, 0.05))
        else:
            b.add_theme_stylebox_override("normal", _flat(Color(0.93, 0.86, 0.72), 14, Color(0.80, 0.62, 0.42), 3, 6.0))
            b.add_theme_color_override("font_color", Color(0.30, 0.16, 0.05))
            b.add_theme_color_override("font_disabled_color", Color(0.55, 0.45, 0.35))
    crop_bar_seeds.text = "Seeds\n%d" % seeds

func _update_crop_bar_visibility() -> void:
    if crop_bar == null:
        return
    var want: bool = active_action == "plant" and not crop_bar_dismissed and not _any_panel_open()
    if crop_bar.visible != want:
        crop_bar.visible = want
    if want:
        crop_bar_seeds.text = "Seeds\n%d" % seeds

# ------------------------------------------------------------ v25 helpers

func _make_close_x() -> Button:
    var b := Button.new()
    b.text = "✕"
    b.custom_minimum_size = Vector2(52.0, 52.0)
    b.add_theme_font_size_override("font_size", 26)
    b.add_theme_color_override("font_color", Color.WHITE)
    b.add_theme_color_override("font_hover_color", Color.WHITE)
    b.add_theme_color_override("font_pressed_color", Color.WHITE)
    b.add_theme_stylebox_override("normal", _flat(Color(0.85, 0.25, 0.22), 26, Color(1, 1, 1, 0.9), 3, 2.0))
    b.add_theme_stylebox_override("hover", _flat(Color(0.92, 0.32, 0.28), 26, Color(1, 1, 1, 0.9), 3, 2.0))
    b.add_theme_stylebox_override("pressed", _flat(Color(0.70, 0.18, 0.16), 26, Color(1, 1, 1, 0.9), 3, 2.0))
    b.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
    b.pressed.connect(_close_panels)
    return b

func _panel_header(col: Control, title: Label) -> void:
    var head := HBoxContainer.new()
    head.add_theme_constant_override("separation", 6)
    col.add_child(head)
    var pad := Control.new()
    pad.custom_minimum_size = Vector2(56.0, 0.0)
    head.add_child(pad)
    title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    title.size_flags_vertical = Control.SIZE_SHRINK_CENTER
    head.add_child(title)
    head.add_child(_make_close_x())

func _update_lock_buttons() -> void:
    var defs: Array = [[hydro_btn, hydro_unlocked, "⚡"], [train_btn, train_unlocked, "🚂"], [carrier_btn, carrier_unlocked, "✈"], [trade_btn, trade_unlocked, "🚚"]]
    for d in defs:
        var b: Button = d[0]
        if b == null:
            continue
        b.visible = true
        b.text = str(d[2]) if bool(d[1]) else "🔒"
        b.modulate = Color(1, 1, 1, 1) if bool(d[1]) else Color(0.72, 0.72, 0.75, 0.95)


# =========================================================================
# v25 railway: zig-zag loop with bridges over roads, train runs on dispatch
# =========================================================================

const TRAIN_CTRL: Array = [
    Vector2(-6.9, -10.8), Vector2(-4.2, -12.0), Vector2(-1.2, -10.6), Vector2(1.6, -12.0), Vector2(4.4, -10.6), Vector2(7.2, -12.0), Vector2(10.2, -10.8),
    Vector2(13.4, -8.0), Vector2(12.3, -5.2), Vector2(13.5, -2.2), Vector2(12.4, 0.8), Vector2(13.2, 4.2), Vector2(12.0, 7.4), Vector2(13.0, 10.6), Vector2(12.2, 13.2),
    Vector2(10.0, 15.2), Vector2(7.0, 14.0), Vector2(4.0, 15.5), Vector2(1.0, 14.0), Vector2(-2.0, 15.5), Vector2(-5.0, 14.2),
    Vector2(-7.6, 12.0), Vector2(-6.8, 9.0), Vector2(-8.0, 6.0), Vector2(-6.9, 3.0), Vector2(-8.0, 0.0), Vector2(-6.9, -3.0), Vector2(-7.9, -6.0), Vector2(-7.2, -9.0)
]
const TRAIN_SPEED := 3.2
const TRAIN_UPGRADE_COST: Array = [900, 2200]
const TRAIN_OFFS: Array = [0.8, 2.3, 3.6, 4.9, 6.2]
const BRIDGE_H := 1.5
const BRIDGE_RAMP := 4.2

var train_unlocked: bool = false
var train_level: int = 1
var train_root: Node3D
var train_site: Node3D
var train_pts: PackedVector2Array = PackedVector2Array()
var train_cum: PackedFloat32Array = PackedFloat32Array()
var train_len: float = 1.0
var train_cars: Array = []
var train_s: float = 0.0
var train_speed: float = 0.0
var train_dwell: float = 0.0
var train_next: int = 0
var train_state: int = 0
var train_dest: int = -1
var train_stops: Array = []
var train_bridges: Array = []
var train_panel: PanelContainer
var train_info: Label
var train_buttons: Array = []
var train_btn: Button
var train_tick: float = 0.0
var road_polys: Array = []

func train_bonus() -> float:
    return 0.04 * float(train_level) if train_unlocked else 0.0

func _catmull(p0: Vector2, p1: Vector2, p2: Vector2, p3: Vector2, t: float) -> Vector2:
    var t2: float = t * t
    var t3: float = t2 * t
    return ((p1 * 2.0) + (p2 - p0) * t + (p0 * 2.0 - p1 * 5.0 + p2 * 4.0 - p3) * t2 + (p1 * 3.0 - p0 - p2 * 3.0 + p3) * t3) * 0.5

func _train_build_path() -> void:
    if train_pts.size() > 0:
        return
    var n: int = TRAIN_CTRL.size()
    var raw: Array = []
    for i in range(n):
        var p0: Vector2 = TRAIN_CTRL[(i + n - 1) % n]
        var p1: Vector2 = TRAIN_CTRL[i]
        var p2: Vector2 = TRAIN_CTRL[(i + 1) % n]
        var p3: Vector2 = TRAIN_CTRL[(i + 2) % n]
        var steps: int = maxi(3, int(ceil(p1.distance_to(p2) / 0.2)))
        for k in range(steps):
            raw.append(_catmull(p0, p1, p2, p3, float(k) / float(steps)))
    train_pts = PackedVector2Array()
    train_cum = PackedFloat32Array()
    var total: float = 0.0
    for i in range(raw.size()):
        var pt: Vector2 = raw[i]
        train_pts.append(pt)
        train_cum.append(total)
        total += pt.distance_to(raw[(i + 1) % raw.size()])
    train_len = total

func _train_reserve_corridor() -> void:
    # Called while the island is laid out so trees keep clear of the future tracks.
    _train_build_path()
    var step: int = 4
    var i: int = 0
    while i < train_pts.size():
        var a: Vector2 = train_pts[i]
        var b: Vector2 = train_pts[(i + step) % train_pts.size()]
        path_segments.append([a, b])
        i += step

func _train_at(s: float) -> Vector2:
    var ss: float = fposmod(s, train_len)
    var lo: int = 0
    var hi: int = train_cum.size() - 1
    while lo < hi:
        var mid: int = (lo + hi + 1) / 2
        if train_cum[mid] <= ss:
            lo = mid
        else:
            hi = mid - 1
    var nxt: int = (lo + 1) % train_pts.size()
    var seg_end: float = train_cum[lo + 1] if lo + 1 < train_cum.size() else train_len
    var seg: float = maxf(0.0001, seg_end - train_cum[lo])
    return train_pts[lo].lerp(train_pts[nxt], clampf((ss - train_cum[lo]) / seg, 0.0, 1.0))

func _train_dir(s: float) -> Vector2:
    var d: Vector2 = _train_at(s + 0.12) - _train_at(s - 0.12)
    if d.length_squared() < 0.00001:
        return Vector2(1.0, 0.0)
    return d.normalized()

func _train_h(s: float) -> float:
    var h: float = 0.0
    for b in train_bridges:
        var d: float = absf(fposmod(s - float(b["s"]) + train_len * 0.5, train_len) - train_len * 0.5)
        var plateau: float = float(b["g"]) + 0.25
        if d <= plateau:
            h = maxf(h, BRIDGE_H)
        elif d < plateau + BRIDGE_RAMP:
            var u: float = (d - plateau) / BRIDGE_RAMP
            h = maxf(h, BRIDGE_H * (1.0 - smoothstep(0.0, 1.0, u)))
    return h

func _find_bridges() -> void:
    train_bridges.clear()
    var n: int = train_pts.size()
    for poly in road_polys:
        var pts: Array = poly
        for r in range(pts.size() - 1):
            var ra: Vector2 = pts[r]
            var rb: Vector2 = pts[r + 1]
            for i in range(n):
                var ta: Vector2 = train_pts[i]
                var tb: Vector2 = train_pts[(i + 1) % n]
                var hit: Variant = Geometry2D.segment_intersects_segment(ta, tb, ra, rb)
                if hit == null:
                    continue
                var s: float = float(train_cum[i]) + ta.distance_to(hit as Vector2)
                var td: Vector2 = (tb - ta).normalized()
                var rd: Vector2 = (rb - ra).normalized()
                var sn: float = clampf(absf(td.x * rd.y - td.y * rd.x), 0.35, 1.0)
                var g: float = clampf(1.0 / sn, 1.3, 2.6)
                var dup: bool = false
                for b in train_bridges:
                    var dd: float = absf(fposmod(s - float(b["s"]) + train_len * 0.5, train_len) - train_len * 0.5)
                    if dd < 6.0:
                        dup = true
                        b["g"] = maxf(float(b["g"]), g)
                if not dup:
                    train_bridges.append({"s": s, "g": g, "pos": hit})

func _oriented_box(st: SurfaceTool, c: Vector3, t: Vector2, sx: float, sy: float, sz: float, col: Color, slope: float = 0.0) -> void:
    var dir3: Vector3 = Vector3(t.x, slope, t.y).normalized()
    var fx: Vector3 = dir3 * (sx * 0.5)
    var fz: Vector3 = Vector3(-t.y, 0.0, t.x) * (sz * 0.5)
    var up: Vector3 = fz.cross(dir3).normalized() * (sy * 0.5)
    var p000: Vector3 = c - fx - fz - up
    var p100: Vector3 = c + fx - fz - up
    var p101: Vector3 = c + fx + fz - up
    var p001: Vector3 = c - fx + fz - up
    var p010: Vector3 = c - fx - fz + up
    var p110: Vector3 = c + fx - fz + up
    var p111: Vector3 = c + fx + fz + up
    var p011: Vector3 = c - fx + fz + up
    var dark: Color = col.darkened(0.18)
    _tri(st, p010, p011, p111, col, col, col)
    _tri(st, p010, p111, p110, col, col, col)
    _tri(st, p000, p010, p110, dark, dark, dark)
    _tri(st, p000, p110, p100, dark, dark, dark)
    _tri(st, p001, p111, p011, dark, dark, dark)
    _tri(st, p001, p101, p111, dark, dark, dark)
    _tri(st, p100, p110, p111, dark, dark, dark)
    _tri(st, p100, p111, p101, dark, dark, dark)
    _tri(st, p000, p011, p010, dark, dark, dark)
    _tri(st, p000, p001, p011, dark, dark, dark)

func _near_bridge_dist(s: float) -> float:
    var best: float = 1000.0
    for b in train_bridges:
        var d: float = absf(fposmod(s - float(b["s"]) + train_len * 0.5, train_len) - train_len * 0.5)
        best = minf(best, d - float(b["g"]))
    return best

func _ribbon(st: SurfaceTool, a: Vector2, b: Vector2, n0: Vector2, n1: Vector2, off: float, w: float, y0: float, y1: float, thick: float, col: Color) -> void:
    var hw: float = w * 0.5
    var ht: float = thick * 0.5
    var al: Vector2 = a + n0 * (off + hw)
    var ar: Vector2 = a + n0 * (off - hw)
    var bl: Vector2 = b + n1 * (off + hw)
    var br: Vector2 = b + n1 * (off - hw)
    var dark: Color = col.darkened(0.18)
    var tal: Vector3 = Vector3(al.x, y0 + ht, al.y)
    var tar: Vector3 = Vector3(ar.x, y0 + ht, ar.y)
    var tbl: Vector3 = Vector3(bl.x, y1 + ht, bl.y)
    var tbr: Vector3 = Vector3(br.x, y1 + ht, br.y)
    var bal: Vector3 = Vector3(al.x, y0 - ht, al.y)
    var bar: Vector3 = Vector3(ar.x, y0 - ht, ar.y)
    var bbl: Vector3 = Vector3(bl.x, y1 - ht, bl.y)
    var bbr: Vector3 = Vector3(br.x, y1 - ht, br.y)
    _tri(st, tal, tbl, tbr, col, col, col)
    _tri(st, tal, tbr, tar, col, col, col)
    _tri(st, bal, bbr, bbl, dark, dark, dark)
    _tri(st, bal, bar, bbr, dark, dark, dark)
    _tri(st, tal, bal, bbl, dark, dark, dark)
    _tri(st, tal, bbl, tbl, dark, dark, dark)
    _tri(st, tar, tbr, bbr, dark, dark, dark)
    _tri(st, tar, bbr, bar, dark, dark, dark)

func _build_track_mesh() -> void:
    var st := SurfaceTool.new()
    st.begin(Mesh.PRIMITIVE_TRIANGLES)
    var ballast: Color = Color(0.60, 0.55, 0.49)
    var sleeper: Color = Color(0.43, 0.29, 0.18)
    var steel: Color = Color(0.74, 0.76, 0.80)
    var stone: Color = Color(0.66, 0.64, 0.60)
    var step: float = 0.3
    var count: int = int(ceil(train_len / step))
    step = train_len / float(count)
    for i in range(count):
        var s0: float = float(i) * step
        var s1: float = s0 + step * 1.02
        var a: Vector2 = _train_at(s0)
        var b: Vector2 = _train_at(s1)
        var h0: float = _train_h(s0)
        var h1: float = _train_h(s1)
        var len2: float = maxf(0.01, a.distance_to(b))
        var t: Vector2 = (b - a) / len2
        var d0: Vector2 = _train_dir(s0)
        var d1: Vector2 = _train_dir(s1)
        var n0: Vector2 = Vector2(-d0.y, d0.x)
        var n1: Vector2 = Vector2(-d1.y, d1.x)
        var mid: Vector2 = (a + b) * 0.5
        var hm: float = (h0 + h1) * 0.5
        var slope: float = (h1 - h0) / len2
        # v27b: ribbons follow the bend (no wedge gaps on tight corners)
        _ribbon(st, a, b, n0, n1, 0.0, 1.05, 0.02 + h0, 0.02 + h1, 0.07, ballast)
        for side in [-0.31, 0.31]:
            _ribbon(st, a, b, n0, n1, float(side), 0.07, 0.10 + h0, 0.10 + h1, 0.07, steel)
        if i % 2 == 0:
            _oriented_box(st, Vector3(mid.x, 0.07 + hm, mid.y), t, 0.15, 0.04, 0.92, sleeper, slope)
        if hm > 0.12:
            var nd: float = _near_bridge_dist(s0 + step * 0.5)
            if nd >= 0.0:
                # Solid stone embankment under the ramps.
                var l0: Vector2 = a + n0 * 0.62
                var r0: Vector2 = a - n0 * 0.62
                var l1: Vector2 = b + n1 * 0.62
                var r1: Vector2 = b - n1 * 0.62
                var top0: float = h0 - 0.02
                var top1: float = h1 - 0.02
                var sc: Color = stone.darkened(0.12)
                _tri(st, Vector3(l0.x, top0, l0.y), Vector3(l1.x, top1, l1.y), Vector3(l1.x, 0.0, l1.y), sc, sc, sc)
                _tri(st, Vector3(l0.x, top0, l0.y), Vector3(l1.x, 0.0, l1.y), Vector3(l0.x, 0.0, l0.y), sc, sc, sc)
                _tri(st, Vector3(r0.x, top0, r0.y), Vector3(r1.x, 0.0, r1.y), Vector3(r1.x, top1, r1.y), sc, sc, sc)
                _tri(st, Vector3(r0.x, top0, r0.y), Vector3(r0.x, 0.0, r0.y), Vector3(r1.x, 0.0, r1.y), sc, sc, sc)
            else:
                # Bridge girder over the road.
                _ribbon(st, a, b, n0, n1, 0.0, 1.20, h0 - 0.17, h1 - 0.17, 0.30, stone.darkened(0.08))
            # Low stone kerb on both sides of anything raised (no taller than the rails).
            for side2 in [-0.58, 0.58]:
                _ribbon(st, a, b, n0, n1, float(side2), 0.08, 0.07 + h0, 0.07 + h1, 0.10, stone.lightened(0.1))
    var node := MeshInstance3D.new()
    node.name = "RailTrack"
    node.mesh = st.commit()
    var m := StandardMaterial3D.new()
    m.vertex_color_use_as_albedo = true
    m.roughness = 0.9
    m.cull_mode = BaseMaterial3D.CULL_DISABLED
    node.material_override = m
    node.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    train_root.add_child(node)

func _train_wheels(parent: Node3D, xs: Array, r: float, col: Color) -> void:
    for x in xs:
        for z in [-0.29, 0.29]:
            var w: MeshInstance3D = _cylinder(parent, r, r, 0.06, Vector3(float(x), r + 0.04, float(z)), col, "Wheel")
            w.rotation.x = PI * 0.5

func _build_loco() -> Node3D:
    var l := Node3D.new()
    l.name = "Locomotive"
    _box(l, Vector3(1.55, 0.14, 0.56), Vector3(0.0, 0.22, 0.0), Color(0.18, 0.18, 0.22), "Chassis")
    var boiler: MeshInstance3D = _cylinder(l, 0.25, 0.25, 1.05, Vector3(0.28, 0.55, 0.0), Color(0.12, 0.50, 0.34), "Boiler")
    boiler.rotation.z = PI * 0.5
    var front: MeshInstance3D = _cylinder(l, 0.26, 0.26, 0.12, Vector3(0.82, 0.55, 0.0), Color(0.15, 0.15, 0.18), "SmokeBox")
    front.rotation.z = PI * 0.5
    var band: MeshInstance3D = _cylinder(l, 0.265, 0.265, 0.06, Vector3(0.1, 0.55, 0.0), Color(0.95, 0.78, 0.25), "Band")
    band.rotation.z = PI * 0.5
    _cylinder(l, 0.10, 0.075, 0.30, Vector3(0.62, 0.92, 0.0), Color(0.12, 0.12, 0.14), "Chimney")
    _cylinder(l, 0.13, 0.10, 0.06, Vector3(0.62, 1.10, 0.0), Color(0.95, 0.78, 0.25), "ChimneyCap")
    _sphere(l, 0.12, 0.2, Vector3(0.15, 0.82, 0.0), Color(0.95, 0.78, 0.25), "Dome")
    _box(l, Vector3(0.52, 0.56, 0.60), Vector3(-0.50, 0.58, 0.0), Color(0.78, 0.16, 0.14), "Cab")
    _box(l, Vector3(0.66, 0.06, 0.74), Vector3(-0.50, 0.89, 0.0), Color(0.22, 0.22, 0.26), "CabRoof")
    for z in [-0.305, 0.305]:
        var w: MeshInstance3D = _box(l, Vector3(0.22, 0.2, 0.02), Vector3(-0.50, 0.68, float(z)), Color(0.33, 0.76, 0.92), "CabWin")
        w.material_override = _window_material()
    var cow: MeshInstance3D = _box(l, Vector3(0.22, 0.14, 0.5), Vector3(0.86, 0.17, 0.0), Color(0.97, 0.80, 0.18), "Cowcatcher")
    cow.rotation.z = -0.35
    var lamp: MeshInstance3D = _sphere(l, 0.07, 0.14, Vector3(0.88, 0.60, 0.0), Color(1.0, 0.95, 0.7), "Headlamp")
    lamp.material_override = _lamp_material()
    _train_wheels(l, [-0.5, -0.05, 0.4], 0.17, Color(0.10, 0.10, 0.12))
    _make_smoke(l, Vector3(0.62, 1.15, 0.0))
    return l

func _build_wagon(kind: int) -> Node3D:
    var w := Node3D.new()
    w.name = "Wagon"
    _box(w, Vector3(1.2, 0.12, 0.54), Vector3(0.0, 0.22, 0.0), Color(0.18, 0.18, 0.22), "Chassis")
    _train_wheels(w, [-0.38, 0.38], 0.15, Color(0.10, 0.10, 0.12))
    if kind == 0:
        _box(w, Vector3(1.1, 0.50, 0.52), Vector3(0.0, 0.53, 0.0), Color(0.95, 0.76, 0.22), "Coach")
        _box(w, Vector3(1.18, 0.06, 0.60), Vector3(0.0, 0.82, 0.0), Color(0.78, 0.22, 0.18), "CoachRoof")
        for x in [-0.34, 0.0, 0.34]:
            for z in [-0.265, 0.265]:
                var win: MeshInstance3D = _box(w, Vector3(0.2, 0.18, 0.02), Vector3(float(x), 0.60, float(z)), Color(0.33, 0.76, 0.92), "CoachWin")
                win.material_override = _window_material()
    elif kind == 1:
        _box(w, Vector3(1.1, 0.30, 0.52), Vector3(0.0, 0.41, 0.0), Color(0.62, 0.38, 0.22), "Truck")
        _box(w, Vector3(0.36, 0.26, 0.34), Vector3(-0.26, 0.69, 0.0), Color(0.86, 0.62, 0.30), "Crate")
        _box(w, Vector3(0.36, 0.20, 0.34), Vector3(0.22, 0.66, 0.0), Color(0.55, 0.78, 0.40), "CrateB")
        _sphere(w, 0.14, 0.28, Vector3(0.22, 0.80, 0.0), Color(0.90, 0.35, 0.20), "Pumpkin")
    elif kind == 2:
        var tank: MeshInstance3D = _cylinder(w, 0.24, 0.24, 1.05, Vector3(0.0, 0.52, 0.0), Color(0.88, 0.90, 0.94), "Tank")
        tank.rotation.z = PI * 0.5
        var tb: MeshInstance3D = _cylinder(w, 0.245, 0.245, 0.08, Vector3(0.0, 0.52, 0.0), Color(0.80, 0.18, 0.16), "TankBand")
        tb.rotation.z = PI * 0.5
    else:
        _box(w, Vector3(1.1, 0.36, 0.52), Vector3(0.0, 0.44, 0.0), Color(0.30, 0.34, 0.50), "Hopper")
        _sphere(w, 0.28, 0.30, Vector3(0.0, 0.64, 0.0), Color(0.16, 0.16, 0.18), "Coal")
    return w

func _build_station(name: String, pos: Vector2, outward: Vector2, roof_col: Color) -> Node3D:
    var st := Node3D.new()
    st.name = "Station_" + name
    st.position = Vector3(pos.x, 0.0, pos.y)
    st.rotation.y = atan2(-outward.y, outward.x)
    train_root.add_child(st)
    _box(st, Vector3(1.0, 0.16, 3.2), Vector3(1.05, 0.08, 0.0), Color(0.80, 0.77, 0.70), "Platform")
    _box(st, Vector3(0.08, 0.17, 3.2), Vector3(0.55, 0.085, 0.0), Color(0.98, 0.85, 0.20), "PlatformEdge")
    for z in [-1.3, 1.3]:
        _box(st, Vector3(0.07, 0.95, 0.07), Vector3(1.4, 0.62, float(z)), Color(0.40, 0.30, 0.22), "Post")
    _box(st, Vector3(1.0, 0.08, 3.0), Vector3(1.2, 1.12, 0.0), roof_col, "Canopy")
    _box(st, Vector3(0.7, 0.28, 0.1), Vector3(1.45, 0.42, 0.0), Color(0.55, 0.38, 0.22), "Bench")
    _box(st, Vector3(0.7, 0.7, 0.9), Vector3(1.95, 0.35, 0.0), Color(0.96, 0.92, 0.82), "Booth")
    var r1: MeshInstance3D = _box(st, Vector3(0.6, 0.06, 1.05), Vector3(1.78, 0.86, 0.0), roof_col, "BoothRoofA")
    r1.rotation_degrees.z = 30.0
    var r2: MeshInstance3D = _box(st, Vector3(0.6, 0.06, 1.05), Vector3(2.12, 0.86, 0.0), roof_col.darkened(0.12), "BoothRoofB")
    r2.rotation_degrees.z = -30.0
    var win: MeshInstance3D = _box(st, Vector3(0.05, 0.22, 0.34), Vector3(1.59, 0.45, 0.22), Color(0.33, 0.76, 0.92), "BoothWin")
    win.material_override = _window_material()
    var lamp: MeshInstance3D = _sphere(st, 0.07, 0.14, Vector3(1.4, 1.02, 0.0), Color(1.0, 0.95, 0.7), "StationLamp")
    lamp.material_override = _lamp_material()
    _label3d(st, name, Vector3(1.6, 1.85, 0.0), 0.010, Color(1.0, 0.95, 0.75))
    return st

func _build_train() -> void:
    _train_build_path()
    _find_bridges()
    train_root = Node3D.new()
    train_root.name = "Railway"
    add_child(train_root)
    _build_track_mesh()
    # name, wanted position, platform side (1 = outside of the loop, -1 = inside), roof colour
    var defs: Array = [
        ["TRADE", Vector2(-4.4, -11.5), 1, Color(0.20, 0.45, 0.75)],
        ["FARM", Vector2(1.6, -11.8), 1, Color(0.80, 0.22, 0.18)],
        ["PORT", Vector2(8.6, -11.6), 1, Color(0.25, 0.62, 0.70)],
        ["POWER", Vector2(12.4, -5.4), 1, Color(0.90, 0.70, 0.15)],
        ["MARKET", Vector2(5.6, 14.6), 1, Color(0.85, 0.40, 0.20)],
        ["WINDMILL", Vector2(-7.4, 9.5), -1, Color(0.55, 0.35, 0.65)],
        ["BAKERY", Vector2(-7.4, 0.5), -1, Color(0.78, 0.30, 0.38)]
    ]
    train_stops.clear()
    for i in range(defs.size()):
        var d: Array = defs[i]
        var want: Vector2 = d[1]
        var best_s: float = 0.0
        var best_d: float = 1000.0
        var s: float = 0.0
        while s < train_len:
            var dd: float = _train_at(s).distance_to(want)
            if dd < best_d:
                best_d = dd
                best_s = s
            s += 0.05
        # Keep stations off the bridge ramps.
        var base_s: float = best_s
        for k in range(0, 400):
            var off: float = float((k + 1) / 2) * 0.5 * (1.0 if k % 2 == 0 else -1.0)
            var cs: float = fposmod(base_s + off, train_len)
            var ok: bool = _near_bridge_dist(cs) >= 3.2
            if ok:
                for o in train_stops:
                    var dd2: float = absf(float(o["s"]) - cs)
                    dd2 = minf(dd2, train_len - dd2)
                    if dd2 < 5.5:
                        ok = false
                        break
            if ok:
                best_s = cs
                break
        var p: Vector2 = _train_at(best_s)
        var t: Vector2 = _train_dir(best_s)
        var out_n: Vector2 = Vector2(t.y, -t.x) * float(d[2])
        var node: Node3D = _build_station(str(d[0]), p, out_n, d[3])
        train_stops.append({"name": str(d[0]), "s": best_s, "node": node, "n": out_n})
    train_cars.clear()
    var loco: Node3D = _build_loco()
    train_root.add_child(loco)
    train_cars.append(loco)
    for k in range(4):
        var wg: Node3D = _build_wagon(k)
        train_root.add_child(wg)
        train_cars.append(wg)
    # The train waits at the Trade Centre station.
    train_state = 0
    train_next = 0
    train_s = float(train_stops[0]["s"]) + 2.4
    train_speed = 0.0
    train_root.visible = false
    _place_train()
    train_site = _make_lock_site(Vector3(-1.2, 0.0, -12.6), "Railway\nLevel %d" % TRAIN_LV, 0.0, 2.6)

func _place_train() -> void:
    for i in range(train_cars.size()):
        var car: Node3D = train_cars[i]
        var cs: float = train_s - float(TRAIN_OFFS[i])
        var p: Vector2 = _train_at(cs)
        var d: Vector2 = _train_dir(cs)
        var h: float = _train_h(cs)
        var h2: float = _train_h(cs + 0.5)
        var h1: float = _train_h(cs - 0.5)
        car.position = Vector3(p.x, 0.07 + h, p.y)
        car.rotation = Vector3(0.0, atan2(-d.y, d.x), atan2(h2 - h1, 1.0))
        if i >= 1:
            car.visible = i <= 1 + train_level

func _update_train_visibility() -> void:
    if train_root == null:
        return
    train_root.visible = train_unlocked
    if train_site != null:
        train_site.visible = not train_unlocked
    _update_lock_buttons()
    _place_train()

func _train_idle() -> bool:
    return train_unlocked and train_state == 0

func _train_dispatch(dest_stop: int) -> bool:
    if not train_unlocked or train_state != 0 or dest_stop <= 0 or dest_stop >= train_stops.size():
        return false
    train_dest = dest_stop
    train_next = dest_stop
    train_state = 1
    train_speed = 0.05
    _play_named("horn", -12.0)
    return true

func _train_eta(dest_stop: int) -> float:
    var a: float = float(train_stops[0]["s"]) + 2.4
    var b: float = float(train_stops[dest_stop]["s"]) + 2.4
    return fposmod(b - a, train_len) / TRAIN_SPEED + 4.0

func _update_train(delta: float) -> void:
    if not train_unlocked or train_root == null:
        return
    if train_state == 0:
        return
    if train_state == 2:
        train_dwell -= delta
        if train_dwell <= 0.0:
            train_state = 3
            train_next = 0
            train_speed = 0.05
            _play_named("bell", -14.0)
    else:
        var stop_s: float = float(train_stops[train_next]["s"]) + 2.4
        var d: float = fposmod(stop_s - train_s, train_len)
        var target: float = TRAIN_SPEED
        if d < 4.5:
            target = clampf(d * 0.75, 0.45, TRAIN_SPEED)
        train_speed = move_toward(train_speed, target, 1.7 * delta)
        var step: float = train_speed * delta
        if step >= d:
            train_s += d
            train_speed = 0.0
            if train_state == 1:
                train_state = 2
                train_dwell = 3.0
                _play_named("bell", -12.0)
                _vehicle_arrived(0)
            else:
                train_state = 0
                _vehicle_returned(0)
        else:
            train_s += step
    train_s = fposmod(train_s, train_len)
    _place_train()
    train_tick -= delta
    if train_tick <= 0.0:
        train_tick = 0.5
        if train_panel != null and train_panel.visible:
            _refresh_train()

func _build_train_panel() -> void:
    var made: Array = _new_panel("🚂 VILLAGE RAILWAY", 0.10, 0.90)
    train_panel = made[0]
    var col: VBoxContainer = made[1]
    train_info = _panel_label(col, 17, Color(1.0, 0.94, 0.80))
    train_buttons.clear()
    for i in range(3):
        var b: Button = _panel_button(col, "", 62, 17)
        b.pressed.connect(_train_action.bind(i))
        train_buttons.append(b)
    var close: Button = _panel_button(col, "CLOSE", 44, 18)
    close.pressed.connect(_close_panels)

func _train_cost() -> int:
    if train_level >= 3:
        return 0
    return int(TRAIN_UPGRADE_COST[train_level - 1])

func _refresh_train() -> void:
    if train_panel == null:
        return
    var names: Array = []
    for s in train_stops:
        names.append(str(s["name"]).capitalize())
    var status: String = "waiting at the Trade Centre"
    if train_state == 1:
        status = "delivering to %s" % str(train_stops[train_dest]["name"]).capitalize()
    elif train_state == 2:
        status = "unloading parcels"
    elif train_state == 3:
        status = "heading back to the Trade Centre"
    train_info.text = "Stations: %s\nCarriages: %d   •   Crop prices +%d%% from rail freight\nTrain is %s.\nSend it from the Trade Centre orders." % [", ".join(names), 1 + train_level, int(round(train_bonus() * 100.0)), status]
    var labels: Array = ["", "📯 Toot the whistle", "Orders by rail are free, but the train can carry only one delivery at a time."]
    if train_level < 3:
        labels[0] = "🚃 Add a carriage (Level %d)\n%d coins  •  +4%% crop prices" % [train_level + 1, _train_cost()]
    else:
        labels[0] = "🚃 Train fully upgraded (4 carriages)"
    for i in range(3):
        (train_buttons[i] as Button).text = labels[i]
    (train_buttons[0] as Button).disabled = train_level >= 3 or coins < _train_cost()
    (train_buttons[2] as Button).disabled = true

func _train_action(i: int) -> void:
    if i == 0 and train_level < 3 and coins >= _train_cost():
        coins -= _train_cost()
        train_level += 1
        _place_train()
        _play_named("jingle", -8.0)
        _refresh_ui()
        _show_toast("Train upgraded: %d carriages!" % (1 + train_level))
    elif i == 1:
        _play_named("horn", -6.0)
        return
    else:
        return
    _refresh_train()
    _save_game()

func _open_train() -> void:
    if not train_unlocked:
        _show_toast("Railway unlocks at Level %d (you are Level %d)" % [TRAIN_LV, level])
        return
    _close_panels()
    train_panel.visible = true
    _refresh_train()

func _tap_train(p: Vector2) -> bool:
    if not train_unlocked or train_root == null:
        return false
    for i in range(train_cars.size()):
        var car: Node3D = train_cars[i]
        if not car.visible:
            continue
        var base: Vector2 = Vector2(car.position.x, car.position.z)
        if _dist_to_segment(p, base, base + Vector2(-0.45, -0.7)) < 1.0:
            _open_train()
            return true
    for s in train_stops:
        var sn: Node3D = s["node"]
        var b: Vector2 = Vector2(sn.position.x, sn.position.z) + (s["n"] as Vector2) * 1.4
        if _dist_to_segment(p, b, b + Vector2(-0.8, -1.2)) < 1.5:
            if str(s["name"]) == "TRADE":
                _open_trade()
            else:
                _open_train()
            return true
    return false

func _save_train(config: ConfigFile) -> void:
    config.set_value("farm", "train_level", train_level)

func _load_train(config: ConfigFile) -> void:
    train_level = clampi(int(config.get_value("farm", "train_level", 1)), 1, 3)

# =========================================================================
# v25 Trade Centre: delivery orders by train, drone, helicopter, plane, boat
# =========================================================================

const TRADE_LV := 11
const TRADE_POS := Vector3(-6.2, 0.0, -15.0)
const RUNWAY_Z := -15.4
const ROOF_Y := 1.68
const MODE_NAMES: Array = ["Train", "Drone", "Helicopter", "Plane", "Boat"]
const MODE_ICONS: Array = ["🚆", "🛸", "🚁", "✈", "🚢"]
const MODE_SPEED: Array = [3.2, 6.0, 5.0, 7.0, 2.6]
const MODE_CAP: Array = [12, 4, 8, 12, 12]
const DRONE_RANGE := 34.0
const TRADE_SLOTS := 4
const TRADE_SLOT3_LV := 16

func _trade_active_slots() -> int:
    return 3 if level >= TRADE_SLOT3_LV else 2
const TRADE_TIME := 900.0
const PLANE_EXIT := Vector2(15.0, -18.0)

var trade_unlocked: bool = false
var trade_root: Node3D
var trade_built: Node3D
var trade_site: Node3D
var trade_btn: Button
var trade_panel: PanelContainer
var trade_info: Label
var trade_list: VBoxContainer
var trade_sig: String = ""
var trade_time_labels: Array = []
var trade_dests: Array = []
var trade_orders: Array = []
var trade_cool: Array = [3.0, 10.0, 25.0, 40.0]
var trade_veh: Array = []
var trade_fx: Array = []
var trade_beacon: MeshInstance3D
var trade_windsock: Node3D
var trade_tick: float = 0.0
var trade_delivered: int = 0

# ------------------------------------------------------------------ items

func _trade_init_dests() -> void:
    trade_dests.clear()
    var land: Array = [0, 1, 2, 3]
    var crops: Array = [["crop", 0], ["crop", 1], ["crop", 2], ["crop", 3]]
    var stn_info: Array = [
        ["Farm Orchard", "🌳", "crops, milk and eggs for the pickers", [["crop", 0], ["crop", 2], ["prod", 0], ["prod", 1]], land],
        ["Sea Port", "⚓", "bread, rice, grain and eggs for the dock crews", [["crop", 1], ["crop", 4], ["crop", 3], ["good", 0], ["prod", 1]], land],
        ["Power Substation", "🔌", "energy cells and hot meals for the engineers", [["energy", 0], ["good", 0], ["good", 1]], land],
        ["Village Market", "🏪", "cakes, popcorn and farm produce for the stalls", [["good", 2], ["good", 3], ["prod", 0], ["prod", 2]], land],
        ["Windmill", "🌬", "wheat and corn to grind", [["crop", 1], ["crop", 3]], land],
        ["Bakery", "🥖", "crops and eggs for the ovens", crops + [["crop", 4], ["prod", 0], ["prod", 1]], land]
    ]
    # Station indexes 2..6 on the track (0 = Trade Centre, 1 = Farm).
    var stn_idx: Array = [1, 2, 3, 4, 5, 6]
    for i in range(stn_info.size()):
        var d: Array = stn_info[i]
        var si: int = int(stn_idx[i])
        trade_dests.append({"name": d[0], "icon": d[1], "uses": d[2], "pool": d[3], "modes": d[4], "stn": si, "pos": Vector3.ZERO, "boat": []})
    var sea_modes: Array = [1, 2, 3, 4]
    trade_dests.append({"name": "Tidal Power Station", "icon": "⚡", "uses": "energy cells, turbine crew meals and eggs", "pool": [["energy", 0], ["good", 0], ["good", 1], ["prod", 1]], "modes": sea_modes, "stn": -1,
        "pos": Vector3(HYDRO_POS.x + 0.2, 0.9, HYDRO_POS.z), "boat": [Vector3(6.8, -0.42, -20.2), Vector3(9.0, -0.42, -22.0), Vector3(20.0, -0.42, -23.2), Vector3(31.0, -0.42, -21.0), Vector3(33.0, -0.42, -12.0), Vector3(30.0, -0.42, -6.5), Vector3(26.4, -0.42, -3.2)]})
    trade_dests.append({"name": "Aircraft Carrier", "icon": "🛳", "uses": "meals, snacks, milk and energy for the air crew", "pool": [["good", 0], ["good", 3], ["prod", 0], ["energy", 0]], "modes": [2, 3, 4], "stn": -1,
        "pos": Vector3(CARRIER_POS.x, CARRIER_POS.y + 1.0, CARRIER_POS.z + 0.6), "boat": [Vector3(6.8, -0.42, -20.2), Vector3(9.0, -0.42, -22.0), Vector3(20.0, -0.42, -23.2), Vector3(31.0, -0.42, -21.0), Vector3(33.0, -0.42, -12.0), Vector3(32.0, -0.42, 0.0), Vector3(31.0, -0.42, 9.0), Vector3(28.4, -0.42, 13.0)]})
    trade_dests.append({"name": "East Isle", "icon": "🏝", "uses": "fresh crops, rice, cake and eggs for the islanders", "pool": [["crop", 0], ["crop", 2], ["crop", 4], ["good", 2], ["prod", 1]], "modes": [2, 3, 4], "stn": -1,
        "pos": Vector3(31.0, 0.6, 23.0), "boat": [Vector3(6.8, -0.42, -20.2), Vector3(9.0, -0.42, -22.0), Vector3(20.0, -0.42, -23.2), Vector3(31.0, -0.42, -21.0), Vector3(34.5, -0.42, -10.0), Vector3(34.5, -0.42, 6.0), Vector3(33.5, -0.42, 17.0), Vector3(31.8, -0.42, 19.2)]})
    trade_dests.append({"name": "Lighthouse Isle", "icon": "🗼", "uses": "hot soup, energy cells and milk for the keeper", "pool": [["good", 1], ["energy", 0], ["prod", 0]], "modes": [2, 3, 4], "stn": -1,
        "pos": Vector3(38.0, 0.6, -11.0), "boat": [Vector3(6.8, -0.42, -20.2), Vector3(9.0, -0.42, -22.0), Vector3(20.0, -0.42, -23.2), Vector3(31.0, -0.42, -21.0), Vector3(36.5, -0.42, -15.5), Vector3(37.2, -0.42, -13.8)]})

func _trade_refresh_dest_pos() -> void:
    for d in trade_dests:
        var si: int = int(d["stn"])
        if si >= 0 and si < train_stops.size():
            var sn: Node3D = train_stops[si]["node"]
            var nrm: Vector2 = train_stops[si]["n"]
            d["pos"] = Vector3(sn.position.x + nrm.x * 1.7, 0.2, sn.position.z + nrm.y * 1.7)

func _trade_dist(d: Dictionary) -> float:
    var p: Vector3 = d["pos"]
    return Vector2(p.x - TRADE_POS.x, p.z - TRADE_POS.z).length()

func _trade_item_ok(k: String, id: int) -> bool:
    if k == "crop":
        return level >= int(crop_defs[id]["lv"])
    if k == "prod":
        return id != 3 or orchard_owned
    return true

func _trade_make_order(slot: int) -> void:
    var d_idx: int = audio_rng.randi() % trade_dests.size()
    var d: Dictionary = trade_dests[d_idx]
    var pool: Array = (d["pool"] as Array).duplicate()
    var items: Array = []
    var want: int = 2 + (audio_rng.randi() % 2)
    var tries: int = 0
    while items.size() < want and pool.size() > 0 and tries < 20:
        tries += 1
        var pick: int = audio_rng.randi() % pool.size()
        var e: Array = pool[pick]
        pool.remove_at(pick)
        if not _trade_item_ok(str(e[0]), int(e[1])):
            continue
        var n: int = 1 + (audio_rng.randi() % (2 + level / 6))
        if str(e[0]) == "energy":
            n = 5 * (1 + (audio_rng.randi() % 3))
        items.append({"k": str(e[0]), "id": int(e[1]), "n": n})
    if items.is_empty():
        items.append({"k": "good", "id": 0, "n": 2})
    var wt: int = 0
    for it in items:
        wt += ((int(it["n"]) + 4) / 5) if str(it["k"]) == "energy" else int(it["n"])
    while wt > 12 and items.size() > 1:
        var last: Dictionary = items.pop_back()
        wt -= ((int(last["n"]) + 4) / 5) if str(last["k"]) == "energy" else int(last["n"])
    var value: float = 0.0
    for it in items:
        value += float(_item_price(str(it["k"]), int(it["id"])) * int(it["n"]))
    var coins_pay: int = int(round((value * 1.5 + _trade_dist(d) * 1.6 + 25.0) * 1.2))
    var xp_pay: int = 10 + 4 * items.size()
    trade_orders[slot] = {"dest": d_idx, "items": items, "coins": coins_pay, "xp": xp_pay, "left": TRADE_TIME + float(audio_rng.randi() % 240), "state": 0, "mode": -1}

func _trade_have(o: Dictionary) -> bool:
    for it in o["items"]:
        if _item_have(str(it["k"]), int(it["id"])) < int(it["n"]):
            return false
    return true

func _trade_count(o: Dictionary) -> int:
    var n: int = 0
    for it in o["items"]:
        if str(it["k"]) == "energy":
            n += (int(it["n"]) + 4) / 5   # 5 energy cells = 1 parcel unit
        else:
            n += int(it["n"])
    return n

func _trade_busy(mode: int) -> bool:
    if mode == 0:
        return train_state != 0
    return int((trade_veh[mode] as Dictionary)["state"]) != 0

func _trade_eta(d: Dictionary, mode: int) -> float:
    if mode == 0:
        return _train_eta(int(d["stn"]))
    var p: Vector3 = d["pos"]
    var dist: float = _trade_dist(d)
    if mode == 4:
        var wl: Array = d["boat"]
        dist = 0.0
        for i in range(wl.size() - 1):
            dist += (wl[i] as Vector3).distance_to(wl[i + 1])
    return dist * 1.15 / float(MODE_SPEED[mode]) + 4.0

func _trade_reason(o: Dictionary, mode: int) -> String:
    var d: Dictionary = trade_dests[int(o["dest"])]
    if not (d["modes"] as Array).has(mode):
        return "no route"
    if _trade_busy(mode):
        return "busy"
    if _trade_count(o) > (v27.mode_cap(mode, int(MODE_CAP[mode])) if v27 != null else int(MODE_CAP[mode])):
        return "too heavy"
    if mode == 1 and _trade_dist(d) > DRONE_RANGE:
        return "too far"
    if mode == 3:
        var p: Vector3 = d["pos"]
        if Vector2(p.x, p.z).distance_to(PLANE_EXIT) < 9.0:
            return "too close"
    if not _trade_have(o):
        return "need items"
    return ""

func _fmt_time(sec: float) -> String:
    var s: int = int(maxf(0.0, sec))
    return "%d:%02d" % [s / 60, s % 60]

# ------------------------------------------------------------------ dispatch

func _trade_send(slot: int, mode: int) -> void:
    var o: Dictionary = trade_orders[slot]
    if o.is_empty() or int(o["state"]) != 0:
        return
    var why: String = _trade_reason(o, mode)
    if why != "":
        _show_toast("Cannot send: %s" % why)
        return
    var d: Dictionary = trade_dests[int(o["dest"])]
    for it in o["items"]:
        _item_take(str(it["k"]), int(it["id"]), int(it["n"]))
    o["state"] = 1
    o["mode"] = mode
    if mode == 0:
        _train_dispatch(int(d["stn"]))
    else:
        _trade_start_vehicle(mode, slot, d)
    _play_named("horn", -14.0)
    _show_toast("%s %s is taking your order to %s!" % [MODE_ICONS[mode], MODE_NAMES[mode], str(d["name"])])
    _refresh_ui()
    _save_game()
    _refresh_trade()

func _trade_start_vehicle(mode: int, slot: int, d: Dictionary) -> void:
    var v: Dictionary = trade_veh[mode]
    var res: Dictionary = _trade_build_path(mode, d)
    v["path"] = res["path"]
    v["drop_t"] = res["drop_t"]
    v["dropped"] = false
    v["order"] = slot
    v["t"] = 0.0
    v["speed"] = 0.0
    v["state"] = 2
    v["pre"] = 1.5 if mode != 4 else 0.6
    var crate: Node3D = (v["d"] as Dictionary).get("crate", null)
    if crate != null:
        crate.visible = true

func _trade_pad(mode: int) -> Vector3:
    if mode == 1:
        return Vector3(TRADE_POS.x - 1.4, ROOF_Y + 0.08, TRADE_POS.z)
    if mode == 2:
        return Vector3(TRADE_POS.x + 0.9, ROOF_Y + 0.09, TRADE_POS.z)
    if mode == 3:
        return Vector3(-0.8, 0.13, RUNWAY_Z)
    return Vector3(6.8, -0.42, -20.2)

func _drop_index_time(path: Dictionary, drop: Vector3) -> float:
    var pts: PackedVector3Array = path["pts"]
    var best: float = 1000.0
    var best_t: float = 0.0
    var cum: PackedFloat32Array = path["cum"]
    for i in range(pts.size()):
        var dd: float = pts[i].distance_to(drop)
        if dd < best - 0.001:
            best = dd
            best_t = cum[i]
        elif dd > best + 6.0 and best < 0.6:
            break
    return best_t

func _trade_build_path(mode: int, d: Dictionary) -> Dictionary:
    var D: Vector3 = d["pos"]
    var pad: Vector3 = _trade_pad(mode)
    var wps: Array = []
    var drop: Vector3 = D
    if mode == 4:
        var wl: Array = d["boat"]
        for i in range(wl.size()):
            var sp: float = 2.6
            if i == 0 or i == wl.size() - 1:
                sp = 0.9
            wps.append([wl[i], sp])
        drop = wl[wl.size() - 1]
        var back: Array = []
        for i in range(wl.size() - 2, -1, -1):
            var sp2: float = 2.6 if i > 0 else 0.9
            back.append([wl[i], sp2])
        wps.append_array(back)
        var pb: Dictionary = _air_build(wps, false)
        return {"path": pb, "drop_t": _drop_index_time(pb, drop)}
    if mode == 3:
        var exit3: Vector3 = Vector3(PLANE_EXIT.x, 3.8, PLANE_EXIT.y)
        wps = [
            [pad, 0.4], [Vector3(2.0, 0.13, RUNWAY_Z), 3.5], [Vector3(6.0, 0.13, RUNWAY_Z), 6.0], [Vector3(9.5, 0.7, RUNWAY_Z - 0.05), 6.5],
            [Vector3(12.5, 2.2, RUNWAY_Z - 0.8), 6.5], [exit3, 6.5]
        ]
        var dir2: Vector2 = (Vector2(D.x, D.z) - PLANE_EXIT).normalized()
        var perp: Vector2 = Vector2(-dir2.y, dir2.x)
        var dxz: Vector2 = Vector2(D.x, D.z)
        if (dxz + perp * 7.0).length() < (dxz - perp * 7.0).length():
            perp = -perp
        var m1: Vector2 = PLANE_EXIT + dir2 * 6.0
        var a2: Vector2 = dxz - dir2 * 5.0
        var b2: Vector2 = dxz + dir2 * 5.0
        var c1: Vector2 = dxz + dir2 * 7.0 + perp * 3.5
        var c2: Vector2 = dxz + dir2 * 3.0 + perp * 7.0
        var r1: Vector2 = dxz - dir2 * 5.0 + perp * 7.0
        wps.append([Vector3(m1.x, 6.0, m1.y), 7.0])
        wps.append([Vector3(a2.x, 4.8, a2.y), 6.0])
        var drop_p: Vector3 = Vector3(D.x, maxf(4.2, D.y + 3.4), D.z)
        wps.append([drop_p, 5.5])
        wps.append([Vector3(b2.x, 5.0, b2.y), 5.5])
        wps.append([Vector3(c1.x, 5.2, c1.y), 5.0])
        wps.append([Vector3(c2.x, 5.2, c2.y), 5.0])
        wps.append([Vector3(r1.x, 5.2, r1.y), 6.0])
        wps.append([Vector3(26.0, 5.2, RUNWAY_Z + 0.2), 6.5])
        wps.append([Vector3(18.0, 4.2, RUNWAY_Z), 5.0])
        wps.append([Vector3(13.5, 3.0, RUNWAY_Z), 4.4])
        wps.append([Vector3(11.0, 1.2, RUNWAY_Z), 3.6])
        wps.append([Vector3(9.4, 0.15, RUNWAY_Z), 3.0])
        wps.append([Vector3(6.0, 0.13, RUNWAY_Z), 2.6])
        wps.append([Vector3(2.0, 0.13, RUNWAY_Z), 1.8])
        wps.append([Vector3(-0.8, 0.13, RUNWAY_Z), 0.4])
        var p3: Dictionary = _air_build(wps, false)
        return {"path": p3, "drop_t": _drop_index_time(p3, drop_p)}
    # Drone / helicopter: straight run at cruise altitude, hover, drop, come back.
    var cruise: float = 5.2 if mode == 1 else 5.8
    var spd: float = float(MODE_SPEED[mode])
    var dir: Vector2 = (Vector2(D.x, D.z) - Vector2(pad.x, pad.z))
    var dist: float = dir.length()
    dir = dir / maxf(0.01, dist)
    var hover: Vector3 = Vector3(D.x, D.y + 1.6, D.z)
    var out: Array = [
        [pad, 0.4], [pad + Vector3(0.0, 1.0, 0.0), 1.6],
        [Vector3(pad.x + dir.x * 3.0, cruise, pad.z + dir.y * 3.0), spd],
        [Vector3(D.x - dir.x * 4.0, cruise - 0.5, D.z - dir.y * 4.0), spd],
        [Vector3(D.x - dir.x * 1.5, hover.y + 0.8, D.z - dir.y * 1.5), 1.6],
        [hover, 0.5]
    ]
    wps = out.duplicate()
    for i in range(out.size() - 2, -1, -1):
        wps.append(out[i])
    var pa: Dictionary = _air_build(wps, false)
    return {"path": pa, "drop_t": _drop_index_time(pa, hover)}

func _vehicle_arrived(mode: int) -> void:
    # Train reached its destination station.
    for i in range(trade_orders.size()):
        var o: Dictionary = trade_orders[i]
        if not o.is_empty() and int(o["state"]) == 1 and int(o["mode"]) == mode:
            _trade_deliver(i, mode)
            return

func _vehicle_returned(mode: int) -> void:
    _show_toast("%s %s is back at the Trade Centre." % [MODE_ICONS[mode], MODE_NAMES[mode]])
    _refresh_trade()

func _trade_deliver(slot: int, mode: int) -> void:
    var o: Dictionary = trade_orders[slot]
    var d: Dictionary = trade_dests[int(o["dest"])]
    var pay: int = int(o["coins"])
    coins += pay
    _add_xp(int(o["xp"]))
    _quest_event("collect", 1)
    trade_delivered += 1
    _play_named("ding")
    _refresh_ui()
    var air: bool = mode == 1 or mode == 2 or mode == 3
    _spawn_parcel(d["pos"], air, mode == 3)
    trade_orders[slot] = {}
    trade_cool[slot] = 15.0 + float(audio_rng.randi() % 20)
    _show_toast("Delivered to %s %s!\n+%d coins, +%d XP" % [str(d["icon"]), str(d["name"]), pay, int(o["xp"])])
    _save_game()
    _refresh_trade()

func _spawn_parcel(pos: Vector3, air: bool, chute: bool) -> void:
    var n := Node3D.new()
    n.name = "Parcel"
    n.position = pos + Vector3(0.0, 3.0 if air else 0.0, 0.0)
    trade_root.add_child(n)
    _box(n, Vector3(0.34, 0.26, 0.34), Vector3(0.0, 0.13, 0.0), Color(0.86, 0.62, 0.30), "ParcelBox")
    _box(n, Vector3(0.36, 0.05, 0.36), Vector3(0.0, 0.13, 0.0), Color(0.55, 0.38, 0.20), "ParcelBand")
    if chute:
        var ch: MeshInstance3D = _ellipsoid(n, Vector3(0.5, 0.2, 0.5), Vector3(0.0, 0.9, 0.0), Color(0.95, 0.30, 0.25), "Chute")
        ch.set_meta("chute", true)
        for sx in [-1.0, 1.0]:
            for sz in [-1.0, 1.0]:
                _wire(n, Vector3(float(sx) * 0.4, 0.88, float(sz) * 0.4), Vector3(float(sx) * 0.1, 0.26, float(sz) * 0.1), 0.012, Color(0.9, 0.9, 0.9))
    var coin: Node3D = _make_coin_bubble(n, Vector3(0.0, 1.1, 0.0))
    coin.visible = true
    trade_fx.append({"node": n, "t": 0.0, "y1": pos.y, "air": air})

func _update_trade_fx(delta: float) -> void:
    var i: int = trade_fx.size() - 1
    while i >= 0:
        var f: Dictionary = trade_fx[i]
        var n: Node3D = f["node"]
        f["t"] = float(f["t"]) + delta
        var t: float = float(f["t"])
        if bool(f["air"]) and t < 1.6:
            n.position.y = lerpf(float(f["y1"]) + 3.0, float(f["y1"]), t / 1.6)
        else:
            n.position.y = float(f["y1"])
        for c in n.get_children():
            if c is Node3D and c.get_child_count() > 0 and not (c is MeshInstance3D):
                (c as Node3D).rotation.y += 3.0 * delta
        if t > 4.5:
            n.queue_free()
            trade_fx.remove_at(i)
        i -= 1

# ------------------------------------------------------------------ models

func _build_drone() -> Dictionary:
    var dr := Node3D.new()
    dr.name = "Drone"
    _box(dr, Vector3(0.30, 0.08, 0.30), Vector3(0.0, 0.18, 0.0), Color(0.22, 0.24, 0.30), "DroneBody")
    _sphere(dr, 0.07, 0.12, Vector3(0.14, 0.14, 0.0), Color(0.3, 0.8, 0.95), "DroneEye").material_override = _window_material()
    var rotors: Array = []
    for sx in [-1.0, 1.0]:
        for sz in [-1.0, 1.0]:
            var arm: MeshInstance3D = _box(dr, Vector3(0.34, 0.025, 0.04), Vector3(float(sx) * 0.15, 0.2, float(sz) * 0.15), Color(0.15, 0.16, 0.2), "DroneArm")
            arm.rotation_degrees.y = 45.0 * float(sx) * float(sz) * -1.0
            var r := Node3D.new()
            r.position = Vector3(float(sx) * 0.27, 0.25, float(sz) * 0.27)
            dr.add_child(r)
            _box(r, Vector3(0.34, 0.01, 0.035), Vector3.ZERO, Color(0.85, 0.85, 0.9), "Blade")
            _box(r, Vector3(0.035, 0.01, 0.34), Vector3.ZERO, Color(0.85, 0.85, 0.9), "Blade")
            rotors.append(r)
    var strobe: MeshInstance3D = _sphere(dr, 0.03, 0.06, Vector3(-0.14, 0.24, 0.0), Color(1, 1, 1), "DroneStrobe")
    strobe.material_override = _strobe_material()
    var crate := Node3D.new()
    crate.name = "Parcel"
    dr.add_child(crate)
    _box(crate, Vector3(0.22, 0.18, 0.22), Vector3(0.0, 0.03, 0.0), Color(0.86, 0.62, 0.30), "Crate")
    _box(crate, Vector3(0.23, 0.04, 0.23), Vector3(0.0, 0.03, 0.0), Color(0.55, 0.38, 0.20), "CrateBand")
    crate.visible = false
    dr.scale = Vector3.ONE * 1.5
    return {"node": dr, "rotors": rotors, "strobe": strobe, "crate": crate}

func _build_cargo_boat() -> Dictionary:
    var wrap := Node3D.new()
    wrap.name = "CargoBoat"
    var b: Node3D = _make_fishing_boat(Color(0.16, 0.52, 0.55))
    remove_child(b)
    b.rotation_degrees.y = 90.0
    b.scale = Vector3.ONE * 1.5
    wrap.add_child(b)
    return {"node": wrap}

func _build_trade() -> void:
    _trade_init_dests()
    trade_root = Node3D.new()
    trade_root.name = "TradeRoot"
    add_child(trade_root)
    trade_built = Node3D.new()
    trade_built.name = "TradeCentre"
    trade_built.position = TRADE_POS
    trade_root.add_child(trade_built)
    var tb: Node3D = trade_built
    _box(tb, Vector3(5.0, 0.12, 3.2), Vector3(0.0, 0.06, 0.0), Color(0.62, 0.62, 0.64), "TradeSlab")
    _box(tb, Vector3(4.4, 1.5, 2.6), Vector3(0.0, 0.87, 0.0), Color(0.93, 0.90, 0.82), "TradeWalls")
    _box(tb, Vector3(4.6, 0.14, 2.8), Vector3(0.0, 1.62, 0.0), Color(0.30, 0.34, 0.42), "TradeRoof")
    for pe in [[Vector3(4.6, 0.16, 0.08), Vector3(0.0, 1.75, 1.4)], [Vector3(4.6, 0.16, 0.08), Vector3(0.0, 1.75, -1.4)], [Vector3(0.08, 0.16, 2.8), Vector3(2.3, 1.75, 0.0)], [Vector3(0.08, 0.16, 2.8), Vector3(-2.3, 1.75, 0.0)]]:
        _box(tb, pe[0], pe[1], Color(0.95, 0.95, 0.95), "Parapet")
    var door_cols: Array = [Color(0.95, 0.55, 0.15), Color(0.20, 0.50, 0.80), Color(0.30, 0.70, 0.35)]
    for i in range(3):
        _box(tb, Vector3(0.85, 0.95, 0.06), Vector3(-1.4 + 1.4 * float(i), 0.6, 1.31), door_cols[i], "TradeDoor")
        _box(tb, Vector3(0.95, 0.06, 0.08), Vector3(-1.4 + 1.4 * float(i), 1.1, 1.32), Color(0.95, 0.95, 0.95), "DoorFrame")
    _box(tb, Vector3(4.2, 0.30, 0.08), Vector3(0.0, 1.42, 1.32), Color(0.14, 0.24, 0.45), "TradeBand")
    for wz in [-0.6, 0.6]:
        var tw: MeshInstance3D = _box(tb, Vector3(0.05, 0.3, 0.5), Vector3(2.22, 0.95, float(wz)), Color(0.33, 0.76, 0.92), "TradeWin")
        tw.material_override = _window_material()
    # Conveyor, crates, pallets.
    _box(tb, Vector3(1.5, 0.14, 0.5), Vector3(-3.0, 0.2, 0.9), Color(0.35, 0.36, 0.40), "Conveyor")
    for rx in range(6):
        _cylinder(tb, 0.05, 0.05, 0.46, Vector3(-3.6 + float(rx) * 0.24, 0.3, 0.9), Color(0.6, 0.6, 0.64), "Roller").rotation.x = PI * 0.5
    _box(tb, Vector3(0.4, 0.3, 0.4), Vector3(-3.2, 0.4, 0.9), Color(0.86, 0.62, 0.30), "BeltCrate")
    _box(tb, Vector3(0.5, 0.36, 0.5), Vector3(-2.9, 0.3, -1.2), Color(0.55, 0.78, 0.40), "CrateStack")
    _box(tb, Vector3(0.5, 0.36, 0.5), Vector3(-2.9, 0.66, -1.2), Color(0.86, 0.62, 0.30), "CrateStack")
    _box(tb, Vector3(0.5, 0.36, 0.5), Vector3(-2.35, 0.3, -1.6), Color(0.35, 0.58, 0.85), "CrateStack")
    # Rooftop pads: drone pad (yellow ring) and helicopter pad with H.
    _disc(tb, 0.40, 0.02, Vector3(-1.4, 1.71, 0.0), Color(0.98, 0.82, 0.15), "DronePad", 0.9, 16)
    _disc(tb, 0.32, 0.02, Vector3(-1.4, 1.72, 0.0), Color(0.22, 0.24, 0.28), "DronePadIn", 0.9, 16)
    _disc(tb, 0.66, 0.02, Vector3(0.9, 1.71, 0.0), Color(0.95, 0.95, 0.95), "HeliPad", 0.9, 20)
    _disc(tb, 0.58, 0.02, Vector3(0.9, 1.72, 0.0), Color(0.22, 0.24, 0.28), "HeliPadIn", 0.9, 20)
    _box(tb, Vector3(0.07, 0.02, 0.44), Vector3(0.78, 1.735, 0.0), Color(0.95, 0.95, 0.95), "PadH")
    _box(tb, Vector3(0.07, 0.02, 0.44), Vector3(1.02, 1.735, 0.0), Color(0.95, 0.95, 0.95), "PadH")
    _box(tb, Vector3(0.24, 0.02, 0.07), Vector3(0.9, 1.735, 0.0), Color(0.95, 0.95, 0.95), "PadH")
    _cylinder(tb, 0.04, 0.05, 1.3, Vector3(1.9, 2.3, -0.9), Color(0.78, 0.78, 0.8), "TradeMast")
    trade_beacon = _sphere(tb, 0.07, 0.14, Vector3(1.9, 3.0, -0.9), Color(1.0, 0.2, 0.15), "TradeBeacon")
    var bm := StandardMaterial3D.new()
    bm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    bm.albedo_color = Color(1.0, 0.2, 0.15)
    trade_beacon.material_override = bm
    _label3d(tb, "TRADE CENTRE", Vector3(0.0, 3.1, 0.0), 0.012, Color(0.85, 0.95, 1.0))
    # Runway for the cargo plane.
    var rw := Node3D.new()
    rw.name = "Runway"
    trade_root.add_child(rw)
    _box(rw, Vector3(13.8, 0.05, 1.7), Vector3(4.3, 0.03, RUNWAY_Z), Color(0.34, 0.36, 0.40), "RunwayStrip")
    var rx2: float = -2.0
    while rx2 < 10.8:
        _box(rw, Vector3(0.6, 0.012, 0.07), Vector3(rx2, 0.06, RUNWAY_Z), Color(0.95, 0.95, 0.95), "RunwayDash")
        rx2 += 1.3
    for ex in [-2.4, 11.0]:
        for k in range(4):
            _box(rw, Vector3(0.5, 0.012, 0.06), Vector3(float(ex), 0.06, RUNWAY_Z - 0.55 + float(k) * 0.37), Color(0.95, 0.95, 0.95), "RunwayBar")
    var lx: float = -2.2
    while lx < 11.0:
        for lz in [-0.9, 0.9]:
            var rl: MeshInstance3D = _sphere(rw, 0.045, 0.09, Vector3(lx, 0.1, RUNWAY_Z + float(lz)), Color(1.0, 0.93, 0.62), "RunwayLight")
            rl.material_override = _lamp_material()
        lx += 2.3
    _cylinder(rw, 0.03, 0.03, 1.0, Vector3(11.4, 0.5, RUNWAY_Z - 1.3), Color(0.8, 0.8, 0.82), "WindPole")
    trade_windsock = Node3D.new()
    trade_windsock.position = Vector3(11.4, 1.0, RUNWAY_Z - 1.3)
    rw.add_child(trade_windsock)
    var sock: MeshInstance3D = _cylinder(trade_windsock, 0.02, 0.09, 0.5, Vector3(0.25, 0.0, 0.0), Color(0.98, 0.5, 0.15), "Windsock")
    sock.rotation.z = PI * 0.5
    # Jetty and mooring for the cargo boat.
    _box(rw, Vector3(1.0, 0.10, 3.4), Vector3(5.2, 0.02, -18.4), Color(0.72, 0.54, 0.32), "Jetty")
    for jz in [-19.6, -17.4]:
        for jx in [4.75, 5.65]:
            _cylinder(rw, 0.07, 0.07, 1.0, Vector3(float(jx), -0.3, float(jz)), Color(0.40, 0.28, 0.16), "JettyPost")
    # Vehicles.
    trade_veh.clear()
    trade_veh.append({"mode": 0, "state": 0})
    var dd: Dictionary = _build_drone()
    var hh: Dictionary = _build_heli()
    var pp: Dictionary = _build_supply_plane()
    var bb: Dictionary = _build_cargo_boat()
    var vs: Array = [null, dd, hh, pp, bb]
    var kinds: Array = [0, 2, 2, 1, 3]
    for m in range(1, 5):
        var vd: Dictionary = vs[m]
        trade_root.add_child(vd["node"])
        var pad: Vector3 = _trade_pad(m)
        trade_veh.append({"mode": m, "node": vd["node"], "d": vd, "kind": kinds[m], "path": {}, "state": 0, "t": 0.0, "speed": 0.0, "pre": 0.0, "rot": 0.0, "yaw": 0.0, "order": -1, "drop_t": 0.0, "dropped": false})
        (vd["node"] as Node3D).position = pad
    (trade_veh[3]["d"]["node"] as Node3D).rotation = Vector3.ZERO
    trade_site = _make_lock_site(Vector3(TRADE_POS.x, 0.0, TRADE_POS.z), "Trade Centre\nLevel %d" % TRADE_LV, 0.0, 3.4)
    trade_orders = []
    for i in range(TRADE_SLOTS):
        trade_orders.append({})
    trade_root.visible = false
    _trade_refresh_dest_pos()

func _update_trade_visibility() -> void:
    if trade_root == null:
        return
    trade_root.visible = trade_unlocked
    trade_site.visible = not trade_unlocked
    _update_lock_buttons()

# ------------------------------------------------------------------ update

func _update_trade(delta: float) -> void:
    if not trade_unlocked or trade_root == null:
        return
    trade_beacon.visible = fmod(sway_clock, 1.5) < 0.75
    trade_windsock.rotation.y = -0.6 + sin(sway_clock * 0.7) * 0.4
    trade_windsock.rotation.z = sin(sway_clock * 2.0) * 0.08
    for i in range(TRADE_SLOTS):
        var o: Dictionary = trade_orders[i]
        if o.is_empty():
            if i >= _trade_active_slots():
                continue
            trade_cool[i] = float(trade_cool[i]) - delta
            if float(trade_cool[i]) <= 0.0:
                _trade_make_order(i)
                if trade_panel != null and trade_panel.visible:
                    _refresh_trade()
        elif int(o["state"]) == 0:
            o["left"] = float(o["left"]) - delta
            if float(o["left"]) <= 0.0:
                _show_toast("A trade order for %s expired." % str(trade_dests[int(o["dest"])]["name"]))
                trade_orders[i] = {}
                trade_cool[i] = 25.0
                _refresh_trade()
    for m in range(1, 5):
        _update_trade_vehicle(trade_veh[m], delta)
    _update_trade_fx(delta)
    trade_tick -= delta
    if trade_tick <= 0.0:
        trade_tick = 0.5
        if trade_panel != null and trade_panel.visible:
            _refresh_trade()

func _update_trade_vehicle(v: Dictionary, delta: float) -> void:
    var st: int = int(v["state"])
    var mode: int = int(v["mode"])
    var dd: Dictionary = v["d"]
    if st == 0:
        v["rot"] = move_toward(float(v["rot"]), 0.0, delta * 0.8)
    elif st == 2:
        v["pre"] = float(v["pre"]) - delta
        v["rot"] = move_toward(float(v["rot"]), 1.0, delta * 0.7)
        if float(v["pre"]) <= 0.0:
            v["state"] = 1
    elif st == 1:
        var path: Dictionary = v["path"]
        var tgt: float = _air_speed(path, float(v["t"]))
        v["speed"] = move_toward(float(v["speed"]), tgt, 6.0 * delta)
        v["t"] = float(v["t"]) + float(v["speed"]) * delta
        v["rot"] = move_toward(float(v["rot"]), 1.0, delta)
        if not bool(v["dropped"]) and float(v["t"]) >= float(v["drop_t"]):
            v["dropped"] = true
            if dd.has("crate"):
                (dd["crate"] as Node3D).visible = false
            _trade_deliver(int(v["order"]), mode)
        if float(v["t"]) >= float(path["len"]):
            v["speed"] = 0.0
            v["t"] = 0.0
            if mode == 3:
                v["state"] = 4
                v["pre"] = 1.4
            else:
                v["state"] = 0
                _trade_park(v)
                _vehicle_returned(mode)
    elif st == 4:
        v["pre"] = float(v["pre"]) - delta
        var node: Node3D = v["node"]
        node.rotation.y = lerp_angle(node.rotation.y, 0.0, clampf(delta * 3.0, 0.0, 1.0))
        v["rot"] = move_toward(float(v["rot"]), 0.0, delta * 0.6)
        if float(v["pre"]) <= 0.0:
            v["state"] = 0
            _trade_park(v)
            _vehicle_returned(mode)
    if st == 1:
        _air_pose(v, delta)
    if dd.has("prop"):
        (dd["prop"] as Node3D).rotation.x += 45.0 * float(v["rot"]) * delta
    if dd.has("rotor"):
        (dd["rotor"] as Node3D).rotation.y += 34.0 * float(v["rot"]) * delta
        (dd["trot"] as Node3D).rotation.z += 40.0 * float(v["rot"]) * delta
    if dd.has("rotors"):
        for r in dd["rotors"]:
            (r as Node3D).rotation.y += 60.0 * float(v["rot"]) * delta

func _trade_park(v: Dictionary) -> void:
    var node: Node3D = v["node"]
    node.position = _trade_pad(int(v["mode"]))
    node.rotation = Vector3.ZERO
    v["yaw"] = 0.0
    v["rot"] = 0.0
    var dd: Dictionary = v["d"]
    if dd.has("crate"):
        (dd["crate"] as Node3D).visible = false
    if dd.has("gear"):
        (dd["gear"] as Node3D).visible = true

# ------------------------------------------------------------------ panel

func _build_trade_panel() -> void:
    var made: Array = _new_panel("🏬 TRADE CENTRE", 0.04, 0.96)
    trade_panel = made[0]
    var col: VBoxContainer = made[1]
    trade_info = _panel_label(col, 16, Color(0.85, 0.97, 1.0))
    var sc := ScrollContainer.new()
    sc.size_flags_vertical = Control.SIZE_EXPAND_FILL
    sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
    col.add_child(sc)
    trade_list = VBoxContainer.new()
    trade_list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    trade_list.add_theme_constant_override("separation", 10)
    sc.add_child(trade_list)
    var close: Button = _panel_button(col, "CLOSE", 44, 18)
    close.pressed.connect(_close_panels)

var trade_sel: Array = [-1, -1, -1, -1]

func _trade_select(slot: int, mode: int) -> void:
    if int(trade_sel[slot]) == mode:
        trade_sel[slot] = -1
    else:
        trade_sel[slot] = mode
        var o27: Dictionary = trade_orders[slot]
        if v27 != null and not o27.is_empty() and _trade_reason(o27, mode) == "too heavy":
            v27.alert("cargo", true)
            return
    _play_named("ding", -20.0)
    _refresh_trade()

func _trade_confirm(slot: int) -> void:
    var m: int = int(trade_sel[slot])
    if m < 0:
        _show_toast("Choose a transport first.")
        return
    trade_sel[slot] = -1
    _trade_send(slot, m)

func _trade_fix_sel() -> void:
    for i in range(TRADE_SLOTS):
        var m: int = int(trade_sel[i])
        if m < 0:
            continue
        var o: Dictionary = trade_orders[i]
        if o.is_empty() or int(o["state"]) != 0 or _trade_reason(o, m) != "":
            trade_sel[i] = -1

func _trade_signature() -> String:
    _trade_fix_sel()
    var s: String = ""
    for q in trade_sel:
        s += "%d," % int(q)
    for m in range(5):
        s += "1" if _trade_busy(m) else "0"
    for o in trade_orders:
        var od: Dictionary = o
        if od.is_empty():
            s += "|-"
        else:
            s += "|%d,%d,%d,%d" % [int(od["dest"]), int(od["state"]), int(od["mode"]), 1 if _trade_have(od) else 0]
    return s

func _refresh_trade() -> void:
    if trade_panel == null:
        return
    var sig: String = _trade_signature()
    if sig != trade_sig:
        trade_sig = sig
        _rebuild_trade_cards()
    var st: String = ""
    for m in range(5):
        st += "%s %s   " % [MODE_ICONS[m], "out" if _trade_busy(m) else "ready"]
    trade_info.text = "Up to %d orders at a time. Pick a transport, then press SEND ORDER.\n%s" % [_trade_active_slots(), st]
    for tl in trade_time_labels:
        var info: Dictionary = tl
        var lab: Label = info["label"]
        if is_instance_valid(lab):
            var o: Dictionary = trade_orders[int(info["slot"])]
            if not o.is_empty():
                lab.text = "Reward: %d coins  •  +%d XP   ⏳ %s" % [int(o["coins"]), int(o["xp"]), _fmt_time(float(o["left"]))] if int(o["state"]) == 0 else "Reward: %d coins  •  +%d XP   🚚 on its way" % [int(o["coins"]), int(o["xp"])]

func _rebuild_trade_cards() -> void:
    for c in trade_list.get_children():
        trade_list.remove_child(c)
        c.queue_free()
    trade_time_labels.clear()
    var any: bool = false
    for slot in range(TRADE_SLOTS):
        var o: Dictionary = trade_orders[slot]
        if o.is_empty():
            continue
        if slot >= _trade_active_slots() and int(o["state"]) == 0:
            continue
        any = true
        var d: Dictionary = trade_dests[int(o["dest"])]
        var card := PanelContainer.new()
        card.add_theme_stylebox_override("panel", _flat(Color(0.17, 0.33, 0.27, 1.0), 14, Color(0.45, 0.70, 0.55), 2, 8.0))
        trade_list.add_child(card)
        var vb := VBoxContainer.new()
        vb.add_theme_constant_override("separation", 4)
        card.add_child(vb)
        var t1: Label = _panel_label(vb, 19, Color(1.0, 0.94, 0.6))
        t1.text = "%s %s" % [d["icon"], d["name"]]
        var t2: Label = _panel_label(vb, 14, Color(0.78, 0.9, 0.82))
        t2.text = "Needs %s" % str(d["uses"])
        var t3: Label = _panel_label(vb, 16, Color(0.95, 0.95, 0.9))
        var parts: Array = []
        for it in o["items"]:
            var have: int = _item_have(str(it["k"]), int(it["id"]))
            var ok: String = "✔" if have >= int(it["n"]) else "✖"
            var nm: String = "⚡ Energy" if str(it["k"]) == "energy" else _item_label(str(it["k"]), int(it["id"]))
            parts.append("%s %s %d/%d" % [ok, nm, mini(have, int(it["n"])), int(it["n"])])
        t3.text = "   ".join(parts)
        var t4: Label = _panel_label(vb, 16, Color(0.7, 1.0, 0.75))
        trade_time_labels.append({"label": t4, "slot": slot})
        if int(o["state"]) == 1:
            var t5: Label = _panel_label(vb, 16, Color(1.0, 0.9, 0.5))
            t5.text = "%s %s is carrying this order." % [MODE_ICONS[int(o["mode"])], MODE_NAMES[int(o["mode"])]]
        else:
            var row := HBoxContainer.new()
            row.add_theme_constant_override("separation", 6)
            vb.add_child(row)
            for m in range(5):
                var b := Button.new()
                b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
                b.custom_minimum_size = Vector2(0, 96)
                var why: String = _trade_reason(o, m)
                var allowed: bool = (d["modes"] as Array).has(m)
                var status: String = ""
                if not allowed:
                    status = "no route"
                    b.disabled = true
                elif why == "":
                    status = _fmt_time(_trade_eta(d, m))
                else:
                    status = why
                    b.disabled = true
                var ic := Label.new()
                ic.text = MODE_ICONS[m]
                ic.add_theme_font_size_override("font_size", 40)
                ic.set_anchors_preset(Control.PRESET_TOP_WIDE)
                ic.offset_top = 4.0
                ic.offset_bottom = 58.0
                ic.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
                ic.mouse_filter = Control.MOUSE_FILTER_IGNORE
                var st2 := Label.new()
                st2.text = "%s\n%s" % [MODE_NAMES[m], status]
                st2.add_theme_font_size_override("font_size", 13)
                st2.set_anchors_preset(Control.PRESET_BOTTOM_WIDE)
                st2.offset_top = -38.0
                st2.offset_bottom = -2.0
                st2.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
                st2.mouse_filter = Control.MOUSE_FILTER_IGNORE
                if b.disabled:
                    ic.modulate = Color(1, 1, 1, 0.4)
                    st2.modulate = Color(1, 1, 1, 0.6)
                b.add_child(ic)
                b.add_child(st2)
                if int(trade_sel[slot]) == m:
                    b.add_theme_stylebox_override("normal", _flat(Color(0.28, 0.52, 0.34), 8, Color(1.0, 0.90, 0.35), 4, 4.0))
                    b.add_theme_stylebox_override("hover", _flat(Color(0.30, 0.56, 0.36), 8, Color(1.0, 0.90, 0.35), 4, 4.0))
                    b.add_theme_stylebox_override("pressed", _flat(Color(0.24, 0.46, 0.30), 8, Color(1.0, 0.90, 0.35), 4, 4.0))
                b.pressed.connect(_trade_select.bind(slot, m))
                row.add_child(b)
            var sk := Button.new()
            sk.text = "✖"
            sk.custom_minimum_size = Vector2(52, 96)
            sk.pressed.connect(_trade_skip.bind(slot))
            row.add_child(sk)
            var sel_m: int = int(trade_sel[slot])
            var send := Button.new()
            send.custom_minimum_size = Vector2(0, 54)
            send.add_theme_font_size_override("font_size", 20)
            if sel_m >= 0:
                send.text = "SEND ORDER  %s %s  •  %s" % [MODE_ICONS[sel_m], MODE_NAMES[sel_m], _fmt_time(_trade_eta(d, sel_m))]
                send.add_theme_stylebox_override("normal", _flat(Color(0.20, 0.62, 0.28), 12, Color(0.85, 1.0, 0.7), 3, 6.0))
                send.add_theme_stylebox_override("hover", _flat(Color(0.24, 0.70, 0.32), 12, Color(0.85, 1.0, 0.7), 3, 6.0))
                send.add_theme_stylebox_override("pressed", _flat(Color(0.16, 0.52, 0.22), 12, Color(0.85, 1.0, 0.7), 3, 6.0))
                send.add_theme_color_override("font_color", Color.WHITE)
                send.pressed.connect(_trade_confirm.bind(slot))
            else:
                send.text = "Choose a transport above"
                send.disabled = true
            vb.add_child(send)
    if not any:
        var e: Label = _panel_label(trade_list, 18, Color(0.85, 0.92, 0.85))
        e.text = "No orders right now. New requests arrive soon!"

func _trade_skip(slot: int) -> void:
    var o: Dictionary = trade_orders[slot]
    if o.is_empty() or int(o["state"]) != 0:
        return
    trade_orders[slot] = {}
    trade_cool[slot] = 20.0
    _refresh_trade()

func _open_trade() -> void:
    if not trade_unlocked:
        _show_toast("Trade Centre unlocks at Level %d (you are Level %d)" % [TRADE_LV, level])
        return
    _close_panels()
    trade_panel.visible = true
    trade_sig = ""
    _refresh_trade()

func _tap_trade(p: Vector2) -> bool:
    if not trade_unlocked or trade_root == null:
        return false
    var base: Vector2 = Vector2(TRADE_POS.x, TRADE_POS.z)
    if _dist_to_segment(p, base, base + Vector2(-1.4, -2.1)) < 3.0:
        _open_trade()
        return true
    return false

func _save_trade(config: ConfigFile) -> void:
    config.set_value("farm", "trade_orders", trade_orders)
    config.set_value("farm", "trade_cool", trade_cool)
    config.set_value("farm", "trade_done", trade_delivered)

func _load_trade(config: ConfigFile) -> void:
    trade_delivered = int(config.get_value("farm", "trade_done", 0))
    var od: Variant = config.get_value("farm", "trade_orders", [])
    if od is Array and (od as Array).size() == TRADE_SLOTS:
        trade_orders = (od as Array).duplicate(true)
        for i in range(TRADE_SLOTS):
            var o: Dictionary = trade_orders[i]
            if o.is_empty():
                continue
            if int(o["dest"]) >= trade_dests.size():
                trade_orders[i] = {}
            elif int(o["state"]) == 1:
                # Delivered while the game was closed.
                coins += int(o["coins"])
                xp += int(o["xp"])
                trade_orders[i] = {}
                trade_cool[i] = 20.0
    var oc: Variant = config.get_value("farm", "trade_cool", [])
    if oc is Array and (oc as Array).size() == TRADE_SLOTS:
        trade_cool = (oc as Array).duplicate()


# ------------------------------------------------------------ v25b natural plants
var crop_vc_mat: StandardMaterial3D

func _crop_material() -> StandardMaterial3D:
    if crop_vc_mat == null:
        crop_vc_mat = StandardMaterial3D.new()
        crop_vc_mat.vertex_color_use_as_albedo = true
        crop_vc_mat.vertex_color_is_srgb = true
        crop_vc_mat.cull_mode = BaseMaterial3D.CULL_DISABLED
        crop_vc_mat.roughness = 0.85
    return crop_vc_mat

func _pm_quad(st: SurfaceTool, a: Vector3, b: Vector3, c: Vector3, d: Vector3, ca: Color, cb: Color, cc: Color, cd: Color) -> void:
    _tri(st, a, b, c, ca, cb, cc)
    _tri(st, a, c, d, ca, cc, cd)

# Curved leaf / grass blade: starts at base, runs along yaw, rises by pitch and droops by `droop` radians.
func _pm_blade(st: SurfaceTool, base: Vector3, yaw: float, length: float, width: float, pitch: float, droop: float, c0: Color, c1: Color, segs: int = 4) -> void:
    var dirh: Vector3 = Vector3(cos(yaw), 0.0, -sin(yaw))
    var side: Vector3 = Vector3(dirh.z, 0.0, -dirh.x)
    var p: Vector3 = base
    var ang: float = pitch
    var step: float = length / float(segs)
    var w0: float = width
    for i in range(segs):
        var t0: float = float(i) / float(segs)
        var t1: float = float(i + 1) / float(segs)
        var d: Vector3 = dirh * cos(ang) + Vector3.UP * sin(ang)
        var pn: Vector3 = p + d * step
        var wa: float = w0 * (1.0 - pow(t0, 2.0) * 0.95)
        var wb: float = w0 * (1.0 - pow(t1, 2.0) * 0.95)
        _pm_quad(st, p + side * wa * 0.5, p - side * wa * 0.5, pn - side * wb * 0.5, pn + side * wb * 0.5, c0.lerp(c1, t0), c0.lerp(c1, t0), c0.lerp(c1, t1), c0.lerp(c1, t1))
        p = pn
        ang -= droop / float(segs)

func _pm_tube(st: SurfaceTool, p0: Vector3, p1: Vector3, r0: float, r1: float, c0: Color, c1: Color, segs: int = 5) -> void:
    var axis: Vector3 = p1 - p0
    var len: float = axis.length()
    if len < 0.0001:
        return
    var ax: Vector3 = axis / len
    var ref: Vector3 = Vector3.UP if absf(ax.y) < 0.95 else Vector3.RIGHT
    var u: Vector3 = ax.cross(ref).normalized()
    var v: Vector3 = ax.cross(u).normalized()
    for i in range(segs):
        var a0: float = TAU * float(i) / float(segs)
        var a1: float = TAU * float(i + 1) / float(segs)
        var o0: Vector3 = u * cos(a0) + v * sin(a0)
        var o1: Vector3 = u * cos(a1) + v * sin(a1)
        _pm_quad(st, p0 + o0 * r0, p0 + o1 * r0, p1 + o1 * r1, p1 + o0 * r1, c0, c0, c1, c1)

func _pm_ell(st: SurfaceTool, c: Vector3, r: Vector3, col: Color, col_top: Color, rings: int = 5, segs: int = 7, tilt: Basis = Basis.IDENTITY) -> void:
    for i in range(rings):
        var la0: float = PI * float(i) / float(rings) - PI * 0.5
        var la1: float = PI * float(i + 1) / float(rings) - PI * 0.5
        var k0: Color = col.lerp(col_top, (sin(la0) + 1.0) * 0.5)
        var k1: Color = col.lerp(col_top, (sin(la1) + 1.0) * 0.5)
        for j in range(segs):
            var lo0: float = TAU * float(j) / float(segs)
            var lo1: float = TAU * float(j + 1) / float(segs)
            var a: Vector3 = c + tilt * Vector3(r.x * cos(la0) * cos(lo0), r.y * sin(la0), r.z * cos(la0) * sin(lo0))
            var b: Vector3 = c + tilt * Vector3(r.x * cos(la0) * cos(lo1), r.y * sin(la0), r.z * cos(la0) * sin(lo1))
            var cc: Vector3 = c + tilt * Vector3(r.x * cos(la1) * cos(lo1), r.y * sin(la1), r.z * cos(la1) * sin(lo1))
            var d: Vector3 = c + tilt * Vector3(r.x * cos(la1) * cos(lo0), r.y * sin(la1), r.z * cos(la1) * sin(lo0))
            _pm_quad(st, a, b, cc, d, k0, k0, k1, k1)

func _plant_tomato(st: SurfaceTool, stage: int, rng: RandomNumberGenerator, ox: float, oz: float, sc: float) -> void:
    var base: Vector3 = Vector3(ox, 0.0, oz)
    var h: float = [0.17, 0.40, 0.58][stage] * sc
    var stem_c: Color = Color(0.34, 0.52, 0.20)
    var leaf_a: Color = Color(0.16, 0.42, 0.12)
    var leaf_b: Color = Color(0.34, 0.62, 0.24)
    var mid: Vector3 = base + Vector3(0.015, h * 0.5, -0.01)
    var top: Vector3 = base + Vector3(-0.01, h, 0.012)
    _pm_tube(st, base, mid, 0.024 * sc, 0.019 * sc, Color(0.28, 0.42, 0.16), stem_c, 5)
    _pm_tube(st, mid, top, 0.019 * sc, 0.012 * sc, stem_c, stem_c, 5)
    if stage >= 1:
        # Wooden stake for the vine.
        _pm_tube(st, base + Vector3(0.07, 0.0, -0.05), base + Vector3(0.07, h + 0.12, -0.05), 0.011, 0.009, Color(0.55, 0.40, 0.22), Color(0.62, 0.46, 0.26), 4)
    var n_leaves: int = [4, 8, 11][stage]
    for k in range(n_leaves):
        var t: float = 0.25 + 0.75 * float(k) / float(maxi(n_leaves - 1, 1))
        var y: float = h * t
        var yaw: float = float(k) * 2.4 + rng.randf() * 0.5
        var o: Vector3 = base + Vector3(0.0, y, 0.0)
        var pl: float = (0.11 + 0.10 * (1.0 - t * 0.5)) * sc * (0.55 if stage == 0 else 1.0)
        _pm_blade(st, o, yaw, pl, 0.022, 0.45, 0.55, stem_c, leaf_a, 3)
        var tip: Vector3 = o + Vector3(cos(yaw), 0.0, -sin(yaw)) * pl * 0.9 + Vector3(0.0, pl * 0.25, 0.0)
        for da in [-0.7, 0.0, 0.7]:
            _pm_blade(st, tip, yaw + float(da), 0.11 * sc, 0.07 * sc, 0.25, 0.5, leaf_a, leaf_b, 3)
        var side_o: Vector3 = o + Vector3(cos(yaw), 0.0, -sin(yaw)) * pl * 0.5 + Vector3(0.0, pl * 0.15, 0.0)
        _pm_blade(st, side_o, yaw + 1.2, 0.07 * sc, 0.05 * sc, 0.2, 0.4, leaf_a, leaf_b, 2)
        _pm_blade(st, side_o, yaw - 1.2, 0.07 * sc, 0.05 * sc, 0.2, 0.4, leaf_a, leaf_b, 2)
    if stage == 1:
        for k in range(2):
            var fy: float = h * (0.55 + 0.2 * float(k))
            var fa: float = float(k) * 3.1 + 0.7
            _pm_ell(st, base + Vector3(cos(fa) * 0.10 * sc, fy, -sin(fa) * 0.10 * sc), Vector3(0.022, 0.012, 0.022), Color(1.0, 0.85, 0.15), Color(1.0, 0.92, 0.35), 3, 6)
        _pm_ell(st, base + Vector3(0.09 * sc, h * 0.45, 0.04 * sc), Vector3(0.036, 0.036, 0.036), Color(0.30, 0.55, 0.18), Color(0.45, 0.70, 0.28), 4, 6)
    if stage == 2:
        var spots: Array = [Vector3(0.12, 0.55, 0.05), Vector3(-0.10, 0.45, 0.10), Vector3(0.05, 0.36, -0.13), Vector3(-0.07, 0.62, -0.08)]
        for si in range(spots.size()):
            var sp: Vector3 = spots[si]
            var fp: Vector3 = base + Vector3(sp.x * sc, sp.y * h / 0.58 * sc * 0.9 + 0.0, sp.z * sc)
            var ripe: bool = si != 3
            var rc: Color = Color(0.86, 0.12, 0.08) if ripe else Color(0.62, 0.72, 0.22)
            var rt: Color = Color(0.98, 0.32, 0.18) if ripe else Color(0.74, 0.82, 0.30)
            _pm_tube(st, base + Vector3(0.0, fp.y + 0.05, 0.0), fp + Vector3(0.0, 0.05, 0.0), 0.007, 0.006, stem_c, stem_c, 3)
            _pm_ell(st, fp, Vector3(0.095, 0.082, 0.095), rc, rt, 5, 8)
            for a in range(5):
                _pm_blade(st, fp + Vector3(0.0, 0.058, 0.0), TAU * float(a) / 5.0, 0.045, 0.016, 0.15, 0.2, Color(0.2, 0.5, 0.15), Color(0.3, 0.6, 0.2), 2)

func _plant_wheat(st: SurfaceTool, stage: int, rng: RandomNumberGenerator) -> void:
    var h: float = [0.15, 0.40, 0.66][stage]
    var green_a: Color = Color(0.30, 0.58, 0.18)
    var green_b: Color = Color(0.52, 0.74, 0.28)
    var straw_a: Color = Color(0.72, 0.58, 0.22)
    var straw_b: Color = Color(0.92, 0.76, 0.34)
    var xs: Array = [-0.30, -0.15, 0.0, 0.15, 0.30]
    var zs: Array = [-0.24, -0.04, 0.16, 0.30]
    for xi in range(xs.size()):
        for zi in range(zs.size()):
            var x: float = float(xs[xi]) + (rng.randf() - 0.5) * 0.09
            var z: float = float(zs[zi]) + (rng.randf() - 0.5) * 0.09 - 0.05
            var hh: float = h * (0.85 + rng.randf() * 0.3)
            var lean: Vector3 = Vector3((rng.randf() - 0.5) * 0.07, 0.0, (rng.randf() - 0.5) * 0.07)
            var b0: Vector3 = Vector3(x, 0.0, z)
            var top: Vector3 = b0 + lean + Vector3(0.0, hh, 0.0)
            var sc0: Color = green_a if stage < 2 else straw_a
            var sc1: Color = green_b if stage < 2 else straw_b
            _pm_tube(st, b0, top, 0.010, 0.006, sc0, sc1, 3)
            var bl0: Color = green_a
            var bl1: Color = green_b if stage < 2 else Color(0.62, 0.68, 0.26)
            var yaw0: float = rng.randf() * TAU
            _pm_blade(st, b0 + Vector3(0.0, hh * 0.18, 0.0), yaw0, 0.10 + hh * 0.30, 0.03, 0.9, 1.0, bl0, bl1, 3)
            _pm_blade(st, b0 + Vector3(0.0, hh * 0.40, 0.0) + lean * 0.4, yaw0 + 2.6, 0.08 + hh * 0.24, 0.026, 0.8, 0.9, bl0, bl1, 3)
            if stage == 1:
                _pm_ell(st, top + Vector3(0.0, 0.03, 0.0), Vector3(0.014, 0.05, 0.014), Color(0.38, 0.62, 0.22), Color(0.55, 0.75, 0.32), 3, 5)
            elif stage == 2:
                var tilt: Basis = Basis(Vector3(0, 0, 1), lean.x * 3.0 + 0.12)
                _pm_ell(st, top + Vector3(0.0, 0.07, 0.0), Vector3(0.026, 0.090, 0.026), Color(0.86, 0.68, 0.26), Color(0.97, 0.84, 0.42), 4, 6, tilt)
                for a in range(5):
                    _pm_blade(st, top + Vector3(0.0, 0.15, 0.0), TAU * float(a) / 5.0, 0.11, 0.008, 1.25, 0.2, Color(0.90, 0.78, 0.40), Color(0.98, 0.90, 0.60), 2)

func _plant_carrot(st: SurfaceTool, stage: int, rng: RandomNumberGenerator) -> void:
    var flen: float = [0.10, 0.22, 0.34][stage]
    var pos: Array = [Vector3(-0.24, 0.0, -0.10), Vector3(0.02, 0.0, 0.14), Vector3(0.26, 0.0, -0.08), Vector3(-0.04, 0.0, -0.26)]
    for p in pos:
        var base: Vector3 = p
        if stage == 2:
            _pm_tube(st, base + Vector3(0.0, -0.03, 0.0), base + Vector3(0.0, 0.05, 0.0), 0.012, 0.062, Color(0.92, 0.46, 0.08), Color(0.98, 0.56, 0.14), 8)
            _pm_ell(st, base + Vector3(0.0, 0.05, 0.0), Vector3(0.062, 0.022, 0.062), Color(0.98, 0.56, 0.14), Color(0.88, 0.42, 0.08), 3, 8)
            _pm_ell(st, base + Vector3(0.0, 0.065, 0.0), Vector3(0.028, 0.014, 0.028), Color(0.35, 0.55, 0.15), Color(0.42, 0.62, 0.2), 3, 6)
        var nf: int = 5 if stage == 0 else 8
        for f in range(nf):
            var yaw: float = TAU * float(f) / float(nf) + rng.randf() * 0.4
            var o: Vector3 = base + Vector3(0.0, 0.05 if stage == 2 else 0.0, 0.0)
            var dirh: Vector3 = Vector3(cos(yaw), 0.0, -sin(yaw))
            var fl: float = flen * (0.8 + rng.randf() * 0.4)
            _pm_blade(st, o, yaw, fl, 0.016, 1.15, 0.5, Color(0.22, 0.48, 0.16), Color(0.30, 0.62, 0.22), 3)
            if stage >= 1:
                for lk in range(3):
                    var t: float = 0.35 + 0.28 * float(lk)
                    var lp: Vector3 = o + dirh * fl * t * 0.55 + Vector3(0.0, fl * t * 0.85, 0.0)
                    _pm_blade(st, lp, yaw + 0.9, fl * 0.38, 0.035, 0.5, 0.4, Color(0.24, 0.55, 0.18), Color(0.36, 0.70, 0.26), 2)
                    _pm_blade(st, lp, yaw - 0.9, fl * 0.38, 0.035, 0.5, 0.4, Color(0.24, 0.55, 0.18), Color(0.36, 0.70, 0.26), 2)

func _plant_corn(st: SurfaceTool, stage: int, rng: RandomNumberGenerator) -> void:
    var ch: float = [0.26, 0.64, 1.02][stage]
    var pos: Array = [Vector3(-0.26, 0.0, -0.10), Vector3(0.10, 0.0, 0.12), Vector3(0.28, 0.0, -0.14)]
    var stalk_a: Color = Color(0.30, 0.52, 0.18)
    var stalk_b: Color = Color(0.40, 0.64, 0.24)
    var leaf_a: Color = Color(0.20, 0.50, 0.15)
    var leaf_b: Color = Color(0.40, 0.72, 0.26)
    for pi in range(pos.size()):
        var sp: Vector3 = pos[pi]
        var hh: float = ch * (0.9 + 0.1 * float(pi % 2))
        var seg: int = 3
        for s in range(seg):
            var y0: float = hh * float(s) / float(seg)
            var y1: float = hh * float(s + 1) / float(seg)
            _pm_tube(st, sp + Vector3(0, y0, 0), sp + Vector3(0, y1, 0), 0.036 * (1.0 - float(s) * 0.22), 0.036 * (1.0 - float(s + 1) * 0.22) + 0.004, stalk_a, stalk_b, 6)
            _pm_ell(st, sp + Vector3(0, y1, 0), Vector3(0.042, 0.012, 0.042), Color(0.24, 0.42, 0.14), Color(0.34, 0.54, 0.2), 2, 6)
        var nl: int = [3, 6, 9][stage]
        for k in range(nl):
            var t: float = 0.12 + 0.82 * float(k) / float(maxi(nl - 1, 1))
            var yaw: float = float(k) * PI + rng.randf() * 0.5 + float(pi)
            var ll: float = (0.20 + 0.20 * (1.0 - absf(t - 0.45))) * (0.7 + 0.3 * float(stage) / 2.0)
            _pm_blade(st, sp + Vector3(0, hh * t, 0), yaw, ll * 1.15, 0.09, 0.55, 1.35, leaf_a, leaf_b, 4)
        if stage >= 1:
            # Tassel at the top of the stalk.
            for a in range(6):
                var tc: Color = Color(0.82, 0.78, 0.45) if stage == 2 else Color(0.45, 0.62, 0.25)
                _pm_blade(st, sp + Vector3(0, hh, 0), TAU * float(a) / 6.0, 0.15, 0.012, 1.0, 0.8, tc, tc.lightened(0.12), 3)
        if stage == 2:
            var ey: float = hh * 0.58
            var dir_out: Vector3 = Vector3(cos(float(pi) * 2.1), 0.0, -sin(float(pi) * 2.1))
            var tilt: Basis = Basis(dir_out.cross(Vector3.UP).normalized(), -0.7)
            var ec: Vector3 = sp + dir_out * 0.07 + Vector3(0, ey, 0)
            _pm_ell(st, ec, Vector3(0.064, 0.16, 0.064), Color(0.38, 0.62, 0.22), Color(0.50, 0.74, 0.30), 4, 7, tilt)
            _pm_ell(st, ec + tilt * Vector3(0, 0.145, 0), Vector3(0.050, 0.060, 0.050), Color(0.96, 0.78, 0.16), Color(1.0, 0.88, 0.30), 3, 6, tilt)
            for a in range(4):
                _pm_blade(st, ec + tilt * Vector3(0, 0.19, 0), TAU * float(a) / 4.0, 0.07, 0.01, 0.9, 0.5, Color(0.55, 0.36, 0.18), Color(0.70, 0.48, 0.25), 2)

func _build_plant_mesh(parent: Node3D, id: int, stage: int, key: String) -> void:
    var rng := RandomNumberGenerator.new()
    rng.seed = hash(key) + id * 17
    var st := SurfaceTool.new()
    st.begin(Mesh.PRIMITIVE_TRIANGLES)
    match id:
        0:
            if stage == 0:
                _plant_tomato(st, stage, rng, -0.18, 0.02, 1.0)
                _plant_tomato(st, stage, rng, 0.18, -0.08, 1.0)
            else:
                _plant_tomato(st, stage, rng, -0.20, 0.04, 1.0)
                _plant_tomato(st, stage, rng, 0.22, -0.08, 0.92)
        1:
            _plant_wheat(st, stage, rng)
        2:
            _plant_carrot(st, stage, rng)
        4:
            _plant_rice(st, stage, rng)
        _:
            _plant_corn(st, stage, rng)
    var mesh: ArrayMesh = st.commit()
    var mi := MeshInstance3D.new()
    mi.name = "PlantMesh"
    mi.mesh = mesh
    mi.material_override = _crop_material()
    mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    parent.add_child(mi)

func _plant_rice(st: SurfaceTool, stage: int, rng: RandomNumberGenerator) -> void:
    # Flooded paddy water under the plants (drained when ripe).
    var wc: Color = Color(0.40, 0.58, 0.62) if stage < 2 else Color(0.52, 0.52, 0.36)
    var wc2: Color = Color(0.52, 0.70, 0.72) if stage < 2 else Color(0.58, 0.56, 0.40)
    _pm_quad(st, Vector3(-0.46, 0.02, -0.40), Vector3(0.46, 0.02, -0.40), Vector3(0.46, 0.02, 0.40), Vector3(-0.46, 0.02, 0.40), wc, wc2, wc, wc2)
    var h: float = [0.14, 0.32, 0.52][stage]
    var xs: Array = [-0.30, -0.10, 0.10, 0.30]
    var zs: Array = [-0.24, -0.02, 0.20]
    for xi in range(xs.size()):
        for zi in range(zs.size()):
            var base: Vector3 = Vector3(float(xs[xi]) + (rng.randf() - 0.5) * 0.08, 0.02, float(zs[zi]) + (rng.randf() - 0.5) * 0.08)
            var nb: int = 4 if stage == 0 else 6
            for b in range(nb):
                var yaw: float = TAU * float(b) / float(nb) + rng.randf() * 0.5
                var blen: float = h * (0.8 + rng.randf() * 0.4)
                var c0: Color = Color(0.28, 0.58, 0.20)
                var c1: Color = Color(0.55, 0.78, 0.30) if stage < 2 else Color(0.72, 0.74, 0.30)
                _pm_blade(st, base, yaw, blen, 0.022, 1.2 - 0.25 * float(stage), 0.8 + 0.3 * float(stage), c0, c1, 3)
            if stage == 2:
                var yaw2: float = rng.randf() * TAU
                var d: Vector3 = Vector3(cos(yaw2), 0.0, -sin(yaw2))
                var p0: Vector3 = base + Vector3(0.0, h * 0.85, 0.0)
                var p1: Vector3 = p0 + d * 0.07 + Vector3(0.0, 0.06, 0.0)
                var p2: Vector3 = p1 + d * 0.08 + Vector3(0.0, -0.01, 0.0)
                var p3: Vector3 = p2 + d * 0.04 + Vector3(0.0, -0.09, 0.0)
                _pm_tube(st, base, p0, 0.008, 0.006, Color(0.62, 0.66, 0.26), Color(0.80, 0.72, 0.30), 3)
                _pm_tube(st, p0, p1, 0.006, 0.005, Color(0.80, 0.72, 0.30), Color(0.84, 0.74, 0.32), 3)
                _pm_tube(st, p1, p2, 0.005, 0.005, Color(0.84, 0.74, 0.32), Color(0.88, 0.76, 0.34), 3)
                _pm_tube(st, p2, p3, 0.005, 0.004, Color(0.88, 0.76, 0.34), Color(0.88, 0.76, 0.34), 3)
                for g in range(7):
                    var tt: float = float(g) / 6.0
                    var gp: Vector3 = p1.lerp(p3, tt)
                    for sgn in [-1.0, 1.0]:
                        _pm_ell(st, gp + Vector3(-d.z, 0.0, d.x) * 0.014 * float(sgn), Vector3(0.012, 0.026, 0.012), Color(0.92, 0.80, 0.38), Color(0.98, 0.88, 0.50), 3, 5)

# ------------------------------------------------------------ v26 farm decor
func _build_farm_decor() -> void:
    var root_d := Node3D.new()
    root_d.name = "FarmDecor"
    add_child(root_d)
    # Scarecrow guarding the field.
    var sc := Node3D.new()
    sc.name = "Scarecrow"
    sc.position = Vector3(-3.55, 0.0, -2.45)
    sc.rotation_degrees.y = 25.0
    root_d.add_child(sc)
    var wood: Color = Color(0.50, 0.34, 0.18)
    _cylinder(sc, 0.04, 0.05, 1.6, Vector3(0, 0.8, 0), wood, "ScPole")
    _box(sc, Vector3(1.1, 0.07, 0.07), Vector3(0, 1.22, 0), wood, "ScArms")
    _box(sc, Vector3(0.42, 0.55, 0.26), Vector3(0, 1.05, 0), Color(0.78, 0.60, 0.34), "ScBody")
    _box(sc, Vector3(0.44, 0.2, 0.28), Vector3(0, 0.95, 0), Color(0.25, 0.42, 0.75), "ScShirtPatch")
    _sphere(sc, 0.2, 0.4, Vector3(0, 1.58, 0), Color(0.92, 0.80, 0.55), "ScHead")
    _disc(sc, 0.34, 0.04, Vector3(0, 1.72, 0), Color(0.88, 0.70, 0.28), "ScHatBrim", 0.9, 16)
    _disc(sc, 0.18, 0.2, Vector3(0, 1.84, 0), Color(0.82, 0.62, 0.22), "ScHatTop", 0.9, 14, 0.13)
    _box(sc, Vector3(0.22, 0.04, 0.04), Vector3(0, 1.74, 0.32), Color(0.8, 0.2, 0.2), "ScHatBand")
    for sx in [-0.56, 0.56]:
        for k in range(3):
            var tuft: MeshInstance3D = _box(sc, Vector3(0.05, 0.22, 0.05), Vector3(float(sx) + float(k - 1) * 0.05, 1.12, 0), Color(0.92, 0.76, 0.30), "ScStraw")
            tuft.rotation_degrees.z = float(k - 1) * 14.0
    for ex in [-0.07, 0.07]:
        _sphere(sc, 0.025, 0.05, Vector3(ex, 1.6, 0.18), Color(0.1, 0.1, 0.1), "ScEye")
    # Hay bales by the barn.
    var hay: Color = Color(0.92, 0.76, 0.32)
    var hay2: Color = Color(0.80, 0.62, 0.22)
    var hb: Array = [Vector3(5.5, 0.28, -2.3), Vector3(6.15, 0.28, -2.05), Vector3(5.8, 0.82, -2.2)]
    for i in range(hb.size()):
        var b: MeshInstance3D = _cylinder(root_d, 0.3, 0.3, 0.55, hb[i], hay, "HayBale")
        b.rotation_degrees = Vector3(0, 12.0 + float(i) * 18.0, 90)
        var band: MeshInstance3D = _cylinder(root_d, 0.305, 0.305, 0.06, hb[i], hay2, "HayBand")
        band.rotation_degrees = Vector3(0, 12.0 + float(i) * 18.0, 90)
    # Pitchfork leaning on the hay.
    _cylinder(root_d, 0.02, 0.02, 1.1, Vector3(6.6, 0.5, -2.35), wood, "Pitchfork").rotation_degrees = Vector3(0, 0, -14)
    for tx in [-0.06, 0.0, 0.06]:
        _box(root_d, Vector3(0.015, 0.2, 0.015), Vector3(6.43 + float(tx), 1.06, -2.35), Color(0.55, 0.55, 0.6), "Tine")
    # Sunflower patch.
    var sf: Array = [Vector2(-4.5, 3.4), Vector2(-4.15, 3.75), Vector2(-4.8, 3.9), Vector2(-4.3, 3.2), Vector2(-4.65, 3.65), Vector2(-3.95, 3.5)]
    for i in range(sf.size()):
        var p: Vector2 = sf[i]
        var h: float = 0.9 + 0.12 * float(i % 3)
        _cylinder(root_d, 0.02, 0.025, h, Vector3(p.x, h * 0.5, p.y), Color(0.30, 0.55, 0.20), "SfStem")
        var lf: MeshInstance3D = _sphere(root_d, 0.09, 0.05, Vector3(p.x + 0.07, h * 0.45, p.y), Color(0.25, 0.58, 0.2), "SfLeaf")
        lf.scale = Vector3(1.6, 0.4, 0.9)
        var face: Node3D = Node3D.new()
        face.position = Vector3(p.x, h, p.y)
        face.rotation_degrees = Vector3(-62.0, 20.0 * float(i), 0.0)
        root_d.add_child(face)
        _disc(face, 0.17, 0.03, Vector3(0, 0, 0), Color(1.0, 0.82, 0.12), "SfPetals", 0.9, 14)
        _disc(face, 0.19, 0.02, Vector3(0, -0.01, 0), Color(0.96, 0.72, 0.08), "SfPetals2", 0.9, 8)
        _disc(face, 0.09, 0.05, Vector3(0, 0.03, 0), Color(0.34, 0.20, 0.08), "SfCentre", 0.9, 12)
    # Wheelbarrow.
    var wb := Node3D.new()
    wb.name = "Wheelbarrow"
    wb.position = Vector3(-3.95, 0.0, 2.6)
    wb.rotation_degrees.y = 55.0
    root_d.add_child(wb)
    var tray: MeshInstance3D = _box(wb, Vector3(0.7, 0.22, 0.45), Vector3(0, 0.38, 0), Color(0.82, 0.28, 0.2), "WbTray")
    tray.rotation_degrees.z = -8.0
    _cylinder(wb, 0.14, 0.14, 0.08, Vector3(0.38, 0.14, 0), Color(0.15, 0.15, 0.17), "WbWheel").rotation_degrees.x = 90.0
    for z in [-0.17, 0.17]:
        var hnd: MeshInstance3D = _box(wb, Vector3(0.6, 0.04, 0.04), Vector3(-0.55, 0.38, float(z)), wood, "WbHandle")
        hnd.rotation_degrees.z = 12.0
        _box(wb, Vector3(0.04, 0.3, 0.04), Vector3(-0.2, 0.15, float(z)), wood, "WbLeg")
    for k in range(3):
        _sphere(wb, 0.1, 0.2, Vector3(-0.1 + float(k) * 0.16, 0.56, float(k % 2) * 0.05), Color(0.92, 0.14, 0.10) if k != 1 else Color(0.97, 0.55, 0.12), "WbProduce")
    _bake_local(root_d, [], "FarmDecor")


# ===========================================================================
# v27 hooks (see scripts/farm_v27.gd)
# ===========================================================================

func _wm_int() -> float:
    return v27.wm_interval() if v27 != null else WM_INTERVAL_BASE

func _batt_cap() -> int:
    return v27.batt_cap() if v27 != null else BATTERY_CAP_BASE

func _open_settings_v27() -> void:
    v27.open_settings()

func _open_upgrades_v27() -> void:
    v27.open_hub()
