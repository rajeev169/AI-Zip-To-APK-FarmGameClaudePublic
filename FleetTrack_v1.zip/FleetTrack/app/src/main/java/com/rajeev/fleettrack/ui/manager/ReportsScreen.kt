package com.rajeev.fleettrack.ui.manager

import android.widget.Toast
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rajeev.fleettrack.data.FuelEntry
import com.rajeev.fleettrack.data.Repo
import com.rajeev.fleettrack.data.Trip
import com.rajeev.fleettrack.data.Vehicle
import com.rajeev.fleettrack.ui.common.EmptyNote
import com.rajeev.fleettrack.ui.common.SectionTitle
import com.rajeev.fleettrack.ui.common.StatRow
import com.rajeev.fleettrack.ui.theme.Navy
import com.rajeev.fleettrack.ui.theme.RedAlert
import com.rajeev.fleettrack.util.Fmt
import com.rajeev.fleettrack.util.PdfReport
import com.rajeev.fleettrack.util.Share
import java.util.Calendar
import java.util.Locale

enum class Range(val label: String) { TODAY("Today"), YESTERDAY("Yesterday"), WEEK("Last 7 days"), MONTH("This month"), LAST_MONTH("Last month") }

private fun Range.bounds(): Pair<String, String> {
    val today = Fmt.dayKey()
    return when (this) {
        Range.TODAY -> today to today
        Range.YESTERDAY -> Fmt.shiftDay(today, -1).let { it to it }
        Range.WEEK -> Fmt.shiftDay(today, -6) to today
        Range.MONTH -> today.substring(0, 8) + "01" to today
        Range.LAST_MONTH -> {
            val c = Calendar.getInstance()
            c.set(Calendar.DAY_OF_MONTH, 1)
            c.add(Calendar.MONTH, -1)
            val first = Fmt.dayKey(c.timeInMillis)
            c.set(Calendar.DAY_OF_MONTH, c.getActualMaximum(Calendar.DAY_OF_MONTH))
            first to Fmt.dayKey(c.timeInMillis)
        }
    }
}

data class VehicleRow(
    val label: String,
    val trips: Int,
    val km: Double,
    val dutyMs: Long,
    val maxSpeed: Double,
    val overspeed: Int,
    val fuelL: Double,
    val fuelAmt: Double,
) {
    val kmPerL: Double get() = if (fuelL > 0) km / fuelL else 0.0
}

data class DriverRow(val name: String, val trips: Int, val km: Double, val dutyMs: Long, val overspeed: Int, val maxSpeed: Double)

private fun buildRows(trips: List<Trip>, fuel: List<FuelEntry>, vehicles: List<Vehicle>): Pair<List<VehicleRow>, List<DriverRow>> {
    val byId = vehicles.associateBy { it.id }
    val keys = (trips.map { it.vehicleId } + fuel.map { it.vehicleId }).distinct()
    val vRows = keys.map { k ->
        val ts = trips.filter { it.vehicleId == k }
        val fs = fuel.filter { it.vehicleId == k }
        val v = byId[k]
        val label = v?.label ?: (ts.firstOrNull()?.vehicleName ?: fs.firstOrNull()?.vehicleName ?: "Vehicle")
        VehicleRow(
            label = label,
            trips = ts.size,
            km = ts.sumOf { it.distanceKm },
            dutyMs = ts.sumOf { (it.endAt - it.startAt).coerceAtLeast(0) },
            maxSpeed = ts.maxOfOrNull { it.maxSpeed } ?: 0.0,
            overspeed = ts.sumOf { it.overspeedCount },
            fuelL = fs.sumOf { it.litres },
            fuelAmt = fs.sumOf { it.amount },
        )
    }.sortedByDescending { it.km }
    val dRows = trips.groupBy { it.driverEmail }.map { (_, ts) ->
        DriverRow(
            name = ts.first().driverName,
            trips = ts.size,
            km = ts.sumOf { it.distanceKm },
            dutyMs = ts.sumOf { (it.endAt - it.startAt).coerceAtLeast(0) },
            overspeed = ts.sumOf { it.overspeedCount },
            maxSpeed = ts.maxOf { it.maxSpeed },
        )
    }.sortedByDescending { it.km }
    return vRows to dRows
}

@Composable
fun ReportsScreen(fleetId: String, fleetName: String, vehicles: List<Vehicle>) {
    val ctx = LocalContext.current
    var range by remember { mutableStateOf(Range.TODAY) }
    var data by remember { mutableStateOf<Pair<List<VehicleRow>, List<DriverRow>>?>(null) }
    var error by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(range, vehicles) {
        data = null
        error = null
        try {
            val (from, to) = range.bounds()
            val trips = Repo.tripsBetween(fleetId, from, to)
            val fuel = Repo.fuelBetween(fleetId, from, to)
            data = buildRows(trips, fuel, vehicles)
        } catch (e: Exception) {
            error = e.message
            data = emptyList<VehicleRow>() to emptyList()
        }
    }

    val (from, to) = range.bounds()
    val rangeText = if (from == to) Fmt.prettyDay(from) else "${Fmt.prettyDay(from)} – ${Fmt.prettyDay(to)}"

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Range.entries.forEach { r ->
                FilterChip(selected = range == r, onClick = { range = r }, label = { Text(r.label) })
            }
        }
        Text(rangeText, Modifier.padding(horizontal = 16.dp), color = Color.Gray, fontSize = 13.sp)

        val d = data
        if (d == null) {
            Box(
                Modifier
                    .fillMaxWidth()
                    .padding(40.dp), contentAlignment = Alignment.Center
            ) { CircularProgressIndicator() }
            return@Column
        }
        error?.let { Text("Error: $it", color = RedAlert, modifier = Modifier.padding(16.dp)) }
        val (vRows, dRows) = d
        if (vRows.isEmpty()) {
            EmptyNote("No trips or fuel entries in this period")
            return@Column
        }

        val totKm = vRows.sumOf { it.km }
        val totTrips = vRows.sumOf { it.trips }
        val totDuty = vRows.sumOf { it.dutyMs }
        val totFuelL = vRows.sumOf { it.fuelL }
        val totFuelAmt = vRows.sumOf { it.fuelAmt }
        val totOver = vRows.sumOf { it.overspeed }

        Card(
            Modifier
                .fillMaxWidth()
                .padding(12.dp),
            colors = CardDefaults.cardColors(containerColor = Navy)
        ) {
            Column(Modifier.padding(16.dp)) {
                Text("Fleet total", color = Color.White.copy(alpha = 0.8f))
                Text(Fmt.km(totKm), color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    WhiteStat("Trips", totTrips.toString())
                    WhiteStat("Duty", Fmt.duration(totDuty))
                    WhiteStat("Fuel", if (totFuelAmt > 0) Fmt.money(totFuelAmt) else "—")
                    WhiteStat("Overspeed", totOver.toString())
                }
            }
        }

        Row(Modifier.padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = {
                Share.text(ctx, reportText(fleetName, rangeText, vRows, dRows, totKm, totTrips, totDuty, totFuelL, totFuelAmt))
            }, modifier = Modifier.weight(1f)) {
                Icon(Icons.Filled.Share, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text("WhatsApp")
            }
            OutlinedButton(onClick = {
                try {
                    val f = PdfReport.build(
                        ctx,
                        title = "$fleetName - Fleet Report",
                        subtitle = rangeText,
                        headers = listOf("Vehicle", "Trips", "Km", "Duty", "Max km/h", "Over", "Fuel L", "Fuel ₹", "Km/L"),
                        widths = listOf(3.2f, 1f, 1.3f, 1.4f, 1.3f, 1f, 1.2f, 1.4f, 1f),
                        rows = vRows.map {
                            listOf(
                                it.label, it.trips.toString(), String.format(Locale.US, "%.1f", it.km),
                                Fmt.duration(it.dutyMs), it.maxSpeed.toInt().toString(), it.overspeed.toString(),
                                if (it.fuelL > 0) String.format(Locale.US, "%.1f", it.fuelL) else "-",
                                if (it.fuelAmt > 0) String.format(Locale.US, "%,.0f", it.fuelAmt) else "-",
                                if (it.kmPerL > 0) String.format(Locale.US, "%.1f", it.kmPerL) else "-",
                            )
                        } + listOf(listOf("")) + listOf(listOf("DRIVER", "Trips", "Km", "Duty", "Max km/h", "Over")) +
                            dRows.map {
                                listOf(
                                    it.name, it.trips.toString(), String.format(Locale.US, "%.1f", it.km),
                                    Fmt.duration(it.dutyMs), it.maxSpeed.toInt().toString(), it.overspeed.toString()
                                )
                            },
                        footer = listOf(
                            "Total: ${Fmt.km(totKm)}  |  $totTrips trips  |  Duty ${Fmt.duration(totDuty)}",
                            "Fuel: " + String.format(Locale.US, "%.1f L", totFuelL) + "  |  Rs " + String.format(Locale.US, "%,.0f", totFuelAmt) +
                                "  |  Overspeed alerts: $totOver",
                            "Generated by Fleet Track on ${Fmt.dateTime(System.currentTimeMillis())}",
                        )
                    )
                    Share.file(ctx, f, "application/pdf")
                } catch (e: Exception) {
                    Toast.makeText(ctx, "PDF failed: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }, modifier = Modifier.weight(1f)) {
                Icon(Icons.Filled.PictureAsPdf, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text("PDF")
            }
        }

        SectionTitle("By vehicle", Modifier.padding(horizontal = 16.dp))
        vRows.forEach { r ->
            Card(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 4.dp),
                elevation = CardDefaults.cardElevation(1.dp)
            ) {
                Column(Modifier.padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(r.label, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        if (r.overspeed > 0) Text("⚠ ${r.overspeed} overspeed", color = RedAlert, fontSize = 12.sp)
                    }
                    Spacer(Modifier.height(6.dp))
                    StatRow(
                        "Km" to String.format(Locale.US, "%.1f", r.km),
                        "Trips" to r.trips.toString(),
                        "Duty" to Fmt.duration(r.dutyMs),
                        "Max" to "${r.maxSpeed.toInt()}",
                    )
                    if (r.fuelL > 0 || r.fuelAmt > 0) {
                        Spacer(Modifier.height(6.dp))
                        Text(
                            "⛽ " + String.format(Locale.US, "%.1f L", r.fuelL) + " • " + Fmt.money(r.fuelAmt) +
                                if (r.kmPerL > 0) " • " + String.format(Locale.US, "%.1f km/L", r.kmPerL) else "",
                            fontSize = 13.sp, color = Color.DarkGray
                        )
                    }
                }
            }
        }

        if (dRows.isNotEmpty()) {
            SectionTitle("By driver", Modifier.padding(horizontal = 16.dp))
            dRows.forEach { r ->
                Card(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 4.dp),
                    elevation = CardDefaults.cardElevation(1.dp)
                ) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(r.name, fontWeight = FontWeight.Bold)
                            Text(
                                "${r.trips} trips • ${Fmt.duration(r.dutyMs)} on duty • max ${r.maxSpeed.toInt()} km/h",
                                fontSize = 12.sp, color = Color.Gray
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(Fmt.km(r.km), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                            Text(
                                if (r.overspeed == 0) "✓ Safe driving" else "⚠ ${r.overspeed} overspeed",
                                fontSize = 12.sp, color = if (r.overspeed == 0) Color(0xFF2E7D32) else RedAlert
                            )
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun WhiteStat(label: String, value: String) {
    Column {
        Text(value, color = Color.White, fontWeight = FontWeight.Bold)
        Text(label, color = Color.White.copy(alpha = 0.75f), fontSize = 11.sp)
    }
}

private fun reportText(
    fleet: String, range: String, vRows: List<VehicleRow>, dRows: List<DriverRow>,
    km: Double, trips: Int, duty: Long, fuelL: Double, fuelAmt: Double,
): String = buildString {
    appendLine("🚚 *$fleet — Fleet Report*")
    appendLine(range)
    appendLine("Total: ${Fmt.km(km)} | $trips trips | ${Fmt.duration(duty)} duty" + if (fuelAmt > 0) " | Fuel ${Fmt.money(fuelAmt)}" else "")
    appendLine()
    appendLine("*Vehicles*")
    vRows.forEach { r ->
        append("• ${r.label}: ${Fmt.km(r.km)}, ${r.trips} trips, ${Fmt.duration(r.dutyMs)}, max ${r.maxSpeed.toInt()} km/h")
        if (r.overspeed > 0) append(", ⚠ ${r.overspeed} overspeed")
        if (r.fuelL > 0) append(", ⛽ ${String.format(Locale.US, "%.1f", r.fuelL)} L ${Fmt.money(r.fuelAmt)}")
        if (r.kmPerL > 0) append(" (${String.format(Locale.US, "%.1f", r.kmPerL)} km/L)")
        appendLine()
    }
    if (dRows.isNotEmpty()) {
        appendLine()
        appendLine("*Drivers*")
        dRows.forEach { r ->
            appendLine("• ${r.name}: ${Fmt.km(r.km)}, ${r.trips} trips" + if (r.overspeed > 0) ", ⚠ ${r.overspeed} overspeed" else ", ✓ safe")
        }
    }
    if (fuelL > 0) {
        appendLine()
        appendLine("Fuel total: ${String.format(Locale.US, "%.1f", fuelL)} L")
    }
}
