package com.rajeev.fleettrack.util

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File
import java.util.Locale

object Share {
    fun mapsLink(lat: Double, lng: Double) =
        String.format(Locale.US, "https://maps.google.com/?q=%.6f,%.6f", lat, lng)

    fun text(ctx: Context, text: String, whatsappFirst: Boolean = true) {
        val base = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text)
        if (whatsappFirst) {
            try {
                ctx.startActivity(Intent(base).setPackage("com.whatsapp").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                return
            } catch (_: ActivityNotFoundException) {
            }
        }
        ctx.startActivity(Intent.createChooser(base, "Share").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun file(ctx: Context, file: File, mime: String) {
        val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", file)
        val i = Intent(Intent.ACTION_SEND).setType(mime)
            .putExtra(Intent.EXTRA_STREAM, uri)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        ctx.startActivity(Intent.createChooser(i, "Share report").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun dial(ctx: Context, phone: String) {
        if (phone.isBlank()) {
            Toast.makeText(ctx, "No phone number saved for this driver", Toast.LENGTH_SHORT).show()
            return
        }
        ctx.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phone")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun openInMaps(ctx: Context, lat: Double, lng: Double, label: String) {
        val uri = Uri.parse(String.format(Locale.US, "geo:%.6f,%.6f?q=%.6f,%.6f(%s)", lat, lng, lat, lng, Uri.encode(label)))
        try {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: ActivityNotFoundException) {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(mapsLink(lat, lng))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }

    @android.annotation.SuppressLint("BatteryLife")
    fun askIgnoreBatteryOptimization(ctx: Context) {
        try {
            ctx.startActivity(
                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + ctx.packageName))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (_: Exception) {
            try {
                ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (_: Exception) {
            }
        }
    }

    fun isIgnoringBatteryOptimization(ctx: Context): Boolean {
        val pm = ctx.getSystemService(Context.POWER_SERVICE) as android.os.PowerManager
        return pm.isIgnoringBatteryOptimizations(ctx.packageName)
    }
}

/** Simple table PDF (A4) used by Reports. */
object PdfReport {
    fun build(ctx: Context, title: String, subtitle: String, headers: List<String>, widths: List<Float>, rows: List<List<String>>, footer: List<String>): File {
        val doc = PdfDocument()
        val pageW = 595
        val pageH = 842
        val margin = 32f
        val titlePaint = Paint().apply { textSize = 18f; typeface = Typeface.DEFAULT_BOLD; color = Color.rgb(13, 71, 161) }
        val subPaint = Paint().apply { textSize = 11f; color = Color.DKGRAY }
        val headPaint = Paint().apply { textSize = 9.5f; typeface = Typeface.DEFAULT_BOLD; color = Color.WHITE }
        val cellPaint = Paint().apply { textSize = 9.5f; color = Color.BLACK }
        val fillHead = Paint().apply { color = Color.rgb(13, 71, 161) }
        val fillAlt = Paint().apply { color = Color.rgb(238, 242, 250) }
        val totalW = widths.sum()
        val usable = pageW - margin * 2
        val colW = widths.map { it / totalW * usable }

        var pageNo = 0
        var page: PdfDocument.Page? = null
        var y = 0f

        fun newPage() {
            page?.let { doc.finishPage(it) }
            pageNo++
            page = doc.startPage(PdfDocument.PageInfo.Builder(pageW, pageH, pageNo).create())
            val c = page!!.canvas
            y = margin + 10f
            if (pageNo == 1) {
                c.drawText(title, margin, y + 8f, titlePaint)
                y += 26f
                c.drawText(subtitle, margin, y, subPaint)
                y += 18f
            }
            c.drawRect(margin, y, pageW - margin, y + 20f, fillHead)
            var x = margin
            headers.forEachIndexed { i, h -> c.drawText(fit(h, headPaint, colW[i] - 6), x + 4, y + 14f, headPaint); x += colW[i] }
            y += 20f
        }

        newPage()
        rows.forEachIndexed { r, row ->
            if (y > pageH - margin - 60) newPage()
            val c = page!!.canvas
            if (r % 2 == 1) c.drawRect(margin, y, pageW - margin, y + 18f, fillAlt)
            var x = margin
            row.forEachIndexed { i, v -> if (i < colW.size) { c.drawText(fit(v, cellPaint, colW[i] - 6), x + 4, y + 13f, cellPaint); x += colW[i] } }
            y += 18f
        }
        y += 14f
        footer.forEach { line ->
            if (y > pageH - margin) newPage()
            page!!.canvas.drawText(line, margin, y, subPaint.apply { typeface = Typeface.DEFAULT_BOLD; color = Color.BLACK })
            y += 16f
        }
        page?.let { doc.finishPage(it) }

        val dir = File(ctx.cacheDir, "reports").apply { mkdirs() }
        val safe = title.replace(Regex("[^A-Za-z0-9_-]+"), "_").take(50)
        val file = File(dir, "$safe.pdf")
        file.outputStream().use { doc.writeTo(it) }
        doc.close()
        return file
    }

    private fun fit(text: String, p: Paint, max: Float): String {
        if (p.measureText(text) <= max) return text
        var t = text
        while (t.isNotEmpty() && p.measureText("$t…") > max) t = t.dropLast(1)
        return "$t…"
    }
}
