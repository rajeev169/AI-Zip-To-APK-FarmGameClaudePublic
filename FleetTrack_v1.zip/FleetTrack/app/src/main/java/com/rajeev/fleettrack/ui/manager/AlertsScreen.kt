package com.rajeev.fleettrack.ui.manager

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.LocalGasStation
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rajeev.fleettrack.data.Alert
import com.rajeev.fleettrack.data.AlertType
import com.rajeev.fleettrack.data.Repo
import com.rajeev.fleettrack.ui.common.EmptyNote
import com.rajeev.fleettrack.ui.theme.GreenOk
import com.rajeev.fleettrack.ui.theme.GreyOff
import com.rajeev.fleettrack.ui.theme.Navy
import com.rajeev.fleettrack.ui.theme.Orange
import com.rajeev.fleettrack.ui.theme.RedAlert
import com.rajeev.fleettrack.util.Fmt
import com.rajeev.fleettrack.util.Share
import kotlinx.coroutines.launch

private enum class AlertFilter(val label: String) { ALL("All"), IMPORTANT("Overspeed & SOS"), DUTY("Duty"), FUEL("Fuel") }

@Composable
fun AlertsScreen(fleetId: String, alerts: List<Alert>) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var filter by remember { mutableStateOf(AlertFilter.ALL) }

    val shown = alerts.filter {
        when (filter) {
            AlertFilter.ALL -> true
            AlertFilter.IMPORTANT -> it.type == AlertType.OVERSPEED || it.type == AlertType.SOS
            AlertFilter.DUTY -> it.type == AlertType.DUTY_START || it.type == AlertType.DUTY_END
            AlertFilter.FUEL -> it.type == AlertType.FUEL
        }
    }
    val unseenIds = alerts.filter { !it.seen }.map { it.id }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(start = 12.dp, end = 4.dp, top = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                Modifier
                    .weight(1f)
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                AlertFilter.entries.forEach { f ->
                    FilterChip(selected = filter == f, onClick = { filter = f }, label = { Text(f.label) })
                }
            }
            TextButton(
                onClick = { scope.launch { runCatching { Repo.markAllAlertsSeen(fleetId, unseenIds) } } },
                enabled = unseenIds.isNotEmpty()
            ) {
                Icon(Icons.Filled.DoneAll, null, Modifier.size(18.dp)); Spacer(Modifier.width(4.dp)); Text("Read")
            }
        }
        if (shown.isEmpty()) {
            EmptyNote("No alerts yet")
        } else {
            LazyColumn(
                contentPadding = PaddingValues(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(shown, key = { it.id }) { a ->
                    AlertRow(a) {
                        if (a.lat != 0.0 || a.lng != 0.0) Share.openInMaps(ctx, a.lat, a.lng, a.vehicleName)
                    }
                }
            }
        }
    }
}

private fun style(a: Alert): Triple<ImageVector, Color, String> = when (a.type) {
    AlertType.SOS -> Triple(Icons.Filled.Warning, RedAlert, "SOS — ${a.driverName}")
    AlertType.OVERSPEED -> Triple(Icons.Filled.Speed, Orange, "Overspeed ${a.speed.toInt()} km/h")
    AlertType.DUTY_START -> Triple(Icons.Filled.PlayArrow, GreenOk, "Duty started")
    AlertType.DUTY_END -> Triple(Icons.Filled.Stop, GreyOff, "Duty ended")
    AlertType.FUEL -> Triple(Icons.Filled.LocalGasStation, Navy, "Fuel added")
    else -> Triple(Icons.Filled.Warning, GreyOff, a.type)
}

@Composable
private fun AlertRow(a: Alert, onClick: () -> Unit) {
    val (icon, color, title) = style(a)
    Card(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(
            containerColor = if (!a.seen && (a.type == AlertType.SOS || a.type == AlertType.OVERSPEED))
                color.copy(alpha = 0.10f) else Color.White
        ),
        elevation = CardDefaults.cardElevation(1.dp)
    ) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(40.dp)
                    .background(color.copy(alpha = 0.15f), CircleShape),
                contentAlignment = Alignment.Center
            ) { Icon(icon, null, tint = color) }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold, color = if (a.type == AlertType.SOS) RedAlert else Color.Unspecified)
                Text(
                    listOf(a.vehicleName, a.vehicleNumber, a.driverName).filter { it.isNotBlank() }.distinct().joinToString(" • "),
                    fontSize = 13.sp, color = Color.DarkGray
                )
                if (a.message.isNotBlank()) Text(a.message, fontSize = 12.sp, color = Color.Gray)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(Fmt.ago(a.at), fontSize = 11.sp, color = Color.Gray)
                if (!a.seen && (a.type == AlertType.SOS || a.type == AlertType.OVERSPEED)) {
                    Box(
                        Modifier
                            .padding(top = 4.dp)
                            .size(8.dp)
                            .background(RedAlert, CircleShape)
                    )
                }
            }
        }
    }
}
