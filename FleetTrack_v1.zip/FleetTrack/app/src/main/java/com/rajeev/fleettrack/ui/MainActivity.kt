package com.rajeev.fleettrack.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.rajeev.fleettrack.data.AuthManager
import com.rajeev.fleettrack.data.Repo
import com.rajeev.fleettrack.data.Session
import com.rajeev.fleettrack.ui.driver.DriverHome
import com.rajeev.fleettrack.ui.login.LoginScreen
import com.rajeev.fleettrack.ui.login.NewUserScreen
import com.rajeev.fleettrack.ui.manager.ManagerHome
import com.rajeev.fleettrack.ui.theme.FleetTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            FleetTheme {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    AppRoot()
                }
            }
        }
    }
}

private sealed class RootState {
    data object Loading : RootState()
    data object SignedOut : RootState()
    data class Ready(val session: Session) : RootState()
    data class Failed(val message: String) : RootState()
}

@Composable
private fun AppRoot() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var reload by remember { mutableIntStateOf(0) }
    var state by remember { mutableStateOf<RootState>(RootState.Loading) }

    LaunchedEffect(reload) {
        val user = AuthManager.user
        state = if (user == null) {
            RootState.SignedOut
        } else {
            RootState.Loading
            try {
                RootState.Ready(Repo.detectRole(user))
            } catch (e: Exception) {
                RootState.Failed(e.message ?: "Could not load your account")
            }
        }
    }

    val signOut: () -> Unit = {
        scope.launch {
            AuthManager.signOut(ctx)
            reload++
        }
    }

    when (val s = state) {
        RootState.Loading -> Column(
            Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            CircularProgressIndicator()
            Spacer(Modifier.height(12.dp))
            Text("Loading…")
        }

        RootState.SignedOut -> LoginScreen(onSignedIn = { state = RootState.Loading; reload++ })

        is RootState.Failed -> Column(
            Modifier
                .fillMaxSize()
                .padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("Couldn't connect", style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(8.dp))
            Text(s.message, textAlign = TextAlign.Center)
            Spacer(Modifier.height(16.dp))
            Button(onClick = { state = RootState.Loading; reload++ }) { Text("Try again") }
            TextButton(onClick = signOut) { Text("Sign out") }
        }

        is RootState.Ready -> when (val session = s.session) {
            is Session.Manager -> ManagerHome(session.fleetId, onSignOut = signOut)
            is Session.DriverSession -> DriverHome(session, onSignOut = signOut)
            is Session.NewUser -> NewUserScreen(
                email = session.email,
                name = session.name,
                onCreate = { business ->
                    val u = AuthManager.user ?: throw IllegalStateException("Not signed in")
                    Repo.createFleet(u, business)
                    reload++
                },
                onRecheck = { state = RootState.Loading; reload++ },
                onSignOut = signOut,
            )
        }
    }
}
