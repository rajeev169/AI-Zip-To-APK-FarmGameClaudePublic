package com.rajeev.fleettrack.tracking

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class DutyConfig(
    val fleetId: String,
    val email: String,
    val driverName: String,
    val driverPhone: String,
    val vehicleId: String,
    val vehicleName: String,
    val vehicleNumber: String,
    val vehicleType: String,
    val speedLimit: Int,
)

/** Saved on the driver phone so a duty survives the app being closed or the phone restarting the service. */
data class DutyProgress(
    val tripId: String = "",
    val startAt: Long = 0,
    val chunkIndex: Int = 0,
    val distanceM: Double = 0.0,
    val maxSpeed: Double = 0.0,
    val overspeedCount: Int = 0,
)

object DutyPrefs {
    private fun p(ctx: Context): SharedPreferences = ctx.getSharedPreferences("duty", Context.MODE_PRIVATE)

    fun isActive(ctx: Context) = p(ctx).getBoolean("active", false)

    fun saveConfig(ctx: Context, c: DutyConfig) {
        p(ctx).edit()
            .putBoolean("active", true)
            .putString("fleetId", c.fleetId).putString("email", c.email)
            .putString("driverName", c.driverName).putString("driverPhone", c.driverPhone)
            .putString("vehicleId", c.vehicleId).putString("vehicleName", c.vehicleName)
            .putString("vehicleNumber", c.vehicleNumber).putString("vehicleType", c.vehicleType)
            .putInt("speedLimit", c.speedLimit)
            .remove("tripId").remove("startAt").remove("chunkIndex")
            .remove("distanceM").remove("maxSpeed").remove("overspeedCount")
            .apply()
    }

    fun config(ctx: Context): DutyConfig? {
        val sp = p(ctx)
        if (!sp.getBoolean("active", false)) return null
        val f = sp.getString("fleetId", null) ?: return null
        return DutyConfig(
            f, sp.getString("email", "") ?: "", sp.getString("driverName", "") ?: "",
            sp.getString("driverPhone", "") ?: "", sp.getString("vehicleId", "") ?: "",
            sp.getString("vehicleName", "") ?: "", sp.getString("vehicleNumber", "") ?: "",
            sp.getString("vehicleType", "") ?: "", sp.getInt("speedLimit", 60),
        )
    }

    fun progress(ctx: Context): DutyProgress {
        val sp = p(ctx)
        return DutyProgress(
            sp.getString("tripId", "") ?: "", sp.getLong("startAt", 0), sp.getInt("chunkIndex", 0),
            sp.getFloat("distanceM", 0f).toDouble(), sp.getFloat("maxSpeed", 0f).toDouble(),
            sp.getInt("overspeedCount", 0),
        )
    }

    fun saveProgress(ctx: Context, d: DutyProgress) {
        p(ctx).edit()
            .putString("tripId", d.tripId).putLong("startAt", d.startAt).putInt("chunkIndex", d.chunkIndex)
            .putFloat("distanceM", d.distanceM.toFloat()).putFloat("maxSpeed", d.maxSpeed.toFloat())
            .putInt("overspeedCount", d.overspeedCount)
            .apply()
    }

    fun clear(ctx: Context) {
        p(ctx).edit().clear().apply()
    }
}

/** Live numbers the driver screen shows (filled by TrackingService). */
data class TrackingUi(
    val running: Boolean = false,
    val vehicleLabel: String = "",
    val speed: Double = 0.0,
    val distanceKm: Double = 0.0,
    val maxSpeed: Double = 0.0,
    val startAt: Long = 0,
    val lastFixAt: Long = 0,
    val accuracy: Double = 0.0,
    val lat: Double = 0.0,
    val lng: Double = 0.0,
    val overspeed: Boolean = false,
    val speedLimit: Int = 60,
    val waitingForGps: Boolean = true,
)

object TrackingState {
    private val _ui = MutableStateFlow(TrackingUi())
    val ui: StateFlow<TrackingUi> = _ui.asStateFlow()
    fun set(v: TrackingUi) { _ui.value = v }
    fun update(f: (TrackingUi) -> TrackingUi) { _ui.value = f(_ui.value) }
}
