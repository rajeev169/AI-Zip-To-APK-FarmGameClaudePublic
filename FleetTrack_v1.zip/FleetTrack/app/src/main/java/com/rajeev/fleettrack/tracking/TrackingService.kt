package com.rajeev.fleettrack.tracking

import android.annotation.SuppressLint
import android.app.Notification
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.location.Location
import android.os.BatteryManager
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.SetOptions
import com.rajeev.fleettrack.R
import com.rajeev.fleettrack.data.AlertType
import com.rajeev.fleettrack.data.Repo
import com.rajeev.fleettrack.util.Fmt
import com.rajeev.fleettrack.util.Notifs
import java.util.Locale
import kotlin.math.max

/**
 * Runs on the driver phone while on duty. Reads GPS every few seconds and
 *  - updates fleets/{f}/live/{gmail} (position + speed) for the manager's live map
 *  - stores the route in batches under the trip (for route history / playback)
 *  - raises an overspeed alert when the speed limit is crossed
 */
class TrackingService : Service() {

    companion object {
        private const val ACTION_START = "start"
        private const val ACTION_STOP = "stop"
        private const val NOTIF_ID = 101
        private const val MOVING_KMH = 3.0

        fun start(ctx: Context, cfg: DutyConfig) {
            DutyPrefs.saveConfig(ctx, cfg)
            ContextCompat.startForegroundService(ctx, Intent(ctx, TrackingService::class.java).setAction(ACTION_START))
        }

        /** Restart tracking after the app was closed, keeping the same trip. */
        fun resume(ctx: Context) {
            if (!DutyPrefs.isActive(ctx) || TrackingState.ui.value.running) return
            ContextCompat.startForegroundService(ctx, Intent(ctx, TrackingService::class.java).setAction(ACTION_START))
        }

        fun stop(ctx: Context) {
            if (TrackingState.ui.value.running) {
                ctx.startService(Intent(ctx, TrackingService::class.java).setAction(ACTION_STOP))
            } else {
                // Service is not running (e.g. GPS permission was removed): close the duty directly.
                val c = DutyPrefs.config(ctx)
                val p = DutyPrefs.progress(ctx)
                if (c != null) {
                    val now = System.currentTimeMillis()
                    if (p.tripId.isNotBlank()) {
                        Repo.trips(c.fleetId).document(p.tripId)
                            .set(mapOf("active" to false, "endAt" to now), SetOptions.merge())
                    }
                    Repo.live(c.fleetId).document(c.email).set(
                        mapOf("onDuty" to false, "speed" to 0.0, "overspeed" to false, "updatedAt" to now),
                        SetOptions.merge()
                    )
                }
                DutyPrefs.clear(ctx)
                TrackingState.set(TrackingUi())
            }
        }
    }

    private lateinit var fused: FusedLocationProviderClient
    private var cfg: DutyConfig? = null
    private var progress = DutyProgress()
    private var speedLimit = 60
    private var running = false

    private var lastAccepted: Location? = null
    private val buffer = mutableListOf<Map<String, Any>>()
    private var lastBufferedLoc: Location? = null
    private var lastBufferedAt = 0L
    private var lastFlushAt = 0L
    private var lastLiveWriteAt = 0L
    private var lastLiveOverspeed = false
    private var stoppedSince = 0L
    private var overReadings = 0
    private var lastOverAlertAt = 0L
    private var limitReg: ListenerRegistration? = null
    private var wakeLock: PowerManager.WakeLock? = null

    private val callback = object : LocationCallback() {
        override fun onLocationResult(result: LocationResult) {
            result.lastLocation?.let { onLocation(it) }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        fused = LocationServices.getFusedLocationProviderClient(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            endDuty()
            return START_NOT_STICKY
        }
        if (running) return START_STICKY

        val c = DutyPrefs.config(this)
        if (c == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        cfg = c
        speedLimit = c.speedLimit

        try {
            ServiceCompat.startForeground(
                this, NOTIF_ID, buildNotification("Starting GPS…"),
                ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION
            )
        } catch (e: Exception) {
            // Location permission missing or app was in background — cannot track.
            stopSelf()
            return START_NOT_STICKY
        }
        running = true

        progress = DutyProgress()
        val saved = DutyPrefs.progress(this)
        val now = System.currentTimeMillis()
        if (saved.tripId.isNotBlank()) {
            progress = saved // resume the same trip
        } else {
            val tripRef = Repo.trips(c.fleetId).document()
            progress = DutyProgress(tripId = tripRef.id, startAt = now)
            DutyPrefs.saveProgress(this, progress)
            tripRef.set(
                mapOf(
                    "driverEmail" to c.email, "driverName" to c.driverName,
                    "vehicleId" to c.vehicleId, "vehicleName" to c.vehicleName, "vehicleNumber" to c.vehicleNumber,
                    "date" to Fmt.dayKey(now), "startAt" to now, "endAt" to now,
                    "distanceKm" to 0.0, "maxSpeed" to 0.0, "overspeedCount" to 0, "active" to true,
                )
            )
            Repo.alerts(c.fleetId).add(
                alertMap(c, AlertType.DUTY_START, 0.0, 0.0, 0.0, "${c.driverName} started duty on ${c.vehicleName}")
            )
        }
        lastFlushAt = now

        TrackingState.set(
            TrackingUi(
                running = true, vehicleLabel = vehicleLabel(c), startAt = progress.startAt,
                distanceKm = progress.distanceM / 1000.0, maxSpeed = progress.maxSpeed, speedLimit = speedLimit,
            )
        )

        // Mark on duty right away so the manager sees the driver even before the first GPS fix
        Repo.live(c.fleetId).document(c.email).set(
            mapOf(
                "driverName" to c.driverName, "driverPhone" to c.driverPhone,
                "vehicleId" to c.vehicleId, "vehicleName" to c.vehicleName,
                "vehicleNumber" to c.vehicleNumber, "vehicleType" to c.vehicleType,
                "onDuty" to true, "tripId" to progress.tripId, "dutyStart" to progress.startAt,
                "updatedAt" to now, "battery" to battery(),
            ),
            SetOptions.merge()
        )

        // Follow speed-limit changes made by the manager during the duty
        limitReg = Repo.fleet(c.fleetId).addSnapshotListener { snap, _ ->
            val l = (snap?.get("speedLimit") as? Number)?.toInt()
            if (l != null && l > 0) {
                speedLimit = l
                TrackingState.update { it.copy(speedLimit = l) }
            }
        }

        acquireWakeLock()
        startGps()
        return START_STICKY
    }

    @SuppressLint("MissingPermission")
    private fun startGps() {
        val req = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 5_000L)
            .setMinUpdateIntervalMillis(3_000L)
            .setWaitForAccurateLocation(false)
            .build()
        try {
            fused.requestLocationUpdates(req, callback, Looper.getMainLooper())
        } catch (_: SecurityException) {
            endDuty()
        }
    }

    private fun onLocation(loc: Location) {
        val c = cfg ?: return
        val now = System.currentTimeMillis()
        val acc = if (loc.hasAccuracy()) loc.accuracy.toDouble() else 50.0
        if (acc > 80) {
            TrackingState.update { it.copy(waitingForGps = true, accuracy = acc) }
            return
        }

        // ---- speed ----
        var kmh = if (loc.hasSpeed()) loc.speed * 3.6 else -1.0
        val prev = lastAccepted
        if (prev == null) {
            lastAccepted = loc
            if (kmh < 0) kmh = 0.0
        } else {
            val d = prev.distanceTo(loc).toDouble()
            val dtSec = max(1L, loc.time - prev.time) / 1000.0
            val calcKmh = d / dtSec * 3.6
            if (kmh < 0) kmh = calcKmh
            // ignore GPS jitter while standing still and impossible jumps
            if (d >= max(10.0, acc) && calcKmh < 180) {
                progress = progress.copy(distanceM = progress.distanceM + d)
                lastAccepted = loc
            } else if (calcKmh >= 180) {
                lastAccepted = loc
            }
        }
        if (kmh < 2.0) kmh = 0.0
        if (kmh > progress.maxSpeed) progress = progress.copy(maxSpeed = kmh)

        // ---- stopped / overspeed ----
        if (kmh < MOVING_KMH) {
            if (stoppedSince == 0L) stoppedSince = now
        } else {
            stoppedSince = 0L
        }
        val over = kmh > speedLimit
        if (over) {
            overReadings++
            if (overReadings >= 2 && now - lastOverAlertAt > 120_000) {
                lastOverAlertAt = now
                progress = progress.copy(overspeedCount = progress.overspeedCount + 1)
                Repo.alerts(c.fleetId).add(
                    alertMap(
                        c, AlertType.OVERSPEED, kmh, loc.latitude, loc.longitude,
                        "${c.vehicleName} at ${kmh.toInt()} km/h (limit $speedLimit)"
                    )
                )
                Notifs.show(
                    this, Notifs.CH_DRIVER_WARN, 202, "Slow down!",
                    "You are driving at ${kmh.toInt()} km/h. Speed limit is $speedLimit km/h."
                )
            }
        } else {
            overReadings = 0
        }
        val overspeedNow = overReadings >= 2

        // ---- route points (buffered) ----
        val lb = lastBufferedLoc
        if (lb == null || lb.distanceTo(loc) >= 15 || now - lastBufferedAt >= 60_000) {
            buffer.add(
                mapOf(
                    "a" to loc.latitude, "o" to loc.longitude,
                    "s" to (Math.round(kmh * 10) / 10.0), "t" to now
                )
            )
            lastBufferedLoc = loc
            lastBufferedAt = now
        }
        if (buffer.size >= 80 || (buffer.isNotEmpty() && now - lastFlushAt >= 120_000)) flush()

        // ---- live position (throttled to save Firestore writes) ----
        val interval = if (kmh >= MOVING_KMH) 10_000L else 60_000L
        if (now - lastLiveWriteAt >= interval || overspeedNow != lastLiveOverspeed) {
            lastLiveWriteAt = now
            lastLiveOverspeed = overspeedNow
            Repo.live(c.fleetId).document(c.email).set(
                mapOf(
                    "driverName" to c.driverName, "driverPhone" to c.driverPhone,
                    "vehicleId" to c.vehicleId, "vehicleName" to c.vehicleName,
                    "vehicleNumber" to c.vehicleNumber, "vehicleType" to c.vehicleType,
                    "lat" to loc.latitude, "lng" to loc.longitude,
                    "speed" to (Math.round(kmh * 10) / 10.0),
                    "bearing" to (if (loc.hasBearing()) loc.bearing.toDouble() else 0.0),
                    "accuracy" to acc, "battery" to battery(),
                    "onDuty" to true, "updatedAt" to now, "stoppedSince" to stoppedSince,
                    "tripId" to progress.tripId, "tripKm" to progress.distanceM / 1000.0,
                    "overspeed" to overspeedNow, "dutyStart" to progress.startAt,
                ),
                SetOptions.merge()
            )
            updateNotification(kmh)
        }

        TrackingState.update {
            it.copy(
                speed = kmh, distanceKm = progress.distanceM / 1000.0, maxSpeed = progress.maxSpeed,
                lastFixAt = now, accuracy = acc, lat = loc.latitude, lng = loc.longitude,
                overspeed = over, speedLimit = speedLimit, waitingForGps = false,
            )
        }
    }

    private fun flush() {
        val c = cfg ?: return
        lastFlushAt = System.currentTimeMillis()
        val tripRef = Repo.trips(c.fleetId).document(progress.tripId)
        if (buffer.isNotEmpty()) {
            val idx = progress.chunkIndex
            tripRef.collection("chunks").document(String.format(Locale.US, "%05d", idx))
                .set(mapOf("i" to idx, "pts" to buffer.toList()))
            buffer.clear()
            progress = progress.copy(chunkIndex = idx + 1)
        }
        tripRef.set(
            mapOf(
                "distanceKm" to Math.round(progress.distanceM / 100.0) / 10.0,
                "maxSpeed" to Math.round(progress.maxSpeed * 10) / 10.0,
                "overspeedCount" to progress.overspeedCount,
                "endAt" to lastFlushAt,
            ),
            SetOptions.merge()
        )
        DutyPrefs.saveProgress(this, progress)
    }

    private fun endDuty() {
        val c = cfg ?: DutyPrefs.config(this)
        try {
            fused.removeLocationUpdates(callback)
        } catch (_: Exception) {
        }
        limitReg?.remove()
        if (c != null && running) {
            cfg = c
            flush()
            val now = System.currentTimeMillis()
            Repo.trips(c.fleetId).document(progress.tripId)
                .set(mapOf("active" to false, "endAt" to now), SetOptions.merge())
            Repo.live(c.fleetId).document(c.email).set(
                mapOf("onDuty" to false, "speed" to 0.0, "overspeed" to false, "updatedAt" to now, "battery" to battery()),
                SetOptions.merge()
            )
            Repo.alerts(c.fleetId).add(
                alertMap(
                    c, AlertType.DUTY_END, 0.0, lastAccepted?.latitude ?: 0.0, lastAccepted?.longitude ?: 0.0,
                    "${c.driverName} ended duty — ${Fmt.km(progress.distanceM / 1000.0)} in ${Fmt.duration(now - progress.startAt)}"
                )
            )
        }
        DutyPrefs.clear(this)
        running = false
        TrackingState.set(TrackingUi())
        releaseWakeLock()
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        if (running) {
            // System killed us mid-duty: save what we have; START_STICKY / app reopen will resume.
            try {
                fused.removeLocationUpdates(callback)
            } catch (_: Exception) {
            }
            flush()
            limitReg?.remove()
            running = false
            TrackingState.update { it.copy(running = false) }
            releaseWakeLock()
        }
        super.onDestroy()
    }

    // ---------------- helpers ----------------

    private fun alertMap(c: DutyConfig, type: String, speed: Double, lat: Double, lng: Double, msg: String) = mapOf(
        "type" to type, "driverName" to c.driverName, "driverEmail" to c.email,
        "vehicleName" to c.vehicleName, "vehicleNumber" to c.vehicleNumber,
        "speed" to (Math.round(speed * 10) / 10.0), "limit" to speedLimit,
        "lat" to lat, "lng" to lng, "at" to System.currentTimeMillis(), "seen" to false, "message" to msg,
    )

    private fun vehicleLabel(c: DutyConfig) =
        if (c.vehicleNumber.isBlank()) c.vehicleName else "${c.vehicleName} • ${c.vehicleNumber}"

    private fun battery(): Int = try {
        (getSystemService(Context.BATTERY_SERVICE) as BatteryManager)
            .getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
    } catch (_: Exception) {
        -1
    }

    private fun buildNotification(text: String): Notification =
        NotificationCompat.Builder(this, Notifs.CH_TRACKING)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle("On duty — location shared with manager")
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(Notifs.openAppIntent(this))
            .build()

    private fun updateNotification(kmh: Double) {
        if (!Notifs.canPost(this)) return
        val text = "${Fmt.speed(kmh)} • ${Fmt.km(progress.distanceM / 1000.0)} today on ${cfg?.vehicleName ?: ""}"
        try {
            NotificationManagerCompat.from(this).notify(NOTIF_ID, buildNotification(text))
        } catch (_: SecurityException) {
        }
    }

    private fun acquireWakeLock() {
        if (wakeLock?.isHeld == true) return
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "FleetTrack:duty").apply {
            setReferenceCounted(false)
            acquire(16 * 60 * 60 * 1000L)
        }
    }

    private fun releaseWakeLock() {
        try {
            if (wakeLock?.isHeld == true) wakeLock?.release()
        } catch (_: Exception) {
        }
        wakeLock = null
    }
}
