package com.rajeev.fleettrack

import android.app.Application
import android.content.Context
import com.rajeev.fleettrack.util.Notifs
import org.osmdroid.config.Configuration
import java.io.File

class FleetApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Notifs.createChannels(this)
        // OpenStreetMap setup: identify the app and keep the tile cache inside app storage
        val osm = Configuration.getInstance()
        osm.load(this, getSharedPreferences("osmdroid", Context.MODE_PRIVATE))
        osm.userAgentValue = packageName
        val base = File(cacheDir, "osmdroid")
        osm.osmdroidBasePath = base
        osm.osmdroidTileCache = File(base, "tiles")
    }
}
