package com.rajeev.fleettrack.util

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object Fmt {
    private val keyFmt get() = SimpleDateFormat("yyyy-MM-dd", Locale.US)

    fun dayKey(millis: Long = System.currentTimeMillis()): String = keyFmt.format(Date(millis))

    fun keyToMillis(key: String): Long = try {
        keyFmt.parse(key)?.time ?: System.currentTimeMillis()
    } catch (_: Exception) {
        System.currentTimeMillis()
    }

    fun shiftDay(key: String, days: Int): String {
        val c = Calendar.getInstance()
        c.timeInMillis = keyToMillis(key)
        c.add(Calendar.DAY_OF_MONTH, days)
        return dayKey(c.timeInMillis)
    }

    fun prettyDay(key: String): String =
        SimpleDateFormat("EEE, dd MMM yyyy", Locale.getDefault()).format(Date(keyToMillis(key)))

    fun time(millis: Long): String =
        if (millis <= 0) "--" else SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date(millis))

    fun dateTime(millis: Long): String =
        if (millis <= 0) "--" else SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(Date(millis))

    fun km(v: Double): String = String.format(Locale.US, "%.1f km", v)

    fun speed(v: Double): String = String.format(Locale.US, "%.0f km/h", v)

    fun duration(ms: Long): String {
        if (ms <= 0) return "0m"
        val totalMin = ms / 60000
        val h = totalMin / 60
        val m = totalMin % 60
        return if (h > 0) "${h}h ${m}m" else "${m}m"
    }

    fun ago(millis: Long, now: Long = System.currentTimeMillis()): String {
        if (millis <= 0) return "never"
        val s = (now - millis) / 1000
        return when {
            s < 15 -> "just now"
            s < 60 -> "${s}s ago"
            s < 3600 -> "${s / 60} min ago"
            s < 86400 -> "${s / 3600} hr ago"
            else -> dateTime(millis)
        }
    }

    /** Material DatePicker works in UTC midnight millis. */
    fun keyToUtcMillis(key: String): Long = try {
        SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { timeZone = java.util.TimeZone.getTimeZone("UTC") }
            .parse(key)?.time ?: System.currentTimeMillis()
    } catch (_: Exception) {
        System.currentTimeMillis()
    }

    fun utcMillisToKey(millis: Long): String =
        SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { timeZone = java.util.TimeZone.getTimeZone("UTC") }
            .format(Date(millis))

    fun money(v: Double): String = String.format(Locale.US, "₹%,.0f", v)
}
