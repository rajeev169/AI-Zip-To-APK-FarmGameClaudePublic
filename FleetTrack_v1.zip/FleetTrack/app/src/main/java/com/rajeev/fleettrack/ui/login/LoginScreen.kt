package com.rajeev.fleettrack.ui.login

import android.app.Activity
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rajeev.fleettrack.data.AuthManager
import com.rajeev.fleettrack.ui.theme.Navy
import com.rajeev.fleettrack.ui.theme.Orange
import kotlinx.coroutines.launch

@Composable
fun LoginScreen(onSignedIn: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Navy, Color(0xFF1976D2))))
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                Modifier
                    .size(104.dp)
                    .background(Color.White, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Filled.LocalShipping, null, tint = Navy, modifier = Modifier.size(56.dp))
            }
            Spacer(Modifier.height(22.dp))
            Text("Fleet Track", color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text(
                "See every vehicle live — location, speed, routes, alerts and reports.",
                color = Color.White.copy(alpha = 0.85f), textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(40.dp))
            Button(
                onClick = {
                    error = null
                    busy = true
                    scope.launch {
                        try {
                            AuthManager.signIn(ctx as Activity)
                            onSignedIn()
                        } catch (e: Exception) {
                            error = e.message ?: "Sign-in cancelled"
                        } finally {
                            busy = false
                        }
                    }
                },
                enabled = !busy,
                colors = ButtonDefaults.buttonColors(containerColor = Orange, contentColor = Color.Black),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
            ) {
                if (busy) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp, color = Color.Black)
                else Text("Sign in with Google", fontWeight = FontWeight.Bold, fontSize = 17.sp)
            }
            Spacer(Modifier.height(16.dp))
            Text(
                "Managers and drivers use the same app.\nDrivers: your manager must add your Gmail first.",
                color = Color.White.copy(alpha = 0.8f), textAlign = TextAlign.Center,
                style = MaterialTheme.typography.bodySmall
            )
            error?.let {
                Spacer(Modifier.height(16.dp))
                Text(it, color = Color(0xFFFFCDD2), textAlign = TextAlign.Center)
            }
        }
    }
}

/** First sign-in with a Gmail that is not a driver: set up a transport business. */
@Composable
fun NewUserScreen(email: String, name: String, onCreate: suspend (String) -> Unit, onRecheck: () -> Unit, onSignOut: () -> Unit) {
    val scope = rememberCoroutineScope()
    var business by remember { mutableStateOf(if (name.isNotBlank()) "$name Transport" else "") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    Column(
        Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text("Welcome!", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("Signed in as $email", color = Color.Gray)
        Spacer(Modifier.height(28.dp))
        Text("I am a transport manager / owner", fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = business, onValueChange = { business = it },
            label = { Text("Business name") }, singleLine = true, modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(12.dp))
        Button(
            onClick = {
                busy = true; error = null
                scope.launch {
                    try { onCreate(business) } catch (e: Exception) { error = e.message } finally { busy = false }
                }
            },
            enabled = !busy && business.isNotBlank(),
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
        ) { Text("Create my fleet") }
        Spacer(Modifier.height(32.dp))
        Text("I am a driver", fontWeight = FontWeight.SemiBold)
        Text(
            "Ask your manager to add $email in Fleet Track → Setup → Drivers, then tap below.",
            color = Color.Gray
        )
        TextButton(onClick = onRecheck) { Text("I've been added — check again") }
        TextButton(onClick = onSignOut) { Text("Use a different Google account") }
        error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
    }
}
