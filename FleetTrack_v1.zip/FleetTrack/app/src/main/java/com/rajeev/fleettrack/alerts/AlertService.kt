package com.rajeev.fleettrack.alerts

import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.google.firebase.firestore.DocumentChange
import com.google.firebase.firestore.ListenerRegistration
import com.rajeev.fleettrack.R
import com.rajeev.fleettrack.data.Alert
import com.rajeev.fleettrack.data.AlertType
import com.rajeev.fleettrack.data.Repo
import com.rajeev.fleettrack.data.toAlert
import com.rajeev.fleettrack.util.Notifs

object AlertWatcher {
    /** Listens for NEW alerts from now on and shows a phone notification for overspeed / SOS. */
    fun watch(ctx: Context, fleetId: String): ListenerRegistration {
        val since = System.currentTimeMillis()
        val app = ctx.applicationContext
        return Repo.alerts(fleetId).whereGreaterThan("at", since).addSnapshotListener { snap, _ ->
            snap?.documentChanges?.forEach { ch ->
                if (ch.type == DocumentChange.Type.ADDED) notifyAlert(app, ch.document.toAlert())
            }
        }
    }

    fun notifyAlert(ctx: Context, a: Alert) {
        val id = (a.id.hashCode() and 0x0fffffff) + 1000
        when (a.type) {
            AlertType.SOS -> Notifs.show(
                ctx, Notifs.CH_ALERTS, id, "🚨 SOS from ${a.driverName}",
                "${a.vehicleName} ${a.vehicleNumber} needs help. ${a.message}".trim()
            )
            AlertType.OVERSPEED -> Notifs.show(
                ctx, Notifs.CH_ALERTS, id, "⚠️ Overspeed — ${a.vehicleName}",
                "${a.driverName} is driving at ${a.speed.toInt()} km/h (limit ${a.limit} km/h)"
            )
        }
    }
}

object ManagerPrefs {
    private fun p(ctx: Context) = ctx.getSharedPreferences("manager", Context.MODE_PRIVATE)
    fun backgroundAlerts(ctx: Context) = p(ctx).getBoolean("bgAlerts", false)
    fun setBackgroundAlerts(ctx: Context, on: Boolean) = p(ctx).edit().putBoolean("bgAlerts", on).apply()
    fun fleetId(ctx: Context) = p(ctx).getString("fleetId", "") ?: ""
    fun setFleetId(ctx: Context, f: String) = p(ctx).edit().putString("fleetId", f).apply()
}

/** Optional: keeps listening for overspeed / SOS alerts on the manager phone even when the app is closed. */
class AlertService : Service() {

    companion object {
        var isRunning = false
            private set

        fun start(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, AlertService::class.java))
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, AlertService::class.java))
        }
    }

    private var reg: ListenerRegistration? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val fleetId = ManagerPrefs.fleetId(this)
        if (fleetId.isBlank() || !ManagerPrefs.backgroundAlerts(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        val n = NotificationCompat.Builder(this, Notifs.CH_SERVICE)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle("Watching for fleet alerts")
            .setContentText("You'll be notified about overspeed and SOS")
            .setOngoing(true)
            .setContentIntent(Notifs.openAppIntent(this))
            .build()
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                ServiceCompat.startForeground(this, 303, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            } else {
                startForeground(303, n)
            }
        } catch (_: Exception) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (reg == null) reg = AlertWatcher.watch(this, fleetId)
        isRunning = true
        return START_STICKY
    }

    override fun onDestroy() {
        reg?.remove()
        reg = null
        isRunning = false
        super.onDestroy()
    }
}
