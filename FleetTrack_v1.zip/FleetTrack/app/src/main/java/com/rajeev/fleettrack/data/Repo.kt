package com.rajeev.fleettrack.data

import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.DocumentReference
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.SetOptions
import com.rajeev.fleettrack.util.Fmt
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

sealed class Session {
    data class Manager(val fleetId: String, val email: String) : Session()
    data class DriverSession(val fleetId: String, val fleetName: String, val driver: Driver) : Session()
    /** Signed in, but neither a manager nor an added driver yet. */
    data class NewUser(val email: String, val name: String) : Session()
}

/**
 * Firestore layout
 *  fleets/{managerUid}                     name, ownerEmail, speedLimit
 *  fleets/{f}/drivers/{gmail}              name, phone
 *  fleets/{f}/vehicles/{id}                name, number, type
 *  fleets/{f}/live/{gmail}                 latest position + speed (one doc per driver)
 *  fleets/{f}/trips/{id}                   one duty session
 *  fleets/{f}/trips/{id}/chunks/{n}        route points in batches (saves writes)
 *  fleets/{f}/alerts/{id}                  overspeed / SOS / duty events
 *  fleets/{f}/fuel/{id}                    fuel entries
 *  driverIndex/{gmail}                     fleetId — lets a driver phone find its manager after Google sign-in
 */
object Repo {
    val db: FirebaseFirestore get() = FirebaseFirestore.getInstance()

    fun fleet(f: String) = db.collection("fleets").document(f)
    fun drivers(f: String) = fleet(f).collection("drivers")
    fun vehicles(f: String) = fleet(f).collection("vehicles")
    fun live(f: String) = fleet(f).collection("live")
    fun trips(f: String) = fleet(f).collection("trips")
    fun alerts(f: String) = fleet(f).collection("alerts")
    fun fuel(f: String) = fleet(f).collection("fuel")
    fun driverIndex(email: String) = db.collection("driverIndex").document(email.lowercase())

    // ---------------- role detection (same idea as Tractor Khata / Family Shield) ----------------

    suspend fun detectRole(user: FirebaseUser): Session {
        val email = (user.email ?: "").lowercase()
        // 1) Is this Gmail added as a driver by some manager?
        val idx = driverIndex(email).get().await()
        if (idx.exists()) {
            val fleetId = idx.getString("fleetId") ?: ""
            if (fleetId.isNotBlank()) {
                val dDoc = drivers(fleetId).document(email).get().await()
                if (dDoc.exists()) {
                    return Session.DriverSession(fleetId, idx.getString("fleetName") ?: "", dDoc.toDriver())
                }
            }
        }
        // 2) Is this person a manager who already set up a fleet?
        val own = fleet(user.uid).get().await()
        if (own.exists()) return Session.Manager(user.uid, email)
        // 3) New
        return Session.NewUser(email, user.displayName ?: "")
    }

    suspend fun createFleet(user: FirebaseUser, businessName: String) {
        fleet(user.uid).set(
            mapOf(
                "name" to businessName.trim(),
                "ownerEmail" to (user.email ?: "").lowercase(),
                "ownerName" to (user.displayName ?: ""),
                "speedLimit" to 60,
                "createdAt" to System.currentTimeMillis(),
            )
        ).await()
    }

    suspend fun updateFleet(f: String, name: String, speedLimit: Int) {
        fleet(f).set(mapOf("name" to name.trim(), "speedLimit" to speedLimit), SetOptions.merge()).await()
    }

    // ---------------- drivers & vehicles ----------------

    suspend fun addDriver(f: String, fleetName: String, name: String, email: String, phone: String) {
        val e = email.trim().lowercase()
        val batch = db.batch()
        batch.set(drivers(f).document(e), mapOf("name" to name.trim(), "phone" to phone.trim(), "addedAt" to System.currentTimeMillis()))
        batch.set(driverIndex(e), mapOf("fleetId" to f, "fleetName" to fleetName))
        batch.commit().await()
    }

    suspend fun removeDriver(f: String, email: String) {
        val batch = db.batch()
        batch.delete(drivers(f).document(email))
        batch.delete(driverIndex(email))
        batch.delete(live(f).document(email))
        batch.commit().await()
    }

    suspend fun addVehicle(f: String, name: String, number: String, type: String) {
        vehicles(f).add(mapOf("name" to name.trim(), "number" to number.trim().uppercase(), "type" to type)).await()
    }

    suspend fun removeVehicle(f: String, id: String) {
        vehicles(f).document(id).delete().await()
    }

    // ---------------- reads ----------------

    suspend fun tripsOn(f: String, day: String): List<Trip> =
        trips(f).whereEqualTo("date", day).get().await().documents.map { it.toTrip() }.sortedBy { it.startAt }

    suspend fun tripsBetween(f: String, from: String, to: String): List<Trip> =
        trips(f).whereGreaterThanOrEqualTo("date", from).whereLessThanOrEqualTo("date", to)
            .get().await().documents.map { it.toTrip() }

    suspend fun fuelBetween(f: String, from: String, to: String): List<FuelEntry> =
        fuel(f).whereGreaterThanOrEqualTo("date", from).whereLessThanOrEqualTo("date", to)
            .get().await().documents.map { it.toFuel() }

    suspend fun tripPoints(f: String, tripId: String): List<TrackPoint> =
        trips(f).document(tripId).collection("chunks").orderBy("i").get().await()
            .documents.flatMap { it.toPoints() }.sortedBy { it.time }

    suspend fun markAllAlertsSeen(f: String, ids: List<String>) {
        if (ids.isEmpty()) return
        ids.chunked(400).forEach { part ->
            val b = db.batch()
            part.forEach { b.update(alerts(f).document(it), "seen", true) }
            b.commit().await()
        }
    }

    suspend fun addFuel(f: String, entry: FuelEntry) {
        fuel(f).add(
            mapOf(
                "vehicleId" to entry.vehicleId, "vehicleName" to entry.vehicleName, "vehicleNumber" to entry.vehicleNumber,
                "driverName" to entry.driverName, "driverEmail" to entry.driverEmail,
                "litres" to entry.litres, "amount" to entry.amount, "note" to entry.note,
                "date" to Fmt.dayKey(entry.at), "at" to entry.at,
            )
        ).await()
    }

    suspend fun addAlert(f: String, data: Map<String, Any?>) {
        alerts(f).add(data).await()
    }
}

// ---------------- realtime helpers ----------------

fun <T> Query.listen(map: (DocumentSnapshot) -> T): Flow<List<T>> = callbackFlow {
    val reg = addSnapshotListener { snap, _ ->
        if (snap != null) trySend(snap.documents.map(map))
    }
    awaitClose { reg.remove() }
}

fun <T> DocumentReference.listen(map: (DocumentSnapshot) -> T?): Flow<T?> = callbackFlow {
    val reg = addSnapshotListener { snap, _ ->
        if (snap != null) trySend(if (snap.exists()) map(snap) else null)
    }
    awaitClose { reg.remove() }
}
