package com.rajeev.fleettrack.data

import android.app.Activity
import android.content.Context
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import com.rajeev.fleettrack.R
import kotlinx.coroutines.tasks.await

/** Google account sign-in — same Gmail on a new phone brings back all data. */
object AuthManager {
    val auth: FirebaseAuth get() = FirebaseAuth.getInstance()
    val user: FirebaseUser? get() = auth.currentUser

    suspend fun signIn(activity: Activity): FirebaseUser {
        val cm = CredentialManager.create(activity)
        val option = GetSignInWithGoogleOption.Builder(activity.getString(R.string.default_web_client_id)).build()
        val request = GetCredentialRequest.Builder().addCredentialOption(option).build()
        val result = cm.getCredential(activity, request)
        val cred = result.credential
        if (cred is CustomCredential && cred.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
            val google = GoogleIdTokenCredential.createFrom(cred.data)
            val firebaseCred = GoogleAuthProvider.getCredential(google.idToken, null)
            return auth.signInWithCredential(firebaseCred).await().user
                ?: throw IllegalStateException("Sign-in failed")
        }
        throw IllegalStateException("Unexpected sign-in response")
    }

    suspend fun signOut(ctx: Context) {
        auth.signOut()
        try {
            CredentialManager.create(ctx).clearCredentialState(ClearCredentialStateRequest())
        } catch (_: Exception) {
        }
    }
}
