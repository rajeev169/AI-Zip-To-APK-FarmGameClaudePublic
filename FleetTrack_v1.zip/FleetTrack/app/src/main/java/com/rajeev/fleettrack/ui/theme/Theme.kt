package com.rajeev.fleettrack.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Navy = Color(0xFF0D47A1)
val Orange = Color(0xFFFF9800)
val GreenOk = Color(0xFF2E7D32)
val AmberIdle = Color(0xFFF9A825)
val RedAlert = Color(0xFFD32F2F)
val GreyOff = Color(0xFF78909C)

private val scheme = lightColorScheme(
    primary = Navy,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD6E4FF),
    onPrimaryContainer = Color(0xFF001A43),
    secondary = Orange,
    onSecondary = Color.Black,
    secondaryContainer = Color(0xFFFFE0B2),
    onSecondaryContainer = Color(0xFF3E2000),
    background = Color(0xFFF5F7FB),
    surface = Color.White,
    surfaceVariant = Color(0xFFEEF2FA),
    error = RedAlert,
)

@Composable
fun FleetTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = scheme, content = content)
}
