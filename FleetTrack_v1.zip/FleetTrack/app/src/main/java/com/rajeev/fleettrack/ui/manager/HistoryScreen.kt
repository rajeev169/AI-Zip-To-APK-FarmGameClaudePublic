package com.rajeev.fleettrack.ui.manager

import android.graphics.Paint
import android.location.Location
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rajeev.fleettrack.data.Repo
import com.rajeev.fleettrack.data.TrackPoint
import com.rajeev.fleettrack.data.Trip
import com.rajeev.fleettrack.data.Vehicle
import com.rajeev.fleettrack.data.VehicleStatus
import com.rajeev.fleettrack.ui.common.EmptyNote
import com.rajeev.fleettrack.ui.common.MarkerIcons
import com.rajeev.fleettrack.ui.common.OsmMap
import com.rajeev.fleettrack.ui.common.StatRow
import com.rajeev.fleettrack.ui.common.fitTo
import com.rajeev.fleettrack.ui.theme.GreenOk
import com.rajeev.fleettrack.ui.theme.Navy
import com.rajeev.fleettrack.ui.theme.RedAlert
import com.rajeev.fleettrack.util.Fmt
import kotlinx.coroutines.delay
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Polyline

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HistoryScreen(fleetId: String, vehicles: List<Vehicle>, speedLimit: Int, initialVehicle: String) {
    var day by remember { mutableStateOf(Fmt.dayKey()) }
    var vFilter by remember(initialVehicle) { mutableStateOf(initialVehicle) }
    var trips by remember { mutableStateOf<List<Trip>?>(null) }
    var openTrip by remember { mutableStateOf<Trip?>(null) }
    var refresh by remember { mutableIntStateOf(0) }
    var showPicker by remember { mutableStateOf(false) }
    val today = Fmt.dayKey()

    LaunchedEffect(day, refresh) {
        trips = null
        trips = try {
            Repo.tripsOn(fleetId, day)
        } catch (_: Exception) {
            emptyList()
        }
    }

    BackHandler(enabled = openTrip != null) { openTrip = null }

    val t = openTrip
    if (t != null) {
        TripDetail(fleetId, t, speedLimit, onBack = { openTrip = null })
        return
    }

    Column(Modifier.fillMaxSize()) {
        // date bar
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { day = Fmt.shiftDay(day, -1) }) { Icon(Icons.Filled.ChevronLeft, "Previous day") }
            Row(
                Modifier
                    .weight(1f)
                    .clickable { showPicker = true }
                    .padding(8.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Filled.CalendarMonth, null, Modifier.size(18.dp), tint = Navy)
                Spacer(Modifier.width(6.dp))
                Text(if (day == today) "Today" else Fmt.prettyDay(day), fontWeight = FontWeight.Bold)
            }
            IconButton(onClick = { day = Fmt.shiftDay(day, 1) }, enabled = day < today) {
                Icon(Icons.Filled.ChevronRight, "Next day")
            }
            IconButton(onClick = { refresh++ }) { Icon(Icons.Filled.Refresh, "Refresh") }
        }
        // vehicle filter
        Row(
            Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(selected = vFilter.isBlank(), onClick = { vFilter = "" }, label = { Text("All vehicles") })
            vehicles.forEach { v ->
                FilterChip(selected = vFilter == v.id, onClick = { vFilter = v.id }, label = { Text(v.name) })
            }
        }

        val list = trips
        when {
            list == null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            else -> {
                val shown = list.filter { vFilter.isBlank() || it.vehicleId == vFilter }
                if (shown.isEmpty()) {
                    EmptyNote("No trips on this day")
                } else {
                    val totalKm = shown.sumOf { it.distanceKm }
                    Text(
                        "${shown.size} trip(s) • ${Fmt.km(totalKm)}",
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                        color = Color.Gray
                    )
                    LazyColumn(
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(shown, key = { it.id }) { trip -> TripCard(trip) { openTrip = trip } }
                    }
                }
            }
        }
    }

    if (showPicker) {
        val state = rememberDatePickerState(initialSelectedDateMillis = Fmt.keyToUtcMillis(day))
        DatePickerDialog(
            onDismissRequest = { showPicker = false },
            confirmButton = {
                TextButton(onClick = {
                    state.selectedDateMillis?.let { day = Fmt.utcMillisToKey(it) }
                    showPicker = false
                }) { Text("OK") }
            },
            dismissButton = { TextButton(onClick = { showPicker = false }) { Text("Cancel") } }
        ) { DatePicker(state = state) }
    }
}

@Composable
private fun TripCard(t: Trip, onClick: () -> Unit) {
    Card(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(t.vehicleName + if (t.vehicleNumber.isNotBlank()) " • ${t.vehicleNumber}" else "", fontWeight = FontWeight.Bold)
                    Text(t.driverName, color = Color.DarkGray, fontSize = 13.sp)
                }
                if (t.overspeedCount > 0) {
                    Icon(Icons.Filled.Warning, null, tint = RedAlert, modifier = Modifier.size(16.dp))
                    Text(" ${t.overspeedCount}", color = RedAlert, fontWeight = FontWeight.Bold)
                }
            }
            Text(
                "${Fmt.time(t.startAt)} → " + if (t.active) "on duty now" else Fmt.time(t.endAt),
                color = if (t.active) GreenOk else Color.Gray, fontSize = 13.sp
            )
            Spacer(Modifier.height(8.dp))
            StatRow(
                "Distance" to Fmt.km(t.distanceKm),
                "Time" to Fmt.duration(t.endAt - t.startAt),
                "Max speed" to Fmt.speed(t.maxSpeed),
            )
        }
    }
}

private class TripMapHolder {
    var built = false
    var mover: Marker? = null
}

@Composable
private fun TripDetail(fleetId: String, trip: Trip, speedLimit: Int, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var pts by remember { mutableStateOf<List<TrackPoint>?>(null) }
    var idx by remember { mutableIntStateOf(0) }
    var playing by remember { mutableStateOf(false) }
    var playSpeed by remember { mutableFloatStateOf(1f) }
    val holder = remember { TripMapHolder() }

    LaunchedEffect(trip.id) {
        pts = try {
            Repo.tripPoints(fleetId, trip.id)
        } catch (_: Exception) {
            emptyList()
        }
        idx = 0
    }
    LaunchedEffect(playing) {
        while (playing) {
            val p = pts ?: break
            if (idx >= p.size - 1) {
                playing = false
                break
            }
            delay((140 / playSpeed).toLong())
            idx++
        }
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.padding(4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
            Column {
                Text(trip.vehicleName, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                Text("${trip.driverName} • ${Fmt.prettyDay(trip.date)}", fontSize = 12.sp, color = Color.Gray)
            }
        }
        val p = pts
        Box(
            Modifier
                .fillMaxWidth()
                .weight(1f)
        ) {
            OsmMap(Modifier.fillMaxSize()) { map ->
                if (p == null || p.isEmpty()) return@OsmMap
                if (!holder.built) {
                    holder.built = true
                    // route split into normal (blue) and overspeed (red) segments
                    var seg = mutableListOf(GeoPoint(p[0].lat, p[0].lng))
                    var segOver = p[0].speed > speedLimit
                    fun addSeg(list: List<GeoPoint>, over: Boolean) {
                        if (list.size < 2) return
                        val line = Polyline(map)
                        line.setPoints(list)
                        line.outlinePaint.color = if (over) RedAlert.toArgb() else Navy.toArgb()
                        line.outlinePaint.strokeWidth = 11f
                        line.outlinePaint.strokeCap = Paint.Cap.ROUND
                        line.outlinePaint.strokeJoin = Paint.Join.ROUND
                        map.overlays.add(line)
                    }
                    for (i in 1 until p.size) {
                        val gp = GeoPoint(p[i].lat, p[i].lng)
                        val over = p[i].speed > speedLimit
                        seg.add(gp)
                        if (over != segOver) {
                            addSeg(seg, segOver)
                            seg = mutableListOf(gp)
                            segOver = over
                        }
                    }
                    addSeg(seg, segOver)

                    val start = Marker(map).apply {
                        position = GeoPoint(p.first().lat, p.first().lng)
                        setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER)
                        icon = MarkerIcons.dot(ctx, GreenOk.toArgb(), 22)
                        title = "Start ${Fmt.time(p.first().time)}"
                    }
                    val end = Marker(map).apply {
                        position = GeoPoint(p.last().lat, p.last().lng)
                        setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER)
                        icon = MarkerIcons.dot(ctx, RedAlert.toArgb(), 22)
                        title = "End ${Fmt.time(p.last().time)}"
                    }
                    map.overlays.add(start)
                    map.overlays.add(end)
                    val mover = Marker(map).apply { setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER) }
                    mover.setOnMarkerClickListener { _, _ -> true }
                    map.overlays.add(mover)
                    holder.mover = mover
                    map.fitTo(p.map { GeoPoint(it.lat, it.lng) })
                }
                val i = idx.coerceIn(0, p.size - 1)
                val cur = p[i]
                val bearing = if (i > 0) {
                    val a = Location("").apply { latitude = p[i - 1].lat; longitude = p[i - 1].lng }
                    val b = Location("").apply { latitude = cur.lat; longitude = cur.lng }
                    a.bearingTo(b)
                } else 0f
                val st = when {
                    cur.speed > speedLimit -> VehicleStatus.OVERSPEED
                    cur.speed >= 3 -> VehicleStatus.MOVING
                    else -> VehicleStatus.STOPPED
                }
                holder.mover?.position = GeoPoint(cur.lat, cur.lng)
                holder.mover?.icon = MarkerIcons.vehicle(ctx, st, cur.speed.toInt(), bearing, false)
                map.invalidate()
            }
            when {
                p == null -> CircularProgressIndicator(Modifier.align(Alignment.Center))
                p.isEmpty() -> Card(Modifier.align(Alignment.Center).padding(24.dp)) {
                    Text("No route saved for this trip (GPS not received).", Modifier.padding(16.dp))
                }
            }
        }

        Card(
            Modifier
                .fillMaxWidth()
                .padding(10.dp),
            elevation = CardDefaults.cardElevation(3.dp)
        ) {
            Column(Modifier.padding(12.dp)) {
                StatRow(
                    "Distance" to Fmt.km(trip.distanceKm),
                    "Time" to Fmt.duration(trip.endAt - trip.startAt),
                    "Max" to Fmt.speed(trip.maxSpeed),
                    "Overspeed" to trip.overspeedCount.toString(),
                )
                if (p != null && p.size > 1) {
                    val cur = p[idx.coerceIn(0, p.size - 1)]
                    Spacer(Modifier.height(10.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        FilledIconButton(onClick = {
                            if (idx >= p.size - 1) idx = 0
                            playing = !playing
                        }) {
                            Icon(if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, "Play route")
                        }
                        Spacer(Modifier.width(8.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                "${Fmt.time(cur.time)} • ${Fmt.speed(cur.speed)}",
                                fontWeight = FontWeight.SemiBold,
                                color = if (cur.speed > speedLimit) RedAlert else Color.Unspecified
                            )
                            Slider(
                                value = idx.toFloat(),
                                onValueChange = { idx = it.toInt(); playing = false },
                                valueRange = 0f..(p.size - 1).toFloat()
                            )
                        }
                        TextButton(onClick = { playSpeed = if (playSpeed >= 4f) 1f else playSpeed * 2 }) {
                            Text("${playSpeed.toInt()}x")
                        }
                    }
                    Text("Blue = normal • Red = above $speedLimit km/h", fontSize = 11.sp, color = Color.Gray)
                }
            }
        }
    }
}
