package com.rajeev.fleettrack.ui.manager

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryStd
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Timeline
import androidx.compose.material.icons.filled.ZoomOutMap
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.SmallFloatingActionButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rajeev.fleettrack.data.Driver
import com.rajeev.fleettrack.data.LiveInfo
import com.rajeev.fleettrack.data.VehicleStatus
import com.rajeev.fleettrack.data.status
import com.rajeev.fleettrack.ui.common.MarkerIcons
import com.rajeev.fleettrack.ui.common.OsmMap
import com.rajeev.fleettrack.ui.common.StatRow
import com.rajeev.fleettrack.ui.common.StatusChip
import com.rajeev.fleettrack.ui.common.fitTo
import com.rajeev.fleettrack.ui.common.statusColor
import com.rajeev.fleettrack.util.Fmt
import com.rajeev.fleettrack.util.Share
import kotlinx.coroutines.delay
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker

private val statusOrder = listOf(
    VehicleStatus.OVERSPEED, VehicleStatus.MOVING, VehicleStatus.STOPPED, VehicleStatus.OFFLINE, VehicleStatus.OFF_DUTY
)

private fun LiveInfo.hasFix() = lat != 0.0 || lng != 0.0

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LiveScreen(
    live: List<LiveInfo>,
    drivers: List<Driver>,
    hasSetup: Boolean,
    onGoSetup: () -> Unit,
    onShowRoute: (String) -> Unit,
) {
    val ctx = LocalContext.current
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(15_000)
            now = System.currentTimeMillis()
        }
    }
    // only show drivers that still exist in the fleet
    val known = drivers.map { it.email }.toSet()
    val rows = live.filter { it.email in known }
        .sortedWith(compareBy<LiveInfo>({ statusOrder.indexOf(it.status(now)) }, { it.vehicleName }))
    val onMap = rows.filter { it.hasFix() && it.status(now) != VehicleStatus.OFF_DUTY }

    var selected by remember { mutableStateOf<String?>(null) }
    var mapRef by remember { mutableStateOf<MapView?>(null) }
    val fitted = remember { booleanArrayOf(false) }

    Column(Modifier.fillMaxSize()) {
        Box(
            Modifier
                .fillMaxWidth()
                .weight(0.58f)
        ) {
            OsmMap(Modifier.fillMaxSize(), onCreated = { mapRef = it }) { map ->
                map.overlays.removeAll { it is Marker }
                onMap.forEach { l ->
                    val st = l.status(now)
                    val m = Marker(map)
                    m.position = GeoPoint(l.lat, l.lng)
                    m.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER)
                    m.icon = MarkerIcons.vehicle(ctx, st, l.speed.toInt(), l.bearing.toFloat(), selected == l.email)
                    m.title = l.vehicleName
                    m.setOnMarkerClickListener { _, _ ->
                        selected = l.email
                        true
                    }
                    map.overlays.add(m)
                }
                if (!fitted[0] && onMap.isNotEmpty()) {
                    fitted[0] = true
                    map.fitTo(onMap.map { GeoPoint(it.lat, it.lng) })
                }
                map.invalidate()
            }

            // summary chips
            Row(
                Modifier
                    .padding(10.dp)
                    .background(Color.White.copy(alpha = 0.94f), RoundedCornerShape(12.dp))
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                CountDot(statusColor(VehicleStatus.MOVING), rows.count { it.status(now) == VehicleStatus.MOVING || it.status(now) == VehicleStatus.OVERSPEED }, "moving")
                CountDot(statusColor(VehicleStatus.STOPPED), rows.count { it.status(now) == VehicleStatus.STOPPED }, "stopped")
                CountDot(statusColor(VehicleStatus.OFFLINE), rows.count { it.status(now) == VehicleStatus.OFFLINE }, "no signal")
            }

            SmallFloatingActionButton(
                onClick = {
                    mapRef?.fitTo(onMap.map { GeoPoint(it.lat, it.lng) })
                },
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(12.dp),
                containerColor = Color.White
            ) { Icon(Icons.Filled.ZoomOutMap, "Show all") }
        }

        if (!hasSetup) {
            Card(
                Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
            ) {
                Column(Modifier.padding(16.dp)) {
                    Text("Get started", fontWeight = FontWeight.Bold)
                    Text("Add your vehicles and drivers' Gmail in Setup. Drivers install this app, sign in with that Gmail and tap Start Duty.")
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = onGoSetup) { Text("Open Setup") }
                }
            }
        }

        LazyColumn(
            Modifier
                .fillMaxWidth()
                .weight(0.42f),
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (rows.isEmpty() && hasSetup) {
                item { Text("No driver has started duty yet.", color = Color.Gray, modifier = Modifier.padding(8.dp)) }
            }
            items(rows, key = { it.email }) { l ->
                VehicleCard(l, now, selected == l.email) {
                    selected = l.email
                    if (l.hasFix()) {
                        mapRef?.controller?.setZoom(15.0)
                        mapRef?.controller?.animateTo(GeoPoint(l.lat, l.lng))
                    }
                }
            }
        }
    }

    val sel = rows.firstOrNull { it.email == selected }
    if (sel != null) {
        ModalBottomSheet(onDismissRequest = { selected = null }) {
            VehicleDetail(sel, now, onShowRoute = {
                selected = null
                onShowRoute(sel.vehicleId)
            }, onCall = { Share.dial(ctx, sel.driverPhone) }, onShare = {
                Share.text(
                    ctx,
                    "📍 ${sel.vehicleName} ${sel.vehicleNumber}\nDriver: ${sel.driverName}\n" +
                        "Speed: ${Fmt.speed(sel.speed)} • ${Fmt.ago(sel.updatedAt)}\n${Share.mapsLink(sel.lat, sel.lng)}"
                )
            }, onMaps = { Share.openInMaps(ctx, sel.lat, sel.lng, sel.vehicleName) })
        }
    }
}

@Composable
private fun CountDot(c: Color, n: Int, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier
                .size(10.dp)
                .background(c, CircleShape)
        )
        Spacer(Modifier.width(4.dp))
        Text("$n $label", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Color.DarkGray)
    }
}

@Composable
private fun VehicleCard(l: LiveInfo, now: Long, selected: Boolean, onClick: () -> Unit) {
    val st = l.status(now)
    Card(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(
            containerColor = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(52.dp)
                    .background(statusColor(st), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        if (st == VehicleStatus.OFF_DUTY || st == VehicleStatus.OFFLINE) "–" else l.speed.toInt().toString(),
                        color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp
                    )
                    Text("km/h", color = Color.White, fontSize = 9.sp)
                }
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    l.vehicleName.ifBlank { "—" } + if (l.vehicleNumber.isNotBlank()) "  •  ${l.vehicleNumber}" else "",
                    fontWeight = FontWeight.Bold
                )
                Text(l.driverName, color = Color.DarkGray, fontSize = 13.sp)
                Text(
                    when (st) {
                        VehicleStatus.STOPPED ->
                            if (l.stoppedSince > 0) "Stopped for ${Fmt.duration(now - l.stoppedSince)}" else "Stopped"
                        VehicleStatus.OFF_DUTY -> "Off duty • last seen ${Fmt.ago(l.updatedAt, now)}"
                        else -> "${Fmt.km(l.tripKm)} today • ${Fmt.ago(l.updatedAt, now)}"
                    },
                    color = Color.Gray, fontSize = 12.sp
                )
            }
            Column(horizontalAlignment = Alignment.End) {
                StatusChip(st)
                if (l.battery >= 0) {
                    Spacer(Modifier.height(4.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Filled.BatteryStd, null, Modifier.size(14.dp),
                            tint = if (l.battery <= 15) Color(0xFFD32F2F) else Color.Gray
                        )
                        Text("${l.battery}%", fontSize = 11.sp, color = Color.Gray)
                    }
                }
            }
        }
    }
}

@Composable
private fun VehicleDetail(
    l: LiveInfo, now: Long,
    onShowRoute: () -> Unit, onCall: () -> Unit, onShare: () -> Unit, onMaps: () -> Unit,
) {
    val st = l.status(now)
    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp)
            .navigationBarsPadding()
            .padding(bottom = 16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(l.vehicleName, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                if (l.vehicleNumber.isNotBlank()) Text(l.vehicleNumber, color = Color.Gray)
            }
            StatusChip(st)
        }
        Spacer(Modifier.height(4.dp))
        Text("Driver: ${l.driverName}" + if (l.driverPhone.isNotBlank()) " • ${l.driverPhone}" else "")
        Spacer(Modifier.height(14.dp))
        StatRow(
            "Speed" to Fmt.speed(l.speed),
            "Today" to Fmt.km(l.tripKm),
            "On duty" to if (l.onDuty && l.dutyStart > 0) Fmt.duration(now - l.dutyStart) else "—",
            "Battery" to if (l.battery >= 0) "${l.battery}%" else "—",
        )
        Spacer(Modifier.height(12.dp))
        HorizontalDivider()
        Spacer(Modifier.height(8.dp))
        Text("Last update: ${Fmt.dateTime(l.updatedAt)} (${Fmt.ago(l.updatedAt, now)})", fontSize = 13.sp, color = Color.Gray)
        if (st == VehicleStatus.STOPPED && l.stoppedSince > 0) {
            Text("Standing since ${Fmt.time(l.stoppedSince)}", fontSize = 13.sp, color = Color.Gray)
        }
        if (l.accuracy > 0) Text("GPS accuracy ±${l.accuracy.toInt()} m", fontSize = 13.sp, color = Color.Gray)
        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilledTonalButton(onClick = onCall, Modifier.weight(1f)) {
                Icon(Icons.Filled.Phone, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text("Call")
            }
            FilledTonalButton(onClick = onShare, Modifier.weight(1f), enabled = l.hasFix()) {
                Icon(Icons.Filled.Share, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text("Share")
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = onMaps, Modifier.weight(1f), enabled = l.hasFix()) {
                Icon(Icons.Filled.Map, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text("Navigate")
            }
            Button(onClick = onShowRoute, Modifier.weight(1f)) {
                Icon(Icons.Filled.Timeline, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text("Route today")
            }
        }
    }
}
