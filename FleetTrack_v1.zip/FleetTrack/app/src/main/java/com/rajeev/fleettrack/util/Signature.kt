package com.rajeev.fleettrack.util

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import java.security.MessageDigest

/** SHA-1 of the key this APK was signed with — must be added in Firebase for Google sign-in to work. */
object AppSignature {
    @Suppress("DEPRECATION")
    fun sha1(ctx: Context): String = try {
        val pm = ctx.packageManager
        val sigs = if (Build.VERSION.SDK_INT >= 28) {
            val info = pm.getPackageInfo(ctx.packageName, PackageManager.GET_SIGNING_CERTIFICATES)
            info.signingInfo?.apkContentsSigners ?: emptyArray()
        } else {
            pm.getPackageInfo(ctx.packageName, PackageManager.GET_SIGNATURES).signatures ?: emptyArray()
        }
        val sig = sigs.firstOrNull() ?: return "unknown"
        MessageDigest.getInstance("SHA-1").digest(sig.toByteArray())
            .joinToString(":") { String.format("%02X", it) }
    } catch (e: Exception) {
        "unknown"
    }
}
