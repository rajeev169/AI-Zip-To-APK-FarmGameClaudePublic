extends Node
# Lighthouse Harbour (v28): a separate play screen reached by tapping Island 3.
# The harbour is built far away from the farm (at H). Entering fades out, hides the
# farm HUD, moves the camera there and shows the harbour HUD. "Back to farm" reverses it.
# Coins, XP and stock are shared with the farm; crops keep growing while you are away.

var g: Node          # main script (farm_3d.gd)
var v: Node          # farm_v27.gd

const H := Vector3(600.0, 0.0, 0.0)
const ZOOM_MIN := 5.0
const ZOOM_MAX := 45.0
const UNLOCK_LV := 6
const UNLOCK_COST := 800
const WAIT_MIN := 25.0
const WAIT_MAX := 45.0
const LAND := Vector3(-9.0, 0.0, -7.0)
const ANCHOR := Vector3(59.5, -0.35, 5.5)   # 50 units from the dock, in line with the berth
const BERTH := Vector3(9.5, -0.35, 5.5)
const SHIP_START := Vector3(100.0, -0.35, 5.5)
const SHIP_NAMES: Array = ["MV Sunrise", "SS Harvest", "MV Blue Whale", "SS Daisy", "MV Pearl", "SS Lantern", "MV Golden Wheat"]
const HULLS: Array = [Color(0.20, 0.32, 0.55), Color(0.70, 0.22, 0.22), Color(0.18, 0.50, 0.40), Color(0.45, 0.30, 0.55), Color(0.80, 0.55, 0.15)]

var unlocked: bool = false
var on: bool = false
var built: bool = false
var busy_fade: bool = false

var rng := RandomNumberGenerator.new()
var t: float = 0.0
var root3: Node3D
var ship: Node3D
var ship_slots: Array = []
var state: int = 0           # 0 waiting for a ship, 1 sailing in, 2 docked, 3 leaving
var wait_left: float = 8.0
var order: Dictionary = {}
var restore_docked: bool = false
var ship_tw: Tween
var fade_tw: Tween
var keeper: Node3D
var keeper_label: Label3D
var beam_pivot: Node3D
var beam_mat: StandardMaterial3D
var beam_sm: ShaderMaterial
var tug: Node3D
var crane_crate: MeshInstance3D
var flag_clock: float = 0.0

# camera memory
var saved_target: Vector3
var saved_zoom: float = 16.8

# ui
var ui: CanvasLayer
var fade_layer: CanvasLayer
var fade_rect: ColorRect
var top_label: Label
var panel: PanelContainer
var p_title: Label
var p_sub: Label
var p_rows: VBoxContainer
var p_reward: Label
var load_btn: Button
var send_btn: Button
var show_btn: Button
var toast: Label
var toast_t: float = 0.0

func _ready() -> void:
    rng.randomize()

# ----------------------------------------------------------------- helpers

func B(p: Node3D, s: Vector3, pos: Vector3, col: Color, n: String = "B") -> MeshInstance3D:
    return g._box(p, s, pos, col, n)

func say(msg: String) -> void:
    if toast != null:
        toast.text = msg
        toast.visible = true
        toast_t = 3.0

# ----------------------------------------------------------------- unlock

func on_island_tap() -> void:
    if unlocked:
        enter()
        return
    v.al_cool.erase("harbor")
    v.alert("harbor", true)

func try_unlock() -> void:
    if unlocked:
        return
    if int(g.level) < UNLOCK_LV:
        g._show_toast("Reach Level %d to unlock the Lighthouse Harbour." % UNLOCK_LV)
        return
    if int(g.coins) < UNLOCK_COST:
        g._show_toast("You need %d coins to unlock the Lighthouse Harbour." % UNLOCK_COST)
        return
    v._buy(UNLOCK_COST)
    unlocked = true
    wait_left = 4.0
    v.refresh_island_flag()
    g._show_toast("Lighthouse Harbour unlocked!")
    enter()

# ----------------------------------------------------------------- save / load

func save(c: ConfigFile) -> void:
    c.set_value("harbor", "unlocked", unlocked)
    c.set_value("harbor", "docked", (state == 2 or state == 4 or state == 1) and not order.is_empty())
    c.set_value("harbor", "order", order)
    c.set_value("harbor", "wait", wait_left)

func load_state(c: ConfigFile) -> void:
    unlocked = bool(c.get_value("harbor", "unlocked", false))
    wait_left = float(c.get_value("harbor", "wait", 8.0))
    var o: Variant = c.get_value("harbor", "order", {})
    if bool(c.get_value("harbor", "docked", false)) and o is Dictionary and not (o as Dictionary).is_empty():
        order = o
        state = 2
        restore_docked = true
    v.refresh_island_flag()

# ----------------------------------------------------------------- order

func _make_order() -> void:
    var cand: Array = []
    for i in range(5):
        cand.append(["crop", i])
    for i in range(4):
        cand.append(["good", i])
    for i in range(4):
        cand.append(["prod", i])
    var ok: Array = []
    for e in cand:
        if g._trade_item_ok(str(e[0]), int(e[1])):
            ok.append(e)
    var want: int = 2 + (rng.randi() % 2)
    var items: Array = []
    var value: float = 0.0
    while items.size() < want and ok.size() > 0:
        var pick: int = rng.randi() % ok.size()
        var e2: Array = ok[pick]
        ok.remove_at(pick)
        var n: int = 1 + (rng.randi() % (2 + int(g.level) / 6))
        items.append({"k": str(e2[0]), "id": int(e2[1]), "n": n, "got": 0})
        value += float(g._item_price(str(e2[0]), int(e2[1])) * n)
    if items.is_empty():
        items.append({"k": "crop", "id": 0, "n": 3, "got": 0})
        value = float(g._item_price("crop", 0) * 3)
    order = {
        "name": str(SHIP_NAMES[rng.randi() % SHIP_NAMES.size()]),
        "hull": rng.randi() % HULLS.size(),
        "items": items,
        "coins": int(round((value * 1.6 + 45.0) * 1.1)),
        "xp": 12 + 5 * items.size()
    }

func _total_need() -> int:
    var n: int = 0
    for it in order.get("items", []):
        n += int(it["n"])
    return n

func _total_got() -> int:
    var n: int = 0
    for it in order.get("items", []):
        n += int(it["got"])
    return n

func _complete() -> bool:
    return not order.is_empty() and _total_got() >= _total_need()

# ----------------------------------------------------------------- tick

func tick(delta: float) -> void:
    if not unlocked:
        return
    t += delta
    # ships come on a timer, also while you are on the farm
    if state == 0:
        wait_left -= delta
        if wait_left <= 0.0:
            _make_order()
            if on and built:
                _ship_arrive()
            else:
                state = 2
                restore_docked = true
                g._save_game()
    flag_clock += delta
    if flag_clock >= 1.0:
        flag_clock = 0.0
        v.refresh_island_flag()
    if toast != null and toast.visible:
        toast_t -= delta
        if toast_t <= 0.0:
            toast.visible = false
    if not on:
        return
    _tick_world(delta)
    _tick_ui()
    # keep the harbour camera in range
    var z: float = clampf(g.cam_zoom, ZOOM_MIN, ZOOM_MAX)
    if absf(z - g.cam_zoom) > 0.001:
        g.cam_zoom = z
        g._update_camera()

func _tick_world(delta: float) -> void:
    if ship != null and is_instance_valid(ship):
        ship.position.y = BERTH.y + sin(t * 1.4) * 0.05
        ship.rotation.z = sin(t * 1.1) * 0.015
    if ship != null and is_instance_valid(ship) and state == 4:
        var mk: Node3D = ship.get_node_or_null("Marker") as Node3D
        if mk != null:
            mk.scale = Vector3.ONE * (1.0 + 0.12 * sin(t * 4.0))
        var ml: Node3D = ship.get_node_or_null("MarkerLabel") as Node3D
        if ml != null:
            ml.position.y = 4.2 + sin(t * 3.0) * 0.25
    if cam_tw != null and cam_tw.is_valid():
        g._update_camera()
    if tug != null:
        tug.position.y = -0.4 + sin(t * 1.7 + 1.0) * 0.05
    if keeper != null:
        keeper.position.y = 0.6 + absf(sin(t * 2.2)) * 0.05
    if beam_pivot != null:
        beam_pivot.rotation.y += delta * 0.7
        var night: float = 0.0
        if g.lamp_mat != null:
            night = clampf(g.lamp_mat.emission_energy_multiplier / 2.2, 0.0, 1.0)
        beam_sm.set_shader_parameter("a", 0.55 * night)
        beam_pivot.visible = night > 0.05

# ----------------------------------------------------------------- enter / leave

func _fade_to(mid: Callable) -> void:
    if busy_fade:
        return
    busy_fade = true
    if fade_tw != null and fade_tw.is_valid():
        fade_tw.kill()
    fade_rect.visible = true
    fade_tw = create_tween()
    fade_tw.tween_property(fade_rect, "color:a", 1.0, 0.35)
    fade_tw.tween_callback(mid)
    fade_tw.tween_property(fade_rect, "color:a", 0.0, 0.45)
    fade_tw.tween_callback(func():
        fade_rect.visible = false
        busy_fade = false)

func enter(instant: bool = false) -> void:
    if on or not unlocked:
        return
    _ensure_built()
    var go: Callable = func():
        if on:
            return
        saved_target = g.cam_target
        saved_zoom = g.cam_zoom
        on = true
        g._close_panels()
        _farm_hud(false)
        if v.map_mode:
            v.map_mode = false
        g.cam_zoom = 21.0
        g.cam_target = H + Vector3(5.0, 0.8, 2.0)
        g._update_camera()
        ui.visible = true
        _restore_or_wait()
        _tick_ui()
    if instant:
        go.call()
    else:
        _fade_to(go)

func leave(instant: bool = false) -> void:
    if not on:
        return
    var back: Callable = func():
        if not on:
            return
        on = false
        ui.visible = false
        _farm_hud(true)
        g.cam_target = saved_target
        g.cam_zoom = saved_zoom
        g._update_camera()
        g._refresh_ui()
        g._save_game()
    if instant:
        back.call()
    else:
        _fade_to(back)

func _farm_hud(vis: bool) -> void:
    g.ui_root.visible = vis
    if g.crop_bar != null and not vis:
        g.crop_bar.visible = false
    if g.clock_label != null:
        var n: Node = g.clock_label
        for i in range(3):
            n = n.get_parent()
        if n is CanvasLayer:
            (n as CanvasLayer).visible = vis

func _restore_or_wait() -> void:
    if state == 2 and ship == null:
        _spawn_ship(BERTH)
        restore_docked = false
        _refresh_cargo_visual()
    elif state == 0 and wait_left > 12.0:
        wait_left = rng.randf_range(4.0, 8.0)   # no long wait when you walk in
    elif state == 4 and ship == null:
        _spawn_ship(ANCHOR)
        _add_marker()
    elif state == 1 and ship == null:
        state = 2
        _spawn_ship(BERTH)

# ----------------------------------------------------------------- ship

func _make_ship(hull: Color) -> Node3D:
    var s := Node3D.new()
    var L: float = 6.0
    var white := Color(0.97, 0.97, 0.94)
    B(s, Vector3(L, 0.9, 2.0), Vector3(0, 0.2, 0), hull, "Hull")
    B(s, Vector3(L + 0.2, 0.18, 2.1), Vector3(0, 0.7, 0), Color(0.95, 0.95, 0.92), "Rail")
    var bow: MeshInstance3D = B(s, Vector3(1.4, 0.9, 1.4), Vector3(-L / 2.0 - 0.2, 0.2, 0), hull, "Bow")
    bow.rotation_degrees.y = 45.0
    B(s, Vector3(1.4, 1.1, 1.5), Vector3(L / 2.0 - 1.0, 1.35, 0), white, "Cabin")
    B(s, Vector3(1.1, 0.25, 1.55), Vector3(L / 2.0 - 1.0, 1.95, 0), Color(0.25, 0.45, 0.70), "Bridge")
    g._disc(s, 0.28, 0.9, Vector3(L / 2.0 - 1.6, 2.2, 0), Color(0.85, 0.22, 0.20), "Funnel", 0.8, 10)
    ship_slots.clear()
    var cols: Array = [Color(0.85, 0.30, 0.25), Color(0.25, 0.55, 0.80), Color(0.95, 0.75, 0.25), Color(0.30, 0.65, 0.40), Color(0.85, 0.45, 0.20), Color(0.55, 0.40, 0.75)]
    var k: int = 0
    for i in range(3):
        for j in range(2):
            var c: MeshInstance3D = B(s, Vector3(0.9, 0.55, 0.8), Vector3(-1.9 + i * 1.0, 1.07, -0.45 + j * 0.9), cols[k % cols.size()], "Slot")
            c.visible = false
            ship_slots.append(c)
            k += 1
    return s

func _spawn_ship(pos: Vector3) -> void:
    if ship != null and is_instance_valid(ship):
        ship.queue_free()
    ship = _make_ship(HULLS[int(order.get("hull", 0)) % HULLS.size()])
    ship.position = pos
    root3.add_child(ship)

func _ship_arrive() -> void:
    # the ship comes in from the horizon and waits far out at sea until you bring it in
    state = 4
    _spawn_ship(SHIP_START)
    ship.rotation_degrees.y = 0.0
    _add_marker()
    g._play_named("horn", -16.0)
    say("%s is waiting far out at sea. Tap the ship or BRING SHIP IN!" % str(order["name"]))
    if ship_tw != null and ship_tw.is_valid():
        ship_tw.kill()
    ship_tw = create_tween()
    ship_tw.tween_property(ship, "position", ANCHOR, 5.0).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)
    ship_tw.tween_callback(func(): _show_ship(true))

func _add_marker() -> void:
    if ship == null:
        return
    var ring: MeshInstance3D = g._disc(ship, 2.6, 0.05, Vector3(0, 0.0, 0), Color(1.0, 0.9, 0.3), "Ring", 0.6, 24, 2.3)
    ring.name = "Marker"
    var arrow: Label3D = g._label3d(ship, "TAP TO BRING IN", Vector3(0, 4.2, 0), 0.016, Color(1.0, 0.95, 0.5))
    arrow.name = "MarkerLabel"
    arrow.no_depth_test = true

func _clear_marker() -> void:
    if ship == null:
        return
    for n in ["Marker", "MarkerLabel"]:
        var m: Node = ship.get_node_or_null(n)
        if m != null:
            m.queue_free()

var cam_tw: Tween

func _cam_to(target: Vector3, dur: float = 1.0) -> void:
    if cam_tw != null and cam_tw.is_valid():
        cam_tw.kill()
    cam_tw = create_tween()
    cam_tw.tween_property(g, "cam_target", _clamp_cam(target), dur).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)

func _show_ship(and_back: bool = false) -> void:
    if ship == null or not on:
        return
    var back_to: Vector3 = g.cam_target
    _cam_to(H + Vector3(ANCHOR.x, 0.8, ANCHOR.z) + Vector3(-6.0, 0.0, -3.0), 1.2)
    if and_back:
        cam_tw.tween_interval(1.6)
        cam_tw.tween_property(g, "cam_target", back_to, 1.2).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)

func _dock_ship() -> void:
    if state != 4 or ship == null:
        return
    state = 1
    _clear_marker()
    if cam_tw != null and cam_tw.is_valid():
        cam_tw.kill()
    if ship_tw != null and ship_tw.is_valid():
        ship_tw.kill()
    # the camera stays still; only the ship moves
    ship_tw = create_tween()
    ship_tw.tween_property(ship, "position", BERTH, 9.0).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
    ship_tw.tween_callback(func():
        state = 2
        say("%s is at the dock. Load the cargo!" % str(order["name"]))
        g._save_game())

func _refresh_cargo_visual() -> void:
    if ship == null or ship_slots.is_empty():
        return
    var need: int = maxi(1, _total_need())
    var shown: int = int(ceil(float(_total_got()) / float(need) * float(ship_slots.size())))
    for i in range(ship_slots.size()):
        (ship_slots[i] as Node3D).visible = i < shown

func _send_off() -> void:
    if state != 2 or not _complete():
        return
    var coins: int = int(order["coins"])
    var xp: int = int(order["xp"])
    g.coins += coins
    g._add_xp(xp)
    g._play_named("jingle", -6.0)
    g._play_named("horn", -12.0)
    say("%s sails off!  +%d coins  +%d XP.  The keeper says thank you!" % [str(order["name"]), coins, xp])
    state = 3
    var old: Node3D = ship
    order = {}
    wait_left = rng.randf_range(WAIT_MIN, WAIT_MAX)
    if ship_tw != null and ship_tw.is_valid():
        ship_tw.kill()
    ship_tw = create_tween()
    ship_tw.tween_property(old, "rotation_degrees:y", 180.0, 1.6).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
    ship_tw.parallel().tween_property(old, "position:z", BERTH.z + 1.6, 1.6)
    ship_tw.tween_property(old, "position", Vector3(SHIP_START.x, SHIP_START.y, BERTH.z + 1.6), 9.0).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN)
    ship_tw.tween_callback(func():
        if is_instance_valid(old):
            old.queue_free()
        if ship == old:
            ship = null
        state = 0)
    g._refresh_ui()
    g._save_game()

func _load_cargo() -> void:
    if state != 2 or order.is_empty():
        say("No ship at the dock yet.")
        return
    var moved: int = 0
    for it in order["items"]:
        var need: int = int(it["n"]) - int(it["got"])
        if need <= 0:
            continue
        var have: int = g._item_have(str(it["k"]), int(it["id"]))
        var take: int = mini(need, have)
        if take > 0:
            g._item_take(str(it["k"]), int(it["id"]), take)
            it["got"] = int(it["got"]) + take
            moved += take
    if moved == 0:
        say("You do not have these items yet. Grow, cook or collect them on the farm.")
        return
    g._play_named("jingle", -14.0)
    _crane_swing()
    _refresh_cargo_visual()
    if _complete():
        say("Cargo is full! Tap SEND SHIP OFF.")
    else:
        say("Loaded %d items. The ship still needs more." % moved)
    g._refresh_ui()
    g._save_game()

func _crane_swing() -> void:
    if crane_crate == null:
        return
    crane_crate.visible = true
    crane_crate.position = Vector3(7.2, 1.2, 2.2)
    var tw := create_tween()
    tw.tween_property(crane_crate, "position:y", 3.4, 0.4)
    tw.tween_property(crane_crate, "position", Vector3(8.6, 3.4, 5.2), 0.6)
    tw.tween_property(crane_crate, "position:y", 1.1, 0.4)
    tw.tween_callback(func(): crane_crate.visible = false)

# ----------------------------------------------------------------- pan inside the harbour

func pan(prev_pos: Vector2, cur_pos: Vector2) -> void:
    var cur: Vector3 = g._ground_hit(cur_pos)
    var prev: Vector3 = g._ground_hit(prev_pos)
    if cur == Vector3.INF or prev == Vector3.INF:
        return
    var shift: Vector3 = prev - cur
    g.cam_target = _clamp_cam(g.cam_target + shift)
    g._update_camera()

func _clamp_cam(p: Vector3) -> Vector3:
    return Vector3(clampf(p.x, H.x - 24.0, H.x + 62.0), p.y, clampf(p.z, H.z - 26.0, H.z + 42.0))

# ----------------------------------------------------------------- taps in the harbour

func tap(screen_pos: Vector2) -> void:
    var hit: Vector3 = g._ground_hit(screen_pos)
    if hit == Vector3.INF:
        return
    var p := Vector2(hit.x - H.x, hit.z - H.z)
    if p.distance_to(Vector2(-3.6, 3.4)) < 2.2 or p.distance_to(Vector2(-5.3, 1.8)) < 2.2:
        _keeper_talk()
    elif p.distance_to(Vector2(-3.2, -3.8)) < 1.8:
        say("The lighthouse lights the sea at night so ships can find the harbour safely.")
    elif state == 4 and ship != null and Vector2(ship.position.x, ship.position.z).distance_to(p) < 6.0:
        _dock_ship()
    elif p.x > 5.0 and p.y > 4.0 and p.y < 8.0 and p.x < 15.0:
        if state == 2:
            say("%s is waiting. Use LOAD CARGO." % str(order.get("name", "The ship")))
        else:
            say("No ship here yet.")
    elif p.distance_to(Vector2(2.0, -2.0)) < 2.5:
        say("Harbour office. Ships book a berth here.")

func _keeper_talk() -> void:
    if order.is_empty():
        say("Keeper: No ship right now. Next one soon!")
        return
    var parts: Array = []
    for it in order["items"]:
        parts.append("%d %s" % [int(it["n"]) - int(it["got"]), g._item_label(str(it["k"]), int(it["id"]))])
    say("Keeper: The ship needs " + ", ".join(parts) + ".")

# ----------------------------------------------------------------- UI

func _style(bg: Color) -> StyleBoxFlat:
    return g._panel_style(bg, 20)

func build_ui() -> void:
    ui = CanvasLayer.new()
    ui.layer = 60
    ui.visible = false
    add_child(ui)
    var back := Button.new()
    back.text = "< BACK TO FARM"
    back.anchor_left = 0.0
    back.anchor_top = 0.0
    back.offset_left = 14.0
    back.offset_top = 14.0
    back.offset_right = 270.0
    back.offset_bottom = 78.0
    back.add_theme_font_size_override("font_size", 22)
    back.pressed.connect(func(): leave())
    ui.add_child(back)
    var top := PanelContainer.new()
    top.anchor_left = 0.30
    top.anchor_right = 0.70
    top.offset_top = 14.0
    top.add_theme_stylebox_override("panel", _style(Color(0.12, 0.25, 0.20, 0.92)))
    ui.add_child(top)
    top_label = Label.new()
    top_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    top_label.add_theme_font_size_override("font_size", 24)
    top_label.add_theme_color_override("font_color", Color(1.0, 0.91, 0.45))
    top.add_child(top_label)
    panel = PanelContainer.new()
    panel.anchor_left = 0.72
    panel.anchor_right = 0.985
    panel.anchor_top = 0.13
    panel.anchor_bottom = 0.62
    panel.add_theme_stylebox_override("panel", _style(Color(0.12, 0.25, 0.20, 0.94)))
    ui.add_child(panel)
    var col := VBoxContainer.new()
    col.add_theme_constant_override("separation", 6)
    panel.add_child(col)
    p_title = g._panel_label(col, 22, Color(1.0, 0.91, 0.45))
    p_sub = g._panel_label(col, 18, Color(0.85, 0.97, 1.0))
    p_rows = VBoxContainer.new()
    p_rows.add_theme_constant_override("separation", 4)
    col.add_child(p_rows)
    p_reward = g._panel_label(col, 19, Color(1.0, 0.95, 0.6))
    load_btn = g._panel_button(col, "LOAD CARGO", 56, 21)
    load_btn.pressed.connect(func():
        if state == 4:
            _dock_ship()
        else:
            _load_cargo())
    show_btn = g._panel_button(col, "SHOW SHIP", 48, 19)
    show_btn.pressed.connect(func(): _show_ship(false))
    send_btn = g._panel_button(col, "SEND SHIP OFF", 56, 21)
    send_btn.pressed.connect(_send_off)
    toast = Label.new()
    toast.anchor_left = 0.10
    toast.anchor_right = 0.68
    toast.anchor_top = 1.0
    toast.anchor_bottom = 1.0
    toast.offset_top = -120.0
    toast.offset_bottom = -20.0
    toast.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    toast.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    toast.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    toast.add_theme_font_size_override("font_size", 22)
    toast.add_theme_color_override("font_color", Color.WHITE)
    toast.add_theme_color_override("font_shadow_color", Color(0.1, 0.1, 0.1))
    toast.add_theme_constant_override("shadow_offset_x", 2)
    toast.add_theme_constant_override("shadow_offset_y", 2)
    toast.mouse_filter = Control.MOUSE_FILTER_IGNORE
    toast.visible = false
    ui.add_child(toast)
    fade_layer = CanvasLayer.new()
    fade_layer.layer = 100
    add_child(fade_layer)
    fade_rect = ColorRect.new()
    fade_rect.color = Color(0.02, 0.05, 0.10, 0.0)
    fade_rect.set_anchors_preset(Control.PRESET_FULL_RECT)
    fade_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
    fade_rect.visible = false
    fade_layer.add_child(fade_rect)

var _ui_key: String = ""

func _tick_ui() -> void:
    if ui == null or not ui.visible:
        return
    top_label.text = "LIGHTHOUSE HARBOUR    Lv %d    %d coins" % [int(g.level), int(g.coins)]
    var key: String = ""
    if order.is_empty():
        key = "wait%d" % int(wait_left)
    else:
        key = "%d|%d|%d|%s" % [state, _total_got(), int(g.coins), str(order["name"])]
        for it in order["items"]:
            key += "|%d" % g._item_have(str(it["k"]), int(it["id"]))
    if key == _ui_key:
        return
    _ui_key = key
    for c in p_rows.get_children():
        c.queue_free()
    if order.is_empty() or state == 3:
        p_title.text = "NO SHIP AT THE DOCK"
        p_sub.text = "Next ship in %s" % g._fmt_time(wait_left) if state == 0 else "A ship is leaving..."
        p_reward.text = ""
        show_btn.visible = false
        load_btn.disabled = true
        send_btn.disabled = true
        return
    p_title.text = "BERTH 1: %s" % str(order["name"])
    p_sub.text = "Cargo wanted" if state == 2 else ("Waiting at sea. Tap the ship!" if state == 4 else "Sailing in...")
    load_btn.text = "BRING SHIP IN" if state == 4 else "LOAD CARGO"
    for it in order["items"]:
        var l := Label.new()
        var have: int = g._item_have(str(it["k"]), int(it["id"]))
        l.text = "%s   %d / %d   (you have %d)" % [g._item_label(str(it["k"]), int(it["id"])), int(it["got"]), int(it["n"]), have]
        l.add_theme_font_size_override("font_size", 18)
        var done: bool = int(it["got"]) >= int(it["n"])
        l.add_theme_color_override("font_color", Color(0.55, 1.0, 0.60) if done else Color(1, 1, 1))
        l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
        p_rows.add_child(l)
    p_reward.text = "Pays %d coins + %d XP" % [int(order["coins"]), int(order["xp"])]
    show_btn.visible = state == 4
    load_btn.disabled = (state != 2 and state != 4) or (state == 2 and _complete())
    send_btn.disabled = state != 2 or not _complete()

func _house(pos: Vector3, wall: Color, roof: Color, yaw: float) -> void:
    var h := Node3D.new()
    h.position = pos
    h.rotation_degrees.y = yaw
    root3.add_child(h)
    B(h, Vector3(2.0, 1.0, 1.6), Vector3(0, 0.5, 0), wall, "Wall")
    var a: MeshInstance3D = B(h, Vector3(1.4, 0.08, 1.9), Vector3(-0.5, 1.25, 0), roof, "RoofA")
    a.rotation_degrees.z = 32.0
    var b: MeshInstance3D = B(h, Vector3(1.4, 0.08, 1.9), Vector3(0.5, 1.25, 0), roof.darkened(0.1), "RoofB")
    b.rotation_degrees.z = -32.0
    B(h, Vector3(0.4, 0.65, 0.06), Vector3(0.45, 0.33, 0.82), Color(0.45, 0.28, 0.14), "Door")
    B(h, Vector3(0.5, 0.4, 0.05), Vector3(-0.5, 0.55, 0.81), Color(0.33, 0.76, 0.92), "Win")
    B(h, Vector3(0.28, 0.6, 0.28), Vector3(0.7, 1.55, -0.3), Color(0.55, 0.25, 0.18), "Chim")

# ----------------------------------------------------------------- build the harbour world

func _ensure_built() -> void:
    if built:
        return
    built = true
    build_ui()
    root3 = Node3D.new()
    root3.name = "HarborWorld"
    root3.position = H
    g.add_child(root3)
    var r := root3
    B(r, Vector3(400, 0.1, 400), Vector3(0, -0.66, 0), Color(0.09, 0.36, 0.74), "HbWater")
    g._disc(r, 62.0, 0.04, Vector3(14, -0.59, 10), Color(0.28, 0.66, 0.88), "HbShallow", 0.9, 64)
    g._disc(r, 20.2, 0.05, Vector3(LAND.x, -0.45, LAND.z), Color(0.62, 0.88, 0.96), "Foam", 0.9, 56)
    g._disc(r, 18.6, 1.2, Vector3(LAND.x, -0.2, LAND.z), Color(0.88, 0.76, 0.52), "Sand", 0.95, 56, 17.7)
    g._disc(r, 17.0, 0.3, Vector3(LAND.x, 0.45, LAND.z), Color(0.38, 0.72, 0.30), "Grass", 0.95, 56, 16.2)
    # headland disc so the north-west shore is not a perfect circle
    g._disc(r, 8.0, 1.2, Vector3(-22, -0.2, -16), Color(0.88, 0.76, 0.52), "Sand2", 0.95, 32, 7.2)
    g._disc(r, 6.8, 0.3, Vector3(-22, 0.45, -16), Color(0.38, 0.72, 0.30), "Grass2", 0.95, 32, 6.2)
    # path from the office to the dock
    B(r, Vector3(5.5, 0.04, 1.2), Vector3(4.2, 0.62, 0.2), Color(0.86, 0.76, 0.54), "Path")
    # lighthouse
    var lh_before: int = g.lh_root.get_child_count()
    g._make_lighthouse(H + Vector3(-3.2, 0.55, -3.8))
    var lh: Node3D = g.lh_root.get_child(g.lh_root.get_child_count() - 1) as Node3D
    if g.lh_root.get_child_count() > lh_before and lh != null:
        lh.scale = Vector3.ONE * 1.5
    beam_pivot = Node3D.new()
    beam_pivot.position = Vector3(-3.2, 6.15, -3.8)
    r.add_child(beam_pivot)
    var sh := Shader.new()
    sh.code = """shader_type spatial;
render_mode unshaded, blend_add, cull_disabled, depth_draw_never;
uniform float a = 0.0;
uniform float h = 12.0;
varying float tt;
void vertex() { tt = clamp((VERTEX.y + 0.5 * h) / h, 0.0, 1.0); }
void fragment() { ALBEDO = vec3(1.0, 0.92, 0.55); ALPHA = a * tt * tt; }"""
    beam_mat = null
    beam_sm = ShaderMaterial.new()
    beam_sm.shader = sh
    beam_sm.set_shader_parameter("a", 0.0)
    for sign_x in [1.0, -1.0]:
        var beam := MeshInstance3D.new()
        var cm := CylinderMesh.new()
        cm.top_radius = 0.10
        cm.bottom_radius = 1.5
        cm.height = 12.0
        beam.mesh = cm
        beam.material_override = beam_sm
        beam.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
        # narrow end sits exactly on the lamp; the ray points slightly down toward the sea
        beam.rotation_degrees = Vector3(0, 0, 90.0 * sign_x - 6.0 * sign_x)
        beam.position = Vector3(6.0 * sign_x * cos(deg_to_rad(6.0)), -6.0 * sin(deg_to_rad(6.0)), 0)
        beam_pivot.add_child(beam)
    # keeper's house
    var h := Node3D.new()
    h.position = Vector3(-5.3, 0.6, 1.8)
    h.rotation_degrees.y = 34.0
    r.add_child(h)
    B(h, Vector3(2.2, 1.1, 1.7), Vector3(0, 0.55, 0), Color(0.98, 0.92, 0.80))
    var r1: MeshInstance3D = B(h, Vector3(1.5, 0.08, 2.0), Vector3(-0.55, 1.36, 0), Color(0.72, 0.28, 0.22))
    r1.rotation_degrees.z = 32.0
    var r2: MeshInstance3D = B(h, Vector3(1.5, 0.08, 2.0), Vector3(0.55, 1.36, 0), Color(0.62, 0.24, 0.20))
    r2.rotation_degrees.z = -32.0
    B(h, Vector3(0.4, 0.7, 0.06), Vector3(0.5, 0.35, 0.87), Color(0.45, 0.28, 0.14))
    B(h, Vector3(0.5, 0.4, 0.05), Vector3(-0.5, 0.6, 0.86), Color(0.33, 0.76, 0.92))
    g._label3d(h, "KEEPER'S HOUSE", Vector3(0, 2.4, 0), 0.010, Color(1, 0.95, 0.75))
    # keeper
    keeper = Node3D.new()
    keeper.position = Vector3(-3.6, 0.6, 3.4)
    r.add_child(keeper)
    g._disc(keeper, 0.2, 0.5, Vector3(0, 0.25, 0), Color(0.20, 0.35, 0.60), "Body", 0.9, 10)
    g._sphere(keeper, 0.16, 0.2, Vector3(0, 0.62, 0), Color(0.95, 0.78, 0.62), "Head")
    g._disc(keeper, 0.22, 0.1, Vector3(0, 0.78, 0), Color(0.95, 0.80, 0.20), "Hat", 0.9, 10)
    keeper_label = g._label3d(keeper, "KEEPER (tap me)", Vector3(0, 1.3, 0), 0.008, Color(1, 1, 1))
    # harbour office
    var o := Node3D.new()
    o.position = Vector3(2.0, 0.6, -2.0)
    o.rotation_degrees.y = 34.0
    r.add_child(o)
    B(o, Vector3(2.8, 1.3, 1.8), Vector3(0, 0.65, 0), Color(0.86, 0.90, 0.95))
    B(o, Vector3(3.0, 0.14, 2.0), Vector3(0, 1.37, 0), Color(0.25, 0.45, 0.70))
    B(o, Vector3(0.5, 0.8, 0.06), Vector3(0.8, 0.4, 0.92), Color(0.45, 0.28, 0.14))
    B(o, Vector3(0.9, 0.45, 0.05), Vector3(-0.6, 0.65, 0.92), Color(0.33, 0.76, 0.92))
    B(o, Vector3(2.5, 0.55, 0.1), Vector3(0, 1.8, 0.8), Color(0.99, 0.85, 0.45))
    var ol: Label3D = g._label3d(o, "HARBOUR OFFICE", Vector3(0, 1.8, 0.88), 0.0075, Color(0.2, 0.2, 0.4))
    ol.billboard = BaseMaterial3D.BILLBOARD_DISABLED
    ol.outline_size = 4
    # dock
    B(r, Vector3(10.0, 0.2, 2.6), Vector3(10.0, 0.5, 3.0), Color(0.62, 0.42, 0.22), "Dock")
    for i in range(10):
        B(r, Vector3(0.04, 0.22, 2.62), Vector3(5.5 + i, 0.51, 3.0), Color(0.45, 0.30, 0.16), "Plank")
    for x in [5.2, 8.0, 11.0, 14.0]:
        for z in [1.75, 4.25]:
            B(r, Vector3(0.22, 1.3, 0.22), Vector3(x, 0.0, z), Color(0.35, 0.22, 0.12), "Pile")
    for x in [6.5, 10.5, 13.5]:
        g._disc(r, 0.16, 0.35, Vector3(x, 0.78, 4.1), Color(0.2, 0.2, 0.22), "Bollard", 0.8, 8)
    # crane
    var cr := Node3D.new()
    cr.position = Vector3(9.4, 0.6, 2.2)
    r.add_child(cr)
    for x in [-0.5, 0.5]:
        for z in [-0.4, 0.4]:
            B(cr, Vector3(0.12, 3.2, 0.12), Vector3(x, 1.6, z), Color(0.95, 0.65, 0.15))
    B(cr, Vector3(1.3, 0.14, 1.1), Vector3(0, 3.25, 0), Color(0.95, 0.65, 0.15))
    B(cr, Vector3(0.18, 0.18, 5.0), Vector3(0, 3.5, 1.6), Color(0.95, 0.65, 0.15))
    B(cr, Vector3(0.9, 0.55, 0.9), Vector3(0, 3.65, -0.1), Color(0.25, 0.45, 0.70))
    crane_crate = B(r, Vector3(0.6, 0.5, 0.6), Vector3(7.2, 1.2, 2.2), Color(0.85, 0.30, 0.25), "CraneCrate")
    crane_crate.visible = false
    # crates on the dock
    for e in [[7.0, 0.88, 2.2, Color(0.70, 0.50, 0.28)], [7.0, 1.43, 2.2, Color(0.78, 0.58, 0.32)], [7.6, 0.88, 2.0, Color(0.62, 0.45, 0.25)], [12.2, 0.88, 2.2, Color(0.30, 0.55, 0.80)], [12.8, 0.88, 2.4, Color(0.85, 0.35, 0.28)]]:
        B(r, Vector3(0.55, 0.55, 0.55), Vector3(e[0], e[1], e[2]), e[3], "Crate")
    g._disc(r, 0.28, 0.6, Vector3(11.4, 0.9, 2.1), Color(0.55, 0.25, 0.15), "Barrel", 0.9, 10)
    g._label3d(r, "BERTH 1", Vector3(10.5, 3.6, 4.0), 0.012, Color(1, 0.95, 0.7))
    # tug that patrols the bay
    tug = Node3D.new()
    tug.position = Vector3(16.0, -0.4, 11.0)
    r.add_child(tug)
    B(tug, Vector3(1.8, 0.5, 0.9), Vector3(0, 0.1, 0), Color(0.88, 0.25, 0.20))
    B(tug, Vector3(0.7, 0.5, 0.7), Vector3(-0.2, 0.55, 0), Color(0.97, 0.97, 0.95))
    var ttw := create_tween().set_loops()
    ttw.tween_property(tug, "position:x", 26.0, 9.0).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
    ttw.tween_property(tug, "position:x", 16.0, 9.0).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
    # buoys
    for p in [Vector3(17, -0.5, 1), Vector3(22, -0.5, 4), Vector3(27, -0.5, 8)]:
        g._sphere(r, 0.22, 0.35, p, Color(0.85, 0.2, 0.2), "Buoy")
    # ---- the wider land: paths, village, market, field, pier, hill, rocks
    var sand := Color(0.80, 0.64, 0.40)
    B(r, Vector3(18.0, 0.04, 1.1), Vector3(-6.0, 0.62, 0.4), sand, "RoadX")
    B(r, Vector3(1.1, 0.04, 16.0), Vector3(-12.0, 0.62, -5.0), sand, "RoadZ")
    B(r, Vector3(1.1, 0.04, 12.0), Vector3(-9.0, 0.62, -17.0), sand, "RoadN")
    B(r, Vector3(1.1, 0.04, 6.0), Vector3(-5.3, 0.62, -1.0), sand, "RoadK")
    _house(Vector3(-14.5, 0.6, 3.5), Color(0.98, 0.88, 0.72), Color(0.70, 0.30, 0.22), 34.0)
    _house(Vector3(-15.5, 0.6, -2.5), Color(0.82, 0.92, 0.98), Color(0.25, 0.45, 0.70), 34.0)
    _house(Vector3(-9.5, 0.6, 6.5), Color(0.98, 0.80, 0.82), Color(0.55, 0.30, 0.22), 34.0)
    # fish market stall
    var m := Node3D.new()
    m.position = Vector3(-1.5, 0.6, 5.5)
    m.rotation_degrees.y = 34.0
    r.add_child(m)
    B(m, Vector3(2.0, 0.6, 0.9), Vector3(0, 0.3, 0), Color(0.62, 0.42, 0.22), "Counter")
    for i in range(5):
        var ac: Color = Color(0.25, 0.55, 0.85) if i % 2 == 0 else Color(0.98, 0.95, 0.90)
        var aw: MeshInstance3D = B(m, Vector3(0.44, 0.05, 1.2), Vector3(-0.88 + i * 0.44, 1.35, 0.1), ac, "Awn")
        aw.rotation_degrees.x = 14.0
    for x in [-0.95, 0.95]:
        B(m, Vector3(0.07, 1.3, 0.07), Vector3(x, 0.65, 0.5), Color(0.45, 0.30, 0.16), "Pole")
    B(m, Vector3(0.5, 0.12, 0.3), Vector3(-0.3, 0.66, 0), Color(0.70, 0.82, 0.92), "Fish")
    B(m, Vector3(0.5, 0.12, 0.3), Vector3(0.4, 0.66, 0), Color(0.92, 0.72, 0.55), "Fish")
    g._label3d(m, "FISH MARKET", Vector3(0, 2.0, 0), 0.010, Color(1, 0.95, 0.75))
    # vegetable field (decoration)
    for i in range(5):
        B(r, Vector3(4.2, 0.1, 0.55), Vector3(-17.0, 0.62, 6.5 + i * 0.9), Color(0.42, 0.28, 0.16), "Row")
        B(r, Vector3(4.0, 0.2, 0.22), Vector3(-17.0, 0.72, 6.5 + i * 0.9), Color(0.30, 0.68, 0.25) if i % 2 == 0 else Color(0.85, 0.55, 0.20), "Crop")
    g._label3d(r, "HARBOUR GARDEN", Vector3(-17.0, 1.7, 8.5), 0.009, Color(1, 0.95, 0.75))
    # fishing pier in the north
    B(r, Vector3(2.2, 0.2, 9.0), Vector3(-9.0, 0.5, -26.0), Color(0.62, 0.42, 0.22), "Pier")
    for z in [-30.0, -27.0, -24.0]:
        for x in [-10.0, -8.0]:
            B(r, Vector3(0.2, 1.3, 0.2), Vector3(x, 0.0, z), Color(0.35, 0.22, 0.12), "Pile")
    var rb := Node3D.new()
    rb.position = Vector3(-6.4, -0.45, -28.0)
    r.add_child(rb)
    B(rb, Vector3(0.9, 0.35, 2.0), Vector3(0, 0.15, 0), Color(0.85, 0.45, 0.20), "Rowboat")
    var fm := Node3D.new()
    fm.position = Vector3(-9.0, 0.6, -29.0)
    r.add_child(fm)
    g._disc(fm, 0.2, 0.5, Vector3(0, 0.25, 0), Color(0.80, 0.35, 0.25), "Body", 0.9, 10)
    g._sphere(fm, 0.16, 0.2, Vector3(0, 0.62, 0), Color(0.95, 0.78, 0.62), "Head")
    g._disc(fm, 0.3, 0.06, Vector3(0, 0.8, 0), Color(0.95, 0.85, 0.40), "StrawHat", 0.9, 12)
    g._label3d(r, "FISHING PIER", Vector3(-9.0, 2.0, -24.5), 0.010, Color(1, 0.95, 0.75))
    # hill behind the lighthouse
    g._disc(r, 5.2, 0.7, Vector3(-16.0, 0.95, -13.0), Color(0.34, 0.66, 0.28), "Hill1", 0.95, 24, 4.0)
    g._disc(r, 3.6, 0.7, Vector3(-16.0, 1.6, -13.0), Color(0.40, 0.72, 0.30), "Hill2", 0.95, 24, 2.6)
    g._disc(r, 2.0, 0.6, Vector3(-16.0, 2.2, -13.0), Color(0.46, 0.76, 0.34), "Hill3", 0.95, 20, 1.2)
    # rocks on the shore
    for e in [Vector3(12.5, 0.5, -3.5), Vector3(-26.0, 0.5, -5.0), Vector3(-20.0, 0.5, 8.0), Vector3(2.0, 0.5, -22.0), Vector3(-30.0, 0.6, -20.0)]:
        g._make_rock(H + e, 0.55)
    g._label3d(r, "VISIT THE DOCK ->", Vector3(3.2, 1.6, 1.2), 0.009, Color(1, 0.95, 0.75))
    # trees
    var trng := RandomNumberGenerator.new()
    trng.seed = 11
    var keep: Array = [Vector3(-3.2, 0, -3.8), Vector3(-5.3, 0, 1.8), Vector3(2.0, 0, -2.0), Vector3(-14.5, 0, 3.5), Vector3(-15.5, 0, -2.5), Vector3(-9.5, 0, 6.5), Vector3(-1.5, 0, 5.5), Vector3(-17.0, 0, 8.5), Vector3(-3.6, 0, 3.4)]
    var planted: int = 0
    var tries: int = 0
    while planted < 34 and tries < 400:
        tries += 1
        var a: float = trng.randf() * TAU
        var rr: float = sqrt(trng.randf()) * 15.0
        var tp := Vector3(LAND.x + cos(a) * rr, 0.6, LAND.z + sin(a) * rr)
        var ok: bool = true
        for kp in keep:
            if Vector2(tp.x - kp.x, tp.z - kp.z).length() < 3.2:
                ok = false
        if tp.x > 2.0 and tp.z > -1.0 and tp.z < 6.5:
            ok = false     # dock approach
        if absf(tp.z - 0.4) < 1.2 and tp.x < 3.0:
            ok = false     # road
        if absf(tp.x + 12.0) < 1.2:
            ok = false
        if not ok:
            continue
        var kind: int = [0, 1, 3, 4, 0, 2][planted % 6]
        g._make_scenery_tree(H + tp, kind, trng.randf_range(0.8, 1.2), trng)
        planted += 1
