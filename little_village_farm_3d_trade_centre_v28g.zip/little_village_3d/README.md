# Little Village Farm 3D — Scene-First Prototype v3

A separate Godot 4.3 project focused first on making the farm world visible and clearly three-dimensional on Android. It does not replace the older working 2D project.

## Scene-first changes in v3
- Fixed the camera setup order: the `Camera3D` is added to the scene tree before `look_at()` is called.
- Switched the target view to landscape so the full farm world has room on a phone screen.
- Added more visible 3D scene props: a cow, chickens, shrubs, a well, barrels, garden path, and perimeter grass tufts.
- Kept the 3D farmhouse, barn, trees, fences, flowers, rocks, farmer, 5×5 crop plots, lighting, shadows, and UI.
- Uses actual Godot 3D nodes and meshes (`Node3D`, `Camera3D`, `MeshInstance3D`, `BoxMesh`, `SphereMesh`, `DirectionalLight3D`, and `WorldEnvironment`).

## Test status
**Static checks only.** The archive integrity and project-source structure can be checked without Godot. This environment does not have a Godot executable, so the scene has not been rendered here and an APK has not been built here. The GitHub Actions workflow is included for a Godot CI build, but its success must be confirmed by running it. Do not treat this ZIP as runtime-verified.

## Build on GitHub
1. Create a separate experimental repository.
2. Extract this ZIP and upload the *contents* of `little_village_3d/` to the repository root, including `.github/`.
3. Run the `Build Little Village Farm 3D APK` workflow.
4. Install the resulting APK and check that the farm world is visible in landscape orientation before adding more features.

Keep the existing working 2D project and workflow untouched until the new project has been verified.


### Tree upgrade
This update improves the procedural fruit-tree mesh with a tapered trunk, branches, irregular multi-tone foliage clusters, root flare, and fruit details. It is still stylized low-poly art, not photorealistic. Verify rendering in Godot and on Android before treating it as complete.


## Landscape Fit v5
This update targets extra-wide landscape phones. `window/stretch/aspect="expand"` lets the logical viewport grow horizontally rather than letterboxing a fixed 16:9 view. The orthographic camera is slightly closer (`size = 16.8`) to increase the farm's on-screen size. Check that the farm edges, HUD, and all four bottom buttons remain visible on your device.

**Test status:** static checks only. This archive has not been run in Godot or built into an APK in this environment.

## Visual polish v6
This iteration focuses on world appearance before adding gameplay features. Trees have deterministic size variation and additional irregular outer foliage clusters; the lawn perimeter has more grass tufts and subtle ground-cover patches. The changes are procedural 3D meshes and materials, not imported high-detail art assets. Runtime appearance and mobile performance still need verification in Godot and on an Android device.


## Natural trees v14
Trees now use many small leaf blades merged into one mesh each (broadleaf, pine, fir, palm), plus a light wind sway. Check the look and frame rate on your phone; if it is heavy, lower the leaf counts in `_make_tree` and `_build_conifer`.


## v15
Pan and zoom the camera, explore the bigger island, level up with XP, and complete the harvest quest. If the frame rate is low on your phone, reduce the tree count (`placed.size() < 46`) in `_build_world_extras`.


## v16
Scenery around the island. If the frame rate drops on your phone, lower the cloud count (`while made < 12`) or mountain count (`placed.size() < 26`) in `_build_scenery`.

## v23
Barn + market + bakery economy, daily quests with login streak, seasons, rounder buildings, tap highlight and a performance pass. See CHANGELOG.md.

## v27
Hired power-tiller farm hand (taps + auto-farming), Upgrades hub, Sell/Upgrade alerts, crop care, animal feeding, settings with graphics quality and save code export/import. See CHANGELOG.md.

## v26
- Trade Centre shows 2 orders at a time (3 from Level 16); a new order arrives shortly after you send or skip one; rewards +20%.
- New crop: Rice (Level 8) with a flooded-paddy look; sells, ships in orders and saves like the other crops.
- Farm decor: scarecrow, hay bales with pitchfork, sunflower patch and a wheelbarrow.
- Includes everything from v25b.

## v25b
- Trade Centre: tap a transport to select it, then press SEND ORDER; bigger transport icons with names; energy cells no longer make orders "too heavy".
- Tapping a button again closes its pop-up (PLANT, SHOP and the HUD buttons); crop bar has a ✕.
- Natural-looking tomato, wheat, carrot and corn plants.
- New 3D farm app icon (night island).

## v25
- Crop picker bar when planting; Trade Centre (Lv 11) with order list, destinations and 5 transport modes (train, drone, helicopter, plane, boat); vehicles leave the Trade Centre, drop the parcel and return.
- Zig-zag railway with bridges over roads; train now only runs when dispatched from the Trade Centre.
- Locked-feature signs (Railway Lv 9, Trade Centre Lv 11) and greyed buttons from Level 1.
- X close icon on every panel, tidier two-row HUD, brighter night/rain, carrier closer with a camera shortcut.

## v24
Orders board, animal/orchard products, farm expansion, Tidal Power Station (Lv 8), Railway (Lv 9) and Aircraft Carrier (Lv 10). See CHANGELOG.md. Delete the old zip from the repo before uploading this one (exactly one .zip is allowed).
