package com.rajeev.familyshield

import android.app.Application
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.viewModelScope
import com.rajeev.familyshield.child.MonitorService
import com.rajeev.familyshield.child.RulesStore
import com.rajeev.familyshield.data.GoogleAuth
import com.rajeev.familyshield.data.Invite
import com.rajeev.familyshield.data.Prefs
import com.rajeev.familyshield.data.Repo
import com.rajeev.familyshield.parent.ParentAlertService
import com.rajeev.familyshield.ui.ErrorScreen
import com.rajeev.familyshield.ui.LoadingScreen
import com.rajeev.familyshield.ui.NewAccountScreen
import com.rajeev.familyshield.ui.SignInScreen
import com.rajeev.familyshield.ui.WaitingScreen
import com.rajeev.familyshield.ui.child.ChildRoot
import com.rajeev.familyshield.ui.parent.ParentRoot
import com.rajeev.familyshield.ui.theme.FamilyShieldTheme
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

sealed interface Gate {
    data object Loading : Gate
    data object SignedOut : Gate
    data object NewAccount : Gate
    data object Waiting : Gate
    data object Parent : Gate
    data class Child(val parentName: String) : Gate
    data class Error(val message: String) : Gate
}

class AppViewModel(app: Application) : AndroidViewModel(app) {
    val prefs = Prefs(app)
    private val _gate = MutableStateFlow<Gate>(Gate.Loading)
    val gate: StateFlow<Gate> = _gate

    init {
        refresh()
    }

    /** Signs-in state -> decides automatically if this phone is a parent or a child. */
    fun refresh() {
        if (Repo.me == null) {
            _gate.value = Gate.SignedOut
            return
        }
        _gate.value = Gate.Loading
        viewModelScope.launch {
            _gate.value = try {
                when (val r = Repo.resolve(prefs)) {
                    Repo.Resolved.Parent -> Gate.Parent
                    Repo.Resolved.NewAccount -> Gate.NewAccount
                    Repo.Resolved.Waiting -> Gate.Waiting
                    is Repo.Resolved.Child -> Gate.Child(r.parentName)
                }
            } catch (e: Exception) {
                Gate.Error(e.message ?: "Could not connect. Check your internet.")
            }
        }
    }

    fun becomeParent() {
        viewModelScope.launch {
            try {
                Repo.becomeParent(prefs)
                _gate.value = Gate.Parent
            } catch (e: Exception) {
                _gate.value = Gate.Error(e.message ?: "Could not create parent account")
            }
        }
    }

    fun waitForParent() {
        _gate.value = Gate.Waiting
    }

    fun linkWith(invite: Invite) {
        viewModelScope.launch {
            try {
                Repo.linkChild(invite, prefs)
                _gate.value = Gate.Child(invite.parentName)
            } catch (e: Exception) {
                _gate.value = Gate.Error(e.message ?: "Could not connect to parent")
            }
        }
    }

    fun onSignedOut() {
        RulesStore.clear(getApplication())
        prefs.clearAll()
        _gate.value = Gate.SignedOut
    }
}

class MainActivity : ComponentActivity() {

    private val vm: AppViewModel by viewModels()
    private val openAlerts = mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        openAlerts.value = intent?.getBooleanExtra("openAlerts", false) == true
        setContent {
            FamilyShieldTheme {
                val gate by vm.gate.collectAsStateWithLifecycle()
                when (val g = gate) {
                    Gate.Loading -> LoadingScreen()
                    Gate.SignedOut -> SignInScreen(activity = this, onSignedIn = { vm.refresh() })
                    Gate.NewAccount -> NewAccountScreen(
                        name = Repo.me?.displayName ?: "",
                        onParent = { vm.becomeParent() },
                        onChild = { vm.waitForParent() },
                        onSignOut = { signOut() },
                    )
                    Gate.Waiting -> WaitingScreen(
                        email = Repo.me?.email ?: "",
                        onInvite = { vm.linkWith(it) },
                        onSignOut = { signOut() },
                    )
                    Gate.Parent -> {
                        LaunchedEffect(Unit) { ParentAlertService.start(this@MainActivity) }
                        ParentRoot(
                            openAlerts = openAlerts.value,
                            onAlertsOpened = { openAlerts.value = false },
                            onSignOut = { signOut() },
                        )
                    }
                    is Gate.Child -> {
                        LaunchedEffect(Unit) { MonitorService.start(this@MainActivity) }
                        ChildRoot(
                            parentName = g.parentName,
                            onUnlinked = { vm.refresh() },
                        )
                    }
                    is Gate.Error -> ErrorScreen(g.message, onRetry = { vm.refresh() }, onSignOut = { signOut() })
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.getBooleanExtra("openAlerts", false)) openAlerts.value = true
    }

    private fun signOut() {
        lifecycleScope.launch {
            ParentAlertService.stop(this@MainActivity)
            MonitorService.stop(this@MainActivity)
            GoogleAuth.signOut(this@MainActivity)
            vm.onSignedOut()
        }
    }
}
