package com.aipdfstudio.app.data

import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import com.tom_roush.pdfbox.text.TextPosition
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** A box on a page as fractions (0..1) of the page as displayed, top-left origin. */
data class FBox(val l: Float, val t: Float, val r: Float, val b: Float) {
    val w get() = r - l
    val h get() = b - t
    fun contains(x: Float, y: Float) = x in l..r && y in t..b
    fun pad(px: Float, py: Float) = FBox(max(0f, l - px), max(0f, t - py), min(1f, r + px), min(1f, b + py))
    fun union(o: FBox) = FBox(min(l, o.l), min(t, o.t), max(r, o.r), max(b, o.b))
}

/** One line of real text on a page. [fontSize] is a fraction of the displayed page height. */
class TextLine(val text: String, val box: FBox, val fontSize: Float, val chars: List<Pair<Char, FBox>>)

class PageText(val index: Int, val lines: List<TextLine>) {
    /** Boxes covering every match of [regex] (one box per line a match touches). */
    fun find(regex: Regex): List<FBox> {
        val out = ArrayList<FBox>()
        for (line in lines) {
            // Build the line's string from its characters so string index == char index.
            val s = String(line.chars.map { it.first }.toCharArray())
            for (m in regex.findAll(s)) {
                if (m.value.isBlank()) continue
                val boxes = line.chars.subList(m.range.first, m.range.last + 1).map { it.second }.filter { it.w > 0f }
                if (boxes.isNotEmpty()) out.add(boxes.reduce { a, b -> a.union(b) })
            }
        }
        return out
    }

    fun lineAt(x: Float, y: Float): TextLine? =
        lines.firstOrNull { it.box.pad(0.005f, 0.004f).contains(x, y) }
}

/**
 * Reads where each character sits on a page, in display coordinates (page rotation applied).
 * Only left-to-right horizontal text (as seen on screen) is collected; other text is ignored.
 */
object TextGeometry {
    private class Collector(private val dispW: Float, private val dispH: Float, private val rot: Int) : PDFTextStripper() {
        val chars = ArrayList<Pair<Char, FBox>>()
        val sizes = ArrayList<Float>()
        val baselines = ArrayList<Float>()
        var wordBreaks = ArrayList<Int>()

        override fun writeString(text: String?, textPositions: MutableList<TextPosition>?) {
            if (textPositions.isNullOrEmpty()) return
            if (chars.isNotEmpty()) wordBreaks.add(chars.size)
            for (p in textPositions) {
                // getDir() is the direction on the unrotated page; subtract /Rotate to get it as seen on screen.
                if (((p.dir.toInt() - rot) % 360 + 360) % 360 != 0) continue
                val fs = p.fontSizeInPt.takeIf { it > 0f } ?: p.heightDir
                val x = p.x
                val y = p.y
                val w = max(p.width, 0f)
                val box = FBox(x / dispW, (y - fs * 0.8f) / dispH, (x + w) / dispW, (y + fs * 0.22f) / dispH)
                val u = p.unicode ?: continue
                // Ligatures like "fi" arrive as one position with 2+ letters: split the width.
                u.forEachIndexed { i, c ->
                    val part = w / u.length
                    chars.add(c to box.copy(l = (x + part * i) / dispW, r = (x + part * (i + 1)) / dispW))
                    sizes.add(fs)
                    baselines.add(y)
                }
            }
        }
    }

    fun read(doc: PDDocument, index: Int): PageText {
        val page = doc.getPage(index)
        val box = page.cropBox
        val pm = PageMath(box.lowerLeftX, box.lowerLeftY, box.width, box.height, page.rotation)
        val c = Collector(pm.dispW, pm.dispH, pm.rot)
        c.sortByPosition = true
        c.startPage = index + 1
        c.endPage = index + 1
        c.getText(doc)
        return PageText(index, group(c, pm.dispH))
    }

    /** Groups characters into lines (same baseline), adding a space between words. */
    private fun group(c: Collector, dispH: Float): List<TextLine> {
        if (c.chars.isEmpty()) return emptyList()
        val breaks = c.wordBreaks.toHashSet()
        val lines = ArrayList<TextLine>()
        var cur = ArrayList<Pair<Char, FBox>>()
        var curSize = 0f
        var curBase = c.baselines[0]

        fun flush() {
            if (cur.isEmpty()) return
            val trimmed = cur.dropWhile { it.first == ' ' }.dropLastWhile { it.first == ' ' }
            if (trimmed.isNotEmpty()) {
                val real = trimmed.filter { it.first != ' ' }.map { it.second }
                val box = real.reduce { a, b -> a.union(b) }
                lines.add(TextLine(String(trimmed.map { it.first }.toCharArray()), box, curSize / dispH, trimmed))
            }
            cur = ArrayList()
            curSize = 0f
        }

        for (i in c.chars.indices) {
            val (ch, b) = c.chars[i]
            val fs = c.sizes[i]
            val base = c.baselines[i]
            if (cur.isNotEmpty() && abs(base - curBase) > max(fs, curSize) * 0.45f) flush()
            if (cur.isNotEmpty() && i in breaks && cur.last().first != ' ') {
                val prev = cur.last().second
                cur.add(' ' to FBox(prev.r, prev.t, b.l.coerceAtLeast(prev.r), prev.b))
            }
            if (cur.isEmpty()) curBase = base
            cur.add(ch to b)
            curSize = max(curSize, fs)
        }
        flush()
        return lines
    }
}

/**
 * Really removes text from a page (not just covering it): every text-drawing command whose
 * letters all sit inside one of the boxes is emptied. Commands that also draw letters outside the
 * boxes are left alone (they are then only covered visually). Returns how many were removed.
 */
object TextRemover {
    private val SHOW_OPS = setOf("Tj", "TJ", "'", "\"")

    private class Locator(private val dispW: Float, private val dispH: Float, private val rot: Int) : PDFTextStripper() {
        var opIndex = -1
        var formDepth = 0
        private var nested = 0
        /** operator index -> boxes of the letters it drew */
        val glyphs = HashMap<Int, MutableList<FBox>>()

        override fun processOperator(operator: com.tom_roush.pdfbox.contentstream.operator.Operator, operands: MutableList<com.tom_roush.pdfbox.cos.COSBase>) {
            // Some commands run others internally (e.g. T* runs Td): count only the ones in the file.
            nested++
            try {
                if (nested == 1 && formDepth == 0) opIndex++
                super.processOperator(operator, operands)
            } finally {
                nested--
            }
        }

        override fun showForm(form: com.tom_roush.pdfbox.pdmodel.graphics.form.PDFormXObject) {
            formDepth++
            val saved = nested
            nested = 0
            try {
                super.showForm(form)
            } finally {
                nested = saved
                formDepth--
            }
        }

        override fun processTextPosition(text: TextPosition) {
            if (formDepth == 0 && ((text.dir.toInt() - rot) % 360 + 360) % 360 == 0) {
                val fs = text.fontSizeInPt.takeIf { it > 0f } ?: text.heightDir
                val box = FBox(text.x / dispW, (text.y - fs * 0.8f) / dispH, (text.x + max(text.width, 0f)) / dispW, (text.y + fs * 0.22f) / dispH)
                glyphs.getOrPut(opIndex) { ArrayList() }.add(box)
            } else if (formDepth == 0) {
                // Text we can't place: mark the command as "touching outside" so it is never removed.
                glyphs.getOrPut(opIndex) { ArrayList() }.add(FBox(-1f, -1f, -1f, -1f))
            }
            super.processTextPosition(text)
        }
    }

    fun remove(doc: PDDocument, index: Int, boxes: List<FBox>): Int {
        if (boxes.isEmpty()) return 0
        val page = doc.getPage(index)
        val cb = page.cropBox
        val pm = PageMath(cb.lowerLeftX, cb.lowerLeftY, cb.width, cb.height, page.rotation)
        val loc = Locator(pm.dispW, pm.dispH, pm.rot)
        loc.startPage = index + 1
        loc.endPage = index + 1
        loc.getText(doc)

        fun inside(g: FBox) = boxes.any { b ->
            val cx = (g.l + g.r) / 2
            val cy = (g.t + g.b) / 2
            b.contains(cx, cy)
        }
        val removable = loc.glyphs.filter { (_, gs) -> gs.isNotEmpty() && gs.all { inside(it) } }.keys
        if (removable.isEmpty()) return 0

        val parser = com.tom_roush.pdfbox.pdfparser.PDFStreamParser(page)
        parser.parse()
        val tokens = parser.tokens
        var op = -1
        var removed = 0
        for (i in tokens.indices) {
            val tk = tokens[i]
            if (tk !is com.tom_roush.pdfbox.contentstream.operator.Operator) continue
            op++
            if (op !in removable || tk.name !in SHOW_OPS) continue
            // Empty the text operand (the one right before the operator) but keep the command,
            // so line moves done by ' and " still happen.
            val j = i - 1
            if (j < 0) continue
            when (val prev = tokens[j]) {
                is com.tom_roush.pdfbox.cos.COSString -> { tokens[j] = com.tom_roush.pdfbox.cos.COSString(""); removed++ }
                is com.tom_roush.pdfbox.cos.COSArray -> { tokens[j] = com.tom_roush.pdfbox.cos.COSArray(); removed++ }
                else -> Unit
            }
        }
        if (removed > 0) {
            val stream = com.tom_roush.pdfbox.pdmodel.common.PDStream(doc)
            stream.createOutputStream(com.tom_roush.pdfbox.cos.COSName.FLATE_DECODE).use { out ->
                com.tom_roush.pdfbox.pdfwriter.ContentStreamWriter(out).writeTokens(tokens)
            }
            page.setContents(stream)
        }
        return removed
    }
}
