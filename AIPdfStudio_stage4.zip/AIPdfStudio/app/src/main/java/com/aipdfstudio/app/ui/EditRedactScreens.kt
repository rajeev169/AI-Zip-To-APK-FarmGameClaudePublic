package com.aipdfstudio.app.ui

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.outlined.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.outlined.Undo
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.aipdfstudio.app.data.BoxKind
import com.aipdfstudio.app.data.EditItem
import com.aipdfstudio.app.data.EditOps
import com.aipdfstudio.app.data.FBox
import com.aipdfstudio.app.data.Outputs
import com.aipdfstudio.app.data.PdfOps
import com.aipdfstudio.app.data.RedactOps
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

// ------------------------------------------------------------------ shared page view

/**
 * Shows one page with page arrows. [drawBoxes] = drag a finger to draw a box (reported in page
 * fractions); otherwise a tap reports its position. [overlay] draws on top, given the page size in px.
 */
@Composable
private fun PageStage(
    vm: ToolVm,
    pageCount: Int,
    drawBoxes: Boolean,
    onTap: (Float, Float) -> Unit,
    onBox: (FBox) -> Unit,
    overlay: @Composable (wPx: Float, hPx: Float, aspect: Float) -> Unit
) {
    val page = vm.page.coerceIn(0, max(0, pageCount - 1))
    val thumbs = vm.thumbs
    var bmp by remember(thumbs, page) { mutableStateOf<Bitmap?>(null) }
    LaunchedEffect(thumbs, page) { bmp = withContext(Dispatchers.IO) { thumbs?.get(page, 1000) } }

    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Spacer(Modifier.weight(1f))
            IconButton(onClick = { vm.page = page - 1 }, enabled = page > 0) {
                Icon(Icons.AutoMirrored.Outlined.KeyboardArrowLeft, contentDescription = "Previous page")
            }
            Text("Page ${page + 1} of $pageCount", style = MaterialTheme.typography.labelLarge)
            IconButton(onClick = { vm.page = page + 1 }, enabled = page < pageCount - 1) {
                Icon(Icons.AutoMirrored.Outlined.KeyboardArrowRight, contentDescription = "Next page")
            }
            Spacer(Modifier.weight(1f))
        }
        val b = bmp
        if (b == null) {
            Box(Modifier.fillMaxWidth().aspectRatio(0.707f).background(Color.White), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(Modifier.size(28.dp))
            }
        } else {
            val aspect = b.width.toFloat() / b.height
            var dragStart by remember { mutableStateOf<Offset?>(null) }
            var dragNow by remember { mutableStateOf<Offset?>(null) }
            BoxWithConstraints(
                Modifier.fillMaxWidth().aspectRatio(aspect)
                    .border(1.dp, MaterialTheme.colorScheme.outlineVariant)
                    .background(Color.White)
            ) {
                val density = LocalDensity.current
                val wPx = with(density) { maxWidth.toPx() }
                val hPx = with(density) { maxHeight.toPx() }
                Image(b.asImageBitmap(), contentDescription = "Page ${page + 1}", modifier = Modifier.fillMaxSize(), contentScale = ContentScale.FillBounds)
                overlay(wPx, hPx, aspect)
                val color = MaterialTheme.colorScheme.primary
                Canvas(
                    Modifier.fillMaxSize()
                        .pointerInput(drawBoxes, page, wPx, hPx) {
                            if (drawBoxes) {
                                detectDragGestures(
                                    onDragStart = { dragStart = it; dragNow = it },
                                    onDragEnd = {
                                        val s = dragStart
                                        val e = dragNow
                                        if (s != null && e != null && abs(s.x - e.x) > 8 && abs(s.y - e.y) > 8) {
                                            onBox(
                                                FBox(
                                                    (min(s.x, e.x) / wPx).coerceIn(0f, 1f), (min(s.y, e.y) / hPx).coerceIn(0f, 1f),
                                                    (max(s.x, e.x) / wPx).coerceIn(0f, 1f), (max(s.y, e.y) / hPx).coerceIn(0f, 1f)
                                                )
                                            )
                                        }
                                        dragStart = null
                                        dragNow = null
                                    },
                                    onDragCancel = { dragStart = null; dragNow = null }
                                ) { change, _ ->
                                    change.consume()
                                    dragNow = change.position
                                }
                            } else {
                                detectTapGestures(onTap = { p -> onTap(p.x / wPx, p.y / hPx) })
                            }
                        }
                ) {
                    val s = dragStart
                    val e = dragNow
                    if (s != null && e != null) {
                        drawRect(
                            color,
                            topLeft = Offset(min(s.x, e.x), min(s.y, e.y)),
                            size = Size(abs(s.x - e.x), abs(s.y - e.y)),
                            style = Stroke(width = 3f)
                        )
                    }
                }
            }
            Hint(if (drawBoxes) "Drag a finger over the page to draw a box. Scroll by dragging outside the page." else "Tap the page.")
        }
    }
}

// ------------------------------------------------------------------ Smart edit

private enum class EditTool(val label: String, val drawsBox: Boolean) {
    EDIT_TEXT("Edit text", false),
    ADD_TEXT("Add text", false),
    WHITEOUT("Erase", true),
    HIGHLIGHT("Highlight", true),
    IMAGE("Image", false)
}

private val TextColors = listOf("Black" to 0x111111, "Blue" to 0x1A3FB5, "Red" to 0xC62828)
private val TextSizes = listOf("Small" to 0.016f, "Medium" to 0.022f, "Large" to 0.032f)

private class TextDraft(val left: Float, val top: Float, val text: String, val size: Float, val replace: FBox?)

@Composable
fun EditScreen(onBack: () -> Unit, onOpen: (Uri) -> Unit, vm: ToolVm = viewModel()) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.addFiles(listOf(uri), replace = true, forPages = true)
    }
    var tool by remember { mutableStateOf(EditTool.EDIT_TEXT) }
    var draft by remember { mutableStateOf<TextDraft?>(null) }
    var imagePath by remember { mutableStateOf<String?>(null) }
    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch {
                val f = withContext(Dispatchers.IO) {
                    try {
                        val dir = File(ctx.filesDir, "edit_images").apply { mkdirs() }
                        val out = File(dir, "img_${System.currentTimeMillis()}")
                        ctx.contentResolver.openInputStream(uri)?.use { i -> out.outputStream().use { o -> i.copyTo(o) } }
                        out
                    } catch (e: Exception) {
                        null
                    }
                }
                imagePath = f?.path
                if (f != null) Toast.makeText(ctx, "Now tap the page where the image should go", Toast.LENGTH_SHORT).show()
            }
        }
    }

    val p = vm.single
    val usable = p != null && !p.locked && !p.broken && p.pages > 0
    val count = vm.edits.size

    ToolPage(
        title = "Smart edit",
        vm = vm,
        onBack = onBack,
        actionLabel = when {
            !usable -> "Choose a PDF"
            count == 0 -> "Make a change first"
            else -> "Save edited PDF ($count change${if (count == 1) "" else "s"})"
        },
        actionEnabled = usable && count > 0,
        onAction = act@{
            val src = p ?: return@act
            val items = vm.edits.toList()
            vm.run("Saving changes…") {
                val out = Outputs.newFile(ctx, src.name, "edited")
                EditOps.apply(ctx, src.uri, items, out)
                listOf(out) to null
            }
        },
        topActions = {
            if (usable) {
                IconButton(onClick = { if (vm.edits.isNotEmpty()) vm.edits.removeAt(vm.edits.size - 1); vm.clearOutcome() }, enabled = count > 0) {
                    Icon(Icons.AutoMirrored.Outlined.Undo, contentDescription = "Undo")
                }
            }
        }
    ) {
        item(key = "hint") { Hint("Change words, add text or pictures, erase or highlight. Your original file is not changed.") }
        item(key = "file") { PickedCard(p, vm.loading) { picker.launch(arrayOf("application/pdf")) } }
        if (p != null && p.locked) {
            item(key = "locked") { MessageCard("This PDF is password protected. Unlock it first with the Unlock tool.", isError = true) }
        }
        if (usable) {
            item(key = "tools") {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    EditTool.entries.forEach { t ->
                        FilterChip(selected = tool == t, onClick = {
                            tool = t
                            if (t == EditTool.IMAGE) imagePicker.launch(arrayOf("image/*"))
                        }, label = { Text(t.label) })
                    }
                }
            }
            item(key = "toolHint") {
                Hint(
                    when (tool) {
                        EditTool.EDIT_TEXT -> "Tap a line of text to change or delete it."
                        EditTool.ADD_TEXT -> "Tap where the new text should start."
                        EditTool.WHITEOUT -> "Draw a box to cover something with white."
                        EditTool.HIGHLIGHT -> "Draw a box over text to highlight it."
                        EditTool.IMAGE -> if (imagePath == null) "Pick a picture first (tap Image again)." else "Tap where the picture should go."
                    }
                )
            }
            item(key = "stage") {
                PageStage(
                    vm = vm,
                    pageCount = p!!.pages,
                    drawBoxes = tool.drawsBox,
                    onTap = { x, y ->
                        val page = vm.page
                        when (tool) {
                            EditTool.EDIT_TEXT -> scope.launch {
                                val line = withContext(Dispatchers.IO) { vm.pageText(page)?.lineAt(x, y) }
                                if (line == null) {
                                    Toast.makeText(ctx, "No editable text there. Use Add text instead.", Toast.LENGTH_SHORT).show()
                                } else {
                                    draft = TextDraft(line.box.l, line.box.t, line.text, line.fontSize, line.box.pad(0.004f, 0.003f))
                                }
                            }
                            EditTool.ADD_TEXT -> draft = TextDraft(x, y, "", TextSizes[1].second, null)
                            EditTool.IMAGE -> {
                                val path = imagePath
                                if (path == null) {
                                    imagePicker.launch(arrayOf("image/*"))
                                } else {
                                    val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                                    BitmapFactory.decodeFile(path, o)
                                    val pageAspect = vm.thumbs?.get(page, 1000)?.let { it.width.toFloat() / it.height } ?: 0.707f
                                    val w = 0.4f
                                    val h = if (o.outWidth > 0) w * pageAspect * o.outHeight / o.outWidth else 0.2f
                                    vm.edits.add(EditItem.Image(page, FBox(x, y, min(1f, x + w), min(1f, y + h)), path))
                                    vm.clearOutcome()
                                }
                            }
                            else -> Unit
                        }
                    },
                    onBox = { box ->
                        val kind = if (tool == EditTool.HIGHLIGHT) BoxKind.HIGHLIGHT else BoxKind.WHITEOUT
                        vm.edits.add(EditItem.Box(vm.page, box, kind))
                        vm.clearOutcome()
                    },
                    overlay = { wPx, hPx, aspect -> EditOverlay(vm, wPx, hPx) }
                )
            }
        }
        outcome(vm, onOpen)
    }

    val d = draft
    if (d != null) {
        TextDialog(
            draft = d,
            onDismiss = { draft = null },
            onDelete = if (d.replace != null) {
                {
                    vm.edits.add(EditItem.Box(vm.page, d.replace, BoxKind.WHITEOUT, removeText = true))
                    vm.clearOutcome()
                    draft = null
                }
            } else null,
            onSave = { text, size, color ->
                if (d.replace != null) vm.edits.add(EditItem.Box(vm.page, d.replace, BoxKind.WHITEOUT, removeText = true))
                vm.edits.add(EditItem.Text(vm.page, d.left, d.top, size, text, color))
                vm.clearOutcome()
                draft = null
            }
        )
    }
}

@Composable
private fun EditOverlay(vm: ToolVm, wPx: Float, hPx: Float) {
    val density = LocalDensity.current
    val page = vm.page
    vm.edits.filter { it.page == page }.forEach { item ->
        when (item) {
            is EditItem.Box -> Box(
                Modifier
                    .offset { IntOffset((item.box.l * wPx).roundToInt(), (item.box.t * hPx).roundToInt()) }
                    .size(with(density) { (item.box.w * wPx).toDp() }, with(density) { (item.box.h * hPx).toDp() })
                    .background(
                        when (item.kind) {
                            BoxKind.WHITEOUT -> Color.White
                            BoxKind.HIGHLIGHT -> Color(0x59FFE600)
                            BoxKind.BLACKOUT -> Color.Black
                        }
                    )
                    .border(1.dp, Color(0x33000000))
            )
            is EditItem.Text -> {
                val fontPx = item.size * hPx
                Column(Modifier.offset { IntOffset((item.left * wPx).roundToInt(), (item.top * hPx).roundToInt()) }) {
                    item.text.split('\n').forEach { line ->
                        Text(
                            line,
                            style = TextStyle(
                                fontFamily = FontFamily.SansSerif,
                                fontSize = with(density) { fontPx.toSp() },
                                lineHeight = with(density) { (fontPx * 1.2f).toSp() },
                                color = Color(0xFF000000.toInt() or item.color)
                            ),
                            softWrap = false
                        )
                    }
                }
            }
            is EditItem.Image -> {
                val bmp = remember(item.path) { BitmapFactory.decodeFile(item.path) }
                if (bmp != null) {
                    Image(
                        bmp.asImageBitmap(),
                        contentDescription = "Added picture",
                        contentScale = ContentScale.FillBounds,
                        modifier = Modifier
                            .offset { IntOffset((item.box.l * wPx).roundToInt(), (item.box.t * hPx).roundToInt()) }
                            .size(with(density) { (item.box.w * wPx).toDp() }, with(density) { (item.box.h * hPx).toDp() })
                    )
                }
            }
        }
    }
}

@Composable
private fun TextDialog(
    draft: TextDraft,
    onDismiss: () -> Unit,
    onDelete: (() -> Unit)?,
    onSave: (String, Float, Int) -> Unit
) {
    var text by remember { mutableStateOf(draft.text) }
    var size by remember { mutableStateOf(draft.size) }
    var color by remember { mutableStateOf(TextColors[0].second) }
    val editing = draft.replace != null
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (editing) "Edit this line" else "Add text") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    label = { Text("Text") },
                    minLines = if (editing) 1 else 2,
                    modifier = Modifier.fillMaxWidth()
                )
                if (!editing) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        TextSizes.forEach { (n, v) -> FilterChip(selected = size == v, onClick = { size = v }, label = { Text(n) }) }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    TextColors.forEach { (n, v) -> FilterChip(selected = color == v, onClick = { color = v }, label = { Text(n) }) }
                }
                Text(
                    "Uses a standard font (Helvetica). English letters, numbers and symbols only.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (onDelete != null) {
                    OutlinedButton(onClick = onDelete) { Text("Delete this line") }
                }
            }
        },
        confirmButton = { TextButton(enabled = text.isNotBlank(), onClick = { onSave(text.trimEnd(), size, color) }) { Text("Done") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

// ------------------------------------------------------------------ Redact

@Composable
fun RedactScreen(onBack: () -> Unit, onOpen: (Uri) -> Unit, vm: ToolVm = viewModel()) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.addFiles(listOf(uri), replace = true, forPages = true)
    }
    var word by remember { mutableStateOf("") }
    val presets = remember { mutableStateOf(setOf<RedactOps.Preset>()) }
    var finding by remember { mutableStateOf(false) }

    val p = vm.single
    val usable = p != null && !p.locked && !p.broken && p.pages > 0
    val total = vm.redactBoxes.values.sumOf { it.size }
    val pagesMarked = vm.redactBoxes.count { it.value.isNotEmpty() }

    fun addBoxes(found: Map<Int, List<FBox>>) {
        var added = 0
        found.forEach { (pg, list) ->
            val old = vm.redactBoxes[pg] ?: emptyList()
            val fresh = list.filter { n -> old.none { o -> abs(o.l - n.l) < 0.002f && abs(o.t - n.t) < 0.002f } }
            added += fresh.size
            vm.redactBoxes[pg] = old + fresh
        }
        Toast.makeText(ctx, if (added == 0) "Nothing new found" else "Marked $added place${if (added == 1) "" else "s"}", Toast.LENGTH_SHORT).show()
        found.keys.minOrNull()?.let { if (added > 0) vm.page = it }
    }

    ToolPage(
        title = "Redact",
        vm = vm,
        onBack = onBack,
        actionLabel = when {
            !usable -> "Choose a PDF"
            total == 0 -> "Mark what to hide first"
            else -> "Hide $total area${if (total == 1) "" else "s"} on $pagesMarked page${if (pagesMarked == 1) "" else "s"}"
        },
        actionEnabled = usable && total > 0,
        onAction = act@{
            val src = p ?: return@act
            val boxes = vm.redactBoxes.toMap()
            vm.run("Redacting…") { progress ->
                val out = Outputs.newFile(ctx, src.name, "redacted")
                RedactOps.apply(ctx, src.uri, boxes, out, progress)
                listOf(out) to "Done. Marked pages were turned into pictures with black boxes, so the hidden text can't be copied or recovered."
            }
        }
    ) {
        item(key = "hint") { Hint("Black out private details for good. Pages you mark become pictures, so the hidden text is really gone.") }
        item(key = "file") { PickedCard(p, vm.loading) { picker.launch(arrayOf("application/pdf")) } }
        if (p != null && p.locked) {
            item(key = "locked") { MessageCard("This PDF is password protected. Unlock it first with the Unlock tool.", isError = true) }
        }
        if (usable) {
            item(key = "find") {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Find and mark automatically", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Medium)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        RedactOps.Preset.entries.forEach { pr ->
                            FilterChip(
                                selected = pr in presets.value,
                                onClick = { presets.value = if (pr in presets.value) presets.value - pr else presets.value + pr },
                                label = { Text(pr.label) }
                            )
                        }
                    }
                    OutlinedTextField(
                        value = word,
                        onValueChange = { word = it },
                        label = { Text("Word or name to hide (optional)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedButton(
                        enabled = !finding && (word.isNotBlank() || presets.value.isNotEmpty()),
                        onClick = {
                            val src = p!!
                            val regexes = presets.value.map { it.regex } + (if (word.isNotBlank()) listOf(RedactOps.wordRegex(word)) else emptyList())
                            finding = true
                            scope.launch {
                                try {
                                    val found = withContext(Dispatchers.IO) { PdfOps.load(ctx, src.uri).use { RedactOps.find(it, regexes) } }
                                    addBoxes(found)
                                } catch (e: Throwable) {
                                    vm.error = PdfOps.friendly(e)
                                } finally {
                                    finding = false
                                }
                            }
                        }
                    ) { Text(if (finding) "Searching…" else "Find and mark") }
                    Hint("Only finds real text. For scanned pages, draw boxes by hand below.")
                }
            }
            item(key = "stage") {
                PageStage(
                    vm = vm,
                    pageCount = p!!.pages,
                    drawBoxes = true,
                    onTap = { _, _ -> },
                    onBox = { b ->
                        vm.redactBoxes[vm.page] = (vm.redactBoxes[vm.page] ?: emptyList()) + b
                        vm.clearOutcome()
                    },
                    overlay = { wPx, hPx, _ ->
                        val density = LocalDensity.current
                        (vm.redactBoxes[vm.page] ?: emptyList()).forEach { b ->
                            Box(
                                Modifier
                                    .offset { IntOffset((b.l * wPx).roundToInt(), (b.t * hPx).roundToInt()) }
                                    .size(with(density) { (b.w * wPx).toDp() }, with(density) { (b.h * hPx).toDp() })
                                    .background(Color(0xCC000000))
                            )
                        }
                    }
                )
            }
            item(key = "pageTools") {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        enabled = !vm.redactBoxes[vm.page].isNullOrEmpty(),
                        onClick = {
                            val l = vm.redactBoxes[vm.page] ?: emptyList()
                            vm.redactBoxes[vm.page] = l.dropLast(1)
                            vm.clearOutcome()
                        }
                    ) { Text("Undo last box") }
                    OutlinedButton(
                        enabled = total > 0,
                        onClick = { vm.redactBoxes.clear(); vm.clearOutcome() }
                    ) { Text("Clear all") }
                }
            }
        }
        outcome(vm, onOpen)
    }
}
