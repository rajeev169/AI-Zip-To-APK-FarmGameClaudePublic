package com.aipdfstudio.app.ui

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.FolderOpen
import androidx.compose.material.icons.outlined.GridView
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.aipdfstudio.app.data.RecentStore
import com.aipdfstudio.app.data.queryName
import kotlinx.coroutines.launch

private data class Tab(val route: String, val label: String, val icon: ImageVector)

private val tabs = listOf(
    Tab("home", "Files", Icons.Outlined.FolderOpen),
    Tab("tools", "Tools", Icons.Outlined.GridView),
    Tab("ai", "AI", Icons.Outlined.AutoAwesome)
)

@Composable
fun AppRoot(ai: AiViewModel, incoming: Uri?, onIncomingHandled: () -> Unit) {
    val ctx = LocalContext.current
    val nav = rememberNavController()
    val store = remember { RecentStore(ctx) }
    var recents by remember { mutableStateOf(store.load()) }
    var viewerUri by rememberSaveable { mutableStateOf<Uri?>(null) }
    val snack = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val entry by nav.currentBackStackEntryAsState()
    val route = entry?.destination?.route

    LaunchedEffect(route) { recents = store.load() }

    fun openViewer(uri: Uri) {
        viewerUri = uri
        nav.navigate("viewer")
    }

    fun goTab(r: String) {
        nav.navigate(r) {
            popUpTo(nav.graph.findStartDestination().id) { saveState = true }
            launchSingleTop = true
            restoreState = true
        }
    }

    fun soon(name: String) {
        scope.launch {
            snack.currentSnackbarData?.dismiss()
            snack.showSnackbar("$name is coming in the next update")
        }
    }

    fun keepAccess(uri: Uri) {
        try {
            ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (ignored: Exception) {
        }
    }

    val openPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            keepAccess(uri)
            openViewer(uri)
        }
    }
    val aiPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            keepAccess(uri)
            ai.setDocument(uri, queryName(ctx, uri))
        }
    }

    LaunchedEffect(incoming) {
        if (incoming != null) {
            openViewer(incoming)
            onIncomingHandled()
        }
    }

    val showBar = route != null && tabs.any { it.route == route }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        snackbarHost = { SnackbarHost(snack) },
        bottomBar = {
            if (showBar) {
                NavigationBar {
                    tabs.forEach { t ->
                        NavigationBarItem(
                            selected = route == t.route,
                            onClick = { goTab(t.route) },
                            icon = { Icon(t.icon, contentDescription = null) },
                            label = { Text(t.label) }
                        )
                    }
                }
            }
        }
    ) { pad ->
        NavHost(nav, startDestination = "home", modifier = Modifier.padding(pad)) {
            composable("home") {
                HomeScreen(
                    recents = recents,
                    onOpenFile = { openPicker.launch(arrayOf("application/pdf")) },
                    onOpenRecent = { openViewer(Uri.parse(it.uri)) },
                    onRemove = { store.remove(it.uri); recents = store.load() },
                    onSettings = { nav.navigate("settings") },
                    onTool = { nav.navigate(it) },
                    onSoon = { soon(it) }
                )
            }
            composable("tools") {
                ToolsScreen(
                    onOpenFile = { openPicker.launch(arrayOf("application/pdf")) },
                    onAi = { goTab("ai") },
                    onTool = { nav.navigate(it) },
                    onSoon = { soon(it) }
                )
            }
            composable("ai") {
                AiScreen(
                    vm = ai,
                    recents = recents,
                    onPickFile = { aiPicker.launch(arrayOf("application/pdf")) },
                    onSettings = { nav.navigate("settings") }
                )
            }
            composable("viewer") {
                val u = viewerUri
                if (u == null) {
                    LaunchedEffect(Unit) { nav.popBackStack() }
                } else {
                    key(u) {
                        ViewerScreen(
                            uri = u,
                            recents = store,
                            onBack = { nav.popBackStack() },
                            onAskAi = { name ->
                                ai.setDocument(u, name)
                                goTab("ai")
                            }
                        )
                    }
                }
            }
            composable("merge") { MergeScreen(onBack = { nav.popBackStack() }, onOpen = { openViewer(it) }) }
            composable("split") { SplitScreen(onBack = { nav.popBackStack() }, onOpen = { openViewer(it) }) }
            composable("pages") { PagesScreen(onBack = { nav.popBackStack() }, onOpen = { openViewer(it) }) }
            composable("compress") { CompressScreen(onBack = { nav.popBackStack() }, onOpen = { openViewer(it) }) }
            composable("lock") { LockScreen(unlock = false, onBack = { nav.popBackStack() }, onOpen = { openViewer(it) }) }
            composable("unlock") { LockScreen(unlock = true, onBack = { nav.popBackStack() }, onOpen = { openViewer(it) }) }
            composable("sign") { SignScreen(onBack = { nav.popBackStack() }, onOpen = { openViewer(it) }) }
            composable("scan") { ScanScreen(onBack = { nav.popBackStack() }, onOpen = { openViewer(it) }) }
            composable("convert") { ConvertScreen(onBack = { nav.popBackStack() }, onOpen = { openViewer(it) }) }
            composable("ocr") { OcrScreen(onBack = { nav.popBackStack() }, onOpen = { openViewer(it) }) }
            composable("edit") { EditScreen(onBack = { nav.popBackStack() }, onOpen = { openViewer(it) }) }
            composable("redact") { RedactScreen(onBack = { nav.popBackStack() }, onOpen = { openViewer(it) }) }
            composable("forms") { FormsScreen(onBack = { nav.popBackStack() }, onOpen = { openViewer(it) }) }
            composable("compare") { CompareScreen(onBack = { nav.popBackStack() }, onOpen = { openViewer(it) }) }
            composable("link") { LinkScreen(onBack = { nav.popBackStack() }, onOpen = { openViewer(it) }) }
            composable("premium") { PremiumScreen(onBack = { nav.popBackStack() }) }
            composable("settings") {
                SettingsScreen(vm = ai, onBack = { nav.popBackStack() }, onPremium = { nav.navigate("premium") })
            }
        }
    }
}
