extends Node
# v27 systems: hired power-tiller farm hand, upgrade hub, "struggling" alerts,
# crop care (water / weeds), animal feeding, settings (graphics + save code).
# Lives as a child of the main farm script (g) and talks to it directly.

var g: Node

const HIRE_LV := 5
const HIRE_COST := 600
const AUTO_LV := 9
const AUTO_COST := 1500
const TILL_ENERGY := 1
const WALK_SPEED := 2.6
const TILL_SPEED := 0.95
const FEED_COST := 2

# ---- upgrade levels (new ones) ----
var batt_level: int = 1
var wm_level: int = 1
var cargo_level: int = 1
const BATT_CAP: Array = [500, 800, 1200]
const BATT_COST: Array = [600, 1400]
const BATT_REQ: Array = [8, 10]
const WM_INT: Array = [45.0, 36.0, 28.0]
const WM_BONUS: Array = [0, 10, 22]
const WM_COST: Array = [400, 1000]
const WM_REQ: Array = [4, 7]
const CARGO_BONUS: Array = [4, 1, 3, 4, 4]
const CARGO_COST: Array = [800, 1800]
const CARGO_REQ: Array = [11, 13]

# ---- farm hand ----
var hired: bool = false
var auto_on: bool = false
var tilled: Dictionary = {}
var tilled_nodes: Dictionary = {}
var queue: Array = []
var cur_key: String = ""
var phase: int = 0            # 0 idle, 1 walking to start, 2 turning, 3 tilling
var rig: Node3D
var stand_node: Node3D
var wheels: Array = []
var drum: Node3D
var puffs: Array = []
var rp: Vector3 = Vector3(-2.6, 0.15, 1.1)
var heading: float = 0.0
var run_from: Vector3
var run_to: Vector3
var run_t: float = 0.0
var run_dir: float = 1.0
var run_d: Vector2 = Vector2(1, 0)
var tilled_clock: float = 0.0
const TILL_KEEP := 180.0
var auto_t: float = 0.0
var engine_on: bool = false
var soil_dark: StandardMaterial3D
var soil_clod: StandardMaterial3D
var anim_t: float = 0.0

# ---- crop care ----
var care: Dictionary = {}       # key -> "water" | "weed"
var care_next: Dictionary = {}  # key -> seconds until the next check
var care_icons: Dictionary = {}
var care_clock: float = 0.0

# ---- animal care ----
var hunger_clock: float = 0.0

# ---- alerts ----
var al_panel: PanelContainer
var al_msg: Label
var al_b1: Button
var al_b2: Button
var al_cool: Dictionary = {}
var al_act1: Callable
var al_act2: Callable
var al_kind: String = ""
var watch_t: float = 0.0

# ---- upgrade hub ----
var up_panel: PanelContainer
var up_col: VBoxContainer
var up_coin: Label
var up_rows: Array = []

# ---- settings ----
var set_panel: PanelContainer
var set_info: Label
var gfx_mode: int = 0           # 0 auto, 1 high, 2 medium, 3 low
var gfx_buttons: Array = []
var code_edit: LineEdit
var sound_btn: Button

# =========================================================== build

func build() -> void:
    _mats()
    _build_alert_panel()
    _build_hub_panel()
    _build_settings_panel()
    g.extra_panels.append(al_panel)
    g.extra_panels.append(up_panel)
    g.extra_panels.append(set_panel)
    _build_standing_farmer()
    build_islands()
    _load_settings()
    _apply_gfx()

func _mats() -> void:
    soil_dark = _mm(Color(0.24, 0.14, 0.07), 1.0)
    soil_clod = _mm(Color(0.36, 0.22, 0.12), 1.0)

func _mm(c: Color, rough: float = 0.6, metal: float = 0.0, alpha: float = 1.0) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = Color(c.r, c.g, c.b, alpha)
    m.roughness = rough
    m.metallic = metal
    if alpha < 1.0:
        m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    return m

func _put(parent: Node3D, mesh: Mesh, pos: Vector3, mat: Material, rot: Vector3 = Vector3.ZERO, scl: Vector3 = Vector3.ONE) -> MeshInstance3D:
    var mi := MeshInstance3D.new()
    mi.mesh = mesh
    mi.material_override = mat
    mi.position = pos
    mi.rotation_degrees = rot
    mi.scale = scl
    parent.add_child(mi)
    return mi

func _sph(r: float, sq: float = 1.0) -> SphereMesh:
    var s := SphereMesh.new()
    s.radius = r
    s.height = 2.0 * r * sq
    s.radial_segments = 16
    s.rings = 8
    return s

func _cyl(rt: float, rb: float, h: float, seg: int = 20) -> CylinderMesh:
    var c := CylinderMesh.new()
    c.top_radius = rt
    c.bottom_radius = rb
    c.height = h
    c.radial_segments = seg
    return c

func _bx(s: Vector3) -> BoxMesh:
    var b := BoxMesh.new()
    b.size = s
    return b

func _limb(parent: Node3D, a: Vector3, b: Vector3, r: float, mat: Material) -> void:
    var d: Vector3 = b - a
    var cap := CapsuleMesh.new()
    cap.radius = r
    cap.height = d.length() + 2.0 * r
    cap.radial_segments = 12
    cap.rings = 5
    var mi := MeshInstance3D.new()
    mi.mesh = cap
    mi.material_override = mat
    mi.position = (a + b) * 0.5
    if d.length() > 0.0001:
        var dn: Vector3 = d.normalized()
        if dn.dot(Vector3.UP) < -0.9999:
            mi.rotation_degrees = Vector3(180, 0, 0)
        else:
            mi.quaternion = Quaternion(Vector3.UP, dn)
    parent.add_child(mi)

func _rod(parent: Node3D, a: Vector3, b: Vector3, r: float, mat: Material) -> void:
    var d: Vector3 = b - a
    var mi := MeshInstance3D.new()
    mi.mesh = _cyl(r, r, d.length(), 10)
    mi.material_override = mat
    mi.position = (a + b) * 0.5
    if d.length() > 0.0001:
        var dn: Vector3 = d.normalized()
        if dn.dot(Vector3.UP) < -0.9999:
            mi.rotation_degrees = Vector3(180, 0, 0)
        else:
            mi.quaternion = Quaternion(Vector3.UP, dn)
    parent.add_child(mi)

# =========================================================== the man

func _build_man(parent: Node3D, pushing: bool) -> void:
    var skin: StandardMaterial3D = _mm(Color(0.58, 0.38, 0.25), 0.7)
    var shirt: StandardMaterial3D = _mm(Color(0.20, 0.42, 0.85), 0.85)
    var trouser: StandardMaterial3D = _mm(Color(0.22, 0.30, 0.52), 0.9)
    var hair: StandardMaterial3D = _mm(Color(0.07, 0.06, 0.06), 0.8)
    var straw: StandardMaterial3D = _mm(Color(0.95, 0.72, 0.22), 0.95)
    var band: StandardMaterial3D = _mm(Color(0.72, 0.18, 0.15), 0.9)
    var boot: StandardMaterial3D = _mm(Color(0.25, 0.16, 0.10), 0.8)
    var dark: StandardMaterial3D = _mm(Color(0.04, 0.03, 0.03), 0.4)
    var hx: float = 0.27 if pushing else 0.04
    var hy: float = 1.43 if pushing else 1.52
    if pushing:
        _put(parent, _bx(Vector3(0.20, 0.05, 0.10)), Vector3(0.30, 0.03, -0.12), boot)
        _put(parent, _bx(Vector3(0.20, 0.05, 0.10)), Vector3(-0.22, 0.03, 0.12), boot)
        _limb(parent, Vector3(0.28, 0.09, -0.12), Vector3(0.12, 0.44, -0.12), 0.055, trouser)
        _limb(parent, Vector3(-0.20, 0.09, 0.12), Vector3(-0.04, 0.44, 0.12), 0.055, trouser)
        _limb(parent, Vector3(0.12, 0.44, -0.12), Vector3(0.0, 0.78, -0.10), 0.075, trouser)
        _limb(parent, Vector3(-0.04, 0.44, 0.12), Vector3(0.0, 0.78, 0.10), 0.075, trouser)
        _put(parent, _cyl(0.15, 0.16, 0.16, 20), Vector3(0.0, 0.80, 0), trouser)
        _limb(parent, Vector3(0.0, 0.80, 0.0), Vector3(0.17, 1.22, 0.0), 0.15, shirt)
        for z in [-0.16, 0.16]:
            _put(parent, _sph(0.07), Vector3(0.16, 1.20, float(z)), shirt)
            _limb(parent, Vector3(0.16, 1.20, float(z)), Vector3(0.34, 1.02, float(z) * 1.1), 0.055, shirt)
            _limb(parent, Vector3(0.34, 1.02, float(z) * 1.1), Vector3(0.53, 0.96, float(z) * 1.25), 0.042, skin)
            _put(parent, _sph(0.05), Vector3(0.55, 0.96, float(z) * 1.27), skin)
        _limb(parent, Vector3(0.18, 1.24, 0.0), Vector3(0.23, 1.34, 0.0), 0.045, skin)
    else:
        _put(parent, _bx(Vector3(0.20, 0.06, 0.11)), Vector3(0.04, 0.03, -0.11), boot)
        _put(parent, _bx(Vector3(0.20, 0.06, 0.11)), Vector3(0.04, 0.03, 0.11), boot)
        _limb(parent, Vector3(0.0, 0.08, -0.11), Vector3(0.0, 0.46, -0.11), 0.058, trouser)
        _limb(parent, Vector3(0.0, 0.08, 0.11), Vector3(0.0, 0.46, 0.11), 0.058, trouser)
        _limb(parent, Vector3(0.0, 0.46, -0.11), Vector3(0.0, 0.82, -0.10), 0.075, trouser)
        _limb(parent, Vector3(0.0, 0.46, 0.11), Vector3(0.0, 0.82, 0.10), 0.075, trouser)
        _put(parent, _cyl(0.17, 0.18, 0.18, 20), Vector3(0.0, 0.83, 0), trouser)
        _limb(parent, Vector3(0.0, 0.84, 0.0), Vector3(0.0, 1.28, 0.0), 0.16, shirt)
        for z2 in [-0.21, 0.21]:
            _put(parent, _sph(0.07), Vector3(0.0, 1.28, float(z2)), shirt)
            _limb(parent, Vector3(0.0, 1.28, float(z2)), Vector3(0.0, 1.02, float(z2) * 1.12), 0.055, shirt)
            _limb(parent, Vector3(0.0, 1.02, float(z2) * 1.12), Vector3(0.04, 0.80, float(z2) * 1.12), 0.042, skin)
            _put(parent, _sph(0.05), Vector3(0.05, 0.77, float(z2) * 1.12), skin)
        _limb(parent, Vector3(0.0, 1.30, 0.0), Vector3(0.02, 1.40, 0.0), 0.045, skin)
    # head
    _put(parent, _sph(0.095, 1.12), Vector3(hx, hy, 0.0), skin)
    _put(parent, _sph(0.10, 0.8), Vector3(hx - 0.02, hy + 0.04, 0.0), hair, Vector3.ZERO, Vector3(1.0, 1.0, 1.02))
    for z3 in [-0.045, 0.045]:
        _put(parent, _sph(0.014), Vector3(hx + 0.085, hy + 0.02, float(z3)), dark)
        _put(parent, _sph(0.02, 1.3), Vector3(hx - 0.005, hy, float(z3) * 2.1), skin)
    _put(parent, _sph(0.02), Vector3(hx + 0.095, hy - 0.02, 0.0), skin)
    _put(parent, _bx(Vector3(0.02, 0.012, 0.07)), Vector3(hx + 0.085, hy - 0.05, 0.0), hair)
    # yellow straw hat
    _put(parent, _sph(0.105, 0.6), Vector3(hx - 0.01, hy + 0.075, 0.0), straw)
    _put(parent, _cyl(0.155, 0.155, 0.016, 28), Vector3(hx - 0.02, hy + 0.07, 0.0), straw, Vector3(0, 0, -8 if pushing else 0))
    _put(parent, _cyl(0.106, 0.108, 0.03, 20), Vector3(hx - 0.01, hy + 0.08, 0.0), band)

func _build_standing_farmer() -> void:
    stand_node = Node3D.new()
    stand_node.name = "FarmerStanding"
    stand_node.position = Vector3(-2.6, 0.15, 1.1)
    stand_node.rotation_degrees.y = -50.0
    g.add_child(stand_node)
    _build_man(stand_node, false)
    g._bake_local(stand_node, [], "FarmerBake")

# =========================================================== the tiller rig

func _build_tiller_body(t: Node3D) -> void:
    var paint: StandardMaterial3D = _mm(Color(0.78, 0.16, 0.10), 0.38, 0.15)
    var paint2: StandardMaterial3D = _mm(Color(0.92, 0.42, 0.10), 0.4, 0.1)
    var steel: StandardMaterial3D = _mm(Color(0.62, 0.64, 0.68), 0.35, 0.55)
    var dark: StandardMaterial3D = _mm(Color(0.12, 0.12, 0.13), 0.55, 0.3)
    var rubber: StandardMaterial3D = _mm(Color(0.07, 0.07, 0.08), 0.95)
    var cast: StandardMaterial3D = _mm(Color(0.30, 0.32, 0.34), 0.5, 0.45)
    _put(t, _bx(Vector3(0.50, 0.14, 0.26)), Vector3(0.02, 0.34, 0), dark)
    _put(t, _sph(0.20, 1.0), Vector3(-0.02, 0.30, 0), cast, Vector3.ZERO, Vector3(1.1, 0.9, 1.1))
    _put(t, _cyl(0.15, 0.15, 0.40, 24), Vector3(0.20, 0.56, 0), paint, Vector3(90, 0, 0))
    _put(t, _cyl(0.17, 0.17, 0.08, 28), Vector3(0.20, 0.56, 0.26), cast, Vector3(90, 0, 0))
    _put(t, _cyl(0.12, 0.12, 0.03, 24), Vector3(0.20, 0.56, 0.31), paint2, Vector3(90, 0, 0))
    for k in range(5):
        _put(t, _cyl(0.165, 0.165, 0.012, 24), Vector3(0.20, 0.56, -0.12 + k * 0.05), cast, Vector3(90, 0, 0))
    _put(t, _bx(Vector3(0.22, 0.16, 0.30)), Vector3(0.08, 0.68, 0), paint)
    _put(t, _cyl(0.10, 0.10, 0.30, 20), Vector3(0.02, 0.84, 0), paint2, Vector3(90, 0, 0))
    _put(t, _cyl(0.035, 0.035, 0.04, 12), Vector3(0.02, 0.94, 0), dark)
    _put(t, _cyl(0.06, 0.06, 0.16, 16), Vector3(0.30, 0.78, -0.10), dark)
    _put(t, _cyl(0.05, 0.03, 0.06, 16), Vector3(0.30, 0.88, -0.10), dark)
    _put(t, _cyl(0.045, 0.045, 0.20, 16), Vector3(0.38, 0.62, 0.12), steel, Vector3(0, 0, 90))
    _rod(t, Vector3(0.40, 0.66, 0.12), Vector3(0.40, 0.98, 0.12), 0.022, steel)
    _put(t, _cyl(0.035, 0.03, 0.03, 12), Vector3(0.40, 0.99, 0.12), dark)
    _put(t, _bx(Vector3(0.06, 0.05, 0.40)), Vector3(0.52, 0.34, 0), dark)
    _rod(t, Vector3(0.04, 0.25, -0.40), Vector3(0.04, 0.25, 0.40), 0.025, steel)
    _put(t, _bx(Vector3(0.12, 0.06, 0.60)), Vector3(-0.30, 0.46, 0), paint)
    _put(t, _cyl(0.22, 0.22, 0.66, 28), Vector3(-0.55, 0.22, 0), paint2, Vector3(90, 0, 0))
    _put(t, _bx(Vector3(0.08, 0.26, 0.10)), Vector3(-0.30, 0.30, 0.34), cast)
    for z in [-0.17, 0.17]:
        _rod(t, Vector3(-0.22, 0.50, float(z) * 0.8), Vector3(-1.00, 0.95, float(z) * 1.25), 0.022, dark)
        _rod(t, Vector3(-0.98, 0.94, float(z) * 1.25), Vector3(-1.10, 0.98, float(z) * 1.3), 0.034, rubber)
        _rod(t, Vector3(-0.90, 0.92, float(z) * 1.2), Vector3(-0.82, 0.80, float(z) * 1.1), 0.01, steel)
    _rod(t, Vector3(-0.70, 0.78, -0.2), Vector3(-0.70, 0.78, 0.2), 0.018, dark)
    _put(t, _bx(Vector3(0.08, 0.10, 0.08)), Vector3(-0.40, 0.58, 0.0), steel)

func _build_wheel(parent: Node3D, z: float) -> Node3D:
    var rubber: StandardMaterial3D = _mm(Color(0.07, 0.07, 0.08), 0.95)
    var paint2: StandardMaterial3D = _mm(Color(0.92, 0.42, 0.10), 0.4, 0.1)
    var steel: StandardMaterial3D = _mm(Color(0.62, 0.64, 0.68), 0.35, 0.55)
    var w := Node3D.new()
    w.position = Vector3(0.04, 0.25, z)
    parent.add_child(w)
    _put(w, _cyl(0.25, 0.25, 0.13, 28), Vector3.ZERO, rubber, Vector3(90, 0, 0))
    _put(w, _cyl(0.15, 0.15, 0.14, 20), Vector3.ZERO, paint2, Vector3(90, 0, 0))
    _put(w, _cyl(0.05, 0.05, 0.16, 12), Vector3.ZERO, steel, Vector3(90, 0, 0))
    for k in range(12):
        var a: float = float(k) * TAU / 12.0
        _put(w, _bx(Vector3(0.05, 0.035, 0.14)), Vector3(cos(a) * 0.255, sin(a) * 0.255, 0.0), rubber, Vector3(0, 0, rad_to_deg(a)))
    g._bake_local(w, [], "WheelBake")
    return w

func _build_drum(parent: Node3D) -> Node3D:
    var steel: StandardMaterial3D = _mm(Color(0.62, 0.64, 0.68), 0.35, 0.55)
    var d := Node3D.new()
    d.position = Vector3(-0.55, 0.14, 0)
    parent.add_child(d)
    _put(d, _cyl(0.045, 0.045, 0.70, 12), Vector3.ZERO, steel, Vector3(90, 0, 0))
    for k in range(8):
        var a2: float = float(k) * TAU / 8.0
        for zz in [-0.27, -0.09, 0.09, 0.27]:
            var ph: float = a2 + (0.35 if int(round(float(zz) * 10.0)) % 2 == 0 else 0.0)
            _put(d, _bx(Vector3(0.025, 0.11, 0.05)), Vector3(sin(ph) * 0.11, -cos(ph) * 0.11, float(zz)), steel, Vector3(0, 0, rad_to_deg(-ph)))
    g._bake_local(d, [], "DrumBake")
    return d

func _build_rig() -> void:
    if rig != null:
        return
    rig = Node3D.new()
    rig.name = "TillerRig"
    rig.position = rp
    g.add_child(rig)
    var man := Node3D.new()
    rig.add_child(man)
    _build_man(man, true)
    g._bake_local(man, [], "ManBake")
    var body := Node3D.new()
    body.position = Vector3(1.5, 0, 0)
    rig.add_child(body)
    _build_tiller_body(body)
    wheels = [_build_wheel(body, -0.40), _build_wheel(body, 0.40)]
    drum = _build_drum(body)
    g._bake_local(body, wheels + [drum], "TillerBake")
    # exhaust smoke
    var sm: StandardMaterial3D = _mm(Color(0.82, 0.82, 0.85), 1.0, 0.0, 0.5)
    puffs.clear()
    for i in range(4):
        var p: MeshInstance3D = _put(body, _sph(0.06), Vector3(0.40, 1.0, 0.12), sm)
        puffs.append({"n": p, "t": float(i) * 0.4})
    rig.visible = true

# =========================================================== hire

func hire(keep_pos: bool = false) -> void:
    if hired:
        return
    hired = true
    if stand_node != null:
        stand_node.visible = false
        if not keep_pos:
            rp = stand_node.position
    _build_rig()
    heading = 0.0
    _place_rig()
    if not keep_pos:
        g._show_toast("Farm hand hired! Tap any plot and he will till it.")

func _place_rig() -> void:
    if rig == null:
        return
    rig.position = rp
    rig.rotation.y = -heading

func start_auto() -> void:
    auto_on = true

# =========================================================== plot taps

func on_plot_tap(key: String) -> bool:
    # Returns true when the tap was used up (care action).
    var st: Dictionary = g.crop_states.get(key, {})
    if care.has(key):
        var ripe: bool = st.get("planted", false) and float(st.get("age", 0.0)) >= g._grow_time_of(st)
        if not (ripe and g.active_action == "harvest"):
            _clear_care(key, true)
            return true
    if hired:
        _queue_till(key)
    return false

func _queue_till(key: String) -> void:
    var st: Dictionary = g.crop_states.get(key, {})
    if st.get("planted", false) and float(st.get("age", 0.0)) >= g._grow_time_of(st):
        return
    if tilled.has(key) or queue.has(key) or cur_key == key:
        return
    if queue.size() >= 8:
        return
    queue.append(key)

func on_harvest(key: String) -> void:
    _remove_tilled(key)
    _clear_care(key, false)
    care_next.erase(key)

# =========================================================== growth

func growth_mult(key: String) -> float:
    var m: float = 1.0
    if tilled.has(key):
        m *= 1.2
    var c: String = str(care.get(key, ""))
    if c == "water":
        m *= 0.45
    elif c == "weed":
        m *= 0.7
    return m

# =========================================================== process

func tick(delta: float) -> void:
    anim_t += delta
    tilled_clock += delta
    if tilled_clock >= 1.0:
        var dt2: float = tilled_clock
        tilled_clock = 0.0
        for k in tilled.keys():
            var st2: Dictionary = g.crop_states.get(k, {})
            if not st2.get("planted", false):
                tilled[k] = float(tilled[k]) - dt2
                if float(tilled[k]) <= 0.0:
                    _remove_tilled(str(k))
    _tick_worker(delta)
    _tick_care(delta)
    _tick_hunger(delta)
    _tick_icons(delta)
    tick_islands(delta)
    watch_t += delta
    if watch_t >= 3.0:
        watch_t = 0.0
        _watch_alerts()

func _tick_worker(delta: float) -> void:
    if not hired or rig == null:
        return
    var moving: bool = false
    var tilling: bool = false
    if phase == 0:
        if cur_key == "":
            if queue.size() > 0:
                cur_key = str(queue.pop_front())
                if tilled.has(cur_key) or not g.plot_centers.has(cur_key):
                    cur_key = ""
                else:
                    if g.energy < TILL_ENERGY:
                        queue.clear()
                        cur_key = ""
                        alert("no_energy")
                    else:
                        phase = 1
            elif auto_on:
                auto_t += delta
                if auto_t >= 1.5:
                    auto_t = 0.0
                    _auto_pick()
    if phase == 1:
        var c: Vector3 = g.plot_centers[cur_key]
        run_d = _run_dir_for(cur_key)
        var s: Vector3 = Vector3(c.x - 1.7 * run_d.x, 0.15, c.z - 1.7 * run_d.y)
        var to: Vector3 = s - rp
        to.y = 0.0
        var dist: float = to.length()
        if dist > 0.08:
            var want: float = atan2(to.z, to.x)
            heading = lerp_angle(heading, want, minf(1.0, delta * 8.0))
            rp += to.normalized() * minf(dist, WALK_SPEED * delta)
            moving = true
        else:
            rp = s
            phase = 2
    elif phase == 2:
        var want_h: float = atan2(run_d.y, run_d.x)
        heading = lerp_angle(heading, want_h, minf(1.0, delta * 8.0))
        if absf(angle_difference(heading, want_h)) < 0.06:
            heading = want_h
            run_from = rp
            run_to = Vector3(rp.x + 1.5 * run_d.x, 0.15, rp.z + 1.5 * run_d.y)
            run_t = 0.0
            phase = 3
    elif phase == 3:
        run_t += delta * TILL_SPEED / 1.5
        rp = run_from.lerp(run_to, minf(run_t, 1.0))
        moving = true
        tilling = true
        if run_t >= 1.0:
            _finish_till(cur_key)
            cur_key = ""
            phase = 0
    engine_on = moving
    if is_instance_valid(drum):
        drum.rotation.z -= delta * (14.0 if tilling else 0.0)
    if moving:
        var spd: float = (TILL_SPEED if tilling else WALK_SPEED)
        for w in wheels:
            (w as Node3D).rotation.z -= delta * spd / 0.25
    _place_rig()
    rig.position.y = rp.y + (sin(anim_t * 18.0) * 0.012 if moving else 0.0)
    for pf in puffs:
        var d: Dictionary = pf
        var n: MeshInstance3D = d["n"]
        d["t"] = float(d["t"]) + delta * (1.0 if engine_on else 0.5)
        var tt: float = fmod(float(d["t"]), 1.6) / 1.6
        n.position = Vector3(0.40 - tt * 0.1, 1.0 + tt * 0.65, 0.12)
        n.scale = Vector3.ONE * (0.6 + tt * 1.6)
        n.visible = engine_on or tt < 0.35

func _field_of(key: String) -> Array:
    # all plots joined to this one (the field it belongs to)
    var cs: float = float(g.CELL)
    var seen: Dictionary = {key: true}
    var todo: Array = [key]
    while todo.size() > 0:
        var k: String = str(todo.pop_back())
        var p: Vector3 = g.plot_centers[k]
        for k2 in g.plot_centers.keys():
            var ks: String = str(k2)
            if seen.has(ks):
                continue
            var q: Vector3 = g.plot_centers[k2]
            if absf(q.x - p.x) < cs * 1.1 and absf(q.z - p.z) < cs * 1.1:
                seen[ks] = true
                todo.append(ks)
    return seen.keys()

func _viol(p: Vector2, lo: Vector2, hi: Vector2) -> float:
    return maxf(0.0, lo.x - p.x) + maxf(0.0, p.x - hi.x) + maxf(0.0, lo.y - p.y) + maxf(0.0, p.y - hi.y)

func _run_dir_for(key: String) -> Vector2:
    # Pick the walking direction (east, west, north or south) that keeps the farm hand AND
    # the front of his tiller over the field as much as possible.
    var c: Vector3 = g.plot_centers[key]
    var half: float = float(g.CELL) * 0.5
    var lo: Vector2 = Vector2(1000.0, 1000.0)
    var hi: Vector2 = Vector2(-1000.0, -1000.0)
    for k in _field_of(key):
        var p: Vector3 = g.plot_centers[k]
        lo = Vector2(minf(lo.x, p.x - half), minf(lo.y, p.z - half))
        hi = Vector2(maxf(hi.x, p.x + half), maxf(hi.y, p.z + half))
    var best: Vector2 = Vector2(1, 0)
    var best_v: float = 1000.0
    for d in [Vector2(1, 0), Vector2(-1, 0), Vector2(0, 1), Vector2(0, -1)]:
        var cc: Vector2 = Vector2(c.x, c.z)
        var man: Vector2 = cc - d * 1.7
        var nose: Vector2 = cc + d * (0.2 + 1.5 + 0.1)
        var v: float = 3.0 * _viol(man, lo, hi) + _viol(nose, lo, hi)
        if v < best_v - 0.001:
            best_v = v
            best = d
    return best

func _finish_till(key: String) -> void:
    if g.energy >= TILL_ENERGY:
        g.energy -= TILL_ENERGY
    tilled[key] = TILL_KEEP
    _add_tilled_overlay(key)
    g._add_xp(1)
    g._update_pill_extra()
    g._save_game()

func _auto_pick() -> void:
    # 1) crops that need care, 2) growing crops that are not tilled yet.
    var best_care: String = ""
    var best_till: String = ""
    for key in g.crop_states.keys():
        var k: String = str(key)
        var st: Dictionary = g.crop_states[key]
        if not st.get("planted", false):
            continue
        if care.has(k):
            best_care = k
            break
        if best_till == "" and not tilled.has(k) and float(st.get("age", 0.0)) < g._grow_time_of(st):
            best_till = k
    if best_care != "":
        # the farm hand walks over and fixes it
        _clear_care(best_care, true)
        return
    if best_till != "" and g.energy >= TILL_ENERGY:
        queue.append(best_till)

# =========================================================== tilled soil visuals

func _add_tilled_overlay(key: String) -> void:
    if tilled_nodes.has(key) or not g.plot_centers.has(key):
        return
    var c: Vector3 = g.plot_centers[key]
    var n := Node3D.new()
    n.name = "Tilled_" + key
    n.position = Vector3(c.x, 0.0, c.z)
    g.add_child(n)
    for j in range(5):
        _put(n, _bx(Vector3(1.3, 0.025, 0.10)), Vector3(0.0, 0.142, -0.55 + j * 0.275), soil_dark)
    var rng := RandomNumberGenerator.new()
    rng.seed = key.hash()
    for k in range(10):
        var r: float = 0.03 + rng.randf() * 0.03
        _put(n, _sph(r, 0.7), Vector3(rng.randf_range(-0.6, 0.6), 0.15 + r * 0.3, rng.randf_range(-0.6, 0.6)), soil_clod, Vector3(0, rng.randf() * 180.0, 0), Vector3(1.2, 0.8, 1.0))
    g._bake_local(n, [], "TilledBake")
    tilled_nodes[key] = n

func _remove_tilled(key: String) -> void:
    tilled.erase(key)
    if tilled_nodes.has(key):
        var n: Variant = tilled_nodes[key]
        if n != null and is_instance_valid(n):
            (n as Node).queue_free()
        tilled_nodes.erase(key)

# =========================================================== crop care

func _tick_care(delta: float) -> void:
    care_clock += delta
    if care_clock < 1.0:
        return
    var dt: float = care_clock
    care_clock = 0.0
    for key in g.crop_states.keys():
        var k: String = str(key)
        var st: Dictionary = g.crop_states[key]
        if not st.get("planted", false):
            continue
        if care.has(k):
            continue
        if not care_next.has(k):
            care_next[k] = randf_range(45.0, 110.0)
        care_next[k] = float(care_next[k]) - dt
        if float(care_next[k]) <= 0.0:
            var ripe: bool = float(st.get("age", 0.0)) >= g._grow_time_of(st)
            care_next[k] = randf_range(70.0, 150.0)
            if not ripe and randf() < 0.55:
                _set_care(k, "water" if randf() < 0.55 else "weed")

func _set_care(key: String, need: String) -> void:
    care[key] = need
    if care_icons.has(key):
        return
    var c: Vector3 = g.plot_centers[key]
    var n := Node3D.new()
    n.name = "CareIcon_" + key
    n.position = Vector3(c.x, 0.9, c.z)
    g.add_child(n)
    var plate: StandardMaterial3D = _mm(Color(1, 1, 1), 0.9, 0.0, 0.85)
    plate.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    var disc: MeshInstance3D = _put(n, _cyl(0.34, 0.34, 0.04, 20), Vector3.ZERO, plate, Vector3(55, 0, 0))
    disc.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    if need == "water":
        var blue: StandardMaterial3D = _mm(Color(0.20, 0.55, 0.98), 0.3)
        blue.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
        _put(n, _sph(0.15, 1.05), Vector3(0, -0.04, 0.10), blue)
        _put(n, _cyl(0.0, 0.10, 0.20, 14), Vector3(0, 0.15, 0.10), blue)
    else:
        var gr: StandardMaterial3D = _mm(Color(0.22, 0.70, 0.22), 0.5)
        gr.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
        for i in range(3):
            var a: float = (float(i) - 1.0) * 24.0
            _put(n, _bx(Vector3(0.05, 0.30, 0.04)), Vector3((float(i) - 1.0) * 0.09, 0.0, 0.1), gr, Vector3(0, 0, -a))
    care_icons[key] = n

func _clear_care(key: String, reward: bool) -> void:
    if care.has(key):
        care.erase(key)
        if reward:
            g._add_xp(1)
            g._play_named("ding", -14.0)
            g._show_toast("Crop looked after! Growing normally again.")
    if care_icons.has(key):
        var n: Variant = care_icons[key]
        if n != null and is_instance_valid(n):
            (n as Node).queue_free()
        care_icons.erase(key)
    care_next[key] = randf_range(70.0, 150.0)

# =========================================================== animal care

func after_collect(p: Dictionary) -> void:
    var kind: int = int(p["kind"])
    if kind > 2:
        return
    p["cycles"] = int(p.get("cycles", 0)) + 1
    if int(p["cycles"]) % 3 == 0:
        p["hungry"] = true

func _tick_hunger(delta: float) -> void:
    hunger_clock += delta
    if hunger_clock < 0.5:
        return
    hunger_clock = 0.0
    for p in g.producers:
        var node: Node3D = p["node"]
        if not is_instance_valid(node):
            continue
        var hungry: bool = bool(p.get("hungry", false))
        var icon: Variant = p.get("hicon", null)
        if hungry and (icon == null or not is_instance_valid(icon)):
            var n := Node3D.new()
            n.name = "HungerIcon"
            n.position = Vector3(0, float(g.PROD_HEIGHT[int(p["kind"])]) + 0.15, 0)
            n.scale = Vector3.ONE * 1.4
            node.add_child(n)
            var plate: StandardMaterial3D = _mm(Color(1, 1, 1), 0.9, 0.0, 0.85)
            plate.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
            _put(n, _cyl(0.32, 0.32, 0.04, 20), Vector3.ZERO, plate, Vector3(55, 0, 0))
            var brown: StandardMaterial3D = _mm(Color(0.52, 0.32, 0.14), 0.7)
            brown.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
            var hay: StandardMaterial3D = _mm(Color(0.95, 0.78, 0.25), 0.9)
            hay.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
            _put(n, _cyl(0.17, 0.11, 0.12, 14), Vector3(0, -0.05, 0.1), brown)
            _put(n, _sph(0.15, 0.7), Vector3(0, 0.03, 0.1), hay)
            p["hicon"] = n
        elif not hungry and icon != null and is_instance_valid(icon):
            (icon as Node).queue_free()
            p["hicon"] = null

func tap_hungry(p2: Vector2) -> bool:
    var best: Dictionary = {}
    var best_d: float = 0.9
    for p in g.producers:
        if not bool(p.get("hungry", false)):
            continue
        var node: Node3D = p["node"]
        if not is_instance_valid(node):
            continue
        var base: Vector2 = Vector2(node.global_position.x, node.global_position.z)
        var h: float = float(g.PROD_HEIGHT[int(p["kind"])])
        var top: Vector2 = base + Vector2(-0.76 * h, -1.13 * h)
        var d: float = g._dist_to_segment(p2, base, top)
        if d < best_d:
            best_d = d
            best = p
    if best.is_empty():
        return false
    if int(g.coins) < FEED_COST:
        g._show_toast("Feed costs %d coins." % FEED_COST)
        return true
    g.coins -= FEED_COST
    best["hungry"] = false
    g._play_named("ding", -12.0)
    g._add_xp(1)
    g._refresh_ui()
    g._show_toast("Fed the animal (-%d coins). It is producing again." % FEED_COST)
    return true

func _tick_icons(delta: float) -> void:
    for key in care_icons.keys():
        var n: Variant = care_icons[key]
        if n != null and is_instance_valid(n):
            (n as Node3D).position.y = 0.9 + sin(anim_t * 3.0 + float(str(key).hash() % 7)) * 0.06
    for p in g.producers:
        var ic: Variant = p.get("hicon", null)
        if ic != null and is_instance_valid(ic):
            (ic as Node3D).position.y = float(g.PROD_HEIGHT[int(p["kind"])]) + 0.15 + sin(anim_t * 3.0) * 0.07

# =========================================================== upgrade helpers

func batt_cap() -> int:
    return int(BATT_CAP[batt_level - 1])

func wm_interval() -> float:
    return float(WM_INT[wm_level - 1])

func wm_pay_bonus() -> int:
    return int(WM_BONUS[wm_level - 1])

func mode_cap(mode: int, base: int) -> int:
    return base + (cargo_level - 1) * int(CARGO_BONUS[mode])

func _can_pay(cost: int, need_lv: int) -> bool:
    return int(g.coins) >= cost and int(g.level) >= need_lv

func _buy(cost: int) -> void:
    g.coins -= cost
    g._play_named("jingle", -8.0)
    g._refresh_ui()
    g._update_pill_extra()
    g._save_game()

func _upgrade_barn() -> bool:
    if g.barn_bonus >= 90 or g.level < g.BARN_LV or g.coins < g._barn_upgrade_cost():
        return false
    g._buy_expand(2)
    return true

func _upgrade_hydro() -> bool:
    if not g.hydro_unlocked or g.hydro_level >= 3:
        return false
    if g.coins < g._hydro_upgrade_cost():
        return false
    if (g.hydro_level == 1 and g.level < 9) or (g.hydro_level == 2 and g.level < 11):
        return false
    g._hydro_action(5)
    return true

func _upgrade_batt() -> bool:
    if batt_level >= 3 or not g.hydro_unlocked:
        return false
    var cost: int = int(BATT_COST[batt_level - 1])
    if not _can_pay(cost, int(BATT_REQ[batt_level - 1])):
        return false
    _buy(cost)
    batt_level += 1
    g._show_toast("Batteries upgraded! Storage now %d energy." % batt_cap())
    return true

func _upgrade_wm() -> bool:
    if wm_level >= 3 or not g.wm_unlocked:
        return false
    var cost: int = int(WM_COST[wm_level - 1])
    if not _can_pay(cost, int(WM_REQ[wm_level - 1])):
        return false
    _buy(cost)
    wm_level += 1
    g._show_toast("Windmill upgraded! Grinds every %d s." % int(wm_interval()))
    return true

func _upgrade_cargo() -> bool:
    if cargo_level >= 3 or not g.trade_unlocked:
        return false
    var cost: int = int(CARGO_COST[cargo_level - 1])
    if not _can_pay(cost, int(CARGO_REQ[cargo_level - 1])):
        return false
    _buy(cost)
    cargo_level += 1
    g._show_toast("Carriers upgraded! They can take bigger loads.")
    return true

# =========================================================== upgrade hub panel

func _build_hub_panel() -> void:
    var made: Array = g._new_panel("🔧 UPGRADES & HELP", 0.05, 0.95)
    up_panel = made[0]
    var col: VBoxContainer = made[1]
    up_coin = g._panel_label(col, 18)
    up_col = VBoxContainer.new()
    up_col.add_theme_constant_override("separation", 6)
    up_col.size_flags_vertical = Control.SIZE_EXPAND_FILL
    col.add_child(up_col)
    var close: Button = g._panel_button(col, "CLOSE", 44, 18)
    close.pressed.connect(g._close_panels)

func open_hub() -> void:
    g._close_panels()
    up_panel.visible = true
    refresh_hub()

func refresh_hub() -> void:
    if up_panel == null:
        return
    up_coin.text = "Your coins: %d      Level %d" % [int(g.coins), int(g.level)]
    for c in up_col.get_children():
        c.queue_free()
    # 1 farm hand
    if not hired:
        _row("🚜 Hire Farm Hand + Power Tiller", "Lv %d  •  %d coins\nTills the plots you tap. Crops grow 20%% faster. Uses 1 energy per plot." % [HIRE_LV, HIRE_COST], _can_pay(HIRE_COST, HIRE_LV), func():
            _buy(HIRE_COST)
            hire())
    elif not auto_on:
        _row("🤖 Auto-Farming for the Farm Hand", "Lv %d  •  %d coins\nHe tills and looks after thirsty / weedy crops by himself." % [AUTO_LV, AUTO_COST], _can_pay(AUTO_COST, AUTO_LV), func():
            _buy(AUTO_COST)
            start_auto()
            g._show_toast("Auto-farming ON! He will work on his own."))
    else:
        _row("🚜 Farm Hand: Auto-Farming ON", "MAX LEVEL", false, Callable())
    # 2 barn
    if g.barn_bonus >= 90:
        _row("📦 Barn", "MAX LEVEL  •  space %d" % g._barn_cap(), false, Callable())
    else:
        _row("📦 Barn  (space %d → %d)" % [g._barn_cap(), g._barn_cap() + 30], "Lv %d  •  %d coins" % [g.BARN_LV, g._barn_upgrade_cost()], g.level >= g.BARN_LV and g.coins >= g._barn_upgrade_cost(), func(): _upgrade_barn())
    # 3 power station
    if not g.hydro_unlocked:
        _row("⚡ Power Station", "Unlocks at Level %d" % g.HYDRO_LV, false, Callable())
    elif g.hydro_level >= 3:
        _row("⚡ Power Station", "MAX LEVEL  •  %d energy per minute" % int(round(g._hydro_rate() * 60.0)), false, Callable())
    else:
        var hreq: int = 9 if g.hydro_level == 1 else 11
        _row("⚡ Power Station  (Level %d → %d)" % [g.hydro_level, g.hydro_level + 1], "Lv %d  •  %d coins\nMore energy and a bigger station store." % [hreq, g._hydro_upgrade_cost()], g.level >= hreq and g.coins >= g._hydro_upgrade_cost(), func(): _upgrade_hydro())
    # 4 batteries
    if not g.hydro_unlocked:
        _row("🔋 Batteries", "Unlocks with the Power Station", false, Callable())
    elif batt_level >= 3:
        _row("🔋 Batteries", "MAX LEVEL  •  stores %d energy" % batt_cap(), false, Callable())
    else:
        var bc: int = int(BATT_COST[batt_level - 1])
        var br: int = int(BATT_REQ[batt_level - 1])
        _row("🔋 Batteries  (%d → %d energy)" % [batt_cap(), int(BATT_CAP[batt_level])], "Lv %d  •  %d coins" % [br, bc], _can_pay(bc, br), func(): _upgrade_batt())
    # 5 windmill
    if not g.wm_unlocked:
        _row("🌬 Windmill", "Unlocks at Level %d" % g.WINDMILL_LV, false, Callable())
    elif wm_level >= 3:
        _row("🌬 Windmill", "MAX LEVEL  •  every %d s, +%d coins" % [int(wm_interval()), wm_pay_bonus()], false, Callable())
    else:
        var wc: int = int(WM_COST[wm_level - 1])
        var wr: int = int(WM_REQ[wm_level - 1])
        _row("🌬 Windmill  (Level %d → %d)" % [wm_level, wm_level + 1], "Lv %d  •  %d coins\nGrinds faster and pays more." % [wr, wc], _can_pay(wc, wr), func(): _upgrade_wm())
    # 6 carriers
    if not g.trade_unlocked:
        _row("🚚 Trade Carriers", "Unlocks with the Trade Centre", false, Callable())
    elif cargo_level >= 3:
        _row("🚚 Trade Carriers", "MAX LEVEL  •  bigger loads for every vehicle", false, Callable())
    else:
        var cc: int = int(CARGO_COST[cargo_level - 1])
        var cr: int = int(CARGO_REQ[cargo_level - 1])
        _row("🚚 Trade Carriers  (Level %d → %d)" % [cargo_level, cargo_level + 1], "Lv %d  •  %d coins\nTrain, truck, drone and plane carry more per trip." % [cr, cc], _can_pay(cc, cr), func(): _upgrade_cargo())

func _row(title: String, desc: String, enabled: bool, act: Callable) -> void:
    var b: Button = g._panel_button(up_col, "%s\n%s" % [title, desc], 70, 16)
    b.disabled = (not enabled) or not act.is_valid()
    if act.is_valid():
        b.pressed.connect(func():
            act.call()
            refresh_hub())

# =========================================================== alerts

func _build_alert_panel() -> void:
    var made: Array = g._new_panel("⚠ HEADS UP", 0.26, 0.74)
    al_panel = made[0]
    var col: VBoxContainer = made[1]
    al_msg = g._panel_label(col, 20, Color(1, 0.96, 0.85))
    al_msg.size_flags_vertical = Control.SIZE_EXPAND_FILL
    al_b1 = g._panel_button(col, "", 66, 18)
    al_b2 = g._panel_button(col, "", 66, 18)
    var close: Button = g._panel_button(col, "NOT NOW", 44, 18)
    close.pressed.connect(g._close_panels)
    al_b1.pressed.connect(func(): _alert_do(1))
    al_b2.pressed.connect(func(): _alert_do(2))

func _alert_do(i: int) -> void:
    var a: Callable = al_act1 if i == 1 else al_act2
    g._close_panels()
    if a.is_valid():
        a.call()

func alert(kind: String, force: bool = false) -> void:
    var now: float = float(Time.get_ticks_msec()) / 1000.0
    var cool: float = 90.0 if kind != "power_full" else 300.0
    if al_cool.has(kind) and now - float(al_cool[kind]) < cool:
        return
    if g._any_panel_open() and not force:
        return
    al_cool[kind] = now
    al_kind = kind
    var m1: String = ""
    var m2: String = ""
    var msg: String = ""
    var a1: Callable
    var a2: Callable
    if kind == "barn":
        msg = "Your barn is full (%d / %d items)!\nNew harvests are sold at once instead of being stored. What would you like to do?" % [g._stock_total(), g._barn_cap()]
        m1 = "📦 Sell items from the barn"
        a1 = func(): g._toggle_panel("market", g._open_market)
        if g.barn_bonus >= 90:
            m2 = "Barn is already at its biggest size"
        else:
            m2 = "⬆ Upgrade Barn (+30 space)\n%d coins  •  need Level %d" % [g._barn_upgrade_cost(), g.BARN_LV]
            a2 = func():
                if not _upgrade_barn():
                    g._show_toast("Not enough coins or level for the barn upgrade yet.")
    elif kind == "power_full":
        msg = "Your power station is full (%d / %d)!\nIt stops making energy until you collect it." % [int(g.energy_store), g._hydro_cap()]
        m1 = "⚡ Open power station and collect"
        a1 = func(): g._toggle_panel("hydro", g._open_hydro)
        if g.energy >= g._batt_cap() and batt_level < 3:
            m2 = "🔋 Bigger batteries (%d coins)" % int(BATT_COST[batt_level - 1])
            a2 = func():
                if not _upgrade_batt():
                    g._show_toast("Not enough coins or level for bigger batteries yet.")
        elif g.hydro_level < 3:
            m2 = "⬆ Upgrade Power Station\n%d coins" % g._hydro_upgrade_cost()
            a2 = func():
                if not _upgrade_hydro():
                    g._show_toast("Not enough coins or level for that upgrade yet.")
        else:
            m2 = "Power station is at maximum level"
    elif kind == "no_energy":
        msg = "Your farm hand has no energy left for the tiller!\nCollect energy from the power station, or make more."
        m1 = "⚡ Open power station"
        a1 = func(): g._toggle_panel("hydro", g._open_hydro)
        if g.hydro_level < 3:
            m2 = "⬆ Upgrade Power Station\n%d coins" % g._hydro_upgrade_cost()
            a2 = func():
                if not _upgrade_hydro():
                    g._show_toast("Not enough coins or level for that upgrade yet.")
        else:
            m2 = "Power station is at maximum level"
    elif kind == "cargo":
        msg = "That order is too heavy for the chosen vehicle.\nUpgrade the carriers to move bigger loads."
        if cargo_level < 3:
            m1 = "⬆ Upgrade Trade Carriers\n%d coins  •  need Level %d" % [int(CARGO_COST[cargo_level - 1]), int(CARGO_REQ[cargo_level - 1])]
            a1 = func():
                if not _upgrade_cargo():
                    g._show_toast("Not enough coins or level for the carrier upgrade yet.")
        else:
            m1 = "Carriers are at maximum level"
        m2 = "OK, I will split the order"
    al_msg.text = msg
    al_b1.text = m1
    al_b1.disabled = not a1.is_valid()
    al_b2.text = m2
    al_b2.disabled = not a2.is_valid()
    al_act1 = a1
    al_act2 = a2
    g._close_panels()
    al_panel.visible = true
    g.panel_owner = "alert"

func _watch_alerts() -> void:
    # no automatic alerts during the first minute after the game opens
    if anim_t < 60.0:
        return
    if g._stock_total() < g._barn_cap():
        al_cool.erase("barn")
    if g.hydro_unlocked and not g._any_panel_open():
        if int(g.energy_store) >= g._hydro_cap() - 1 and g.energy >= 0:
            alert("power_full")

# =========================================================== settings panel

func _build_settings_panel() -> void:
    var made: Array = g._new_panel("⚙ SETTINGS", 0.05, 0.95)
    set_panel = made[0]
    var col: VBoxContainer = made[1]
    set_info = g._panel_label(col, 16, Color(0.85, 0.97, 1.0))
    sound_btn = g._panel_button(col, "", 50, 18)
    sound_btn.pressed.connect(func():
        g._toggle_sound()
        _refresh_settings())
    var gl: Label = g._panel_label(col, 17, Color(1.0, 0.91, 0.45))
    gl.text = "Graphics quality"
    var row := HBoxContainer.new()
    row.add_theme_constant_override("separation", 6)
    col.add_child(row)
    gfx_buttons.clear()
    var names: Array = ["Auto", "High", "Medium", "Low"]
    for i in range(4):
        var b := Button.new()
        b.text = str(names[i])
        b.custom_minimum_size = Vector2(0, 48)
        b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        b.add_theme_font_size_override("font_size", 17)
        b.pressed.connect(func(): _set_gfx(i))
        row.add_child(b)
        gfx_buttons.append(b)
    var sl: Label = g._panel_label(col, 17, Color(1.0, 0.91, 0.45))
    sl.text = "Back up / move your farm"
    var copy: Button = g._panel_button(col, "📋 Copy my save code", 50, 17)
    copy.pressed.connect(_export_code)
    code_edit = LineEdit.new()
    code_edit.placeholder_text = "Paste a save code here"
    code_edit.custom_minimum_size = Vector2(0, 46)
    col.add_child(code_edit)
    var paste: Button = g._panel_button(col, "📥 Load farm from the code above", 50, 17)
    paste.pressed.connect(_import_code)
    var close: Button = g._panel_button(col, "CLOSE", 44, 18)
    close.pressed.connect(g._close_panels)

func open_settings() -> void:
    g._close_panels()
    set_panel.visible = true
    _refresh_settings()

func _refresh_settings() -> void:
    set_info.text = "Little Village Farm 3D  •  version %s" % str(ProjectSettings.get_setting("application/config/version", "0.6.0"))
    sound_btn.text = "🔊 Sound: ON" if g.sound_on else "🔇 Sound: OFF"
    for i in range(gfx_buttons.size()):
        (gfx_buttons[i] as Button).disabled = (i == gfx_mode)

func _set_gfx(i: int) -> void:
    gfx_mode = i
    _apply_gfx()
    _save_settings()
    _refresh_settings()
    g._show_toast("Graphics: " + str(["Auto", "High", "Medium", "Low"][i]))

func _apply_gfx() -> void:
    var vp: Viewport = g.get_viewport()
    if gfx_mode == 0:
        g.adaptive_quality = true
        g.quality_level = 0
        vp.scaling_3d_scale = 1.0
    elif gfx_mode == 1:
        g.adaptive_quality = false
        g.quality_level = 0
        vp.scaling_3d_scale = 1.0
    elif gfx_mode == 2:
        g.adaptive_quality = false
        g.quality_level = 2
        vp.scaling_3d_scale = 0.85
    else:
        g.adaptive_quality = false
        g.quality_level = 3
        vp.scaling_3d_scale = 0.7
    g._apply_quality()
    if gfx_mode <= 1 and g.sun_light != null:
        g.sun_light.shadow_enabled = true
        g.sun_light.directional_shadow_max_distance = 60.0

func _save_settings() -> void:
    var c := ConfigFile.new()
    c.set_value("v27", "gfx", gfx_mode)
    c.save("user://v27_settings.cfg")

func _load_settings() -> void:
    var c := ConfigFile.new()
    if c.load("user://v27_settings.cfg") == OK:
        gfx_mode = clampi(int(c.get_value("v27", "gfx", 0)), 0, 3)

# ---- save code ----

func _export_code() -> void:
    g._save_game()
    var f := FileAccess.open("user://farm_save.cfg", FileAccess.READ)
    if f == null:
        g._show_toast("No save file yet.")
        return
    var text: String = f.get_as_text()
    f.close()
    var raw: PackedByteArray = text.to_utf8_buffer()
    var comp: PackedByteArray = raw.compress(FileAccess.COMPRESSION_DEFLATE)
    var code: String = "LVF1:%d:%s" % [raw.size(), Marshalls.raw_to_base64(comp)]
    code_edit.text = code
    DisplayServer.clipboard_set(code)
    g._show_toast("Save code copied! Paste it somewhere safe.")

func _import_code() -> void:
    var code: String = code_edit.text.strip_edges()
    if code == "":
        code = DisplayServer.clipboard_get().strip_edges()
    if not code.begins_with("LVF1:"):
        g._show_toast("That is not a save code.")
        return
    var parts: PackedStringArray = code.split(":", false, 2)
    if parts.size() < 3:
        g._show_toast("The save code looks cut off.")
        return
    var size: int = int(parts[1])
    if size <= 0 or size > 2000000:
        g._show_toast("The save code looks damaged.")
        return
    var comp: PackedByteArray = Marshalls.base64_to_raw(parts[2])
    if comp.is_empty():
        g._show_toast("The save code looks damaged.")
        return
    var raw: PackedByteArray = comp.decompress(size, FileAccess.COMPRESSION_DEFLATE)
    if raw.size() != size:
        g._show_toast("The save code looks damaged.")
        return
    var text: String = raw.get_string_from_utf8()
    var test := ConfigFile.new()
    if test.parse(text) != OK or not test.has_section("farm"):
        g._show_toast("The save code is not a farm save.")
        return
    # keep a backup of the current farm, then replace it
    var old := FileAccess.open("user://farm_save.cfg", FileAccess.READ)
    if old != null:
        var bk := FileAccess.open("user://farm_save_backup.cfg", FileAccess.WRITE)
        if bk != null:
            bk.store_string(old.get_as_text())
            bk.close()
        old.close()
    var out := FileAccess.open("user://farm_save.cfg", FileAccess.WRITE)
    if out == null:
        g._show_toast("Could not write the save.")
        return
    out.store_string(text)
    out.close()
    g.set_meta("skip_save", true)
    g._show_toast("Farm loaded! Restarting...")
    g.get_tree().reload_current_scene()

# =========================================================== save / load

func save(c: ConfigFile) -> void:
    c.set_value("v27", "hired", hired)
    c.set_value("v27", "auto", auto_on)
    c.set_value("v27", "tilled", tilled.keys())
    c.set_value("v27", "care", care)
    c.set_value("v27", "batt", batt_level)
    c.set_value("v27", "wm", wm_level)
    c.set_value("v27", "cargo", cargo_level)
    var hs: Array = []
    for p in g.producers:
        hs.append([bool(p.get("hungry", false)), int(p.get("cycles", 0))])
    c.set_value("v27", "hunger", hs)
    if rig != null:
        c.set_value("v27", "rp", Vector2(rp.x, rp.z))

func load_levels(c: ConfigFile) -> void:
    batt_level = clampi(int(c.get_value("v27", "batt", 1)), 1, 3)
    wm_level = clampi(int(c.get_value("v27", "wm", 1)), 1, 3)
    cargo_level = clampi(int(c.get_value("v27", "cargo", 1)), 1, 3)
    var hs: Variant = c.get_value("v27", "hunger", [])
    if hs is Array:
        var arr: Array = hs
        for i in range(mini(arr.size(), g.producers.size())):
            var e: Array = arr[i]
            var p: Dictionary = g.producers[i]
            p["hungry"] = bool(e[0])
            p["cycles"] = int(e[1])

func load_world(c: ConfigFile) -> void:
    var tl: Variant = c.get_value("v27", "tilled", [])
    if tl is Array:
        for k in tl:
            var key: String = str(k)
            if g.plot_centers.has(key) and g.crop_states.has(key) and g.crop_states[key].get("planted", false):
                tilled[key] = TILL_KEEP
                _add_tilled_overlay(key)
    var cr: Variant = c.get_value("v27", "care", {})
    if cr is Dictionary:
        for k in cr.keys():
            var key2: String = str(k)
            if g.plot_centers.has(key2) and g.crop_states.has(key2) and g.crop_states[key2].get("planted", false):
                _set_care(key2, str(cr[k]))
    if bool(c.get_value("v27", "hired", false)):
        var rv: Variant = c.get_value("v27", "rp", Vector2(-2.6, 1.1))
        if rv is Vector2:
            rp = Vector3((rv as Vector2).x, 0.15, (rv as Vector2).y)
        hired = false
        hire(true)
        _place_rig()
    auto_on = bool(c.get_value("v27", "auto", false)) and hired

# ===========================================================================
# v27i — see every island: locked-island markers, map view, wider camera range
# ===========================================================================

const ISLES := [
    {"c": Vector2(31.0, 23.0), "r": 4.6, "h": 3.4},
    {"c": Vector2(-27.0, 31.0), "r": 3.8, "h": 3.4},
    {"c": Vector2(38.0, -11.0), "r": 3.6, "h": 5.4},
    {"c": Vector2(-40.0, 11.0), "r": 4.3, "h": 3.4},
    {"c": Vector2(13.0, 41.0), "r": 3.4, "h": 3.4},
    {"c": Vector2(-30.0, -33.0), "r": 4.0, "h": 3.4}
]
var isle_locks: Array = []
var map_mode: bool = false
var map_tween: Tween = null
var map_btn: Button = null

func build_islands() -> void:
    var gold: StandardMaterial3D = _mm(Color(0.98, 0.78, 0.20), 0.35, 0.3)
    var dark: StandardMaterial3D = _mm(Color(0.30, 0.20, 0.10), 0.7)
    for i in range(ISLES.size()):
        var info: Dictionary = ISLES[i]
        var c: Vector2 = info["c"]
        var top: float = float(info["h"]) + 1.1
        var root := Node3D.new()
        root.name = "IsleLock_%d" % (i + 1)
        root.position = Vector3(c.x, top, c.y)
        root.rotation_degrees.y = 34.0
        g.add_child(root)
        # padlock: body, U-shaped shackle, keyhole
        _put(root, _box_mesh(Vector3(0.9, 0.7, 0.3)), Vector3(0, 0, 0), gold)
        _put(root, _box_mesh(Vector3(0.12, 0.5, 0.2)), Vector3(-0.28, 0.55, 0), gold)
        _put(root, _box_mesh(Vector3(0.12, 0.5, 0.2)), Vector3(0.28, 0.55, 0), gold)
        _put(root, _box_mesh(Vector3(0.68, 0.12, 0.2)), Vector3(0, 0.82, 0), gold)
        _put(root, _box_mesh(Vector3(0.12, 0.28, 0.06)), Vector3(0, -0.02, 0.17), dark)
        var l1: Label3D = g._label3d(root, "ISLAND %d" % (i + 1), Vector3(0, 1.75, 0.0), 0.020, Color(1.0, 0.95, 0.75))
        l1.outline_size = 10
        var l2: Label3D = g._label3d(root, "COMING SOON", Vector3(0, 1.15, 0.0), 0.010, Color(0.85, 0.95, 1.0))
        l2.outline_size = 8
        isle_locks.append(root)
    # Map button below the other buttons on the left.
    var hud: Node = g.get("hud_left_ref")
    if hud != null:
        map_btn = g._icon_button(hud as Control, "🗺", Vector2(4.0, 278.0), 54.0)
        map_btn.pressed.connect(toggle_map)

func _box_mesh(sz: Vector3) -> BoxMesh:
    var b := BoxMesh.new()
    b.size = sz
    return b

func pan_limit() -> float:
    # Normal farm range when zoomed in; the whole sea (all six islands) when zoomed out.
    var f: float = clampf((g.cam_zoom - 13.0) / 6.0, 0.0, 1.0)
    return lerpf(g.PAN_LIMIT, 44.0, f)

func toggle_map() -> void:
    if map_tween != null and map_tween.is_valid():
        map_tween.kill()
    var to_t: Vector3
    var to_z: float
    if not map_mode:
        map_mode = true
        to_t = Vector3(-4.0, 0.25, 2.0)
        to_z = MAP_ZOOM
        g._show_toast("Map view. Tap the map button again to return.")
    else:
        map_mode = false
        to_t = Vector3(0.0, 0.25, 0.0)
        to_z = 16.8
    map_tween = create_tween().set_parallel(true).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
    map_tween.tween_property(g, "cam_target", to_t, 0.8)
    map_tween.tween_property(g, "cam_zoom", to_z, 0.8)
    map_tween.tween_callback(func(): pass)

const MAP_ZOOM := 82.0

func tick_islands(delta: float) -> void:
    if isle_locks.is_empty():
        return
    var t: float = anim_t
    for i in range(isle_locks.size()):
        var n: Node3D = isle_locks[i]
        n.position.y = float(ISLES[i]["h"]) + 1.1 + sin(t * 1.6 + float(i)) * 0.12
        n.scale = Vector3.ONE * clampf(g.cam_zoom / 20.0, 1.0, 3.0)
    if map_tween != null and map_tween.is_valid():
        g._update_camera()

func tap_island(p2: Vector2) -> bool:
    for i in range(ISLES.size()):
        var info: Dictionary = ISLES[i]
        var c: Vector2 = info["c"]
        if p2.distance_to(c) < float(info["r"]) + 0.8:
            g._show_toast("Island %d is locked. Coming in a future update!" % (i + 1))
            return true
    return false
