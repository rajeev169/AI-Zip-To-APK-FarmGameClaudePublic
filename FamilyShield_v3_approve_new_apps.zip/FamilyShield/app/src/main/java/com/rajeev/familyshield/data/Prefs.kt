package com.rajeev.familyshield.data

import android.content.Context
import android.content.SharedPreferences

/** Small local store so the child phone keeps working offline and after a reboot. */
class Prefs(context: Context) {
    private val sp: SharedPreferences =
        context.applicationContext.getSharedPreferences("family_shield", Context.MODE_PRIVATE)

    var role: String
        get() = sp.getString("role", "") ?: ""
        set(v) = sp.edit().putString("role", v).apply()

    var linked: Boolean
        get() = sp.getBoolean("linked", false)
        set(v) = sp.edit().putBoolean("linked", v).apply()

    var parentUid: String
        get() = sp.getString("parentUid", "") ?: ""
        set(v) = sp.edit().putString("parentUid", v).apply()

    var parentName: String
        get() = sp.getString("parentName", "") ?: ""
        set(v) = sp.edit().putString("parentName", v).apply()

    var childName: String
        get() = sp.getString("childName", "") ?: ""
        set(v) = sp.edit().putString("childName", v).apply()

    var rulesJson: String
        get() = sp.getString("rulesJson", "") ?: ""
        set(v) = sp.edit().putString("rulesJson", v).apply()

    var lastCmdId: String
        get() = sp.getString("lastCmdId", "") ?: ""
        set(v) = sp.edit().putString("lastCmdId", v).apply()

    var knownApps: Set<String>
        get() = sp.getStringSet("knownApps", emptySet()) ?: emptySet()
        set(v) = sp.edit().putStringSet("knownApps", HashSet(v)).apply()

    /** New apps installed while "approve new apps" was on; locked until the parent approves them. */
    var pendingApps: Set<String>
        get() = sp.getStringSet("pendingApps", emptySet()) ?: emptySet()
        set(v) = sp.edit().putStringSet("pendingApps", HashSet(v)).apply()

    var insidePlaces: Set<String>?
        get() = if (sp.contains("insidePlaces")) sp.getStringSet("insidePlaces", emptySet()) else null
        set(v) = if (v == null) sp.edit().remove("insidePlaces").apply()
        else sp.edit().putStringSet("insidePlaces", HashSet(v)).apply()

    var lastProtection: String
        get() = sp.getString("lastProtection", "") ?: ""
        set(v) = sp.edit().putString("lastProtection", v).apply()

    var lastUploadedDay: String
        get() = sp.getString("lastUploadedDay", "") ?: ""
        set(v) = sp.edit().putString("lastUploadedDay", v).apply()

    var limitAlertDay: String
        get() = sp.getString("limitAlertDay", "") ?: ""
        set(v) = sp.edit().putString("limitAlertDay", v).apply()

    var lastAlertTime: Long
        get() = sp.getLong("lastAlertTime", 0L)
        set(v) = sp.edit().putLong("lastAlertTime", v).apply()

    var disclosureAccepted: Boolean
        get() = sp.getBoolean("disclosureAccepted", false)
        set(v) = sp.edit().putBoolean("disclosureAccepted", v).apply()

    /** Until this time the Accessibility uninstall guard lets Android finish a parent-approved uninstall. */
    var uninstallUnlockUntil: Long
        get() = sp.getLong("uninstallUnlockUntil", 0L)
        set(v) = sp.edit().putLong("uninstallUnlockUntil", v).apply()

    // Parent side: which children we've already sent an "offline" alert for.
    var offlineNotified: Set<String>
        get() = sp.getStringSet("offlineNotified", emptySet()) ?: emptySet()
        set(v) = sp.edit().putStringSet("offlineNotified", HashSet(v)).apply()

    fun clearAll() = sp.edit().clear().apply()
}
