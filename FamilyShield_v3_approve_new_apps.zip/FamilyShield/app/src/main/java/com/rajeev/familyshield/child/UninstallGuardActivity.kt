package com.rajeev.familyshield.child

import android.app.Activity
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.rajeev.familyshield.data.Prefs
import com.rajeev.familyshield.ui.theme.FamilyShieldTheme

/** Visible PIN gate shown when Android's Settings tries to uninstall Family Shield. */
class UninstallGuardActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            FamilyShieldTheme {
                UninstallGuardScreen(
                    correctPin = RulesStore.get(this).pin,
                    parentName = Prefs(this).parentName,
                    onCancel = { goHome() },
                    onUnlock = {
                        // Give the system uninstall flow a short, explicit parent-approved window.
                        Prefs(this).uninstallUnlockUntil = System.currentTimeMillis() + 60_000L
                        finish()
                    }
                )
            }
        }
    }

    private fun goHome() {
        startActivity(android.content.Intent(android.content.Intent.ACTION_MAIN)
            .addCategory(android.content.Intent.CATEGORY_HOME)
            .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK))
        finish()
    }
}

@Composable
private fun UninstallGuardScreen(
    correctPin: String,
    parentName: String,
    onCancel: () -> Unit,
    onUnlock: () -> Unit,
) {
    var entry by remember { mutableStateOf("") }
    var error by remember { mutableStateOf(false) }
    Column(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(Icons.Filled.AdminPanelSettings, contentDescription = null,
            tint = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.padding(8.dp))
        Text("Family Shield protection", style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        Spacer(Modifier.padding(6.dp))
        Text(
            if (parentName.isBlank()) "To access uninstall, please enter the parent PIN."
            else "To access uninstall, please enter $parentName's parent PIN.",
            textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.padding(12.dp))
        OutlinedTextField(
            value = entry,
            onValueChange = { if (it.length <= 4 && it.all(Char::isDigit)) { entry = it; error = false } },
            label = { Text("Parent PIN") },
            singleLine = true,
            isError = error,
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
            modifier = Modifier.fillMaxWidth()
        )
        if (error) Text("Incorrect parent PIN", color = MaterialTheme.colorScheme.error)
        Spacer(Modifier.padding(10.dp))
        Button(
            onClick = { if (correctPin.isNotBlank() && entry == correctPin) onUnlock() else error = true },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Continue to uninstall") }
        Spacer(Modifier.padding(4.dp))
        androidx.compose.material3.TextButton(onClick = onCancel) { Text("Cancel") }
        Text(
            "Family Shield is a visible parental-control app. The parent PIN is required before it can be removed.",
            style = MaterialTheme.typography.bodySmall,
            color = Color.Gray,
            textAlign = TextAlign.Center
        )
    }
}
