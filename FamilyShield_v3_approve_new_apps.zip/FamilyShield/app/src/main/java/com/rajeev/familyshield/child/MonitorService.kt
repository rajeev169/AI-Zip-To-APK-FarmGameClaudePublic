package com.rajeev.familyshield.child

import android.annotation.SuppressLint
import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.app.admin.DevicePolicyManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.location.Location
import android.os.BatteryManager
import android.os.Build
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.firebase.firestore.ListenerRegistration
import com.rajeev.familyshield.FamilyShieldApp
import com.rajeev.familyshield.MainActivity
import com.rajeev.familyshield.R
import com.rajeev.familyshield.data.AlertType
import com.rajeev.familyshield.data.ChildInfo
import com.rajeev.familyshield.data.Day
import com.rajeev.familyshield.data.Prefs
import com.rajeev.familyshield.data.Repo
import com.rajeev.familyshield.data.Rules
import com.rajeev.familyshield.data.formatMinutes
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Runs on the child's phone with a permanent notification, so the child always
 * knows the phone is supervised. Syncs rules, usage, apps, battery and location.
 */
class MonitorService : Service() {

    companion object {
        private const val NOTIF_ID = 11

        fun start(ctx: Context) {
            try {
                ContextCompat.startForegroundService(ctx, Intent(ctx, MonitorService::class.java))
            } catch (_: Exception) {
                // Android may refuse a start from the background; the accessibility service retries later.
            }
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, MonitorService::class.java))
        }

        /** Tells the parent once a day when the total screen time is used up. */
        fun onAppBlocked(ctx: Context, pkg: String) {
            val r = RulesStore.get(ctx)
            if (r.totalLimit <= 0) return
            val p = Prefs(ctx)
            val today = Day.key()
            if (p.limitAlertDay == today) return
            if (UsageTracker.totalMinutes(UsageTracker.today(ctx)) >= r.totalLimit) {
                p.limitAlertDay = today
                Repo.sendAlert(
                    p, AlertType.LIMIT, "Screen time over",
                    "${p.childName.ifBlank { "Your child" }} has used today's ${formatMinutes(r.totalLimit)} of screen time."
                )
            }
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private lateinit var prefs: Prefs
    private var rulesReg: ListenerRegistration? = null
    private var childReg: ListenerRegistration? = null
    private var fused: FusedLocationProviderClient? = null
    private var locationStarted = false
    private var lastLocation: Location? = null
    private var pkgReceiverRegistered = false
    private var loopStarted = false

    private val locationCallback = object : LocationCallback() {
        override fun onLocationResult(result: LocationResult) {
            result.lastLocation?.let { onLocation(it) }
        }
    }

    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            scope.launch {
                delay(3000)
                syncApps()
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
        goForeground()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val uid = Repo.me?.uid
        if (!prefs.linked || uid == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        // Re-assert the OS uninstall block after boot, app update, or service restart.
        Perms.enforceUninstallBlocked(this)
        goForeground() // refreshes the type once location permission is granted
        if (rulesReg == null) listen(uid)
        startLocation()
        if (!pkgReceiverRegistered) {
            val f = IntentFilter().apply {
                addAction(Intent.ACTION_PACKAGE_ADDED)
                addAction(Intent.ACTION_PACKAGE_REMOVED)
                addDataScheme("package")
            }
            ContextCompat.registerReceiver(this, pkgReceiver, f, ContextCompat.RECEIVER_EXPORTED)
            pkgReceiverRegistered = true
        }
        if (!loopStarted) {
            loopStarted = true
            scope.launch { loop() }
        }
        return START_STICKY
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val parent = prefs.parentName.ifBlank { "your parent" }
        return NotificationCompat.Builder(this, FamilyShieldApp.CH_MONITOR)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("Family Shield is on")
            .setContentText("This phone is supervised by $parent")
            .setOngoing(true)
            .setContentIntent(open)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .build()
    }

    private fun goForeground() {
        val notification = buildNotification()
        val withLocation = Perms.hasLocation(this)
        val type = when {
            Build.VERSION.SDK_INT >= 34 ->
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE or
                        (if (withLocation) ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION else 0)
            Build.VERSION.SDK_INT >= 29 ->
                if (withLocation) ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION else 0
            else -> 0
        }
        try {
            ServiceCompat.startForeground(this, NOTIF_ID, notification, type)
        } catch (e: Exception) {
            // Location type not allowed right now: keep running without it.
            val fallback = if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
            try {
                ServiceCompat.startForeground(this, NOTIF_ID, notification, fallback)
            } catch (_: Exception) {
            }
        }
    }

    // ---------- Firestore listeners ----------

    private fun listen(uid: String) {
        rulesReg = Repo.rulesDoc(uid).addSnapshotListener { snap, _ ->
            if (snap == null) return@addSnapshotListener
            val rules = Rules.from(snap)
            RulesStore.set(this, rules)
            handleCommand(rules, snap.getLong("cmdTime") ?: 0L)
            lastLocation?.let { checkPlaces(it.latitude, it.longitude) }
            GuardAccessibilityService.instance?.check()
        }
        childReg = Repo.childDoc(uid).addSnapshotListener { snap, _ ->
            if (snap == null) return@addSnapshotListener
            if (!snap.exists() && !snap.metadata.isFromCache) {
                // Parent removed this phone.
                prefs.linked = false
                RulesStore.clear(this)
                stopSelf()
            } else if (snap.exists()) {
                ChildInfo.from(snap)?.let {
                    if (it.parentName != prefs.parentName || it.name != prefs.childName) {
                        prefs.parentName = it.parentName
                        prefs.childName = it.name
                        goForeground()
                    }
                }
            }
        }
    }

    private fun handleCommand(r: Rules, cmdTime: Long) {
        if (r.cmdId.isBlank() || r.cmdId == prefs.lastCmdId) return
        prefs.lastCmdId = r.cmdId
        if (System.currentTimeMillis() - cmdTime > 10 * 60_000L) return // too old
        when (r.cmdType) {
            "lock" -> if (Perms.isAdmin(this)) {
                val dpm = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
                try {
                    dpm.lockNow()
                } catch (_: Exception) {
                }
            }
            "locate" -> requestFreshLocation()
        }
    }

    // ---------- Main loop ----------

    private suspend fun loop() {
        var tick = 0
        syncApps()
        uploadStatus()
        while (scope.isActive) {
            delay(30_000)
            tick++
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            if (pm.isInteractive) {
                withContext(Dispatchers.Main) { GuardAccessibilityService.instance?.check() }
            }
            if (tick % 4 == 0) uploadStatus()
            if (tick % 30 == 0) syncApps()
        }
    }

    private fun uploadStatus() {
        val uid = Repo.me?.uid ?: return
        val now = System.currentTimeMillis()
        val today = Day.key(now)

        // Finish yesterday's numbers after midnight.
        val lastDay = prefs.lastUploadedDay
        if (lastDay.isNotBlank() && lastDay != today) {
            val start = Day.startOfToday()
            val y = UsageTracker.between(this, start - 24 * 3600_000L, start)
            if (Day.key(start - 1000) == lastDay) writeUsage(uid, lastDay, y)
        }

        val usage = UsageTracker.today(this, force = true)
        writeUsage(uid, today, usage)
        prefs.lastUploadedDay = today

        val battery = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = battery?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = battery?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val status = battery?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val pct = if (level >= 0 && scale > 0) level * 100 / scale else -1
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL

        val protection = Perms.protectionMap(this)
        checkProtection(protection)

        Repo.updateChildStatus(
            mapOf(
                "lastSeen" to now,
                "battery" to pct,
                "charging" to charging,
                "todayDate" to today,
                "todayTotalMin" to UsageTracker.totalMinutes(usage),
                "protection" to protection,
            )
        )
    }

    private fun writeUsage(uid: String, day: String, usage: Map<String, Long>) {
        val apps = usage.mapValues { it.value / 60_000 }.filterValues { it > 0 }
        Repo.usageCol(uid).document(day).set(
            mapOf("apps" to apps, "total" to UsageTracker.totalMinutes(usage), "updated" to System.currentTimeMillis())
        )
    }

    /** Alerts the parent when a protection that was on gets turned off. */
    private fun checkProtection(now: Map<String, Boolean>) {
        val encoded = now.entries.sortedBy { it.key }.joinToString(",") { "${it.key}=${if (it.value) 1 else 0}" }
        val before = prefs.lastProtection
        prefs.lastProtection = encoded
        if (before.isBlank()) return
        val prev = before.split(",").mapNotNull {
            val parts = it.split("=")
            if (parts.size == 2) parts[0] to (parts[1] == "1") else null
        }.toMap()
        val turnedOff = now.filter { (k, v) -> !v && prev[k] == true }.keys
        if (turnedOff.isEmpty()) return
        val names = turnedOff.mapNotNull { ChildInfo.PROTECTION_LABELS[it] }.joinToString(", ")
        Repo.sendAlert(
            prefs, AlertType.PROTECTION_OFF, "Protection turned off",
            "${prefs.childName.ifBlank { "Your child" }} turned off: $names"
        )
    }

    private fun syncApps() {
        val uid = Repo.me?.uid ?: return
        val apps = Essentials.launchableApps(this)
        val known = prefs.knownApps
        val firstSync = known.isEmpty()
        val added = apps.keys - known
        val removed = known - apps.keys
        if (added.isEmpty() && removed.isEmpty()) return
        val now = System.currentTimeMillis()
        // When the parent turned on "approve new apps", lock every new install until approved.
        val approve = !firstSync && RulesStore.get(this).approveNew
        if (approve) prefs.pendingApps = prefs.pendingApps + added
        if (removed.isNotEmpty()) prefs.pendingApps = prefs.pendingApps - removed
        val col = Repo.appsCol(uid)
        val ops = added.map { pkg -> pkg to true } + removed.map { pkg -> pkg to false }
        ops.chunked(400).forEach { chunk ->
            val batch = Repo.db.batch()
            chunk.forEach { (pkg, isAdd) ->
                if (isAdd) batch.set(col.document(pkg), mapOf("name" to (apps[pkg] ?: pkg), "firstSeen" to now, "pending" to approve))
                else batch.delete(col.document(pkg))
            }
            batch.commit()
        }
        prefs.knownApps = apps.keys
        if (!firstSync) {
            added.forEach { pkg ->
                Repo.sendAlert(
                    prefs, AlertType.NEW_APP, "New app installed",
                    "${prefs.childName.ifBlank { "Your child" }} installed ${apps[pkg] ?: pkg}" +
                        if (approve) ". It is locked until you approve it in the Apps tab." else ""
                )
            }
        }
    }

    // ---------- Location & safe places ----------

    @SuppressLint("MissingPermission")
    private fun startLocation() {
        if (locationStarted || !Perms.hasLocation(this)) return
        val client = fused ?: LocationServices.getFusedLocationProviderClient(this).also { fused = it }
        val req = LocationRequest.Builder(Priority.PRIORITY_BALANCED_POWER_ACCURACY, 5 * 60_000L)
            .setMinUpdateIntervalMillis(2 * 60_000L)
            .setMinUpdateDistanceMeters(50f)
            .build()
        try {
            client.requestLocationUpdates(req, locationCallback, Looper.getMainLooper())
            locationStarted = true
            requestFreshLocation()
        } catch (_: Exception) {
        }
    }

    @SuppressLint("MissingPermission")
    private fun requestFreshLocation() {
        if (!Perms.hasLocation(this)) return
        val client = fused ?: LocationServices.getFusedLocationProviderClient(this).also { fused = it }
        try {
            client.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, null)
                .addOnSuccessListener { loc -> loc?.let { onLocation(it) } }
        } catch (_: Exception) {
        }
    }

    private fun onLocation(loc: Location) {
        lastLocation = loc
        val place = checkPlaces(loc.latitude, loc.longitude)
        Repo.updateChildStatus(
            mapOf(
                "lat" to loc.latitude,
                "lng" to loc.longitude,
                "accuracy" to loc.accuracy.toDouble(),
                "locTime" to System.currentTimeMillis(),
                "currentPlace" to place,
            )
        )
    }

    /** Returns the name of the safe place the child is in (or ""), and alerts on arrive / leave. */
    private fun checkPlaces(lat: Double, lng: Double): String {
        val places = RulesStore.get(this).places
        val inside = places.filter { p ->
            val d = FloatArray(1)
            Location.distanceBetween(lat, lng, p.lat, p.lng, d)
            d[0] <= p.radius
        }.map { it.name }.toSet()
        val before = prefs.insidePlaces
        prefs.insidePlaces = inside
        if (before != null) {
            val names = places.map { it.name }.toSet()
            val who = prefs.childName.ifBlank { "Your child" }
            (inside - before).forEach {
                Repo.sendAlert(prefs, AlertType.ARRIVED, "Arrived at $it", "$who reached $it", lat, lng)
            }
            (before - inside).filter { it in names }.forEach {
                Repo.sendAlert(prefs, AlertType.LEFT, "Left $it", "$who left $it", lat, lng)
            }
        }
        return inside.firstOrNull() ?: ""
    }

    override fun onDestroy() {
        rulesReg?.remove()
        childReg?.remove()
        if (locationStarted) fused?.removeLocationUpdates(locationCallback)
        if (pkgReceiverRegistered) {
            try {
                unregisterReceiver(pkgReceiver)
            } catch (_: Exception) {
            }
        }
        scope.cancel()
        super.onDestroy()
    }
}
