# Changelog

## v29a
- NEW: your own ship. Buy it at the Lighthouse Harbour (Level 8, 1,500 coins), then tap SAIL YOUR SHIP (or tap the ship at the dock). You sail the whole farm sea with a round joystick on the left; a red BRAKE button stops the ship quickly, a yellow HORN button sounds the ship horn (with a TOOOT! sign). A speed readout shows the knots.
- The ship cannot sail through the farm land, mountains, islands, the aircraft carrier or the power station. The camera follows the ship; pinch to zoom. "Back to farm" returns to your farm.
- Your ship is kept moored at the harbour dock and the purchase is saved.
- Version 0.9.0 (code 24).

## v28g
- Harbour zoom range is now 5 (closest) to 45 (farthest). The main farm keeps 7 to 40.
- Includes everything from v28c to v28f (beam fix, ship waits 50 units out in line with the dock, no camera follow, straight sailing).
- Version 0.8.6 (code 23).

## v28f
- Harbour: the ship now waits in line with the dock and sails straight in along its own length (before it crossed at an angle and looked like it was sliding sideways). It also sails straight back out after you send it off.
- Version 0.8.5 (code 22).

## v28e
- Harbour: BRING SHIP IN no longer moves the camera. The island stays still and only the ship sails in to the dock.
- Version 0.8.4 (code 21).

## v28d
- Harbour: the cargo ship now waits about 50 units out in open sea. It has a pulsing yellow ring and a floating "TAP TO BRING IN" sign. When it arrives the camera glides out to show it, then returns.
- New SHOW SHIP button moves the camera to the waiting ship. Tapping the ship or BRING SHIP IN sends it to the dock (about 9 seconds) and the camera follows it in. After you send it off it sails back out to the horizon.
- You can pan further out to sea. The shallow-sea patch is now round instead of square.
- Version 0.8.3 (code 20).

## v28c
- Harbour zoom range is now 7 (closest) to 40 (farthest), so the whole land fits in one view.
- Lighthouse beam fixed: two soft rays now start exactly at the lamp and fade out over the sea and land (before, the lighthouse was smaller than the beam position, so the beam floated above it). The lighthouse is now properly scaled up.
- Version 0.8.2 (code 19).

## v28b
- Lighthouse Harbour is now a large separate land (like visiting another farm): tap the island, fade in, drag to look around, pinch to zoom, and use "Back to farm" to return.
- The land has a harbour district with dock, crane and office, a lighthouse on a hill, keeper's house, three village houses, fish market, garden, a fishing pier, paths, trees and rocks.
- Ships now wait at sea; tap the ship (or BRING SHIP IN) to dock it, then load and send it off.
- Version 0.8.1 (code 18).

## v28a
- NEW: Lighthouse Harbour. Island 3 (the lighthouse island) can be unlocked at Level 6 for 800 coins. Tap it, pay, and the screen fades to a separate harbour play area. A "Back to farm" button fades back to the farm exactly as you left it (crops keep growing).
- In the harbour: a bigger island with the lighthouse (rotating light beam at night), keeper's house with the keeper, harbour office, dock, crane and a tug. Cargo ships sail in on a timer (also while you are on the farm), ask for farm goods, you LOAD CARGO (crane lifts crates onto the ship) and SEND SHIP OFF for coins and XP.
- The island on the farm map shows "SHIP IN PORT! TAP" when a ship is waiting.
- Saves the unlock and the ship at the dock.
- Version 0.8.0 (code 17).

## v27k
- Zoom range widened: closest view 7 (was 9), farthest pinch view 40 (was 26). You can now pinch out to see the farm and nearby islands; the map button still shows all six. Start view is unchanged.
- Version 0.7.0 (code 16).

## v27j
- Islands: all six small islands can now be reached. Zoom out and the camera can move across the whole sea; a new map button (left side, below the wrench) zooms out to show the farm and every island, and a second press returns to the farm.
- Each island now has a floating gold padlock with "ISLAND n / COMING SOON". Tapping an island shows that it is locked (ready for future unlocks).
- Sea enlarged so no edge shows in the map view.
- Version 0.6.9 (code 15).

## v27i
- Roads: the soft lawn colour patches were drawn slightly above the sand roads and hid parts of them, so vehicles looked like they were driving on grass. The patches now sit below the road surface.
- Version 0.6.8 (code 14).

## v27h
- Signing: the fixed key is now set directly in the Android export preset, and the build log prints the signing certificate so it can be checked. Version 0.6.7 (code 13).

## v27g
- Bakery is now a proper shop: bigger building, striped awning, bread display and a large "BAKERY" sign on the roof, so it is easy to find.
- Version 0.6.6 (code 12).

## v27f
- Builds are now signed with one fixed key (signing/lvf.keystore), so every new APK installs over the old one without uninstalling. First install of this build needs one uninstall of the old app.

## v27e
- Farm hand: picks east, west, north or south for each plot so he always stands on the field and the tiller stays over the field as much as possible. Only the very corner plots can let the tiller's front overhang the edge slightly.
- Version 0.6.4 (code 10).

## v27d
- Farm hand now always works from inside the field: he walks the tiller toward the nearer field edge, so he never stands out on the grass in front of the bakery.
- Tilled rows on empty plots fade after 3 minutes (they stay while a crop grows and clear on harvest), so the field no longer stays striped dark brown.
- The barn-full alert re-arms as soon as you free barn space, so it shows again the next time the barn fills.
- Version 0.6.3 (code 9).

## v27c
- Railway: fixed the real break in the track at the north-west bend. The last piece of the loop was never drawn, leaving a slit. The track is now built as continuous strips that follow the bends, with no gaps on tight corners.
- Version 0.6.2 (code 8).

## v27b
- Railway: the stone side wall on raised track and bridges is now a low kerb, so both rails and sleepers stay visible on the curves (it looked like a break in the track).
- The PLANT crop box no longer pops up when the game opens; it appears when you press PLANT.
- Power / barn alerts wait one minute after the game starts.
- Version 0.6.1 (code 7).

## v27
- Hire a Farm Hand with a Power Tiller (Level 5, 600 coins): a natural-looking farmer with a yellow straw hat walks to the plot you tap and tills it. Tilled plots grow 20% faster and show dark turned soil. Uses 1 energy per plot.
- Auto-Farming upgrade (Level 9, 1500 coins): the farm hand tills and looks after crops by himself.
- New Upgrades hub (🔧 button): Farm Hand, Barn, Power Station, Batteries (500/800/1200), Windmill (3 levels), Trade Carriers (3 levels, bigger loads).
- "Struggling" alerts with a Sell or Upgrade choice: barn full, power station full, no energy for the tiller, order too heavy for a vehicle.
- Crop care: crops sometimes get thirsty (water drop) or weedy (green tuft). Tap the plot to fix; ignored crops grow slower.
- Animal care: cows, chickens and pigs get hungry every 3rd product. Tap the hay bowl to feed (2 coins) or they stop producing.
- Settings (⚙): sound, graphics quality (Auto / High / Medium / Low), and Copy / Load save code to back up or move your farm.
- Version 0.6.0 (code 6).

## v26
- Trade Centre shows 2 orders at a time (3 from Level 16); a new order arrives shortly after you send or skip one; rewards +20%.
- New crop: Rice (Level 8) with a flooded-paddy look; sells, ships in orders and saves like the other crops.
- Farm decor: scarecrow, hay bales with pitchfork, sunflower patch and a wheelbarrow.
- Includes everything from v25b.

## v25b
- Trade Centre: tap a transport to select it, then press SEND ORDER; bigger transport icons with names; energy cells no longer make orders "too heavy".
- Tapping a button again closes its pop-up (PLANT, SHOP and the HUD buttons); crop bar has a ✕.
- Natural-looking tomato, wheat, carrot and corn plants.
- New 3D farm app icon (night island).

## v25
- Crop picker bar when planting; Trade Centre (Lv 11) with order list, destinations and 5 transport modes (train, drone, helicopter, plane, boat); vehicles leave the Trade Centre, drop the parcel and return.
- Zig-zag railway with bridges over roads; train now only runs when dispatched from the Trade Centre.
- Locked-feature signs (Railway Lv 9, Trade Centre Lv 11) and greyed buttons from Level 1.
- X close icon on every panel, tidier two-row HUD, brighter night/rain, carrier closer with a camera shortcut.

## Scene-first Prototype v3
- Fixed the likely cause of the empty blue scene by adding the camera to the scene tree before calling `look_at()`.
- Set the game viewport and Android orientation to landscape for the wide farm layout.
- Made the top HUD responsive to the viewport width.
- Added a low-poly cow, two chickens, shrubs, a stone well, barrels, an upper garden path, and grass tufts to make the farm scene read more clearly as a 3D world.
- Retained the current farming loop, shop, save/load, and Android workflow for later runtime verification.

## Prototype v2
- Initial primitive-mesh 3D farm, camera, lighting, farmer, crop plots, and UI.


## Tree visual upgrade v4
- Replaced the simple bulb-like canopy with a layered low-poly crown made from varied leaf clusters and several green tones.
- Added a tapered trunk, visible branching limbs, root flare, and small fruit details.
- Gameplay and Android workflow are unchanged.
- Static checks only; Godot runtime rendering and Android build must still be confirmed.


## Landscape Fit v5
- Set viewport stretch aspect to `expand` so extra-wide landscape phones use the available screen instead of keeping a 16:9 canvas with black side bars.
- Kept the UI positioned with normalized anchors so the top HUD and bottom action row expand with the viewport.
- Reduced the orthographic camera size from 18.5 to 16.8 to make the farm larger while retaining the island in view; confirm framing on-device.
- Based on Tree Upgrade v4; no gameplay systems or Android workflow were intentionally changed.
- Validation: archive integrity and static configuration/source checks only; no Godot runtime or APK build was available here.

## Visual polish v6 — varied trees and ground cover
- Added deterministic per-tree size variation so the orchard no longer uses identical silhouettes.
- Expanded the low-poly tree crowns with extra outer foliage lobes, varied rotations, and visible branch structure.
- Added additional lightweight grass tufts and flattened ground-cover patches around the perimeter to reduce the empty flat-lawn appearance.
- Preserved the existing landscape camera, HUD, buttons, planting, harvesting, shop, and save/load source.

**Validation status:** ZIP integrity and static source assertions only. Godot runtime rendering and Android APK build have not been run in this environment. Inspect the resulting APK before treating visual changes as confirmed.


## Visual Update v7 — Tree Variety and HUD
- Added four distinct tree silhouettes: broadleaf fruit tree, pine, palm, and fir.
- Made the top HUD panel fully opaque to prevent the sky color from showing through the bar.
- Preserved the landscape layout and existing farming/shop/save source.
- Static validation only; Godot runtime and Android APK build still need to be run.


## Update 8 — HUD strip adjustment
- Extended the opaque top HUD panel downward so the light-blue area no longer begins immediately beneath the level/coin/seed row.
- Preserved the four tree types and existing gameplay source.
- Static source/ZIP checks only; Godot runtime and Android APK build were not run in this environment.


## v9 — Floating HUD
- Removed the dark-green background panel behind Level, coin, and seed labels.
- Kept the labels and existing gameplay/tree variety.
- Reduced the transparent HUD layout area to avoid covering the farm.
- Static source change only; Godot runtime and Android APK build still require verification.

# Diagnostic Fix v13

- Based on recovery v11, the last project version whose farm and floating HUD were confirmed visible in the user's screenshot.
- Reapplied the palm-frond visual improvement with explicit GDScript types and a typed loop index to avoid type-inference ambiguity.
- Other world initialization, camera, HUD, tree types, and gameplay code are unchanged from recovery v11.
- Validation: ZIP integrity and source-level checks only. Godot runtime/export could not be run in this environment.


## v14 — Natural trees (leaf detail)
- Broadleaf: crown rebuilt from 12 lobes, each a dark core plus dozens of individual folded leaf blades in five green tones (lighter on top, darker underneath). Trunk, branches, roots and apples kept.
- Pine and fir: each tier now has a solid core plus rings of drooping branches made of 3-blade needle fans, giving a jagged, feathery silhouette. Pine is sparse with flatter branches and small hanging cones; fir is denser and droopier.
- Palm: curved, ringed trunk, coconut cluster, and 13 arching fronds with paired, swept leaflets and a central rib (the old leaflets were too small and mirrored, so fronds looked like bare sticks). Two older yellow-green fronds add variety.
- Foliage is merged into one vertex-coloured mesh per tree (about 10k triangles for the whole scene) to keep draw calls low on phones.
- Added a gentle wind sway to every tree (palms move most).
- Tree positions and types, and everything that is not a tree, are unchanged.
- Validation: source-level checks only. Godot runtime and APK build were not run here.


## v15 — Township-style upgrade
- Camera: drag with one finger to pan, pinch with two fingers to zoom (mouse drag and wheel on desktop). A quick tap still plants or harvests.
- World: island grown from 15x15 to 36x36 and surrounded by water. Four winding sand roads, two ponds with stones and lily pads, a blue-fenced animal pen with cows, pigs, trough and hay, a red silo, a bakery oven with bread table, a striped market tent, and a wooden gate on the farm's front fence. About 46 light-weight background trees (fir, pine, broadleaf, pink, golden and purple), plus bushes, rocks, flowers, lawn patches and grass tufts.
- HUD: avatar with a level badge and XP bar, round settings, mail and quest buttons, cream coin and seed pills (the + opens the shop), a barn stats button, and cream action buttons where the active tool is highlighted.
- Levels and XP: planting gives 2 XP and harvesting 10 XP. Level n needs 30 + 25*(n-1) XP. Level-ups pay coins and seeds and show a banner. Harvest pays 7 + level coins.
- Quest: harvest 5 crops for a bonus; each completed quest raises the goal by 2.
- Saving: level, XP and quest progress are saved. Crops now keep growing while the game is closed. The game autosaves every 15 seconds and when the app is paused.
- Materials are shared by colour, and the sun's shadow range is capped, to keep the bigger scene light on phones.
- Fix: the HUD (level badge, XP bar, coins, seeds) now refreshes immediately after XP or a level-up.
- Validation: opened in Godot 4.3 (headless and software-rendered) with no script or parse errors. Simulated planting, harvesting, level-ups, save/load, tap, drag-pan and pinch-zoom; all worked. Not tested on a real phone.

## v15 build fix
- Android export no longer uses the Gradle build (`gradle_build/use_gradle_build=false`). A GitHub build failed with "No space left on device" inside Gradle's native-libs step. Godot's prebuilt Android template needs far less disk and has no Gradle cache. The game has no plugins that require Gradle.
- Output size and gameplay are unchanged.


## v16 — Scenery
- The empty water around the island is now filled: 26 snow-capped mountains (tallest on the far side, all merged into one mesh), 12 slowly drifting clouds, six small islands (palm, pine grove, lighthouse, blossom trees), four bobbing sailboats and sea rocks.
- Deeper ocean with a lighter shallow band and a gently pulsing foam ring around the farm island.
- Clouds and mountains are placed so they cannot hide the farm from the camera.
- Settings, mail and quest icons are darker and outlined so they are easy to see.
- Maximum zoom-out reduced from 28 to 26.
- Validation: opened in Godot 4.3 (software rendering) with no script errors; checked screenshots from seven camera positions. Not tested on a phone.

## v17 — day/night, birds, windmill, sea port, cargo ship
- Automatic day/night cycle (4 min per day): sunrise, noon, sunset, night with moon light, darker sea, glowing lamps and windows, clock on the HUD.
- Birds: white gull flocks over the sea and red songbirds over the meadow (they sleep at night).
- Windmill (unlocks Level 3), Sea Port with pier and crane (Level 5), big cargo ship that sails in and out (Level 8). Locked buildings show as construction sites with a sign. Tap a building when the gold coin floats above it to collect coins and XP; the ship doubles port income.
- Farmhouse and barn moved clear of the crop plots; pan limit tightened; more clouds.
- Save file now also stores time of day and production timers.

## v18 — feather wings, road vehicles, soundscape
- Birds now have real feather-shaped wings (fanned primary feathers, dark tips) and a feather tail instead of rectangles.
- Roads no longer run under the crop plots; roads now end at the farm gate and the farmhouse door.
- Vehicles drive the roads automatically: tractor (south road), ambulance with flashing lights (east road to the port), pickup truck with hay (north-west road). Headlights glow at night.
- Sound (all generated in code, no audio files): ocean waves (louder near the coast), soft wind, birdsong (dawn chorus in the morning, silent at night), crickets at night, soft music-box melody, ship horn, coin ding, level-up jingle. The gear button toggles sound on/off (saved).

## v19 — crops, wandering animals, rain, fishing boats
- Four crops (Tomato, Wheat Lv2, Carrot Lv4, Corn Lv6), each with its own look, grow time, price and XP; pick the crop in the shop. Shop also sells 20-seed bundles.
- Cows, pigs and chickens now wander around their areas and occasionally moo.
- Weather: rain showers (crops grow 50% faster), dark skies, lightning and thunder, and a rainbow after the rain.
- Fishing boats (unlock with the Sea Port) sail out, fish and return with crates; tap the port to sell the fish.

## v20 — smoother ships and rounder animals
- Cargo ship and fishing boats now have a lofted, curved hull (pointed rising bow, rounded body, red above the waterline) and a round funnel.
- Cows and pigs rebuilt from rounded shapes: barrel body, neck, head with muzzle, eyes, ears, horns, hooves, udder, tail.
- Night is a little brighter so the farm stays readable.

## v21 — seamless field
- The 25 separate crop plots are now one big tilled field with soft plough ridges and a wooden frame; no gaps or outlines between cells. Tapping still works per cell.

## v23 — everything: barn economy, daily quests, seasons, rounder buildings, performance
Includes v20 (smooth ships, rounded animals) and v21 (seamless field).
- Tap highlight: the cell you tap on the big field flashes green (plant) or gold (harvest).
- Barn storage: harvested crops now go to the barn (60 items). Tap the barn, the market tent, the silo or the 📦 button to sell one, all, or everything. If the barn is full the crop is sold on the spot.
- Bakery (opens at Level 2): tap the oven to cook Bread, Tomato Soup, Carrot Cake or Popcorn from stored crops. Up to 3 in the queue, the oven keeps baking while the game is closed, goods sell for about 1.8x.
- Daily quests (📋 button): three new quests every day, XP + coin rewards, an all-done bonus, and a login streak gift (extra seeds every 3rd day).
- Rounder buildings: farmhouse (thick gabled roof, porch, arched door, shuttered windows, flower boxes, chimney smoke), barn (gambrel roof, braced doors, hayloft), domed silo, round well with roof and bucket, rounded tractor hood and roof, smoking bakery oven.
- Seasons (about 5 minutes each, 20-minute year, saved): spring blossoms and petals (crops +10% faster), summer, autumn orange leaves (market prices +15%), snowy winter with snowfall (crops 25% slower). Ground, trees and sky change colour; the season shows next to the clock.
- Performance: about 1000 static meshes are merged into ~180 (draw calls roughly halved), day/night lighting updates 14x per second instead of every frame, shadow/particle quality drops automatically on slow phones, 60 fps cap, 2048 shadow map.

## v24 — orders, products, expansion, tidal power, railway, aircraft carrier
Includes everything from v23.
- Village Orders board (🧾, next to the farmhouse): three villagers at a time ask for crops, baked goods or farm products; deliver for big coins + XP, skip for a new one later. Orders expire and are saved.
- Animal & orchard products: cows give milk, chickens eggs, pigs truffles, apple trees apples. A bubble shows over each animal when its product is ready; tap it to collect. Products sell at the market or fill orders.
- Farm expansion (🏗): Field B (Lv 4, 25 more plots), Apple Orchard (Lv 6), Barn upgrades (Lv 5+, more storage).
- Tidal Power Station (⚡, Lv 8): spinning turbines and wave buoys in the sea. Collect energy and spend it on Irrigation (+30% growth), Turbo Oven (2x baking), Feed Boost (2x animal output) or sell it. Upgrade to 3 turbines.
- Village Railway (🚂, Lv 9): looping track with 6 stations (Farm, Port, Power, Market, Windmill, Bakery), a steam locomotive and up to 4 wagons, level crossings with blinking lights. Every stop loads freight; collect it or upgrade carriages for +4% crop prices per level.
- Aircraft Carrier (✈, Lv 10): a peaceful grey carrier at sea. Two jets, a supply plane and a helicopter take off, circle and land by themselves. Tap it to send the helicopter on a supply run (coins + seeds, 2 min cooldown).
- Performance: new static meshes are baked into a few meshes per material; adaptive quality unchanged.

## v24b — crop picker
- Tapping 🌱 PLANT now shows a crop bar above the buttons: choose Tomato, Wheat, Carrot or Corn (locked ones show their level), see seeds left, grow time and price. The bar hides on Harvest or when a panel is open. The Shop still works as before.
