package com.rajeev.familyshield.ui.parent

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.rajeev.familyshield.data.Place
import com.rajeev.familyshield.data.Repo
import com.rajeev.familyshield.data.formatAgo
import com.rajeev.familyshield.ui.theme.SafeGreen
import com.rajeev.familyshield.ui.theme.ShieldBlue
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Polygon

private val DEFAULT_CENTER = GeoPoint(25.1972, 85.5239) // used only before the first location arrives

@Composable
fun LocationTab(d: ChildData) {
    val ctx = LocalContext.current
    val c = d.child
    val places = d.rules.places
    var mapRef by remember { mutableStateOf<MapView?>(null) }
    var centred by remember { mutableStateOf(false) }
    var addPlace by remember { mutableStateOf(false) }
    val lifecycle = LocalLifecycleOwner.current.lifecycle

    DisposableEffect(lifecycle, mapRef) {
        val obs = LifecycleEventObserver { _, e ->
            when (e) {
                Lifecycle.Event.ON_RESUME -> mapRef?.onResume()
                Lifecycle.Event.ON_PAUSE -> mapRef?.onPause()
                else -> {}
            }
        }
        lifecycle.addObserver(obs)
        onDispose {
            lifecycle.removeObserver(obs)
        }
    }

    Column(Modifier.fillMaxSize()) {
        Box(
            Modifier
                .fillMaxWidth()
                .weight(1f)
        ) {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { context ->
                    MapView(context).apply {
                        setTileSource(TileSourceFactory.MAPNIK)
                        setMultiTouchControls(true)
                        zoomController.setVisibility(org.osmdroid.views.CustomZoomButtonsController.Visibility.NEVER)
                        controller.setZoom(16.0)
                        controller.setCenter(DEFAULT_CENTER)
                        mapRef = this
                    }
                },
                update = { map ->
                    map.overlays.clear()
                    places.forEach { p ->
                        val circle = Polygon(map).apply {
                            points = Polygon.pointsAsCircle(GeoPoint(p.lat, p.lng), p.radius.toDouble())
                            fillPaint.color = SafeGreen.copy(alpha = 0.18f).toArgb()
                            outlinePaint.color = SafeGreen.toArgb()
                            outlinePaint.strokeWidth = 3f
                            title = p.name
                        }
                        map.overlays.add(circle)
                    }
                    if (c.hasLocation) {
                        val pos = GeoPoint(c.lat!!, c.lng!!)
                        val marker = Marker(map).apply {
                            position = pos
                            setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
                            title = c.name
                            snippet = "Updated ${formatAgo(c.locTime)}"
                        }
                        map.overlays.add(marker)
                        if (!centred) {
                            map.controller.setCenter(pos)
                            centred = true
                        }
                    }
                    map.invalidate()
                }
            )
            // Cross-hair in the middle: used when adding a safe place.
            Icon(
                Icons.Filled.Add, null,
                tint = ShieldBlue,
                modifier = Modifier
                    .align(Alignment.Center)
                    .size(28.dp)
            )
            Column(
                Modifier
                    .align(Alignment.TopEnd)
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                SmallFloatingActionButton(onClick = {
                    if (c.hasLocation) mapRef?.controller?.animateTo(GeoPoint(c.lat!!, c.lng!!))
                }) { Icon(Icons.Filled.PersonPin, "Show child") }
                SmallFloatingActionButton(onClick = { Repo.sendCommand(c.uid, "locate") }) {
                    Icon(Icons.Filled.Refresh, "Refresh location")
                }
            }
            Text(
                if (c.hasLocation) "Updated ${formatAgo(c.locTime)}" else "Waiting for first location",
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(12.dp)
                    .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(10.dp))
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                style = MaterialTheme.typography.labelMedium
            )
            Text(
                "© OpenStreetMap contributors",
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(4.dp)
                    .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.7f))
                    .padding(horizontal = 4.dp),
                style = MaterialTheme.typography.labelSmall
            )
        }

        Column(Modifier.padding(16.dp, 12.dp, 16.dp, 8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Safe places", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                if (c.hasLocation) {
                    TextButton(onClick = {
                        ctx.startActivity(
                            Intent(Intent.ACTION_VIEW, Uri.parse("geo:${c.lat},${c.lng}?q=${c.lat},${c.lng}(${Uri.encode(c.name)})"))
                        )
                    }) { Text("Directions") }
                }
                FilledTonalButton(onClick = { addPlace = true }) {
                    Icon(Icons.Filled.AddLocationAlt, null, Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Add")
                }
            }
            Text(
                "You get an alert when ${c.name} arrives at or leaves these places.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            LazyColumn(Modifier.heightIn(max = 180.dp)) {
                items(places, key = { it.name + it.lat }) { p ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier.size(34.dp).background(SafeGreen.copy(alpha = 0.15f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) { Icon(Icons.Filled.Place, null, tint = SafeGreen, modifier = Modifier.size(20.dp)) }
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(p.name, fontWeight = FontWeight.SemiBold)
                            Text("${p.radius} m around", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        if (c.currentPlace == p.name) {
                            Text("Here now", color = SafeGreen, style = MaterialTheme.typography.labelMedium)
                        }
                        IconButton(onClick = { Repo.setPlaces(c.uid, places - p) }) {
                            Icon(Icons.Filled.Delete, "Delete")
                        }
                    }
                }
            }
        }
    }

    if (addPlace) {
        AddPlaceDialog(
            onDismiss = { addPlace = false },
            onSave = { name, radius ->
                val centre = mapRef?.mapCenter
                if (centre != null) {
                    Repo.setPlaces(c.uid, places + Place(name, centre.latitude, centre.longitude, radius))
                }
                addPlace = false
            }
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun AddPlaceDialog(onDismiss: () -> Unit, onSave: (String, Int) -> Unit) {
    var name by remember { mutableStateOf("Home") }
    var radius by remember { mutableIntStateOf(200) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add safe place") },
        text = {
            Column {
                Text(
                    "Move the map so the + in the middle is on the place, then save.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(10.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Home", "School", "Tuition", "Grandparents").forEach {
                        FilterChip(selected = name == it, onClick = { name = it }, label = { Text(it) })
                    }
                }
                OutlinedTextField(
                    value = name, onValueChange = { name = it },
                    label = { Text("Name") }, singleLine = true, modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(10.dp))
                Text("Area size", style = MaterialTheme.typography.labelLarge)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(100, 200, 500, 1000).forEach {
                        FilterChip(selected = radius == it, onClick = { radius = it }, label = { Text("$it m") })
                    }
                }
            }
        },
        confirmButton = {
            Button(enabled = name.isNotBlank(), onClick = { onSave(name.trim(), radius) }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
