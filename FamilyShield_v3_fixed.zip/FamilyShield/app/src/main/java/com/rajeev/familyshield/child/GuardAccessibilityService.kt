package com.rajeev.familyshield.child

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.rajeev.familyshield.data.Prefs

/**
 * Watches which app comes to the front and the visible system uninstall flow,
 * showing a block screen or parent-PIN gate when the parent's rules require it.
 */
class GuardAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: GuardAccessibilityService? = null
            private set

        /** Package of the app currently in front, as seen by this service. */
        @Volatile
        var currentPackage: String? = null
            private set
    }

    private var lastBlockedPkg: String? = null
    private var lastBlockTime = 0L
    private var lastUninstallPrompt = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        if (Prefs(this).linked) MonitorService.start(this)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val pkg = event.packageName?.toString() ?: return
        if (isUninstallAttempt(pkg)) {
            promptForUninstallPin()
            return
        }
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        // Keyboard and system overlays should not change the "current app".
        if (pkg == "com.android.systemui" || isKeyboard(pkg)) return
        currentPackage = pkg
        check(pkg)
    }

    /** Detects only the system uninstall flow for Family Shield, not general Settings usage. */
    private fun isUninstallAttempt(pkg: String): Boolean {
        val prefs = Prefs(this)
        if (!prefs.linked || pkg == packageName || prefs.uninstallUnlockUntil > System.currentTimeMillis()) return false
        val systemPackage = pkg == "com.android.settings" ||
            pkg == "com.android.packageinstaller" ||
            pkg == "com.google.android.packageinstaller" ||
            pkg == "com.android.permissioncontroller"
        if (!systemPackage) return false
        val root = rootInActiveWindow ?: return false
        val text = StringBuilder()
        collectText(root, text)
        val screen = text.toString().lowercase()
        val uninstall = screen.contains("uninstall") || screen.contains("remove app") || screen.contains("delete app")
        val target = screen.contains("family shield") || screen.contains(packageName.lowercase())
        return uninstall && target
    }

    private fun collectText(node: AccessibilityNodeInfo?, out: StringBuilder) {
        if (node == null) return
        node.text?.let { out.append(' ').append(it) }
        node.contentDescription?.let { out.append(' ').append(it) }
        for (i in 0 until node.childCount) collectText(node.getChild(i), out)
    }

    private fun promptForUninstallPin() {
        val now = System.currentTimeMillis()
        if (now - lastUninstallPrompt < 1200L) return
        lastUninstallPrompt = now
        val intent = android.content.Intent(this, UninstallGuardActivity::class.java)
            .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK or android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP)
        try { startActivity(intent) } catch (_: Exception) { }
    }

    private fun isKeyboard(pkg: String): Boolean {
        val ime = android.provider.Settings.Secure.getString(
            contentResolver, android.provider.Settings.Secure.DEFAULT_INPUT_METHOD
        ) ?: return false
        return ime.startsWith("$pkg/")
    }

    /** Called on every app switch and every 30 seconds by MonitorService. */
    fun check(pkg: String? = currentPackage) {
        if (pkg == null || pkg == packageName) return
        val reason = BlockPolicy.reason(this, pkg) ?: return
        val now = System.currentTimeMillis()
        if (pkg == lastBlockedPkg && now - lastBlockTime < 1500) return
        lastBlockedPkg = pkg
        lastBlockTime = now
        performGlobalAction(GLOBAL_ACTION_HOME)
        BlockActivity.show(this, pkg, reason)
        MonitorService.onAppBlocked(this, pkg)
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }
}
