package com.rajeev.familyshield.ui

import android.app.Activity
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChildCare
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.rajeev.familyshield.data.GoogleAuth
import com.rajeev.familyshield.data.Invite
import com.rajeev.familyshield.data.Repo
import com.rajeev.familyshield.data.asFlow
import com.rajeev.familyshield.ui.common.ShieldLogo
import kotlinx.coroutines.launch

@Composable
private fun CenterPage(content: @Composable () -> Unit) {
    Box(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .safeDrawingPadding()
            .verticalScroll(rememberScrollState())
            .padding(28.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) { content() }
    }
}

@Composable
fun LoadingScreen() {
    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            ShieldLogo(80.dp)
            Spacer(Modifier.height(24.dp))
            CircularProgressIndicator()
        }
    }
}

@Composable
fun SignInScreen(activity: Activity, onSignedIn: () -> Unit) {
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    CenterPage {
        Spacer(Modifier.height(24.dp))
        ShieldLogo(112.dp)
        Spacer(Modifier.height(24.dp))
        Text("Family Shield", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text(
            "Keep your child safe on their phone: screen time, app limits, location and SOS.",
            style = MaterialTheme.typography.bodyLarge, textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(40.dp))
        Button(
            onClick = {
                busy = true; error = null
                scope.launch {
                    val err = GoogleAuth.signIn(activity)
                    busy = false
                    if (err == null && Repo.me != null) onSignedIn() else error = err
                }
            },
            enabled = !busy,
            modifier = Modifier.fillMaxWidth().height(54.dp),
            shape = RoundedCornerShape(16.dp)
        ) {
            if (busy) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
            else Text("Sign in with Google", style = MaterialTheme.typography.titleMedium)
        }
        error?.let {
            Spacer(Modifier.height(12.dp))
            Text(it, color = MaterialTheme.colorScheme.error, textAlign = TextAlign.Center)
        }
        Spacer(Modifier.height(28.dp))
        Row(
            Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.primaryContainer, RoundedCornerShape(16.dp))
                .padding(14.dp),
            verticalAlignment = Alignment.Top
        ) {
            Icon(Icons.Filled.Info, null, tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.width(10.dp))
            Text(
                "Child's phone? Sign in with the same Gmail your parent added. The phone connects to your parent automatically.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onPrimaryContainer
            )
        }
    }
}

@Composable
fun NewAccountScreen(name: String, onParent: () -> Unit, onChild: () -> Unit, onSignOut: () -> Unit) {
    CenterPage {
        ShieldLogo(96.dp)
        Spacer(Modifier.height(24.dp))
        Text(
            "Welcome${if (name.isNotBlank()) ", ${name.substringBefore(' ')}" else ""}!",
            style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold
        )
        Spacer(Modifier.height(10.dp))
        Text(
            "This Gmail hasn't been added by any parent, so it will be set up as a parent account. You can then add your children.",
            textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(32.dp))
        Button(
            onClick = onParent,
            modifier = Modifier.fillMaxWidth().height(54.dp),
            shape = RoundedCornerShape(16.dp)
        ) { Text("Continue as parent", style = MaterialTheme.typography.titleMedium) }
        Spacer(Modifier.height(12.dp))
        TextButton(onClick = onChild) {
            Icon(Icons.Filled.ChildCare, null)
            Spacer(Modifier.width(6.dp))
            Text("I'm a child, waiting for my parent")
        }
        TextButton(onClick = onSignOut) { Text("Use a different Gmail") }
    }
}

@Composable
fun WaitingScreen(email: String, onInvite: (Invite) -> Unit, onSignOut: () -> Unit) {
    val flow = remember(email) { Repo.inviteDoc(email).asFlow() }
    LaunchedEffect(flow) {
        flow.collect { snap ->
            val inv = snap?.let { Invite.from(it) }
            if (inv != null) onInvite(inv)
        }
    }
    CenterPage {
        ShieldLogo(96.dp)
        Spacer(Modifier.height(24.dp))
        Text("Waiting for your parent", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Text(
            "Ask your parent to open Family Shield on their phone, tap \"Add child\" and enter this Gmail:",
            textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(16.dp))
        Text(
            email,
            modifier = Modifier
                .background(MaterialTheme.colorScheme.primaryContainer, RoundedCornerShape(12.dp))
                .padding(horizontal = 16.dp, vertical = 10.dp),
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onPrimaryContainer
        )
        Spacer(Modifier.height(28.dp))
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
            CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
            Spacer(Modifier.width(10.dp))
            Text("This phone will connect automatically", style = MaterialTheme.typography.bodyMedium)
        }
        Spacer(Modifier.height(28.dp))
        OutlinedButton(onClick = onSignOut) { Text("Use a different Gmail") }
    }
}

@Composable
fun ErrorScreen(message: String, onRetry: () -> Unit, onSignOut: () -> Unit) {
    CenterPage {
        ShieldLogo(80.dp)
        Spacer(Modifier.height(24.dp))
        Text("Something went wrong", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text(message, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(24.dp))
        Button(onClick = onRetry) { Text("Try again") }
        TextButton(onClick = onSignOut) { Text("Sign out") }
    }
}
