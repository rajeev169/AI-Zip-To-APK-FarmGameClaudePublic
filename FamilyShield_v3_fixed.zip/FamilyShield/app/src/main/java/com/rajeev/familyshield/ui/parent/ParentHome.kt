package com.rajeev.familyshield.ui.parent

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.rajeev.familyshield.data.ChildInfo
import com.rajeev.familyshield.data.Day
import com.rajeev.familyshield.data.Invite
import com.rajeev.familyshield.data.Repo
import com.rajeev.familyshield.data.asFlow
import com.rajeev.familyshield.data.formatAgo
import com.rajeev.familyshield.data.formatMinutes
import com.rajeev.familyshield.ui.common.Avatar
import com.rajeev.familyshield.ui.common.SectionCard
import com.rajeev.familyshield.ui.common.ShieldLogo
import com.rajeev.familyshield.ui.common.StatusDot
import com.rajeev.familyshield.ui.theme.SosRed
import kotlinx.coroutines.launch

@Composable
fun ParentRoot(openAlerts: Boolean, onAlertsOpened: () -> Unit, onSignOut: () -> Unit) {
    val nav = rememberNavController()
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    LaunchedEffect(openAlerts) {
        if (openAlerts) {
            nav.navigate("alerts") { launchSingleTop = true }
            onAlertsOpened()
        }
    }
    NavHost(nav, startDestination = "home") {
        composable("home") {
            ParentHome(
                onOpenChild = { nav.navigate("child/$it") },
                onOpenAlerts = { nav.navigate("alerts") },
                onSignOut = onSignOut,
            )
        }
        composable("child/{uid}", arguments = listOf(navArgument("uid") { type = NavType.StringType })) {
            ChildDetail(uid = it.arguments?.getString("uid") ?: "", onBack = { nav.popBackStack() })
        }
        composable("alerts") {
            AlertsScreen(onBack = { nav.popBackStack() })
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ParentHome(onOpenChild: (String) -> Unit, onOpenAlerts: () -> Unit, onSignOut: () -> Unit) {
    val uid = Repo.me?.uid ?: return
    val childrenSnap by remember(uid) {
        Repo.db.collection("children").whereEqualTo("parentUid", uid).asFlow()
    }.collectAsStateWithLifecycle(null)
    val invitesSnap by remember(uid) {
        Repo.db.collection("invites").whereEqualTo("parentUid", uid).asFlow()
    }.collectAsStateWithLifecycle(null)
    val unreadSnap by remember(uid) {
        Repo.alertsCol(uid).whereEqualTo("read", false).asFlow()
    }.collectAsStateWithLifecycle(null)

    val children = childrenSnap?.documents?.mapNotNull { ChildInfo.from(it) }?.sortedBy { it.name } ?: emptyList()
    val pending = invitesSnap?.documents?.mapNotNull { Invite.from(it) }?.filter { it.status == "pending" } ?: emptyList()
    val unread = unreadSnap?.size() ?: 0
    val loading = childrenSnap == null

    var showAdd by remember { mutableStateOf(false) }
    var showPin by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        ShieldLogo(32.dp)
                        Spacer(Modifier.width(10.dp))
                        Text("Family Shield", fontWeight = FontWeight.Bold)
                    }
                },
                actions = {
                    IconButton(onClick = onOpenAlerts) {
                        BadgedBox(badge = { if (unread > 0) Badge { Text(if (unread > 99) "99+" else "$unread") } }) {
                            Icon(Icons.Filled.Notifications, "Alerts")
                        }
                    }
                    Box {
                        IconButton(onClick = { menu = true }) { Icon(Icons.Filled.MoreVert, "Menu") }
                        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                            DropdownMenuItem(
                                text = { Text("Signed in as ${Repo.me?.email ?: ""}") },
                                onClick = {}, enabled = false
                            )
                            DropdownMenuItem(
                                text = { Text("Set parent PIN") },
                                leadingIcon = { Icon(Icons.Filled.Lock, null) },
                                onClick = { menu = false; showPin = true }
                            )
                            DropdownMenuItem(
                                text = { Text("Sign out") },
                                leadingIcon = { Icon(Icons.Filled.Logout, null) },
                                onClick = { menu = false; onSignOut() }
                            )
                        }
                    }
                }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showAdd = true },
                icon = { Icon(Icons.Filled.PersonAdd, null) },
                text = { Text("Add child") }
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { pad ->
        LazyColumn(
            Modifier
                .fillMaxSize()
                .padding(pad),
            contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 96.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (loading) {
                item {
                    Box(Modifier.fillMaxWidth().padding(40.dp), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }
                }
            } else if (children.isEmpty() && pending.isEmpty()) {
                item { EmptyState() }
            }
            items(children, key = { it.uid }) { child ->
                ChildCard(child) { onOpenChild(child.uid) }
            }
            if (pending.isNotEmpty()) {
                item {
                    Text(
                        "Waiting to connect",
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 8.dp, start = 4.dp)
                    )
                }
                items(pending, key = { it.email }) { inv ->
                    SectionCard {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Avatar(inv.childName.ifBlank { inv.email }, 44.dp, MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(inv.childName.ifBlank { "Child" }, fontWeight = FontWeight.SemiBold)
                                Text(
                                    inv.email, style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1, overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    "Install Family Shield on the child's phone and sign in with this Gmail",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                            IconButton(onClick = { scope.launch { runCatching { Repo.removeInvite(inv.email) } } }) {
                                Icon(Icons.Filled.Close, "Cancel")
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAdd) AddChildDialog(onDismiss = { showAdd = false })
    if (showPin) SetPinDialog(onDismiss = { showPin = false })
}

@Composable
private fun SetPinDialog(onDismiss: () -> Unit) {
    var pin by remember { mutableStateOf("") }
    var loaded by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    LaunchedEffect(Unit) {
        pin = runCatching { Repo.currentPin() }.getOrDefault("")
        loaded = true
    }
    AlertDialog(
        onDismissRequest = { if (!busy) onDismiss() },
        icon = { Icon(Icons.Filled.Lock, null) },
        title = { Text("Parent PIN") },
        text = {
            Column {
                Text(
                    "This PIN is needed on your child's phone before anyone can change protection settings in the app. Leave empty to turn it off.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = pin,
                    onValueChange = { if (it.length <= 4 && it.all { c -> c.isDigit() }) pin = it },
                    label = { Text("4-digit PIN") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                enabled = loaded && !busy && (pin.isEmpty() || pin.length == 4),
                onClick = {
                    busy = true
                    scope.launch {
                        runCatching { Repo.setParentPin(pin) }
                        busy = false
                        onDismiss()
                    }
                }
            ) { Text(if (busy) "Saving..." else "Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss, enabled = !busy) { Text("Cancel") } }
    )
}

@Composable
private fun EmptyState() {
    SectionCard {
        Text("Add your first child", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        val steps = listOf(
            "Tap \"Add child\" and enter your child's name and Gmail.",
            "Install Family Shield on your child's phone.",
            "Sign in there with the same Gmail. It connects to you automatically.",
            "Allow the permissions on the child's phone (takes about a minute).",
        )
        steps.forEachIndexed { i, s ->
            Row(Modifier.padding(vertical = 6.dp), verticalAlignment = Alignment.Top) {
                Box(
                    Modifier
                        .size(26.dp)
                        .background(MaterialTheme.colorScheme.primary, RoundedCornerShape(13.dp)),
                    contentAlignment = Alignment.Center
                ) { Text("${i + 1}", color = MaterialTheme.colorScheme.onPrimary, style = MaterialTheme.typography.labelLarge) }
                Spacer(Modifier.width(12.dp))
                Text(s, style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}

@Composable
private fun ChildCard(child: ChildInfo, onClick: () -> Unit) {
    val online = System.currentTimeMillis() - child.lastSeen < 6 * 60_000L
    val todayMin = if (child.todayDate == Day.key()) child.todayTotalMin else 0L
    val missing = child.missingProtection
    SectionCard(Modifier.clickable(onClick = onClick)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Avatar(child.name, 52.dp)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(child.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    StatusDot(online)
                    Spacer(Modifier.width(6.dp))
                    Text(
                        if (online) "Online" else "Last seen ${formatAgo(child.lastSeen)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (child.battery >= 0) {
                        Spacer(Modifier.width(10.dp))
                        Icon(
                            if (child.charging) Icons.Filled.BatteryChargingFull else Icons.Filled.BatteryStd,
                            null, Modifier.size(14.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            "${child.battery}%", style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                if (child.currentPlace.isNotBlank()) {
                    Text(
                        "At ${child.currentPlace}", style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.tertiary
                    )
                }
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(formatMinutes(todayMin), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text("today", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        if (missing.isNotEmpty()) {
            Spacer(Modifier.height(10.dp))
            Row(
                Modifier
                    .fillMaxWidth()
                    .background(SosRed.copy(alpha = 0.1f), RoundedCornerShape(10.dp))
                    .padding(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Filled.Warning, null, tint = SosRed, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text(
                    "Off on child's phone: ${missing.joinToString(", ")}",
                    style = MaterialTheme.typography.bodySmall, color = SosRed
                )
            }
        }
    }
}

@Composable
private fun AddChildDialog(onDismiss: () -> Unit) {
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    AlertDialog(
        onDismissRequest = { if (!busy) onDismiss() },
        icon = { Icon(Icons.Filled.PersonAdd, null) },
        title = { Text("Add child") },
        text = {
            Column {
                OutlinedTextField(
                    value = name, onValueChange = { name = it; error = null },
                    label = { Text("Child's name") }, singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = email, onValueChange = { email = it.trim(); error = null },
                    label = { Text("Child's Gmail") }, singleLine = true,
                    placeholder = { Text("name@gmail.com") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    "When your child signs in to Family Shield with this Gmail, their phone connects to you automatically.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                error?.let {
                    Spacer(Modifier.height(8.dp))
                    Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            Button(
                enabled = !busy && name.isNotBlank() && email.isNotBlank(),
                onClick = {
                    busy = true
                    scope.launch {
                        val err = Repo.addChild(name, email)
                        busy = false
                        if (err == null) onDismiss() else error = err
                    }
                }
            ) { Text(if (busy) "Adding..." else "Add") }
        },
        dismissButton = { TextButton(onClick = onDismiss, enabled = !busy) { Text("Cancel") } }
    )
}
