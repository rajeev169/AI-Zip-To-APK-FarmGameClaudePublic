package com.rajeev.familyshield.parent

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.google.firebase.firestore.DocumentChange
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import com.rajeev.familyshield.FamilyShieldApp
import com.rajeev.familyshield.MainActivity
import com.rajeev.familyshield.R
import com.rajeev.familyshield.data.AlertItem
import com.rajeev.familyshield.data.AlertType
import com.rajeev.familyshield.data.Prefs
import com.rajeev.familyshield.data.Repo

/** Keeps listening on the parent's phone so SOS and safety alerts arrive instantly. */
class ParentAlertService : Service() {

    companion object {
        private const val NOTIF_ID = 21

        fun start(ctx: Context) {
            try {
                ContextCompat.startForegroundService(ctx, Intent(ctx, ParentAlertService::class.java))
            } catch (_: Exception) {
            }
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, ParentAlertService::class.java))
        }
    }

    private var reg: ListenerRegistration? = null
    private lateinit var prefs: Prefs

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(this, FamilyShieldApp.CH_MONITOR)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("Family Shield")
            .setContentText("Watching for alerts from your children")
            .setOngoing(true)
            .setContentIntent(open)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .build()
        val type = if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
        try {
            ServiceCompat.startForeground(this, NOTIF_ID, n, type)
        } catch (_: Exception) {
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val uid = Repo.me?.uid
        if (uid == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (reg == null) {
            if (prefs.lastAlertTime == 0L) prefs.lastAlertTime = System.currentTimeMillis()
            reg = Repo.alertsCol(uid)
                .whereGreaterThan("time", prefs.lastAlertTime)
                .orderBy("time", Query.Direction.ASCENDING)
                .addSnapshotListener { snap, _ ->
                    snap ?: return@addSnapshotListener
                    snap.documentChanges
                        .filter { it.type == DocumentChange.Type.ADDED && !it.document.metadata.hasPendingWrites() }
                        .map { AlertItem.from(it.document) }
                        .filter { it.time > prefs.lastAlertTime && !it.read }
                        .forEach { notify(it) }
                }
        }
        return START_STICKY
    }

    private fun notify(a: AlertItem) {
        prefs.lastAlertTime = maxOf(prefs.lastAlertTime, a.time)
        val open = PendingIntent.getActivity(
            this, a.id.hashCode(),
            Intent(this, MainActivity::class.java).putExtra("openAlerts", true)
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val sos = a.type == AlertType.SOS
        val n: Notification = NotificationCompat.Builder(this, if (sos) FamilyShieldApp.CH_SOS else FamilyShieldApp.CH_ALERTS)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(a.title)
            .setContentText(a.message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(a.message))
            .setAutoCancel(true)
            .setContentIntent(open)
            .setPriority(if (sos) NotificationCompat.PRIORITY_MAX else NotificationCompat.PRIORITY_HIGH)
            .setCategory(if (sos) NotificationCompat.CATEGORY_ALARM else NotificationCompat.CATEGORY_MESSAGE)
            .build()
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        try {
            nm.notify(a.id.hashCode(), n)
        } catch (_: SecurityException) {
        }
    }

    override fun onDestroy() {
        reg?.remove()
        super.onDestroy()
    }
}
