package com.rajeev.familyshield.parent

import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.rajeev.familyshield.FamilyShieldApp
import com.rajeev.familyshield.MainActivity
import com.rajeev.familyshield.R
import com.rajeev.familyshield.data.ChildInfo
import com.rajeev.familyshield.data.Prefs
import com.rajeev.familyshield.data.Repo
import com.rajeev.familyshield.data.formatAgo
import kotlinx.coroutines.tasks.await
import java.util.concurrent.TimeUnit

/**
 * Runs on the parent's phone every ~15 minutes. If a child's phone has stopped
 * reporting for a while — app removed, phone off, or no internet — the parent is
 * told. This is the Play-compliant way to detect tampering: we alert, we don't
 * try to lock the child out of their own settings.
 */
class OfflineCheckWorker(appContext: Context, params: WorkerParameters) :
    CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        val uid = Repo.me?.uid ?: return Result.success()
        val prefs = Prefs(applicationContext)
        val now = System.currentTimeMillis()

        val children = try {
            Repo.db.collection("children").whereEqualTo("parentUid", uid).get().await()
                .documents.mapNotNull { ChildInfo.from(it) }
        } catch (e: Exception) {
            return Result.retry()
        }

        val notified = prefs.offlineNotified.toMutableSet()
        children.forEach { child ->
            // Give a freshly linked phone time before judging it offline.
            if (child.lastSeen <= 0) return@forEach
            val silentFor = now - child.lastSeen
            val isOffline = silentFor > OFFLINE_AFTER_MS
            if (isOffline && child.uid !in notified) {
                notifyOffline(child)
                notified += child.uid
            } else if (!isOffline && child.uid in notified) {
                notified -= child.uid
            }
        }
        prefs.offlineNotified = notified
        return Result.success()
    }

    private fun notifyOffline(child: ChildInfo) {
        val open = PendingIntent.getActivity(
            applicationContext, ("off" + child.uid).hashCode(),
            android.content.Intent(applicationContext, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(applicationContext, FamilyShieldApp.CH_ALERTS)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("${child.name}'s phone is offline")
            .setContentText(
                "No update since ${formatAgo(child.lastSeen)}. The phone may be off, out of network, " +
                        "or Family Shield may have been removed."
            )
            .setStyle(NotificationCompat.BigTextStyle())
            .setAutoCancel(true)
            .setContentIntent(open)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()
        try {
            (applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
                .notify(("off" + child.uid).hashCode(), n)
        } catch (_: SecurityException) {
        }
    }

    companion object {
        private const val OFFLINE_AFTER_MS = 40 * 60_000L
        private const val WORK = "offline_check"

        fun schedule(ctx: Context) {
            val req = PeriodicWorkRequestBuilder<OfflineCheckWorker>(15, TimeUnit.MINUTES).build()
            WorkManager.getInstance(ctx)
                .enqueueUniquePeriodicWork(WORK, ExistingPeriodicWorkPolicy.KEEP, req)
        }

        fun cancel(ctx: Context) {
            WorkManager.getInstance(ctx).cancelUniqueWork(WORK)
        }
    }
}
