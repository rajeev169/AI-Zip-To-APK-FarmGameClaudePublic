package com.aipdfstudio.app.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.lifecycle.viewmodel.compose.viewModel
import com.aipdfstudio.app.data.OcrOps
import com.aipdfstudio.app.data.OcrScript
import com.aipdfstudio.app.data.Outputs

@Composable
fun OcrScreen(onBack: () -> Unit, onOpen: (Uri) -> Unit, vm: ToolVm = viewModel()) {
    val ctx = LocalContext.current
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.addFiles(listOf(uri), replace = true)
    }
    var script by rememberSaveable { mutableStateOf(OcrScript.LATIN) }
    var searchable by rememberSaveable { mutableStateOf(true) }
    val p = vm.single
    val usable = p != null && !p.locked && !p.broken
    // The built-in PDF font has no Hindi letters, so the hidden text layer is English-only.
    val makePdf = searchable && script == OcrScript.LATIN

    ToolPage(
        title = "OCR: read scanned text",
        vm = vm,
        onBack = onBack,
        actionLabel = if (makePdf) "Make searchable PDF" else "Read text",
        actionEnabled = usable,
        onAction = act@{
            val src = p ?: return@act
            val chosen = script
            val pdf = makePdf
            vm.run("Starting text reader…") { progress ->
                val outPdf = if (pdf) Outputs.newFile(ctx, src.name, "searchable") else null
                val text = OcrOps.run(ctx, src.uri, chosen, outPdf, progress)
                val txt = Outputs.newFile(ctx, src.name, "text", "txt")
                txt.writeText(text)
                vm.postText(text)
                listOfNotNull(outPdf, txt) to
                    if (pdf) "Done. The new PDF looks the same but you can now search and copy its text." else null
            }
        }
    ) {
        item(key = "hint") {
            Hint("Reads the words in scanned pages and photos. Runs on your phone; nothing is uploaded.")
        }
        item(key = "file") { PickedCard(p, vm.loading) { picker.launch(arrayOf("application/pdf")) } }
        if (p != null && p.locked) {
            item(key = "locked") { MessageCard("This PDF is password protected. Unlock it first with the Unlock tool.", isError = true) }
        }
        if (usable) {
            item(key = "langTitle") {
                Text("Language of the document", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Medium)
            }
            OcrScript.entries.forEach { s ->
                item(key = "lang_" + s.name) {
                    ChoiceRow(s.label, s.sub, script == s) { script = s; vm.clearOutcome() }
                }
            }
            item(key = "outTitle") {
                Text("What do you want?", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Medium)
            }
            item(key = "out1") {
                ChoiceRow(
                    "Searchable PDF + text",
                    if (script == OcrScript.LATIN) "Same-looking PDF you can search and copy from, plus a .txt file"
                    else "Searchable PDF is for English only. For Hindi you'll get the text file.",
                    searchable
                ) { searchable = true; vm.clearOutcome() }
            }
            item(key = "out2") {
                ChoiceRow("Text only", "A .txt file and text you can copy", !searchable) { searchable = false; vm.clearOutcome() }
            }
        }
        outcome(vm, onOpen)
    }
}
