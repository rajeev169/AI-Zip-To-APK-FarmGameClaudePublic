# AI PDF Studio (stage 3)

Native Android app (Kotlin, Jetpack Compose, Material 3) with a Fresh teal theme, light and dark.

## Built so far
### Stage 1
- App shell: bottom navigation (Files, Tools, AI), teal Material 3 theme with dark mode, adaptive icon
- Files: search, "continue where you left off" card, recent list, open from the file picker or from other apps
- PDF viewer: smooth scrolling, zoom steps, night mode, page counter, remembers last page
- AI studio (Gemini, user's own key): summarize, key points, translate, chat with the document
- AI settings: key entry (encrypted on device), Test key button, model name, privacy note

### Stage 2 (new)
- Merge: pick several PDFs, reorder them, join into one
- Split: pick pages (e.g. `1-3, 5, 8-`) into one file, split every N pages, or one file per page
- Page tools: page thumbnails, select pages, rotate left/right, move earlier/later, delete, undo, reset
- Compress: Light / Recommended / Strong. Re-encodes photos and scans as smaller JPEGs; text stays sharp.
  Shows before → after size, and tells you if the file can't be made smaller
- Lock: add a password (AES-256)
- Unlock: remove a password you know (or remove owner restrictions from a file that opens without one)
- Results screen for every tool: Open, Share, Save to phone; "Save all" to a folder and "Share all" for multiple files
- Viewer: new Share button; locked files now point you to the Unlock tool
- Home: Merge and Compress shortcuts now work
- All processing is done on the phone. Nothing is uploaded. Originals are never changed;
  results are kept in the app's private storage until you save or share them.

### Stage 3 (new)
- Sign: draw or type a signature (black or blue ink), saved for next time. Drag it onto any page,
  resize it, or put it in the same spot on every page. Works on rotated pages.
- Scan to PDF: Google ML Kit document scanner (auto edge detection, crop, rotate, clean-up filters,
  multi-page, import from gallery). Needs Google Play services.
- Convert: Images to PDF (A4 or photo-shaped pages, EXIF rotation fixed, reorder),
  PDF to JPG (one image per page), PDF to Word (.docx, text only), PDF to text (.txt)
- OCR: reads scanned pages on the phone (English/Latin or Hindi/Devanagari). Makes a searchable PDF
  (English) with an invisible text layer, plus a .txt file and copyable text. Pages that already
  have text are not scanned again.
- Results can now be images, Word and text files: Open uses another app for non-PDF files.

## Not built yet
Smart edit, redact, forms, compare, bookmarks, cloud links, ads and Premium (will be added switched off).

## Build
- JDK 17, Gradle 8.9, Android Gradle Plugin 8.7.3, Kotlin 2.0.21, compileSdk/targetSdk 35, minSdk 26
- Package / applicationId: com.aipdfstudio.app (change before publishing if you want a different id)
- Gradle wrapper (gradlew, Gradle 8.9) is included: run `./gradlew assembleDebug`
- This code was written without an Android SDK to compile against, so the first build may need small fixes.
  Send me the Gradle error text if it fails and I'll fix it.

## Tested before delivery (stage 3)
- Whole project type-checked with the Kotlin 2.0.21 + Compose compiler against the exact library
  versions from the stage 2 APK (ML Kit checked against its documented API).
- Signature placement and OCR text layer math unit-tested and checked by rendering real PDFs with
  page rotation 0/90/180/270. Word export opened in LibreOffice.

## Before Play Store release
Signing config, AAB build, privacy policy, data safety form (document text is sent to Google Gemini
using the user's own key), real store screenshots.
