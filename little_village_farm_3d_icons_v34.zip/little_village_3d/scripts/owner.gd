extends Node
# Owner Mode (v30): you are the farmer. Walk anywhere on your land with a round
# joystick, see the farm from behind your shoulder, and do the work yourself:
# collect milk, eggs, truffles and apples, plant, water, weed and harvest crops,
# and open the shops. Coins, XP, stock and saves are shared with the normal game.

var g: Node
var v: Node

const SailScript := preload("res://scripts/sail.gd")
const GROUND_Y := 0.15
const WALK_SPEED := 4.2
const LIMIT := 18.0

var on: bool = false
var top_view: bool = false
var player: Node3D
var model: Node3D
var cam: Camera3D
var heading: float = 0.0          # player yaw; the model faces local +x
var cam_h: float = 0.0
var speed: float = 0.0
var phase: float = 0.0
var hop_t: float = 0.0
var t: float = 0.0
var built: bool = false
var obstacles: Array = []
var target: Dictionary = {}
var steer_vis: float = 0.0
var parts: Dictionary = {}
var glow: OmniLight3D
var cam_dist: float = 4.4
var py_cur: float = 0.15
var in_building: bool = false
var flying: int = 0                # 0 = walking, 1 = drone, 2 = helicopter
var fveh: Dictionary = {}
var fnode: Node3D
var fyaw: float = 0.0
var fspeed: float = 0.0
var falt: float = 0.0
var fvy: float = 0.0
var f_autopilot: bool = false
var pilot_view: bool = false
var pilot_hud: Control
var pilot_lbl: Label
var f_phase: int = 0
var dv: Dictionary = {}            # the road vehicle being driven
const WATER_Y := -0.57
const SWIM_SPEED := 2.7
var reg: int = 0                   # 0 farm land, 1 swimming in the sea, 2 small island, 3 carrier deck
var reg_i: int = -1
var cl_on: bool = false            # climbing / jumping animation
var cl_t: float = 0.0
var cl_dur: float = 1.0
var cl_from: Vector3 = Vector3.ZERO
var cl_to: Vector3 = Vector3.ZERO
var cl_arc: float = 0.0
var cl_reg: int = 0
var cl_i: int = -1
var swim_t: float = 0.0
var swim_fx: Node3D
var fk: int = 0                    # 1 drone, 2 helicopter, 3 plane, 4 boat, 5 jet
var fpad: Vector3 = Vector3.ZERO
var fland: float = PI
var shadow: MeshInstance3D
var eng: AudioStreamPlayer
var eng_kind: String = ""
var eng_waves: Dictionary = {}
var dspeed: float = 0.0
var dyaw: float = 0.0
const DRIVE := {"Tractor": [4.2, 0.9], "Ambulance": [8.5, 1.1], "Pickup": [7.0, 1.0]}
const PV := {
    "Tractor": [Vector3(-0.2, 1.1, 0.12), Vector3(0, 0, 1)],
    "Ambulance": [Vector3(0.0, 1.02, 0.78), Vector3(0, 0, 1)],
    "Pickup": [Vector3(0.0, 0.95, 1.05), Vector3(0, 0, 1)],
    "Locomotive": [Vector3(-0.3, 0.95, 0.27), Vector3(1, 0, 0)],
    "SupplyPlane": [Vector3(-0.2, 0.66, 0.0), Vector3(1, 0, 0)],
    "CargoBoat": [Vector3(-0.3, 1.43, 0.45), Vector3(1, 0, 0)],
    "Jet": [Vector3(0.02, 0.36, 0.0), Vector3(1, 0, 0)],
}
var up_btn: Button
var down_btn: Button
var up_held: bool = false
var down_held: bool = false
var still_t: float = 0.0

var hud: CanvasLayer
var enter_btn: Button
var exit_btn: Button
var view_btn: Button
var act_btn: Button
var joy: Control
var bottom_bar: Control

const SOLIDS := [
    Vector3(-4.2, -4.1, 2.3),    # farmhouse
    Vector3(3.7, -4.1, 2.4),     # barn
    Vector3(9.6, -7.4, 1.6),     # silo
    Vector3(-10.8, -1.4, 1.8),   # bakery oven
    Vector3(8.2, 11.0, 2.3),     # market tent
    Vector3(-10.0, 12.5, 2.6),   # windmill site
    Vector3(5.0, 0.1, 0.9),      # well
    Vector3(-12.0, -6.5, 3.1),   # pond
    Vector3(15.5, 7.0, 2.7),     # pond
]

# ----------------------------------------------------------------- HUD

func _style(b: Button, col: Color, radius: int) -> void:
    b.add_theme_font_size_override("font_size", 22)
    b.add_theme_color_override("font_color", Color.WHITE)
    b.add_theme_color_override("font_pressed_color", Color.WHITE)
    for st in ["normal", "hover", "pressed", "focus"]:
        var sb := StyleBoxFlat.new()
        sb.bg_color = col if st != "pressed" else col.darkened(0.3)
        sb.set_corner_radius_all(radius)
        sb.border_color = Color(1, 1, 1, 0.9)
        sb.set_border_width_all(4)
        sb.shadow_color = Color(0, 0, 0, 0.3)
        sb.shadow_size = 4
        b.add_theme_stylebox_override(st, sb)

# ----------------------------------------------------------------- icon buttons (no text)
# v34: pilot view, UP, DOWN, GET IN / GET OUT and RETURN buttons are round icon buttons.

class BtnIcon extends Control:
    var kind: String = ""
    func _ready() -> void:
        mouse_filter = Control.MOUSE_FILTER_IGNORE
        set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    func _pie(c: Vector2, r: float, a0: float, a1: float, col: Color, u: float) -> void:
        var pts := PackedVector2Array()
        pts.append(c)
        for i in range(25):
            var a: float = a0 + (a1 - a0) * float(i) / 24.0
            pts.append(c + Vector2(cos(a), sin(a)) * r * u)
        draw_colored_polygon(pts, col)
    func _draw() -> void:
        var u: float = minf(size.x, size.y) / 100.0
        var o: Vector2 = (size - Vector2(100, 100) * u) * 0.5
        var W := Color.WHITE
        if kind == "up" or kind == "down":
            var k: float = -1.0 if kind == "up" else 1.0
            var pts: Array = [Vector2(50, 50 + k * 26), Vector2(26, 50 - k * 2), Vector2(40, 50 - k * 2), Vector2(40, 50 - k * 24), Vector2(60, 50 - k * 24), Vector2(60, 50 - k * 2), Vector2(74, 50 - k * 2)]
            var pp := PackedVector2Array()
            for q in pts:
                pp.append(o + (q as Vector2) * u)
            draw_colored_polygon(pp, W)
        elif kind == "house":
            draw_colored_polygon(PackedVector2Array([o + Vector2(50, 22) * u, o + Vector2(22, 50) * u, o + Vector2(78, 50) * u]), W)
            draw_rect(Rect2(o + Vector2(30, 50) * u, Vector2(40, 26) * u), W)
            draw_rect(Rect2(o + Vector2(44, 58) * u, Vector2(12, 18) * u), Color(0.93, 0.55, 0.12))
        elif kind == "wheel":
            draw_arc(o + Vector2(50, 50) * u, 24.0 * u, 0.0, TAU, 40, W, 6.0 * u)
            for a in [PI * 0.5, PI * 7.0 / 6.0, PI * 11.0 / 6.0]:
                draw_line(o + Vector2(50, 50) * u, o + (Vector2(50, 50) + Vector2(cos(a), sin(a)) * 22.0) * u, W, 6.0 * u)
            draw_circle(o + Vector2(50, 50) * u, 6.0 * u, W)
        elif kind == "door":
            draw_rect(Rect2(o + Vector2(28, 24) * u, Vector2(26, 52) * u), W, false, 5.0 * u)
            draw_colored_polygon(PackedVector2Array([o + Vector2(58, 40) * u, o + Vector2(58, 60) * u, o + Vector2(78, 50) * u]), W)
        elif kind == "cap":
            var skin := Color(1.0, 0.84, 0.67)
            var navy := Color(0.12, 0.2, 0.43)
            var gold := Color(0.92, 0.78, 0.24)
            _pie(o + Vector2(50, 88) * u, 27.0, PI, TAU, Color(0.96, 0.96, 0.96), u)
            draw_rect(Rect2(o + Vector2(44, 56) * u, Vector2(12, 12) * u), skin)
            draw_circle(o + Vector2(50, 46) * u, 14.0 * u, skin)
            draw_circle(o + Vector2(44, 49) * u, 1.8 * u, Color(0.15, 0.15, 0.15))
            draw_circle(o + Vector2(56, 49) * u, 1.8 * u, Color(0.15, 0.15, 0.15))
            draw_arc(o + Vector2(50, 53) * u, 4.5 * u, 0.3, PI - 0.3, 10, Color(0.6, 0.28, 0.24), 1.6 * u)
            _pie(o + Vector2(50, 40) * u, 17.0, PI, TAU, navy, u)
            draw_rect(Rect2(o + Vector2(33, 36) * u, Vector2(34, 5) * u), gold)
            draw_colored_polygon(PackedVector2Array([o + Vector2(29, 41) * u, o + Vector2(71, 41) * u, o + Vector2(66, 46) * u, o + Vector2(34, 46) * u]), Color(0.08, 0.13, 0.3))
            draw_circle(o + Vector2(50, 31) * u, 2.6 * u, gold)

var bcache: Dictionary = {}

func _put_rect(b: Control, al: float, at: float, ar: float, ab: float, ol: float, ot: float, orr: float, ob: float) -> void:
    b.anchor_left = al
    b.anchor_top = at
    b.anchor_right = ar
    b.anchor_bottom = ab
    b.offset_left = ol
    b.offset_top = ot
    b.offset_right = orr
    b.offset_bottom = ob

func _icon_btn(b: Button, kind: String, col: Color) -> void:
    _style(b, col, 55)
    b.clip_text = true          # the hidden text must not make the round button wider
    for c in ["font_color", "font_pressed_color", "font_hover_color", "font_focus_color"]:
        b.add_theme_color_override(c, Color(0, 0, 0, 0))
    var ic: BtnIcon = b.get_node_or_null("Ic") as BtnIcon
    if ic == null:
        ic = BtnIcon.new()
        ic.name = "Ic"
        b.add_child(ic)
    ic.kind = kind
    ic.queue_redraw()

func _text_btn(b: Button, col: Color, radius: int) -> void:
    _style(b, col, radius)
    b.clip_text = false
    var ic: Node = b.get_node_or_null("Ic")
    if ic != null:
        ic.queue_free()

func _sync_buttons() -> void:
    if hud == null:
        return
    # UP / DOWN
    if not bcache.has("ud"):
        bcache["ud"] = 1
        _put_rect(up_btn, 1, 1, 1, 1, -114, -360, -24, -270)
        _put_rect(down_btn, 1, 1, 1, 1, -114, -260, -24, -170)
        _icon_btn(up_btn, "up", Color(0.25, 0.45, 0.75))
        _icon_btn(down_btn, "down", Color(0.25, 0.45, 0.75))
    # view button: icon while in a vehicle, normal text button while walking
    var vt: String = view_btn.text
    var v_icon: bool = vt != "TOP VIEW" and vt != "WALK VIEW"
    var vsig: String = ("icon_on" if vt == "CHASE VIEW" else "icon") if v_icon else "text"
    if bcache.get("view", "") != vsig:
        bcache["view"] = vsig
        if v_icon:
            _put_rect(view_btn, 1, 1, 1, 1, -114, -460, -24, -370)
            _icon_btn(view_btn, "cap", Color(0.12, 0.6, 0.85) if vsig == "icon_on" else Color(0.24, 0.31, 0.43))
        else:
            _put_rect(view_btn, 0.5, 0, 0.5, 0, 5, 12, 215, 72)
            _text_btn(view_btn, Color(0.2, 0.3, 0.45, 0.9), 14)
    # action button: GET IN / GET OUT / RETURN are icons, the farm actions stay text
    var at: String = act_btn.text
    var kind: String = ""
    if at.begins_with("GET IN"):
        kind = "wheel"
    elif at.begins_with("GET OUT"):
        kind = "door"
    elif at.begins_with("RETURN"):
        kind = "house"
    if bcache.get("act", "x") != kind:
        bcache["act"] = kind
        if kind == "":
            _put_rect(act_btn, 1, 1, 1, 1, -330, -150, -24, -40)
            _text_btn(act_btn, Color(0.93, 0.55, 0.12), 30)
            act_btn.add_theme_font_size_override("font_size", 26)
        else:
            _put_rect(act_btn, 1, 1, 1, 1, -124, -150, -24, -50)
            _icon_btn(act_btn, kind, Color(0.93, 0.55, 0.12) if kind == "house" else Color(0.24, 0.63, 0.31))

func _process(_d: float) -> void:
    _sync_buttons()

func _ensure_hud() -> void:
    if hud != null:
        return
    hud = CanvasLayer.new()
    hud.layer = 62
    add_child(hud)
    enter_btn = Button.new()
    enter_btn.text = "WALK"
    enter_btn.anchor_top = 1.0
    enter_btn.anchor_bottom = 1.0
    enter_btn.offset_left = 14.0
    enter_btn.offset_right = 124.0
    enter_btn.offset_top = -126.0
    enter_btn.offset_bottom = -16.0
    _style(enter_btn, Color(0.25, 0.62, 0.30), 55)
    enter_btn.pressed.connect(enter)
    hud.add_child(enter_btn)
    exit_btn = Button.new()
    exit_btn.text = "< EXIT WALK"
    exit_btn.anchor_left = 0.5
    exit_btn.anchor_right = 0.5
    exit_btn.offset_left = -215.0
    exit_btn.offset_right = -5.0
    exit_btn.offset_top = 12.0
    exit_btn.offset_bottom = 72.0
    _style(exit_btn, Color(0.2, 0.3, 0.45, 0.9), 14)
    exit_btn.pressed.connect(leave)
    exit_btn.visible = false
    hud.add_child(exit_btn)
    view_btn = Button.new()
    view_btn.text = "TOP VIEW"
    view_btn.anchor_left = 0.5
    view_btn.anchor_right = 0.5
    view_btn.offset_left = 5.0
    view_btn.offset_right = 215.0
    view_btn.offset_top = 12.0
    view_btn.offset_bottom = 72.0
    _style(view_btn, Color(0.2, 0.3, 0.45, 0.9), 14)
    view_btn.pressed.connect(_toggle_view)
    view_btn.visible = false
    hud.add_child(view_btn)
    joy = SailScript.Joy.new()
    joy.anchor_top = 1.0
    joy.anchor_bottom = 1.0
    joy.offset_left = 30.0
    joy.offset_right = 290.0
    joy.offset_top = -290.0
    joy.offset_bottom = -30.0
    joy.visible = false
    hud.add_child(joy)
    act_btn = Button.new()
    act_btn.anchor_left = 1.0
    act_btn.anchor_right = 1.0
    act_btn.anchor_top = 1.0
    act_btn.anchor_bottom = 1.0
    act_btn.offset_left = -330.0
    act_btn.offset_right = -24.0
    act_btn.offset_top = -150.0
    act_btn.offset_bottom = -40.0
    _style(act_btn, Color(0.93, 0.55, 0.12), 30)
    act_btn.add_theme_font_size_override("font_size", 26)
    act_btn.pressed.connect(_act)
    act_btn.visible = false
    hud.add_child(act_btn)
    up_btn = Button.new()
    up_btn.text = ""
    down_btn = Button.new()
    down_btn.text = ""
    var ub: int = 0
    for b in [up_btn, down_btn]:
        var bb: Button = b
        bb.anchor_left = 1.0
        bb.anchor_right = 1.0
        bb.anchor_top = 1.0
        bb.anchor_bottom = 1.0
        bb.offset_left = -130.0
        bb.offset_right = -24.0
        bb.offset_top = -330.0 + 100.0 * float(ub)
        bb.offset_bottom = -240.0 + 100.0 * float(ub)
        _style(bb, Color(0.25, 0.45, 0.75), 20)
        bb.visible = false
        hud.add_child(bb)
        ub += 1
    up_btn.button_down.connect(func(): up_held = true)
    up_btn.button_up.connect(func(): up_held = false)
    down_btn.button_down.connect(func(): down_held = true)
    down_btn.button_up.connect(func(): down_held = false)

# ----------------------------------------------------------------- multi-touch buttons
# The first finger is turned into a mouse click by Godot, so buttons already work for it. Any
# further finger (for example the right thumb on UP while the left thumb holds the joystick)
# is routed to the button under it here.
var btn_touch: Dictionary = {}      # finger index -> Button

func _all_buttons(n: Node, out: Array) -> void:
    for c in n.get_children():
        if c is BaseButton and (c as BaseButton).is_visible_in_tree():
            out.append(c)
        _all_buttons(c, out)

func _press_btn(b: BaseButton, down: bool) -> void:
    if b == up_btn:
        up_held = down
    elif b == down_btn:
        down_held = down
    elif down:
        b.pressed.emit()

func _input(e: InputEvent) -> void:
    if hud == null or not hud.visible:
        return
    if e is InputEventScreenTouch:
        var t: InputEventScreenTouch = e
        if t.pressed:
            if t.index == 0:
                return
            var bl: Array = []
            _all_buttons(hud, bl)
            for b in bl:
                var bb: BaseButton = b
                if bb.get_global_rect().has_point(t.position):
                    btn_touch[t.index] = bb
                    _press_btn(bb, true)
                    get_viewport().set_input_as_handled()
                    break
        elif btn_touch.has(t.index):
            _press_btn(btn_touch[t.index], false)
            btn_touch.erase(t.index)
            get_viewport().set_input_as_handled()

# ----------------------------------------------------------------- build

func _build() -> void:
    if built:
        return
    built = true
    player = Node3D.new()
    player.name = "OwnerPlayer"
    g.add_child(player)
    model = Node3D.new()
    model.scale = Vector3.ONE * 0.9
    player.add_child(model)
    _build_human()
    glow = OmniLight3D.new()
    glow.position = Vector3(0.0, 2.2, 0.0)
    glow.omni_range = 7.0
    glow.light_energy = 0.0
    glow.light_color = Color(1.0, 0.9, 0.7)
    glow.shadow_enabled = false
    player.add_child(glow)
    cam = Camera3D.new()
    cam.fov = 62.0
    cam.near = 0.1
    cam.far = 400.0
    g.add_child(cam)
    player.position = Vector3(0.6, GROUND_Y, 5.6)
    heading = deg_to_rad(90.0)       # facing the field (towards -z)
    cam_h = heading
    player.visible = false

func _make_obstacles() -> void:
    obstacles = SOLIDS.duplicate()
    for d in g.solid_discs:
        obstacles.append(d)
    # the railway embankments are solid; you can still walk under the bridge girders
    if g.train_pts.size() > 1 and g.train_len > 1.0:
        var ts: float = 0.0
        while ts < g.train_len:
            if g._train_h(ts) > 0.3 and g._near_bridge_dist(ts) >= 0.0:
                var tp: Vector2 = g._train_at(ts)
                obstacles.append(Vector3(tp.x, tp.y, 0.85))
            ts += 0.6


# ----------------------------------------------------------------- the farmer
# A jointed human: hips, knees, shoulders, elbows, hands with fingers, a neck and a
# detailed head. The model faces local +x; local +z is the farmer's right-hand side.

func _joint(parent: Node3D, pos: Vector3) -> Node3D:
    var n := Node3D.new()
    n.position = pos
    parent.add_child(n)
    return n

func _taper(parent: Node3D, a: Vector3, b: Vector3, r1: float, r2: float, mat: Material) -> void:
    # a smooth tapered limb piece from a (radius r1) to b (radius r2)
    var d: Vector3 = b - a
    var mi := MeshInstance3D.new()
    var cm := CylinderMesh.new()
    cm.top_radius = r1
    cm.bottom_radius = r2
    cm.height = d.length()
    cm.radial_segments = 14
    mi.mesh = cm
    mi.material_override = mat
    mi.position = (a + b) * 0.5
    var dn: Vector3 = d.normalized()
    if dn.dot(Vector3.DOWN) > 0.9999:
        pass
    else:
        mi.quaternion = Quaternion(Vector3.DOWN, dn)
    parent.add_child(mi)

func _build_human() -> void:
    var skin: StandardMaterial3D = v._mm(Color(0.68, 0.47, 0.33), 0.62)
    var skin_d: StandardMaterial3D = v._mm(Color(0.55, 0.36, 0.25), 0.7)
    var shirt: StandardMaterial3D = v._mm(Color(0.78, 0.18, 0.16), 0.85)
    var shirt_d: StandardMaterial3D = v._mm(Color(0.58, 0.12, 0.11), 0.85)
    var denim: StandardMaterial3D = v._mm(Color(0.60, 0.50, 0.34), 0.9)
    var denim_d: StandardMaterial3D = v._mm(Color(0.48, 0.39, 0.26), 0.9)
    var leather: StandardMaterial3D = v._mm(Color(0.30, 0.18, 0.10), 0.55)
    var sole: StandardMaterial3D = v._mm(Color(0.10, 0.08, 0.07), 0.85)
    var gold: StandardMaterial3D = v._mm(Color(0.85, 0.7, 0.25), 0.3, 0.6)
    var hair: StandardMaterial3D = v._mm(Color(0.06, 0.05, 0.05), 0.7)
    var white: StandardMaterial3D = v._mm(Color(0.96, 0.96, 0.94), 0.4)
    var iris: StandardMaterial3D = v._mm(Color(0.14, 0.08, 0.05), 0.2)
    var lip: StandardMaterial3D = v._mm(Color(0.45, 0.2, 0.18), 0.5)
    var straw: StandardMaterial3D = v._mm(Color(0.40, 0.26, 0.14), 0.9)
    var band: StandardMaterial3D = v._mm(Color(0.10, 0.10, 0.10), 0.9)
    var hips: Node3D = _joint(model, Vector3(0, 0, 0))
    parts["hips"] = hips
    # pelvis, belt
    v._put(hips, v._cyl(0.15, 0.16, 0.16, 24), Vector3(0, 0.93, 0), denim, Vector3.ZERO, Vector3(0.72, 1.0, 1.2))
    v._put(hips, v._cyl(0.158, 0.158, 0.045, 24), Vector3(0, 1.00, 0), leather, Vector3.ZERO, Vector3(0.72, 1.0, 1.2))
    v._put(hips, v._bx(Vector3(0.02, 0.035, 0.05)), Vector3(0.118, 1.00, 0), gold)
    # legs: tapered thigh and shin, knee and ankle joints the same width as the limb
    for side in [-1.0, 1.0]:
        var nm: String = "r" if side > 0.0 else "l"
        var th: Node3D = _joint(hips, Vector3(0, 0.90, 0.1 * side))
        _taper(th, Vector3(0, 0.02, 0), Vector3(0, -0.45, 0), 0.088, 0.062, denim)
        var kn: Node3D = _joint(th, Vector3(0, -0.45, 0))
        v._put(kn, v._sph(0.062), Vector3.ZERO, denim)
        _taper(kn, Vector3(0, 0, 0), Vector3(0, -0.40, 0), 0.060, 0.043, denim_d)
        var an: Node3D = _joint(kn, Vector3(0, -0.40, 0))
        v._put(an, v._cyl(0.05, 0.062, 0.11, 14), Vector3(0, 0.02, 0), leather)
        v._put(an, v._sph(0.058), Vector3(-0.012, -0.012, 0), leather, Vector3.ZERO, Vector3(0.95, 0.9, 0.95))       # heel
        v._put(an, v._sph(0.058), Vector3(0.06, -0.026, 0), leather, Vector3.ZERO, Vector3(1.5, 0.78, 0.95))         # instep
        v._put(an, v._sph(0.05), Vector3(0.135, -0.04, 0), leather, Vector3.ZERO, Vector3(1.35, 0.62, 0.95))         # rounded toe
        v._put(an, v._sph(0.074), Vector3(0.062, -0.062, 0), sole, Vector3.ZERO, Vector3(1.95, 0.2, 0.78))           # thin curved sole
        v._put(an, v._sph(0.03), Vector3(-0.045, -0.058, 0), sole, Vector3.ZERO, Vector3(1.0, 0.45, 1.5))           # heel block
        parts[nm + "thigh"] = th
        parts[nm + "knee"] = kn
    # torso: broad chest tapering to the waist
    var torso: Node3D = _joint(hips, Vector3(0, 0.98, 0))
    parts["torso"] = torso
    v._put(torso, v._cyl(0.145, 0.135, 0.14, 24), Vector3(0, 0.06, 0), shirt, Vector3.ZERO, Vector3(0.70, 1.0, 1.18))    # belly
    v._put(torso, v._cyl(0.168, 0.145, 0.30, 26), Vector3(0, 0.27, 0), shirt, Vector3.ZERO, Vector3(0.68, 1.0, 1.28))     # chest
    v._put(torso, v._cyl(0.056, 0.056, 0.38, 14), Vector3(0, 0.425, 0), shirt, Vector3(90, 0, 0), Vector3(1.0, 1.0, 1.0))   # shoulder line
    for pz in [-1.0, 1.0]:
        _taper(torso, Vector3(0, 0.50, 0.045 * pz), Vector3(0, 0.43, 0.175 * pz), 0.04, 0.056, shirt)                          # trapezius
    v._put(torso, v._bx(Vector3(0.02, 0.26, 0.012)), Vector3(0.118, 0.20, 0), shirt_d)
    for bi in range(3):
        v._put(torso, v._sph(0.01), Vector3(0.124, 0.12 + 0.07 * float(bi), 0), white)
    # neck and collar
    v._put(torso, v._cyl(0.047, 0.058, 0.11, 14), Vector3(0, 0.52, 0), skin)
    v._put(torso, v._cyl(0.075, 0.095, 0.04, 16), Vector3(0, 0.47, 0), shirt_d)
    # arms: tapered, joints no wider than the limb
    for side2 in [-1.0, 1.0]:
        var nm2: String = "r" if side2 > 0.0 else "l"
        var sh: Node3D = _joint(torso, Vector3(0, 0.42, 0.205 * side2))
        _taper(sh, Vector3(0, 0.03, 0), Vector3(0, -0.28, 0), 0.056, 0.047, shirt)
        var el: Node3D = _joint(sh, Vector3(0, -0.29, 0))
        v._put(el, v._sph(0.045), Vector3.ZERO, shirt_d)
        _taper(el, Vector3(0, 0, 0), Vector3(0, -0.26, 0), 0.042, 0.030, skin)
        var wr: Node3D = _joint(el, Vector3(0, -0.27, 0))
        v._put(wr, v._sph(0.03), Vector3.ZERO, skin)
        v._put(wr, v._bx(Vector3(0.03, 0.08, 0.07)), Vector3(0, -0.055, 0), skin)
        for fi in range(4):
            var fz: float = (-0.027 + 0.018 * float(fi))
            var fl: float = 0.075 - 0.008 * absf(float(fi) - 1.5)
            v._limb(wr, Vector3(0.006, -0.095, fz), Vector3(0.022, -0.095 - fl * 0.95, fz), 0.0095, skin)
        v._limb(wr, Vector3(0.016, -0.03, 0.034 * side2), Vector3(0.05, -0.075, 0.03 * side2), 0.011, skin)
        parts[nm2 + "sh"] = sh
        parts[nm2 + "el"] = el
    # head
    var head: Node3D = _joint(torso, Vector3(0, 0.57, 0))
    parts["head"] = head
    v._put(head, v._sph(0.105, 1.2), Vector3(0.01, 0.12, 0), skin, Vector3.ZERO, Vector3(1.0, 1.0, 0.86))
    v._put(head, v._sph(0.065, 0.85), Vector3(0.03, 0.045, 0), skin, Vector3.ZERO, Vector3(1.05, 1.0, 0.95))  # jaw and chin
    for ez in [-1.0, 1.0]:
        v._put(head, v._sph(0.02), Vector3(0.086, 0.135, 0.037 * ez), white, Vector3.ZERO, Vector3(0.5, 0.9, 1.25))
        v._put(head, v._sph(0.0105), Vector3(0.096, 0.135, 0.037 * ez), iris)
        v._put(head, v._bx(Vector3(0.012, 0.009, 0.046)), Vector3(0.091, 0.166, 0.039 * ez), hair, Vector3(ez * 8.0, 0, 0))
        v._put(head, v._sph(0.025), Vector3(0.0, 0.11, 0.088 * ez), skin_d, Vector3.ZERO, Vector3(0.45, 1.0, 0.7))
    v._put(head, v._sph(0.02), Vector3(0.102, 0.095, 0), skin, Vector3.ZERO, Vector3(1.2, 1.5, 0.9))   # nose
    v._put(head, v._bx(Vector3(0.008, 0.009, 0.048)), Vector3(0.094, 0.052, 0), lip)                   # mouth
    v._put(head, v._sph(0.108, 0.8), Vector3(-0.012, 0.165, 0), hair, Vector3.ZERO, Vector3(1.0, 0.8, 0.9))
    v._put(head, v._cyl(0.2, 0.2, 0.012, 32), Vector3(0.0, 0.215, 0), straw, Vector3(0, 0, 4))
    v._put(head, v._sph(0.116, 0.65), Vector3(-0.005, 0.225, 0), straw)
    v._put(head, v._cyl(0.119, 0.121, 0.03, 24), Vector3(-0.005, 0.225, 0), band)

func _animate(moved: bool, amp: float, delta: float) -> void:
    var kr: float = clampf(10.0 * delta, 0.0, 1.0)
    model.rotation.z = lerpf(model.rotation.z, 0.0, kr)
    model.position.x = lerpf(model.position.x, 0.0, kr)
    model.position.y = lerpf(model.position.y, 0.0, kr)
    var s: float = sin(phase)
    var c: float = cos(phase)
    var idle: float = 1.0 - amp
    var br: float = sin(t * 1.8) * 0.012 * idle
    (parts["hips"] as Node3D).position.y = (absf(s) * 0.045 * amp) if moved else 0.0
    for side in ["l", "r"]:
        var sg: float = 1.0 if side == "l" else -1.0     # legs swing in opposition
        var sw: float = s * sg
        var cw: float = c * sg
        (parts[side + "thigh"] as Node3D).rotation.z = sw * 0.62 * amp
        (parts[side + "knee"] as Node3D).rotation.z = -(maxf(0.0, cw) * 0.85 + 0.05) * amp
        (parts[side + "sh"] as Node3D).rotation.z = -sw * 0.5 * amp + br
        (parts[side + "el"] as Node3D).rotation.z = 0.25 + (0.35 + maxf(0.0, -sw) * 0.3) * amp
    var torso: Node3D = parts["torso"]
    torso.rotation.y = s * 0.12 * amp
    torso.rotation.z = -0.07 * amp + br
    (parts["head"] as Node3D).rotation.z = 0.07 * amp
    (parts["head"] as Node3D).rotation.y = -steer_vis * 0.35 - s * 0.05 * amp
    if hop_t > 0.0:
        var k: float = sin(clampf(hop_t / 0.4, 0.0, 1.0) * PI)
        (parts["rsh"] as Node3D).rotation.z = 1.25 * k
        (parts["rel"] as Node3D).rotation.z = 0.35 * k
        torso.rotation.z = 0.14 * k

# ----------------------------------------------------------------- enter / leave

func can_enter() -> bool:
    if on or g == null:
        return false
    if v.hb != null and (v.hb.on or v.hb.sailing):
        return false
    if g.ui_root == null or not g.ui_root.visible:
        return false
    if g._any_panel_open():
        return false
    return true

func enter() -> void:
    if on or not can_enter():
        return
    _ensure_hud()
    _build()
    _make_obstacles()
    on = true
    g.owner_on = true
    if bottom_bar == null:
        for c in g.ui_root.get_children():
            if c is HBoxContainer and absf((c as Control).anchor_left - 0.22) < 0.01 and (c as Control).anchor_top == 1.0:
                bottom_bar = c
    if bottom_bar != null:
        bottom_bar.visible = false
    top_view = false
    player.visible = true
    cam_h = heading
    enter_btn.visible = false
    exit_btn.visible = true
    view_btn.visible = true
    view_btn.text = "TOP VIEW"
    joy.visible = true
    speed = 0.0
    _update_cam(1.0)
    cam.make_current()
    g._show_toast("You are the farmer! Walk up to animals, crops and shops.")

func leave() -> void:
    if not on:
        return
    on = false
    g.owner_on = false
    player.visible = false
    g.camera.make_current()
    if bottom_bar != null:
        bottom_bar.visible = true
    exit_btn.visible = false
    view_btn.visible = false
    joy.visible = false
    act_btn.visible = false
    (joy as SailScript.Joy).vec = Vector2.ZERO
    g.cam_zoom = 16.8
    g.cam_target = Vector3(0.0, 0.25, 0.0)
    g._update_camera()
    if g.crop_bar != null and not g.crop_bar_dismissed:
        g.crop_bar.visible = true

func _toggle_view() -> void:
    if flying != 0:
        _set_pilot(not pilot_view)
        return
    top_view = not top_view
    view_btn.text = "WALK VIEW" if top_view else "TOP VIEW"
    if top_view:
        g.cam_zoom = 11.0
        g.cam_target = player.position
        g.camera.make_current()
    else:
        cam.make_current()

# ----------------------------------------------------------------- actions

func _near_producer() -> Dictionary:
    var best: Dictionary = {}
    var best_d: float = 2.5
    for p in g.producers:
        if not bool(p["ready"]):
            continue
        var n: Node3D = p["node"]
        if not is_instance_valid(n):
            continue
        var d: float = Vector2(n.global_position.x - player.position.x, n.global_position.z - player.position.z).length()
        if d < best_d:
            best_d = d
            best = {"type": "prod", "p": p, "pos": n.global_position}
    return best

func _near_plot() -> Dictionary:
    var best_key: String = ""
    var best_d: float = g.CELL * 0.85
    for k in g.plot_centers.keys():
        var c: Vector3 = g.plot_centers[k]
        var d: float = maxf(absf(c.x - player.position.x), absf(c.z - player.position.z))
        if d < best_d:
            best_d = d
            best_key = str(k)
    if best_key == "":
        return {}
    var st: Dictionary = g.crop_states[best_key]
    var c2: Vector3 = g.plot_centers[best_key]
    var planted: bool = bool(st.get("planted", false))
    var ripe: bool = planted and float(st.get("age", 0.0)) >= g._grow_time_of(st)
    if v.care.has(best_key) and not ripe:
        var kind: String = str(v.care[best_key])
        return {"type": "care", "key": best_key, "pos": c2, "label": "WATER THE CROP" if kind == "water" else "PULL THE WEEDS"}
    if ripe:
        return {"type": "harvest", "key": best_key, "pos": c2, "label": "HARVEST"}
    if not planted and still_t > 0.35:
        return {"type": "plant", "key": best_key, "pos": c2, "label": "PLANT SEEDS (%d)" % g.seeds}
    return {}

func _near_building() -> Dictionary:
    var pp := Vector2(player.position.x, player.position.z)
    if pp.distance_to(Vector2(g.OVEN_POS.x, g.OVEN_POS.z)) < 3.6:
        return {"type": "bakery", "pos": g.OVEN_POS, "label": "OPEN BAKERY"}
    for mp in [g.BARN_POS, g.MARKET_POS, g.SILO_POS]:
        if pp.distance_to(Vector2(mp.x, mp.z)) < 3.7:
            return {"type": "market", "pos": mp, "label": "OPEN MARKET"}
    if pp.distance_to(Vector2(g.WM_POS.x, g.WM_POS.z)) < 3.8:
        return {"type": "windmill", "pos": g.WM_POS, "label": "WINDMILL"}
    return {}

func _near_tc_target() -> Dictionary:
    if not _tc_active():
        return {}
    var pp := Vector2(player.position.x, player.position.z)
    var t0: Vector3 = _tp()
    if py_cur < 3.2:
        var dw: Vector3 = _door_world()
        if pp.distance_to(Vector2(dw.x, dw.z)) < 2.3:
            return {"type": "door", "pos": dw, "label": "CLOSE DOOR" if g.trade_door_open else "OPEN DOOR"}
        if in_building and pp.distance_to(Vector2(t0.x + 2.1, t0.z + 0.4)) < 2.2:
            return {"type": "trade", "pos": Vector3(t0.x + 2.1, 0.0, t0.z + 0.4), "label": "TRADE ORDERS"}
    elif py_cur >= 3.2:
        for m in [1, 2]:
            var vv: Dictionary = g.trade_veh[m]
            if int(vv["state"]) != 0:
                continue
            var pad: Vector3 = g._trade_pad(m)
            if pp.distance_to(Vector2(pad.x, pad.z)) < 1.7:
                return {"type": "fly", "mode": m, "pos": pad, "label": "GET IN " + ("DRONE" if m == 1 else "HELICOPTER")}
    return {}

func _near_vehicle_target() -> Dictionary:
    if py_cur > 0.6:
        return {}
    var pp := Vector2(player.position.x, player.position.z)
    for i in range(g.vehicles.size()):
        var vv: Dictionary = g.vehicles[i]
        if bool(vv.get("driven", false)) or bool(vv.get("rejoin", false)):
            continue
        var n: Node3D = vv["node"]
        if not n.visible:
            continue
        if pp.distance_to(Vector2(n.position.x, n.position.z)) < 2.1:
            return {"type": "drive", "idx": i, "pos": n.position, "label": "GET IN " + str(n.name).to_upper()}
    if g.train_unlocked and g.train_root != null and g.train_root.visible and g.train_state == 0:
        for car in g.train_cars:
            var cn: Node3D = car
            if not cn.visible:
                continue
            if absf(cn.position.y - 0.07) < 1.0 and pp.distance_to(Vector2(cn.position.x, cn.position.z)) < 2.0:
                return {"type": "drivetrain", "pos": cn.position, "label": "GET IN TRAIN"}
    if g.trade_unlocked and g.trade_root != null and g.trade_root.visible:
        for m in [3, 4]:
            var tv: Dictionary = g.trade_veh[m]
            if int(tv["state"]) != 0:
                continue
            var pad: Vector3 = g._trade_pad(m)
            var rad: float = 2.8 if m == 3 else 4.2
            if pp.distance_to(Vector2(pad.x, pad.z)) < rad:
                return {"type": "fly", "mode": m, "pos": pad, "label": "GET IN " + ("PLANE" if m == 3 else "CARGO BOAT")}
    return {}

func _show_target_btn() -> void:
    if target.is_empty():
        act_btn.visible = false
        return
    act_btn.visible = not g._any_panel_open()
    act_btn.text = str(target["label"])

func _find_target() -> void:
    if reg == 1:
        target = _swim_target()
        _show_target_btn()
        return
    if reg == 3:
        target = _deck_target()
        _show_target_btn()
        return
    if reg == 2:
        target = {}
        _show_target_btn()
        return
    target = _near_tc_target()
    if target.is_empty():
        target = _near_vehicle_target()
    if target.is_empty():
        target = _near_producer()
    if target.is_empty():
        target = _near_plot()
        if not target.is_empty() and str(target["type"]) == "plant":
            var b: Dictionary = _near_building()
            if not b.is_empty():
                target = b
    if target.is_empty():
        target = _near_building()
    if py_cur >= 2.5 and not target.is_empty() and str(target["type"]) != "fly":
        target = {}
    if target.is_empty():
        act_btn.visible = false
        return
    act_btn.visible = not g._any_panel_open()
    if str(target["type"]) == "prod":
        var kind: int = int(target["p"]["kind"])
        act_btn.text = "COLLECT " + str(g.PROD_NAMES[kind]).to_upper()
    else:
        act_btn.text = str(target["label"])

func _act() -> void:
    if flying >= 20:
        _try_get_out()
        return
    if flying != 0:
        f_autopilot = true
        f_phase = 0
        return
    if not on or target.is_empty() or g._any_panel_open():
        return
    var pos: Vector3 = target["pos"]
    var d := Vector2(pos.x - player.position.x, pos.z - player.position.z)
    if d.length() > 0.3:
        heading = atan2(-d.y, d.x)
    hop_t = 0.4
    var ty: String = str(target["type"])
    if ty == "prod":
        g._collect_producer(target["p"])
    elif ty == "plant" or ty == "harvest" or ty == "care":
        var old: String = g.active_action
        g.active_action = "harvest" if ty == "harvest" else "plant"
        g._flash_cell(str(target["key"]))
        g._apply_plot_action(str(target["key"]))
        g.active_action = old
    elif ty == "bakery":
        g._open_bakery()
    elif ty == "market":
        g._open_market()
    elif ty == "door":
        g.trade_door_open = not g.trade_door_open
        g._play_named("ding", -14.0)
    elif ty == "trade":
        g._open_trade()
    elif ty == "fly":
        _start_flight(int(target["mode"]))
    elif ty == "drive":
        _start_drive(int(target["idx"]))
    elif ty == "climb":
        _carrier_climb()
    elif ty == "jump":
        _deck_jump()
    elif ty == "cflight":
        _start_carrier_flight(int(target["idx"]))
    elif ty == "drivetrain":
        _start_train()
    elif ty == "windmill":
        g._tap_buildings(Vector3(g.WM_POS.x - 1.3, 0.0, g.WM_POS.z - 1.95))
    target = {}


# ----------------------------------------------------------------- flying the drone / helicopter

func _start_flight(mode: int) -> void:
    var vv: Dictionary = g.trade_veh[mode]
    if int(vv["state"]) != 0:
        return
    fveh = vv
    vv["state"] = 5            # busy: the trade orders cannot use it while you fly
    flying = mode
    fk = mode
    fpad = g._trade_pad(mode)
    fland = PI
    fnode = vv["node"]
    fyaw = heading
    if mode == 3:
        fyaw = 0.0
    elif mode == 4:
        fyaw = PI * 0.5
    fspeed = 0.0
    fvy = 0.0
    falt = fnode.position.y
    f_autopilot = false
    f_phase = 0
    up_held = false
    down_held = false
    player.visible = false
    exit_btn.visible = false
    view_btn.visible = false
    up_btn.visible = mode != 4
    down_btn.visible = mode != 4
    act_btn.text = "RETURN TO PAD"
    act_btn.visible = true
    cam_h = fyaw
    top_view = false
    view_btn.visible = true
    _set_pilot(false)
    cam.make_current()
    _eng_start("prop" if mode == 3 else ("motor" if mode == 4 else "heli"))
    if mode == 3:
        g._show_toast("Plane: push the stick up to speed along the runway, then hold UP to take off!")
    elif mode == 4:
        g._show_toast("Cargo boat: stick up to sail, left / right to steer.")
    else:
        g._show_toast("You are flying! Stick: steer and go. UP / DOWN: height.")

func _end_flight() -> void:
    _eng_stop()
    if flying >= 10 and flying < 20:
        _end_carrier_flight()
        return
    var m: int = flying
    g._trade_park(fveh)
    fveh["state"] = 0
    var pad: Vector3 = g._trade_pad(m)
    flying = 0
    fk = 0
    _shadow_hide()
    f_autopilot = false
    up_held = false
    down_held = false
    up_btn.visible = false
    down_btn.visible = false
    player.visible = true
    if m <= 2:
        player.position = Vector3(pad.x, g.ROOF_Y, pad.z + 1.5)
        py_cur = g.ROOF_Y
    elif m == 3:
        player.position = Vector3(pad.x, GROUND_Y, pad.z + 2.4)
        py_cur = GROUND_Y
    else:
        player.position = Vector3(5.2, GROUND_Y, -17.8)
        py_cur = GROUND_Y
    heading = deg_to_rad(90.0)
    cam_h = heading
    _set_pilot(false)
    exit_btn.visible = true
    view_btn.visible = true
    view_btn.text = "TOP VIEW"
    act_btn.visible = false
    cam.make_current()
    g._show_toast("Landed. Welcome back on the roof." if m <= 2 else "Parked. Welcome back!")

func _pv_name() -> String:
    if fk == 4:
        return "CAPTAIN VIEW"
    if flying >= 20:
        return "DRIVER VIEW"
    return "PILOT VIEW"

func _set_pilot(on: bool) -> void:
    pilot_view = on
    cam.fov = ((78.0 if flying < 20 else 72.0) if on else 62.0)
    if fnode != null:
        fnode.visible = not (on and (fk == 1 or fk == 2))
    view_btn.text = "CHASE VIEW" if on else _pv_name()
    if pilot_hud == null:
        pilot_hud = Control.new()
        pilot_hud.set_anchors_preset(Control.PRESET_FULL_RECT)
        pilot_hud.mouse_filter = Control.MOUSE_FILTER_IGNORE
        hud.add_child(pilot_hud)
        hud.move_child(pilot_hud, 0)
        var cross := Label.new()
        cross.text = "+"
        cross.add_theme_font_size_override("font_size", 44)
        cross.add_theme_color_override("font_color", Color(1, 1, 1, 0.8))
        cross.set_anchors_preset(Control.PRESET_CENTER)
        cross.offset_left = -14.0
        cross.offset_top = -30.0
        cross.mouse_filter = Control.MOUSE_FILTER_IGNORE
        pilot_hud.add_child(cross)
        pilot_lbl = Label.new()
        pilot_lbl.add_theme_font_size_override("font_size", 26)
        pilot_lbl.add_theme_color_override("font_color", Color(0.6, 1.0, 0.7))
        pilot_lbl.add_theme_color_override("font_outline_color", Color(0, 0.1, 0.05))
        pilot_lbl.add_theme_constant_override("outline_size", 6)
        pilot_lbl.anchor_left = 0.5
        pilot_lbl.anchor_right = 0.5
        pilot_lbl.anchor_top = 1.0
        pilot_lbl.anchor_bottom = 1.0
        pilot_lbl.offset_left = -150.0
        pilot_lbl.offset_right = 150.0
        pilot_lbl.offset_top = -64.0
        pilot_lbl.offset_bottom = -16.0
        pilot_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
        pilot_lbl.mouse_filter = Control.MOUSE_FILTER_IGNORE
        pilot_hud.add_child(pilot_lbl)
    pilot_hud.visible = on

# chase camera that never ends up inside a wall: it moves in closer when something is behind the vehicle
func _cam_clear(anchor: Vector3, dirv: Vector3, d: float, base_h: float, slope: float) -> Vector3:
    var dd: float = d
    var q: Vector3 = anchor - dirv * dd + Vector3(0.0, base_h + dd * slope, 0.0)
    while dd > 1.2:
        q = anchor - dirv * dd + Vector3(0.0, base_h + dd * slope, 0.0)
        var blocked: bool = false
        if q.y < g.ROOF_Y + 0.4 and _tc_active() and _in_tc_box(q, 0.5):
            blocked = true
        if not blocked and q.y < 3.5:
            for o in obstacles:
                var ov: Vector3 = o
                if Vector2(q.x - ov.x, q.z - ov.y).length() < ov.z + 0.4:
                    blocked = true
                    break
        if not blocked:
            return q
        dd -= 0.4
    return anchor - dirv * 1.2 + Vector3(0.0, base_h + 1.2 * slope + 0.3, 0.0)

func _pilot_cam(key: String) -> void:
    var e: Array = PV[key]
    var tr: Transform3D = fnode.global_transform
    var eye: Vector3 = tr * (e[0] as Vector3)
    var f: Vector3 = (tr.basis * (e[1] as Vector3)).normalized()
    cam.global_position = eye
    cam.look_at(eye + f * 10.0, tr.basis.y.normalized())

func _boat_blocked(q: Vector3) -> bool:
    return absf(q.x) < 21.0 and q.z > -19.7 and q.z < 21.0

func _fly_tick(delta: float) -> void:
    if g.crop_bar != null:
        g.crop_bar.visible = false
    var is_h: bool = fk == 2
    var is_j: bool = fk == 5
    var is_p: bool = fk == 3 or fk == 5
    var is_b: bool = fk == 4
    var maxs: float = 7.0
    if is_h:
        maxs = 9.0
    elif is_j:
        maxs = 20.0
    elif is_p:
        maxs = 14.0
    var jv: Vector2 = (joy as SailScript.Joy).vec
    var steer: float = jv.x if absf(jv.x) > 0.12 else 0.0
    var thr: float = -jv.y if absf(jv.y) > 0.12 else 0.0
    var pad: Vector3 = fpad
    var pos: Vector3 = fnode.position
    var lateral_fix: bool = false
    if f_autopilot:
        act_btn.text = "DOCKING..." if is_b else "LANDING..."
        var dirv := Vector2(cos(fland), -sin(fland))
        steer = 0.0
        var to := Vector2(pad.x - pos.x, pad.z - pos.z)
        var dist: float = to.length()
        if is_b:
            var wantb: float = atan2(-to.y, to.x)
            fyaw = fyaw + clampf(wrapf(wantb - fyaw, -PI, PI), -1.6 * delta, 1.6 * delta)
            fspeed = move_toward(fspeed, clampf(dist * 0.8, 0.8, 5.0), 5.0 * delta)
            if dist < 0.7:
                _end_flight()
                return
        elif is_p:
            var sp0: float = 9.0 if is_j else 6.5
            var sp1: float = 6.5 if is_j else 4.5
            if f_phase == 0:
                falt = move_toward(falt, maxf(falt, 5.0), 3.0 * delta)
                var tt := Vector2(pad.x - dirv.x * 8.0 - pos.x, pad.z - dirv.y * 8.0 - pos.z)
                var wantp: float = atan2(-tt.y, tt.x)
                fyaw = fyaw + clampf(wrapf(wantp - fyaw, -PI, PI), -1.4 * delta, 1.4 * delta)
                fspeed = move_toward(fspeed, sp0, 5.0 * delta)
                if tt.length() < 1.3:
                    f_phase = 1
            else:
                fyaw = fyaw + clampf(wrapf(fland - fyaw, -PI, PI), -2.0 * delta, 2.0 * delta)
                fspeed = move_toward(fspeed, sp1, 4.0 * delta)
                var rel := Vector2(pos.x - pad.x, pos.z - pad.z)
                var along: float = -rel.dot(dirv)
                var gp: float = pad.y + minf(maxf(along, 0.0), 8.0) * 0.55
                falt = move_toward(falt, gp, 4.0 * delta)
                lateral_fix = true
                if along <= 0.15:
                    _end_flight()
                    return
        elif f_phase == 0:
            # climb above the roof, then fly over the pad
            var safe: float = g.ROOF_Y + 2.0
            falt = move_toward(falt, maxf(falt, safe), 3.0 * delta)
            if dist > 0.35:
                if falt >= safe - 0.2:
                    var want: float = atan2(-to.y, to.x)
                    fyaw = fyaw + clampf(wrapf(want - fyaw, -PI, PI), -2.5 * delta, 2.5 * delta)
                    fspeed = move_toward(fspeed, clampf(dist * 1.2, 0.8, 6.0), 6.0 * delta)
                else:
                    fspeed = move_toward(fspeed, 0.0, 8.0 * delta)
            else:
                fspeed = move_toward(fspeed, 0.0, 8.0 * delta)
                if fspeed < 0.2:
                    f_phase = 1
        else:
            fspeed = move_toward(fspeed, 0.0, 8.0 * delta)
            fyaw = fyaw + clampf(wrapf(0.0 - fyaw, -PI, PI), -2.0 * delta, 2.0 * delta)
            falt = move_toward(falt, pad.y, 1.8 * delta)
            if falt <= pad.y + 0.02:
                _end_flight()
                return
    else:
        act_btn.text = "RETURN TO CARRIER" if (flying >= 10 and flying < 20) else "RETURN TO PAD"
        var rate: float = 130.0
        if is_h:
            rate = 95.0
        elif is_j:
            rate = 75.0
        elif is_p:
            rate = 60.0
        elif is_b:
            rate = 50.0
        var sf: float = 1.0
        if is_p:
            sf = clampf(fspeed / 4.0, 0.0, 1.0)
        elif is_b:
            sf = clampf(absf(fspeed) / 1.5, 0.25, 1.0) * (1.0 if fspeed >= -0.1 else -1.0)
        fyaw -= steer * deg_to_rad(rate) * delta * sf
        var tspeed: float = thr * maxs if thr > 0.0 else thr * maxs * 0.3
        if is_p:
            tspeed = maxf(thr, 0.0) * maxs
            if falt > _air_floor(fnode.position) + 0.5:
                tspeed = maxf(tspeed, 7.0 if is_j else 5.0)
        fspeed = move_toward(fspeed, tspeed, (8.0 if is_j else (4.0 if is_p else 6.0)) * delta)
        if is_p:
            var vtp: float = 0.0
            var fl: float = _air_floor(fnode.position)
            if up_held and (falt > fl + 0.5 or fspeed > (6.5 if is_j else 5.5)):
                vtp = 4.0 if is_j else 3.2
            elif down_held:
                vtp = -3.2
            elif falt > fl + 0.5 and fspeed < (6.5 if is_j else 4.8):
                vtp = -2.0
            fvy = move_toward(fvy, vtp, 9.0 * delta)
            falt += fvy * delta
        elif not is_b:
            var vt: float = (3.5 if up_held else 0.0) - (3.5 if down_held else 0.0)
            fvy = move_toward(fvy, vt, 9.0 * delta)
            falt += fvy * delta
    var dir := Vector3(cos(fyaw), 0.0, -sin(fyaw))
    var np: Vector3 = pos + dir * fspeed * delta
    if lateral_fix:
        var dv3 := Vector2(cos(fland), -sin(fland))
        var rl := Vector2(np.x - pad.x, np.z - pad.z)
        var pp3: Vector2 = rl - dv3 * rl.dot(dv3)
        np.x -= pp3.x * clampf(2.0 * delta, 0.0, 1.0)
        np.z -= pp3.y * clampf(2.0 * delta, 0.0, 1.0)
    np.x = clampf(np.x, -75.0, 75.0)
    np.z = clampf(np.z, -75.0, 75.0)
    # the Trade Centre is solid below roof height (you can still land on its roof)
    var roof_top: float = g.ROOF_Y + 0.08
    if not f_autopilot and not is_b and _in_tc_box(Vector3(np.x, 0.0, np.z), 0.3) and not _in_tc_box(Vector3(pos.x, 0.0, pos.z), 0.3) and falt < roof_top + 0.7:
        np.x = pos.x
        np.z = pos.z
        fspeed *= 0.5
    if is_b and not f_autopilot and _boat_blocked(np) and not _boat_blocked(pos):
        np.x = pos.x
        np.z = pos.z
        fspeed *= 0.3
    if not f_autopilot:
        var ay: float = 0.0 if is_b else falt
        if not is_b and falt < 4.0:
            for o in obstacles:
                var ov: Vector3 = o
                var dd := Vector2(np.x - ov.x, np.z - ov.y)
                var rr: float = ov.z + (0.9 if is_p else 0.6)
                if dd.length() < rr:
                    var nn: Vector2 = dd.normalized() if dd.length() > 0.001 else Vector2(1, 0)
                    np.x = ov.x + nn.x * rr
                    np.z = ov.y + nn.y * rr
                    fspeed *= 0.9
        for md in g.mountain_discs:
            var mv: Vector3 = md
            var mr: float = mv.z * 0.9 * clampf(1.0 - ay / (mv.z * 1.5), 0.0, 1.0)
            var dm := Vector2(np.x - mv.x, np.z - mv.y)
            if mr > 0.1 and dm.length() < mr:
                var nm: Vector2 = dm.normalized() if dm.length() > 0.001 else Vector2(1, 0)
                np.x = mv.x + nm.x * mr
                np.z = mv.y + nm.y * mr
                fspeed *= 0.8
        if _carrier_vis() and falt < 3.1 and not is_b:
            var sp: Vector3 = _push_rect(Vector3(np.x, 0.0, np.z), Rect2(g.CARRIER_POS.x + 1.1, g.CARRIER_POS.z - 3.95, 1.2, 2.8), 0.9)
            np.x = sp.x
            np.z = sp.z
    var min_y: float = 0.45
    if is_p:
        min_y = _air_floor(Vector3(np.x, 0.0, np.z))
    elif _carrier_vis():
        min_y = maxf(min_y, _air_floor(Vector3(np.x, 0.0, np.z)) if _on_deck_xz(np) else 0.0)
    if not is_b and _in_tc_box(Vector3(np.x, 0.0, np.z), 0.0):
        min_y = roof_top
    if is_b:
        falt = -0.42 + 0.03 * sin(t * 2.2)
    else:
        falt = clampf(falt, min_y, 28.0 if is_p else 18.0)
    fnode.position = Vector3(np.x, falt, np.z)
    fnode.rotation.y = fyaw
    steer_vis = lerpf(steer_vis, steer, clampf(5.0 * delta, 0.0, 1.0))
    var kk: float = clampf(5.0 * delta, 0.0, 1.0)
    if is_p:
        fnode.rotation.z = lerpf(fnode.rotation.z, clampf(fvy * 0.09, -0.35, 0.35), kk)
        fnode.rotation.x = lerpf(fnode.rotation.x, -steer_vis * 0.55 * clampf(fspeed / 8.0, 0.0, 1.0), kk)
    elif is_b:
        fnode.rotation.z = 0.0
        fnode.rotation.x = lerpf(fnode.rotation.x, -steer_vis * 0.08, kk)
    else:
        var tilt: float = -clampf(fspeed / maxs, -0.4, 1.0) * (0.28 if is_h else 0.35)
        fnode.rotation.z = lerpf(fnode.rotation.z, tilt, kk)
        fnode.rotation.x = lerpf(fnode.rotation.x, -steer_vis * 0.3, kk)
    if not is_b:
        fveh["rot"] = 1.0
    var fd: Dictionary = fveh.get("d", {})
    if fd.has("gear"):
        (fd["gear"] as Node3D).visible = falt < _air_floor(fnode.position) + 0.7
    if fd.has("glow"):
        (fd["glow"] as Node3D).visible = fspeed > 8.0
    if not is_b:
        _shadow_update(np, falt, 1.4 if is_j else (1.8 if is_p else 1.5))
    _eng_set(clampf(absf(fspeed) / maxs, 0.0, 1.0), clampf(falt / 15.0, 0.0, 1.0) * 0.1 + clampf(fvy / 4.0, 0.0, 1.0) * 0.15)
    if pilot_view:
        if is_p or is_b:
            _pilot_cam("CargoBoat" if is_b else ("Jet" if is_j else "SupplyPlane"))
            cam_h = fyaw
            if is_p:
                pilot_lbl.text = "ALT %d m   SPEED %d" % [int(falt * 3.0), int(absf(fspeed) * 8.0)]
            else:
                pilot_lbl.text = "SPEED %d" % int(absf(fspeed) * 8.0)
            return
        var pd := Vector3(cos(fyaw), 0.0, -sin(fyaw))
        var eye: Vector3 = fnode.position + pd * (0.55 if is_h else 0.3) + Vector3(0.0, 0.5 if is_h else 0.2, 0.0)
        cam.global_position = eye
        var pitch: float = clampf(fspeed / maxs, -0.4, 1.0) * 0.22 + fvy * 0.02
        cam.look_at(eye + pd * 10.0 + Vector3(0.0, -pitch * 10.0, 0.0), Vector3.UP)
        cam.rotate_object_local(Vector3(0, 0, 1), -fnode.rotation.x * 0.8)
        cam_h = fyaw
        pilot_lbl.text = "ALT %d m   SPEED %d" % [int(falt * 3.0), int(absf(fspeed) * 8.0)]
        return
    cam_h = lerp_angle(cam_h, fyaw, clampf(1.0 - exp(-3.0 * delta), 0.0, 1.0))
    var cdir := Vector3(cos(cam_h), 0.0, -sin(cam_h))
    var cd: float = 3.8
    if is_h:
        cd = 5.0
    elif is_j:
        cd = 5.2
    elif is_p:
        cd = 4.8
    elif is_b:
        cd = 5.5
    var cp: Vector3 = _cam_clear(fnode.position, cdir, cd, 1.1, 0.10)
    cp.y = maxf(cp.y, 0.6)
    cam.global_position = cam.global_position.lerp(cp, clampf(1.0 - exp(-9.0 * delta), 0.0, 1.0))
    cam.look_at(fnode.position + Vector3(0.0, 0.25, 0.0) + cdir * 2.0, Vector3.UP)

# ----------------------------------------------------------------- driving road vehicles and the train

func _restore_walk_hud() -> void:
    up_btn.visible = false
    down_btn.visible = false
    player.visible = true
    exit_btn.visible = true
    view_btn.visible = true
    view_btn.text = "TOP VIEW"
    act_btn.visible = false
    top_view = false
    cam.make_current()

func _drive_start_common(vnode: Node3D, kind: int) -> void:
    fnode = vnode
    flying = kind
    fk = 0
    _eng_start("motor")
    dspeed = 0.0
    f_autopilot = false
    up_held = false
    down_held = false
    player.visible = false
    exit_btn.visible = false
    up_btn.visible = false
    down_btn.visible = false
    act_btn.text = "GET OUT"
    act_btn.visible = true
    view_btn.visible = true
    top_view = false
    _set_pilot(false)
    cam.global_position = player.position + Vector3(0, 3, 4)
    cam.make_current()

func _start_drive(idx: int) -> void:
    dv = g.vehicles[idx]
    dv["driven"] = true
    dv["rejoin"] = false
    fveh = dv
    var n: Node3D = dv["node"]
    dyaw = n.rotation.y
    _drive_start_common(n, 20)
    g._play_named("horn", -10.0)
    g._show_toast("Driving the %s! Stick up: go, down: reverse, left / right: steer." % str(n.name).to_lower())

func _start_train() -> void:
    if g.train_state != 0:
        return
    g.train_state = 9
    g.train_speed = 0.0
    fveh = {}
    _drive_start_common(g.train_cars[0], 30)
    g._play_named("horn", -8.0)
    g._show_toast("You are the train driver! Stick up: go, down: brake. Stop to get out.")

func _try_get_out() -> void:
    var spd: float = absf(g.train_speed) if flying == 30 else absf(dspeed)
    if spd > 0.8:
        g._show_toast("Stop first, then get out.")
        return
    var base := Vector3.ZERO
    var yaw_dir := Vector2(1, 0)
    if flying == 30:
        base = fnode.global_position
        var fw: Vector3 = fnode.global_transform.basis.x
        yaw_dir = Vector2(fw.x, fw.z).normalized()
    else:
        base = fnode.position
        yaw_dir = Vector2(sin(dyaw), cos(dyaw))
    var side := Vector2(yaw_dir.y, -yaw_dir.x)
    var spot := Vector2(base.x, base.z) + side * 1.7
    var found: bool = false
    for k in [1.7, -1.7, 2.6, -2.6, 3.5, -3.5]:
        var c: Vector2 = Vector2(base.x, base.z) + side * float(k)
        var ok: bool = absf(c.x) < LIMIT and c.y > -18.4 and c.y < LIMIT
        if ok:
            for o in obstacles:
                var ov: Vector3 = o
                if Vector2(c.x - ov.x, c.y - ov.y).length() < ov.z + 0.4:
                    ok = false
                    break
        if ok:
            spot = c
            found = true
            break
    if not found:
        spot = Vector2(clampf(spot.x, -LIMIT, LIMIT), clampf(spot.y, -18.4, LIMIT))
    player.position = Vector3(spot.x, GROUND_Y, spot.y)
    py_cur = GROUND_Y
    heading = atan2(-yaw_dir.y, yaw_dir.x)
    cam_h = heading
    if flying == 30:
        g.train_state = 3
        g.train_next = 0
        g.train_speed = 0.05
        g._show_toast("The train drives itself back to the Trade Centre station.")
    else:
        dv["driven"] = false
        var cur := Vector2(fnode.position.x, fnode.position.z)
        var route: Array = dv["route"]
        var cum: Array = dv["cum"]
        var best: float = 1e9
        for i in range(route.size() - 1):
            var a: Vector2 = route[i]
            var b: Vector2 = route[i + 1]
            var ab: Vector2 = b - a
            var tt: float = clampf((cur - a).dot(ab) / maxf(ab.length_squared(), 0.0001), 0.0, 1.0)
            var q: Vector2 = a + ab * tt
            var dq: float = q.distance_to(cur)
            if dq < best:
                best = dq
                dv["rpos"] = q
                dv["rs"] = float(cum[i]) + tt * ab.length()
        dv["rejoin"] = true
        g._show_toast("You got out. The %s drives back to its road." % str(fnode.name).to_lower())
    flying = 0
    _eng_stop()
    dv_clear()
    _set_pilot(false)
    _restore_walk_hud()

func dv_clear() -> void:
    if not dv.is_empty():
        dv["driven"] = false
    dv = {}

func _drive_tick(delta: float) -> void:
    if g.crop_bar != null:
        g.crop_bar.visible = false
    act_btn.text = "GET OUT"
    var jv: Vector2 = (joy as SailScript.Joy).vec
    var steer: float = jv.x if absf(jv.x) > 0.12 else 0.0
    var thr: float = -jv.y if absf(jv.y) > 0.12 else 0.0
    if flying == 30:
        _train_drive(delta, thr)
        return
    var spec: Array = DRIVE.get(str(fnode.name), [5.0, 1.0])
    var maxs: float = float(spec[0])
    var rad: float = float(spec[1])
    var tspeed: float = thr * maxs if thr > 0.0 else thr * maxs * 0.4
    dspeed = move_toward(dspeed, tspeed, (6.0 if thr != 0.0 else 9.0) * delta)
    _eng_set(clampf(absf(dspeed) / maxs, 0.0, 1.0), 0.0)
    var yr: float = 1.9 * clampf(absf(dspeed) / 2.0, 0.0, 1.0) * signf(dspeed)
    dyaw -= steer * yr * delta
    var fwd := Vector3(sin(dyaw), 0.0, cos(dyaw))
    var old: Vector3 = fnode.position
    var p: Vector3 = old + fwd * dspeed * delta
    var all_obs: Array = obstacles.duplicate()
    for ov2 in g.vehicles:
        var ovd: Dictionary = ov2
        if ovd != dv:
            var on2: Node3D = ovd["node"]
            if on2.visible:
                all_obs.append(Vector3(on2.position.x, on2.position.z, 1.2))
    for o in all_obs:
        var ov: Vector3 = o
        var dd := Vector2(p.x - ov.x, p.z - ov.y)
        if dd.length() < ov.z + rad:
            var n: Vector2 = dd.normalized() if dd.length() > 0.001 else Vector2(1, 0)
            p.x = ov.x + n.x * (ov.z + rad)
            p.z = ov.y + n.y * (ov.z + rad)
    for rc in _tc_rects(GROUND_Y):
        p = _push_rect(p, rc, rad)
    p.x = clampf(p.x, -LIMIT + 0.6, LIMIT - 0.6)
    p.z = clampf(p.z, -17.8, LIMIT - 0.6)
    var moved: float = Vector2(p.x - old.x, p.z - old.z).length()
    if moved < absf(dspeed) * delta * 0.5:
        dspeed = move_toward(dspeed, 0.0, 20.0 * delta)
    fnode.position = Vector3(p.x, old.y, p.z)
    fnode.rotation.y = dyaw
    var wheels: Array = dv["wheels"]
    var wr: Array = dv["wr"]
    for i in range(wheels.size()):
        (wheels[i] as Node3D).rotation.x += dspeed * delta / float(wr[i])
    var lights: Array = dv["light"]
    if lights.size() == 2:
        var flip: bool = int(t * 4.0) % 2 == 0
        (lights[0] as StandardMaterial3D).emission_energy_multiplier = 2.5 if (flip and absf(dspeed) > 0.2) else 0.0
        (lights[1] as StandardMaterial3D).emission_energy_multiplier = 2.5 if (not flip and absf(dspeed) > 0.2) else 0.0
    if pilot_view:
        _pilot_cam(str(fnode.name))
        cam_h = dyaw
        pilot_lbl.text = "SPEED %d km/h" % int(absf(dspeed) * 9.0)
        return
    var cd: float = 3.6 if str(fnode.name) == "Tractor" else 4.4
    var cp: Vector3 = _cam_clear(fnode.position, fwd, cd, 2.3, 0.0)
    cam.global_position = cam.global_position.lerp(cp, clampf(1.0 - exp(-8.0 * delta), 0.0, 1.0))
    cam.look_at(fnode.position + fwd * 2.0 + Vector3(0.0, 0.6, 0.0), Vector3.UP)

func _train_drive(delta: float, thr: float) -> void:
    var maxs: float = 5.0
    var tspeed: float = thr * maxs if thr > 0.0 else thr * maxs * 0.3
    g.train_speed = move_toward(g.train_speed, tspeed, 1.8 * delta)
    _eng_set(clampf(absf(g.train_speed) / maxs, 0.0, 1.0), 0.0)
    g.train_s = fposmod(g.train_s + g.train_speed * delta, g.train_len)
    g._place_train()
    var fw: Vector3 = fnode.global_transform.basis.x.normalized()
    if pilot_view:
        _pilot_cam("Locomotive")
        cam_h = atan2(-fw.z, fw.x)
        pilot_lbl.text = "SPEED %d km/h" % int(absf(g.train_speed) * 12.0)
        return
    var cp: Vector3 = fnode.global_position - fw * 3.6 + Vector3(0.0, 1.9, 0.0)
    cam.global_position = cam.global_position.lerp(cp, clampf(1.0 - exp(-8.0 * delta), 0.0, 1.0))
    cam.look_at(fnode.global_position + fw * 1.5 + Vector3(0.0, 0.4, 0.0), Vector3.UP)

# ----------------------------------------------------------------- per frame



# ----------------------------------------------------------------- swimming, the carrier and the sea

func _carrier_vis() -> bool:
    return g.carrier_unlocked and g.carrier_root != null and g.carrier_root.visible

func _carrier_rect() -> Rect2:
    var cp: Vector3 = g.CARRIER_POS
    return Rect2(cp.x - 2.35, cp.z - 7.0, 4.7, 13.8)

func _deck_y() -> float:
    return g.CARRIER_POS.y + g.DECK_Y

func _deck_hw(lz: float) -> float:
    if lz <= 3.6:
        return 2.3
    if lz >= 6.6:
        return 1.1
    return lerpf(2.3, 1.1, (lz - 3.6) / 3.0)

func _on_deck_xz(q: Vector3) -> bool:
    var cp: Vector3 = g.CARRIER_POS
    var lz: float = q.z - cp.z
    return lz > -6.9 and lz < 6.6 and absf(q.x - cp.x) < _deck_hw(lz)

func _deck_clamp(p: Vector3) -> Vector3:
    var cp: Vector3 = g.CARRIER_POS
    var lz: float = clampf(p.z - cp.z, -6.9 + 0.35, 6.6 - 0.35)
    var hw: float = _deck_hw(lz) - 0.35
    var lx: float = clampf(p.x - cp.x, -hw, hw)
    return Vector3(cp.x + lx, p.y, cp.z + lz)

func _deck_push(p: Vector3) -> Vector3:
    var cp: Vector3 = g.CARRIER_POS
    var q: Vector3 = _push_rect(p, Rect2(cp.x + 1.15, cp.z - 3.9, 1.1, 2.7), 0.3)
    for a in g.aircraft:
        if int(a["state"]) == 0:
            var n: Node3D = a["node"]
            var op: Vector3 = n.global_position
            var dd := Vector2(q.x - op.x, q.z - op.z)
            if dd.length() < 0.85:
                var nn: Vector2 = dd.normalized() if dd.length() > 0.001 else Vector2(1, 0)
                q.x = op.x + nn.x * 0.85
                q.z = op.z + nn.y * 0.85
    return q

func _island_y_at(q: Vector2, i: int) -> float:
    var ic: Vector3 = g.island_discs[i]
    var d: float = q.distance_to(Vector2(ic.x, ic.y)) / ic.z
    return lerpf(0.40, 0.15, smoothstep(0.78, 0.92, d))

func _air_floor(q: Vector3) -> float:
    if _carrier_vis() and _on_deck_xz(q):
        return _deck_y() + 0.08
    if absf(q.x) <= 18.5 and absf(q.z) <= 18.5:
        return 0.13
    for ic in g.island_discs:
        var iv: Vector3 = ic
        if Vector2(q.x - iv.x, q.z - iv.y).length() < iv.z:
            return 0.45
    return 0.12

func _swim_target() -> Dictionary:
    if _carrier_vis():
        var r: Rect2 = _carrier_rect()
        var pp := Vector2(player.position.x, player.position.z)
        var cl := Vector2(clampf(pp.x, r.position.x, r.end.x), clampf(pp.y, r.position.y, r.end.y))
        if pp.distance_to(cl) < 1.3:
            return {"type": "climb", "pos": Vector3(cl.x, 0.0, cl.y), "label": "CLIMB ON CARRIER"}
    return {}

func _deck_target() -> Dictionary:
    var pp := Vector2(player.position.x, player.position.z)
    for i in range(g.aircraft.size()):
        var a: Dictionary = g.aircraft[i]
        if int(a["state"]) != 0:
            continue
        var n: Node3D = a["node"]
        var op: Vector3 = n.global_position
        if pp.distance_to(Vector2(op.x, op.z)) < 2.0:
            var kind: int = int(a["kind"])
            var nm: String = "JET" if kind == 0 else ("SUPPLY PLANE" if kind == 1 else "HELICOPTER")
            return {"type": "cflight", "idx": i, "pos": op, "label": "GET IN " + nm}
    var cp: Vector3 = g.CARRIER_POS
    var lx: float = player.position.x - cp.x
    var lz: float = player.position.z - cp.z
    if _deck_hw(lz) - absf(lx) < 0.75 or lz < -6.9 + 0.75 or lz > 6.6 - 0.75:
        return {"type": "jump", "pos": player.position, "label": "JUMP IN WATER"}
    return {}

func _start_climb(from: Vector3, to: Vector3, dur: float, arc: float, to_reg: int, idx: int) -> void:
    cl_on = true
    cl_t = 0.0
    cl_dur = dur
    cl_from = from
    cl_to = to
    cl_arc = arc
    cl_reg = to_reg
    cl_i = idx
    speed = 0.0
    var d := Vector2(to.x - from.x, to.z - from.z)
    if d.length() > 0.05:
        heading = atan2(-d.y, d.x)
    target = {}
    act_btn.visible = false

func _jump_to_water(from: Vector3, to_xz: Vector2) -> void:
    _start_climb(from, Vector3(to_xz.x, WATER_Y - 0.42, to_xz.y), 0.7, 0.9, 1, -1)

func _carrier_climb() -> void:
    var cp: Vector3 = g.CARRIER_POS
    var lx: float = clampf(player.position.x - cp.x, -1.4, 1.4)
    var lz: float = clampf(player.position.z - cp.z, -6.2, 5.2)
    var dp: Vector3 = _deck_clamp(Vector3(cp.x + lx, 0.0, cp.z + lz))
    dp.y = _deck_y()
    _start_climb(player.position, dp, 1.2, 0.55, 3, -1)

func _deck_jump() -> void:
    var cp: Vector3 = g.CARRIER_POS
    var lx: float = player.position.x - cp.x
    var lz: float = player.position.z - cp.z
    var out := Vector2.ZERO
    if lz < -6.9 + 0.75:
        out = Vector2(cp.x + lx, cp.z - 8.4)
    elif lz > 6.6 - 0.75:
        out = Vector2(cp.x + lx, cp.z + 8.2)
    else:
        out = Vector2(cp.x + signf(lx) * 3.3 if absf(lx) > 0.01 else cp.x + 3.3, cp.z + lz)
    _jump_to_water(player.position, out)

func _climb_tick(delta: float) -> void:
    if g.crop_bar != null:
        g.crop_bar.visible = false
    cl_t += delta / maxf(cl_dur, 0.05)
    var k: float = clampf(cl_t, 0.0, 1.0)
    var e: float = smoothstep(0.0, 1.0, k)
    var px: float = lerpf(cl_from.x, cl_to.x, e)
    var pz: float = lerpf(cl_from.z, cl_to.z, e)
    var py: float = lerpf(cl_from.y, cl_to.y, e) + sin(k * PI) * cl_arc
    player.position = Vector3(px, py, pz)
    player.rotation.y = heading
    py_cur = py
    in_building = false
    _animate_climb(delta, k)
    _cam_follow(delta)
    if k >= 1.0:
        cl_on = false
        reg = cl_reg
        reg_i = cl_i
        py_cur = cl_to.y
        if reg == 1:
            g._play_named("ding", -24.0)
        _ensure_swim_fx()
        _swim_fx_update(delta)
        return
    _ensure_swim_fx()
    _swim_fx_update(delta)

func _cam_follow(delta: float) -> void:
    var night: float = clampf(float(g.lamp_mat.emission_energy_multiplier) / 2.2, 0.0, 1.0) if g.lamp_mat != null else 0.0
    glow.light_energy = night * 1.6
    cam_h = lerp_angle(cam_h, heading, clampf(1.0 - exp(-3.2 * delta), 0.0, 1.0))
    if top_view:
        g.cam_target = g.cam_target.lerp(player.position, clampf(1.0 - exp(-6.0 * delta), 0.0, 1.0))
        g._update_camera()
    else:
        _update_cam(clampf(1.0 - exp(-12.0 * delta), 0.0, 1.0))

func _swim_tick(delta: float) -> void:
    if g.crop_bar != null:
        g.crop_bar.visible = false
    var jv: Vector2 = (joy as SailScript.Joy).vec
    var busy: bool = g._any_panel_open()
    var steer: float = jv.x if (absf(jv.x) > 0.12 and not busy) else 0.0
    var thr: float = -jv.y if not busy else 0.0
    if absf(thr) < 0.12:
        thr = 0.0
    var tspeed: float = thr * SWIM_SPEED if thr > 0.0 else thr * SWIM_SPEED * 0.4
    speed = move_toward(speed, tspeed, 8.0 * delta)
    if steer != 0.0:
        heading -= steer * deg_to_rad(100.0) * delta
    steer_vis = lerpf(steer_vis, steer, clampf(8.0 * delta, 0.0, 1.0))
    var dir := Vector3(cos(heading), 0.0, -sin(heading))
    var p: Vector3 = player.position + dir * speed * delta
    for md in g.mountain_discs:
        var mv: Vector3 = md
        var dm := Vector2(p.x - mv.x, p.z - mv.y)
        if dm.length() < mv.z * 0.88:
            var nm: Vector2 = dm.normalized() if dm.length() > 0.001 else Vector2(1, 0)
            p.x = mv.x + nm.x * mv.z * 0.88
            p.z = mv.y + nm.y * mv.z * 0.88
    for rd in g.rock_discs:
        var rv: Vector3 = rd
        var dr := Vector2(p.x - rv.x, p.z - rv.y)
        if dr.length() < rv.z + 0.3:
            var nr: Vector2 = dr.normalized() if dr.length() > 0.001 else Vector2(1, 0)
            p.x = rv.x + nr.x * (rv.z + 0.3)
            p.z = rv.y + nr.y * (rv.z + 0.3)
    if _carrier_vis():
        p = _push_rect(p, _carrier_rect(), 0.35)
    p.x = clampf(p.x, -70.0, 70.0)
    p.z = clampf(p.z, -70.0, 70.0)
    # reach a small island: hop out onto it
    for i in range(g.island_discs.size()):
        var ic: Vector3 = g.island_discs[i]
        var dd := Vector2(p.x - ic.x, p.z - ic.y)
        if dd.length() < ic.z * 1.06:
            var nd: Vector2 = dd.normalized() if dd.length() > 0.001 else Vector2(1, 0)
            var ep := Vector2(ic.x, ic.y) + nd * (ic.z * 0.86)
            _start_climb(player.position, Vector3(ep.x, _island_y_at(ep, i), ep.y), 0.8, 0.35, 2, i)
            return
    # reach the farm shore: climb out
    if absf(p.x) < 18.55 and p.z > -18.55 and p.z < 18.55:
        var inx: float = clampf(p.x, -17.6, 17.6)
        var inz: float = clampf(p.z, -17.6, 17.6)
        _start_climb(player.position, Vector3(inx, GROUND_Y, inz), 0.8, 0.5, 0, -1)
        return
    var moved: float = Vector2(p.x - player.position.x, p.z - player.position.z).length()
    player.position.x = p.x
    player.position.z = p.z
    swim_t += delta * (2.2 + speed * 1.6)
    py_cur = lerpf(py_cur, WATER_Y - 0.42 + sin(t * 2.4) * 0.04, clampf(10.0 * delta, 0.0, 1.0))
    player.position.y = py_cur
    player.rotation.y = heading
    in_building = false
    _animate_swim(delta)
    still_t = still_t + delta if moved < 0.002 else 0.0
    _cam_follow(delta)
    _ensure_swim_fx()
    _swim_fx_update(delta)
    _find_target()

func _animate_swim(delta: float) -> void:
    var kr: float = clampf(8.0 * delta, 0.0, 1.0)
    model.rotation.z = lerpf(model.rotation.z, -1.2, kr)
    model.position.x = lerpf(model.position.x, -0.75, kr)
    model.position.y = lerpf(model.position.y, 0.05, kr)
    var a: float = swim_t * 2.0
    (parts["lsh"] as Node3D).rotation.z = a
    (parts["rsh"] as Node3D).rotation.z = a + PI
    (parts["lel"] as Node3D).rotation.z = 0.35
    (parts["rel"] as Node3D).rotation.z = 0.35
    var kick: float = sin(swim_t * 4.0) * 0.35
    (parts["lthigh"] as Node3D).rotation.z = kick
    (parts["rthigh"] as Node3D).rotation.z = -kick
    (parts["lknee"] as Node3D).rotation.z = -0.15
    (parts["rknee"] as Node3D).rotation.z = -0.15
    (parts["hips"] as Node3D).position.y = 0.0
    (parts["torso"] as Node3D).rotation.z = 0.0
    (parts["torso"] as Node3D).rotation.y = sin(swim_t * 2.0) * 0.12
    (parts["head"] as Node3D).rotation.z = 0.9
    (parts["head"] as Node3D).rotation.y = -steer_vis * 0.3

func _animate_climb(delta: float, k: float) -> void:
    var kr: float = clampf(8.0 * delta, 0.0, 1.0)
    var lean: float = -1.2 if cl_reg == 1 else 0.0
    model.rotation.z = lerpf(model.rotation.z, lean, kr)
    model.position.x = lerpf(model.position.x, -0.75 if cl_reg == 1 else 0.0, kr)
    model.position.y = lerpf(model.position.y, 0.05 if cl_reg == 1 else 0.0, kr)
    var up: float = 2.7 if cl_reg != 1 else 2.2
    (parts["lsh"] as Node3D).rotation.z = up
    (parts["rsh"] as Node3D).rotation.z = up
    (parts["lel"] as Node3D).rotation.z = 0.3
    (parts["rel"] as Node3D).rotation.z = 0.3
    var kick: float = sin(k * 18.0) * 0.5
    (parts["lthigh"] as Node3D).rotation.z = kick
    (parts["rthigh"] as Node3D).rotation.z = -kick
    (parts["lknee"] as Node3D).rotation.z = -0.4
    (parts["rknee"] as Node3D).rotation.z = -0.4

func _ensure_swim_fx() -> void:
    if swim_fx != null:
        return
    swim_fx = Node3D.new()
    swim_fx.name = "SwimRipple"
    g.add_child(swim_fx)
    for rr in [0.55, 0.95]:
        var m := MeshInstance3D.new()
        var cyl := CylinderMesh.new()
        cyl.top_radius = rr
        cyl.bottom_radius = rr
        cyl.height = 0.01
        cyl.radial_segments = 20
        m.mesh = cyl
        var mat := StandardMaterial3D.new()
        mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
        mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
        mat.albedo_color = Color(1, 1, 1, 0.28 if rr < 0.8 else 0.16)
        m.material_override = mat
        m.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
        swim_fx.add_child(m)

func _swim_fx_update(delta: float) -> void:
    if swim_fx == null:
        return
    var near_water: bool = reg == 1 or (cl_on and (cl_reg == 1 or cl_from.y < 0.0))
    swim_fx.visible = near_water and on
    if not swim_fx.visible:
        return
    swim_fx.global_position = Vector3(player.position.x, WATER_Y + 0.03, player.position.z)
    var pulse: float = 1.0 + 0.18 * sin(t * 4.0) + absf(speed) * 0.12
    swim_fx.scale = Vector3(pulse, 1.0, pulse)

# ---- carrier aircraft: take control of the jets, the supply plane and the helicopter on the deck

func _start_carrier_flight(idx: int) -> void:
    var a: Dictionary = g.aircraft[idx]
    if int(a["state"]) != 0:
        return
    var kind: int = int(a["kind"])
    var node: Node3D = a["node"]
    var gt: Transform3D = node.global_transform
    g.carrier_root.remove_child(node)
    g.add_child(node)
    node.global_transform = gt
    a["state"] = 5
    fveh = a
    fnode = node
    flying = 10 + kind
    fk = 5 if kind == 0 else (3 if kind == 1 else 2)
    fpad = node.global_position
    fland = -PI * 0.5
    fyaw = node.rotation.y
    fspeed = 0.0
    fvy = 0.0
    falt = node.position.y
    f_autopilot = false
    f_phase = 0
    up_held = false
    down_held = false
    player.visible = false
    exit_btn.visible = false
    view_btn.visible = true
    up_btn.visible = true
    down_btn.visible = true
    act_btn.text = "RETURN TO CARRIER"
    act_btn.visible = true
    cam_h = fyaw
    top_view = false
    _set_pilot(false)
    cam.make_current()
    _eng_start("jet" if kind == 0 else ("prop" if kind == 1 else "heli"))
    if kind == 2:
        g._show_toast("Helicopter: stick to steer and go, UP / DOWN for height.")
    else:
        g._show_toast("Push the stick up to roll along the deck, then hold UP to take off!")

func _end_carrier_flight() -> void:
    var a: Dictionary = fveh
    fnode.visible = true
    g.remove_child(fnode)
    g.carrier_root.add_child(fnode)
    a["state"] = 0
    a["t"] = 0.0
    a["speed"] = 0.0
    a["rot"] = 0.0
    a["timer"] = 25.0 + float(randi() % 20)
    g._air_pose(a, 0.0)
    var lp: Vector3 = fnode.position
    flying = 0
    fk = 0
    f_autopilot = false
    up_held = false
    down_held = false
    _shadow_hide()
    var cp: Vector3 = g.CARRIER_POS
    var ox: float = -1.4 if lp.x > 0.0 else 1.4
    player.position = _deck_clamp(Vector3(cp.x + lp.x + ox, 0.0, cp.z + lp.z))
    player.position.y = _deck_y()
    py_cur = _deck_y()
    reg = 3
    reg_i = -1
    heading = 0.0 if ox > 0.0 else PI
    cam_h = heading
    speed = 0.0
    _set_pilot(false)
    _restore_walk_hud()
    g._show_toast("Back on the carrier deck.")

# ---- shadow under the aircraft

func _shadow_update(pos: Vector3, alt: float, size: float) -> void:
    if shadow == null:
        shadow = MeshInstance3D.new()
        var cyl := CylinderMesh.new()
        cyl.top_radius = 0.5
        cyl.bottom_radius = 0.5
        cyl.height = 0.01
        cyl.radial_segments = 20
        shadow.mesh = cyl
        var mat := StandardMaterial3D.new()
        mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
        mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
        mat.albedo_color = Color(0, 0, 0, 0.35)
        shadow.material_override = mat
        shadow.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
        g.add_child(shadow)
    var fl: float = _air_floor(pos)
    var over_land: bool = fl > 0.2 or (absf(pos.x) <= 18.5 and absf(pos.z) <= 18.5)
    shadow.visible = over_land
    if not over_land:
        return
    var h: float = maxf(alt - fl, 0.0)
    shadow.global_position = Vector3(pos.x, fl + 0.03, pos.z)
    shadow.rotation.y = fyaw
    var sz: float = size * (1.0 + h * 0.04)
    shadow.scale = Vector3(sz, 1.0, sz * 0.8)
    (shadow.material_override as StandardMaterial3D).albedo_color = Color(0, 0, 0, clampf(0.42 - h * 0.012, 0.1, 0.42))

func _shadow_hide() -> void:
    if shadow != null:
        shadow.visible = false

# ---- engine sound (generated: it rises with speed)

func _eng_wave(kind: String) -> AudioStreamWAV:
    var rate: int = 11025
    var n: int = rate
    var data := PackedFloat32Array()
    data.resize(n)
    var rng := RandomNumberGenerator.new()
    rng.seed = 77
    var lp: float = 0.0
    for i in range(n):
        var tt: float = float(i) / float(rate)
        var nz: float = rng.randf_range(-1.0, 1.0)
        lp += (nz - lp) * 0.12
        var x: float = 0.0
        if kind == "prop":
            for h in range(1, 7):
                x += sin(TAU * 55.0 * float(h) * tt) / float(h)
            x += nz * 0.18
        elif kind == "heli":
            var env: float = pow(maxf(0.0, sin(TAU * 11.0 * tt)), 2.0)
            x = lp * env * 3.0 + sin(TAU * 44.0 * tt) * 0.35
        elif kind == "jet":
            x = lp * 2.2 + sin(TAU * 220.0 * tt) * 0.25 + nz * 0.12
        else:
            for h in range(1, 5):
                x += sin(TAU * 36.0 * float(h) * tt) / float(h)
            x += lp * 0.5
        data[i] = x
    g._normalize(data, 0.8)
    return g._pcm_to_wav(data, rate, true)

func _eng_start(kind: String) -> void:
    if eng == null:
        eng = AudioStreamPlayer.new()
        hud.add_child(eng)
    if not eng_waves.has(kind):
        eng_waves[kind] = _eng_wave(kind)
    eng_kind = kind
    eng.stream = eng_waves[kind]
    eng.volume_db = -16.0
    eng.pitch_scale = 0.7
    eng.play()

func _eng_stop() -> void:
    if eng != null:
        eng.stop()

func _eng_set(ratio: float, extra: float) -> void:
    if eng == null or not eng.playing:
        return
    var base: float = 0.55 if eng_kind != "heli" else 0.85
    var span: float = 1.1 if eng_kind != "heli" else 0.35
    eng.pitch_scale = base + ratio * span + extra
    eng.volume_db = -17.0 + ratio * 5.0

# ----------------------------------------------------------------- Trade Centre building

func _tp() -> Vector3:
    return g.TRADE_POS

func _rect(x0: float, z0: float, x1: float, z1: float) -> Rect2:
    var t0: Vector3 = _tp()
    return Rect2(t0.x + x0, t0.z + z0, x1 - x0, z1 - z0)

func _tc_active() -> bool:
    return g.trade_unlocked and g.trade_root != null and g.trade_root.visible

func _tc_rects(py: float) -> Array:
    var out: Array = []
    if not _tc_active():
        return out
    var hw: float = g.TC_HW
    var hd: float = g.TC_HD
    var w: float = g.TC_WALL
    var dh: float = g.TC_DOOR_HW
    if py < 3.2:
        out.append(_rect(-hw, -hd, hw, -hd + w))                 # back wall
        out.append(_rect(-hw, -hd, -hw + w, hd))                  # left wall
        out.append(_rect(hw - w, -hd, hw, hd))                    # right wall
        out.append(_rect(-hw, hd - w, -dh, hd))                   # front left
        out.append(_rect(dh, hd - w, hw, hd))                     # front right
        if g.trade_door_amt < 0.85:
            out.append(_rect(-dh, hd - w, dh, hd))                # the door
        out.append(_rect(1.0, 0.05, 3.2, 0.75))                   # counter
        out.append(_rect(-3.2, -0.3, -2.6, 2.1))                  # conveyor
        out.append(_rect(1.7, -2.2, 3.2, -1.3))                   # crates
    if py < 2.2:
        out.append(_rect(-2.5, g.TC_STAIR_Z1 - 0.02, g.TC_HOLE_X0, g.TC_STAIR_Z1 + 0.1))   # stair side rail (low part)
    out.append(_rect(g.TC_HOLE_X0, g.TC_STAIR_Z1 - 0.02, g.TC_STAIR_X1, g.TC_STAIR_Z1 + 0.1))   # stairwell rail
    if py >= 3.2:
        out.append(_rect(-hw, hd - 0.15, hw, hd))
        out.append(_rect(-hw, -hd, hw, -hd + 0.15))
        out.append(_rect(-hw, -hd, -hw + 0.15, hd))
        out.append(_rect(hw - 0.15, -hd, hw, hd))
    return out

func _push_rect(p: Vector3, r: Rect2, rad: float) -> Vector3:
    var cx: float = clampf(p.x, r.position.x, r.position.x + r.size.x)
    var cz: float = clampf(p.z, r.position.y, r.position.y + r.size.y)
    var dx: float = p.x - cx
    var dz: float = p.z - cz
    var d2: float = dx * dx + dz * dz
    if d2 >= rad * rad:
        return p
    if d2 > 0.000001:
        var d: float = sqrt(d2)
        p.x = cx + dx / d * rad
        p.z = cz + dz / d * rad
        return p
    # centre is inside the rect: leave through the nearest side
    var l: float = p.x - r.position.x
    var rr: float = r.position.x + r.size.x - p.x
    var u: float = p.z - r.position.y
    var dn: float = r.position.y + r.size.y - p.z
    var m: float = minf(minf(l, rr), minf(u, dn))
    if m == l:
        p.x = r.position.x - rad
    elif m == rr:
        p.x = r.position.x + r.size.x + rad
    elif m == u:
        p.z = r.position.y - rad
    else:
        p.z = r.position.y + r.size.y + rad
    return p

func _surface_y(x: float, z: float, cur_y: float) -> float:
    var best: float = GROUND_Y
    if not _tc_active():
        return best
    var t0: Vector3 = _tp()
    var lx: float = x - t0.x
    var lz: float = z - t0.z
    var cands: Array = [GROUND_Y]
    if lx >= g.TC_STAIR_X0 and lx <= g.TC_STAIR_X1 and lz >= g.TC_STAIR_Z0 and lz <= g.TC_STAIR_Z1:
        var tread: float = (g.TC_STAIR_X1 - g.TC_STAIR_X0) / float(g.TC_STEPS)
        var i: int = clampi(int((lx - g.TC_STAIR_X0) / tread), 0, g.TC_STEPS - 1)
        cands.append(g.TC_FLOOR + g.TC_STEP_H * float(i + 1))
    if absf(lx) <= g.TC_HW and absf(lz) <= g.TC_HD:
        var in_hole: bool = lx >= g.TC_HOLE_X0 and lx <= g.TC_STAIR_X1 and lz >= g.TC_STAIR_Z0 and lz <= g.TC_STAIR_Z1
        if not in_hole:
            cands.append(g.ROOF_Y)
    for c in cands:
        var cy: float = c
        if cy <= cur_y + 0.5 and cy > best:
            best = cy
    return best

func _inside_tc(p: Vector3) -> bool:
    if not _tc_active():
        return false
    var t0: Vector3 = _tp()
    return absf(p.x - t0.x) < g.TC_HW - 0.3 and absf(p.z - t0.z) < g.TC_HD - 0.3 and p.y < 3.2

func _door_world() -> Vector3:
    var t0: Vector3 = _tp()
    return Vector3(t0.x, 0.0, t0.z + g.TC_HD - 0.1)

func _in_tc_box(q: Vector3, m: float) -> bool:
    var t0: Vector3 = _tp()
    return absf(q.x - t0.x) < g.TC_HW + m and absf(q.z - t0.z) < g.TC_HD + m and q.y < 3.6

func _update_cam(k: float) -> void:
    var dir := Vector3(cos(cam_h), 0.0, -sin(cam_h))
    var p: Vector3 = player.position
    var want_d: float = 4.4
    var d: float = 4.4
    while d > 1.7:
        var q: Vector3 = p - dir * d
        var clear: bool = true
        for o in obstacles:
            var ov: Vector3 = o
            if Vector2(q.x - ov.x, q.z - ov.y).length() < ov.z + 1.3:
                clear = false
                break
        if clear and not in_building and p.y < 2.5 and _tc_active() and _in_tc_box(q, 0.5):
            clear = false
        if clear:
            break
        d -= 0.35
    if in_building:
        d = 2.3
    want_d = d
    cam_dist = lerpf(cam_dist, want_d, 0.25 if want_d < cam_dist else 0.05)
    var cp: Vector3 = p - dir * cam_dist + Vector3(0.0, 2.1 + cam_dist * 0.14, 0.0)
    if in_building:
        var t0: Vector3 = _tp()
        cp.x = clampf(cp.x, t0.x - g.TC_HW + 0.45, t0.x + g.TC_HW - 0.45)
        cp.z = clampf(cp.z, t0.z - g.TC_HD + 0.45, t0.z + g.TC_HD - 0.45)
        cp.y = minf(cp.y, 2.85)
    cam.global_position = cam.global_position.lerp(cp, k) if k < 1.0 else cp
    cam.look_at(p + Vector3(0.0, 1.0, 0.0) + dir * 2.2, Vector3.UP)

func tick(delta_raw: float) -> void:
    var delta: float = minf(delta_raw, 0.05)     # slow frames never let you jump through a wall
    t += delta
    if hud == null:
        if g != null and g.ui_root != null:
            _ensure_hud()
        else:
            return
    if not on:
        enter_btn.visible = can_enter()
        return
    if flying >= 20:
        _drive_tick(delta)
        return
    if flying != 0:
        _fly_tick(delta)
        return
    if cl_on:
        _climb_tick(delta)
        return
    if reg == 1:
        _swim_tick(delta)
        return
    if g.crop_bar != null:
        g.crop_bar.visible = false
    var jv: Vector2 = (joy as SailScript.Joy).vec
    var busy: bool = g._any_panel_open()
    var steer: float = jv.x if (absf(jv.x) > 0.12 and not busy) else 0.0
    var thr: float = -jv.y if not busy else 0.0
    if absf(thr) < 0.12:
        thr = 0.0
    var tspeed: float = thr * WALK_SPEED if thr > 0.0 else thr * WALK_SPEED * 0.5
    speed = move_toward(speed, tspeed, 14.0 * delta)
    var turn: float = deg_to_rad(110.0)
    if steer != 0.0:
        heading -= steer * turn * delta
    steer_vis = lerpf(steer_vis, steer, clampf(8.0 * delta, 0.0, 1.0))
    var dir := Vector3(cos(heading), 0.0, -sin(heading))
    var p: Vector3 = player.position + dir * speed * delta
    var all_obs: Array = obstacles.duplicate()
    for vn in ["Tractor", "Ambulance", "Pickup"]:
        var vnode: Node3D = g.get_node_or_null(vn)
        if vnode != null and vnode.visible:
            all_obs.append(Vector3(vnode.global_position.x, vnode.global_position.z, 1.5))
    for o in all_obs:
        var ov: Vector3 = o
        var dd := Vector2(p.x - ov.x, p.z - ov.y)
        if dd.length() < ov.z:
            var n: Vector2 = dd.normalized() if dd.length() > 0.001 else Vector2(1, 0)
            p.x = ov.x + n.x * ov.z
            p.z = ov.y + n.y * ov.z
    if reg == 0:
        for rc in _tc_rects(py_cur):
            p = _push_rect(p, rc, 0.28)
        if p.x > LIMIT or p.x < -LIMIT or p.z > LIMIT or p.z < -18.45:
            # walked off the edge of the farm: jump into the sea
            var ex: float = clampf(p.x, -LIMIT, LIMIT)
            var ez: float = clampf(p.z, -18.45, LIMIT)
            var od := Vector2(p.x - ex, p.z - ez)
            var wd: Vector2 = od.normalized() if od.length() > 0.001 else Vector2(0, 1)
            _jump_to_water(Vector3(ex, py_cur, ez), Vector2(ex, ez) + wd * 1.0 + wd * 0.0)
            return
    elif reg == 2:
        var ic: Vector3 = g.island_discs[reg_i]
        var dv2 := Vector2(p.x - ic.x, p.z - ic.y)
        if dv2.length() > ic.z * 0.99:
            var wd2: Vector2 = dv2.normalized()
            _jump_to_water(Vector3(p.x, py_cur, p.z), Vector2(ic.x, ic.y) + wd2 * ic.z * 1.14)
            return
    elif reg == 3:
        p = _deck_clamp(_deck_push(p))
    var moved: float = Vector2(p.x - player.position.x, p.z - player.position.z).length()
    phase += moved * 3.2
    player.position.x = p.x
    player.position.z = p.z
    if hop_t > 0.0:
        hop_t -= delta
    var ty: float = _surface_y(p.x, p.z, py_cur)
    if reg == 2:
        ty = _island_y_at(Vector2(p.x, p.z), reg_i)
    elif reg == 3:
        ty = _deck_y()
    py_cur = lerpf(py_cur, ty, clampf(1.0 - exp(-18.0 * delta), 0.0, 1.0))
    player.position.y = py_cur
    in_building = reg == 0 and _inside_tc(player.position)
    player.rotation.y = heading
    _animate(moved > 0.002, clampf(absf(speed) / WALK_SPEED, 0.0, 1.0), delta)
    still_t = still_t + delta if moved < 0.002 else 0.0
    var night: float = clampf(float(g.lamp_mat.emission_energy_multiplier) / 2.2, 0.0, 1.0) if g.lamp_mat != null else 0.0
    glow.light_energy = night * 1.6
    cam_h = lerp_angle(cam_h, heading, clampf(1.0 - exp(-3.2 * delta), 0.0, 1.0))
    if top_view:
        g.cam_target = g.cam_target.lerp(player.position, clampf(1.0 - exp(-6.0 * delta), 0.0, 1.0))
        g._update_camera()
    else:
        _update_cam(clampf(1.0 - exp(-12.0 * delta), 0.0, 1.0))
    _find_target()
