extends Node
# Owner Mode (v30): you are the farmer. Walk anywhere on your land with a round
# joystick, see the farm from behind your shoulder, and do the work yourself:
# collect milk, eggs, truffles and apples, plant, water, weed and harvest crops,
# and open the shops. Coins, XP, stock and saves are shared with the normal game.

var g: Node
var v: Node

const SailScript := preload("res://scripts/sail.gd")
const GROUND_Y := 0.15
const WALK_SPEED := 4.2
const LIMIT := 18.0

var on: bool = false
var top_view: bool = false
var player: Node3D
var model: Node3D
var cam: Camera3D
var heading: float = 0.0          # player yaw; the model faces local +x
var cam_h: float = 0.0
var speed: float = 0.0
var phase: float = 0.0
var hop_t: float = 0.0
var t: float = 0.0
var built: bool = false
var obstacles: Array = []
var target: Dictionary = {}
var steer_vis: float = 0.0
var parts: Dictionary = {}
var glow: OmniLight3D
var cam_dist: float = 4.4
var py_cur: float = 0.15
var in_building: bool = false
var flying: int = 0                # 0 = walking, 1 = drone, 2 = helicopter
var fveh: Dictionary = {}
var fnode: Node3D
var fyaw: float = 0.0
var fspeed: float = 0.0
var falt: float = 0.0
var fvy: float = 0.0
var f_autopilot: bool = false
var pilot_view: bool = false
var pilot_hud: Control
var pilot_lbl: Label
var f_phase: int = 0
var up_btn: Button
var down_btn: Button
var up_held: bool = false
var down_held: bool = false
var still_t: float = 0.0

var hud: CanvasLayer
var enter_btn: Button
var exit_btn: Button
var view_btn: Button
var act_btn: Button
var joy: Control
var bottom_bar: Control

const SOLIDS := [
    Vector3(-4.2, -4.1, 2.3),    # farmhouse
    Vector3(3.7, -4.1, 2.4),     # barn
    Vector3(9.6, -7.4, 1.6),     # silo
    Vector3(-10.8, -1.4, 1.8),   # bakery oven
    Vector3(8.2, 11.0, 2.3),     # market tent
    Vector3(-10.0, 12.5, 2.6),   # windmill site
    Vector3(5.0, 0.1, 0.9),      # well
    Vector3(-12.0, -6.5, 3.1),   # pond
    Vector3(15.5, 7.0, 2.7),     # pond
]

# ----------------------------------------------------------------- HUD

func _style(b: Button, col: Color, radius: int) -> void:
    b.add_theme_font_size_override("font_size", 22)
    b.add_theme_color_override("font_color", Color.WHITE)
    b.add_theme_color_override("font_pressed_color", Color.WHITE)
    for st in ["normal", "hover", "pressed", "focus"]:
        var sb := StyleBoxFlat.new()
        sb.bg_color = col if st != "pressed" else col.darkened(0.3)
        sb.set_corner_radius_all(radius)
        sb.border_color = Color(1, 1, 1, 0.9)
        sb.set_border_width_all(4)
        sb.shadow_color = Color(0, 0, 0, 0.3)
        sb.shadow_size = 4
        b.add_theme_stylebox_override(st, sb)

func _ensure_hud() -> void:
    if hud != null:
        return
    hud = CanvasLayer.new()
    hud.layer = 62
    add_child(hud)
    enter_btn = Button.new()
    enter_btn.text = "WALK"
    enter_btn.anchor_top = 1.0
    enter_btn.anchor_bottom = 1.0
    enter_btn.offset_left = 14.0
    enter_btn.offset_right = 124.0
    enter_btn.offset_top = -126.0
    enter_btn.offset_bottom = -16.0
    _style(enter_btn, Color(0.25, 0.62, 0.30), 55)
    enter_btn.pressed.connect(enter)
    hud.add_child(enter_btn)
    exit_btn = Button.new()
    exit_btn.text = "< EXIT WALK"
    exit_btn.anchor_left = 0.5
    exit_btn.anchor_right = 0.5
    exit_btn.offset_left = -215.0
    exit_btn.offset_right = -5.0
    exit_btn.offset_top = 12.0
    exit_btn.offset_bottom = 72.0
    _style(exit_btn, Color(0.2, 0.3, 0.45, 0.9), 14)
    exit_btn.pressed.connect(leave)
    exit_btn.visible = false
    hud.add_child(exit_btn)
    view_btn = Button.new()
    view_btn.text = "TOP VIEW"
    view_btn.anchor_left = 0.5
    view_btn.anchor_right = 0.5
    view_btn.offset_left = 5.0
    view_btn.offset_right = 215.0
    view_btn.offset_top = 12.0
    view_btn.offset_bottom = 72.0
    _style(view_btn, Color(0.2, 0.3, 0.45, 0.9), 14)
    view_btn.pressed.connect(_toggle_view)
    view_btn.visible = false
    hud.add_child(view_btn)
    joy = SailScript.Joy.new()
    joy.anchor_top = 1.0
    joy.anchor_bottom = 1.0
    joy.offset_left = 30.0
    joy.offset_right = 290.0
    joy.offset_top = -290.0
    joy.offset_bottom = -30.0
    joy.visible = false
    hud.add_child(joy)
    act_btn = Button.new()
    act_btn.anchor_left = 1.0
    act_btn.anchor_right = 1.0
    act_btn.anchor_top = 1.0
    act_btn.anchor_bottom = 1.0
    act_btn.offset_left = -330.0
    act_btn.offset_right = -24.0
    act_btn.offset_top = -150.0
    act_btn.offset_bottom = -40.0
    _style(act_btn, Color(0.93, 0.55, 0.12), 30)
    act_btn.add_theme_font_size_override("font_size", 26)
    act_btn.pressed.connect(_act)
    act_btn.visible = false
    hud.add_child(act_btn)
    up_btn = Button.new()
    up_btn.text = "UP"
    down_btn = Button.new()
    down_btn.text = "DOWN"
    var ub: int = 0
    for b in [up_btn, down_btn]:
        var bb: Button = b
        bb.anchor_left = 1.0
        bb.anchor_right = 1.0
        bb.anchor_top = 1.0
        bb.anchor_bottom = 1.0
        bb.offset_left = -130.0
        bb.offset_right = -24.0
        bb.offset_top = -330.0 + 100.0 * float(ub)
        bb.offset_bottom = -240.0 + 100.0 * float(ub)
        _style(bb, Color(0.25, 0.45, 0.75), 20)
        bb.visible = false
        hud.add_child(bb)
        ub += 1
    up_btn.button_down.connect(func(): up_held = true)
    up_btn.button_up.connect(func(): up_held = false)
    down_btn.button_down.connect(func(): down_held = true)
    down_btn.button_up.connect(func(): down_held = false)

# ----------------------------------------------------------------- build

func _build() -> void:
    if built:
        return
    built = true
    player = Node3D.new()
    player.name = "OwnerPlayer"
    g.add_child(player)
    model = Node3D.new()
    model.scale = Vector3.ONE * 0.9
    player.add_child(model)
    _build_human()
    glow = OmniLight3D.new()
    glow.position = Vector3(0.0, 2.2, 0.0)
    glow.omni_range = 7.0
    glow.light_energy = 0.0
    glow.light_color = Color(1.0, 0.9, 0.7)
    glow.shadow_enabled = false
    player.add_child(glow)
    cam = Camera3D.new()
    cam.fov = 62.0
    cam.near = 0.1
    cam.far = 400.0
    g.add_child(cam)
    player.position = Vector3(0.6, GROUND_Y, 5.6)
    heading = deg_to_rad(90.0)       # facing the field (towards -z)
    cam_h = heading
    player.visible = false

func _make_obstacles() -> void:
    obstacles = SOLIDS.duplicate()
    for d in g.solid_discs:
        obstacles.append(d)
    # the railway embankments are solid; you can still walk under the bridge girders
    if g.train_pts.size() > 1 and g.train_len > 1.0:
        var ts: float = 0.0
        while ts < g.train_len:
            if g._train_h(ts) > 0.3 and g._near_bridge_dist(ts) >= 0.0:
                var tp: Vector2 = g._train_at(ts)
                obstacles.append(Vector3(tp.x, tp.y, 0.85))
            ts += 0.6


# ----------------------------------------------------------------- the farmer
# A jointed human: hips, knees, shoulders, elbows, hands with fingers, a neck and a
# detailed head. The model faces local +x; local +z is the farmer's right-hand side.

func _joint(parent: Node3D, pos: Vector3) -> Node3D:
    var n := Node3D.new()
    n.position = pos
    parent.add_child(n)
    return n

func _taper(parent: Node3D, a: Vector3, b: Vector3, r1: float, r2: float, mat: Material) -> void:
    # a smooth tapered limb piece from a (radius r1) to b (radius r2)
    var d: Vector3 = b - a
    var mi := MeshInstance3D.new()
    var cm := CylinderMesh.new()
    cm.top_radius = r1
    cm.bottom_radius = r2
    cm.height = d.length()
    cm.radial_segments = 14
    mi.mesh = cm
    mi.material_override = mat
    mi.position = (a + b) * 0.5
    var dn: Vector3 = d.normalized()
    if dn.dot(Vector3.DOWN) > 0.9999:
        pass
    else:
        mi.quaternion = Quaternion(Vector3.DOWN, dn)
    parent.add_child(mi)

func _build_human() -> void:
    var skin: StandardMaterial3D = v._mm(Color(0.68, 0.47, 0.33), 0.62)
    var skin_d: StandardMaterial3D = v._mm(Color(0.55, 0.36, 0.25), 0.7)
    var shirt: StandardMaterial3D = v._mm(Color(0.78, 0.18, 0.16), 0.85)
    var shirt_d: StandardMaterial3D = v._mm(Color(0.58, 0.12, 0.11), 0.85)
    var denim: StandardMaterial3D = v._mm(Color(0.60, 0.50, 0.34), 0.9)
    var denim_d: StandardMaterial3D = v._mm(Color(0.48, 0.39, 0.26), 0.9)
    var leather: StandardMaterial3D = v._mm(Color(0.30, 0.18, 0.10), 0.55)
    var sole: StandardMaterial3D = v._mm(Color(0.10, 0.08, 0.07), 0.85)
    var gold: StandardMaterial3D = v._mm(Color(0.85, 0.7, 0.25), 0.3, 0.6)
    var hair: StandardMaterial3D = v._mm(Color(0.06, 0.05, 0.05), 0.7)
    var white: StandardMaterial3D = v._mm(Color(0.96, 0.96, 0.94), 0.4)
    var iris: StandardMaterial3D = v._mm(Color(0.14, 0.08, 0.05), 0.2)
    var lip: StandardMaterial3D = v._mm(Color(0.45, 0.2, 0.18), 0.5)
    var straw: StandardMaterial3D = v._mm(Color(0.40, 0.26, 0.14), 0.9)
    var band: StandardMaterial3D = v._mm(Color(0.10, 0.10, 0.10), 0.9)
    var hips: Node3D = _joint(model, Vector3(0, 0, 0))
    parts["hips"] = hips
    # pelvis, belt
    v._put(hips, v._cyl(0.15, 0.16, 0.16, 24), Vector3(0, 0.93, 0), denim, Vector3.ZERO, Vector3(0.72, 1.0, 1.2))
    v._put(hips, v._cyl(0.158, 0.158, 0.045, 24), Vector3(0, 1.00, 0), leather, Vector3.ZERO, Vector3(0.72, 1.0, 1.2))
    v._put(hips, v._bx(Vector3(0.02, 0.035, 0.05)), Vector3(0.118, 1.00, 0), gold)
    # legs: tapered thigh and shin, knee and ankle joints the same width as the limb
    for side in [-1.0, 1.0]:
        var nm: String = "r" if side > 0.0 else "l"
        var th: Node3D = _joint(hips, Vector3(0, 0.90, 0.1 * side))
        _taper(th, Vector3(0, 0.02, 0), Vector3(0, -0.45, 0), 0.088, 0.062, denim)
        var kn: Node3D = _joint(th, Vector3(0, -0.45, 0))
        v._put(kn, v._sph(0.062), Vector3.ZERO, denim)
        _taper(kn, Vector3(0, 0, 0), Vector3(0, -0.40, 0), 0.060, 0.043, denim_d)
        var an: Node3D = _joint(kn, Vector3(0, -0.40, 0))
        v._put(an, v._cyl(0.05, 0.062, 0.11, 14), Vector3(0, 0.02, 0), leather)
        v._put(an, v._sph(0.058), Vector3(-0.012, -0.012, 0), leather, Vector3.ZERO, Vector3(0.95, 0.9, 0.95))       # heel
        v._put(an, v._sph(0.058), Vector3(0.06, -0.026, 0), leather, Vector3.ZERO, Vector3(1.5, 0.78, 0.95))         # instep
        v._put(an, v._sph(0.05), Vector3(0.135, -0.04, 0), leather, Vector3.ZERO, Vector3(1.35, 0.62, 0.95))         # rounded toe
        v._put(an, v._sph(0.074), Vector3(0.062, -0.062, 0), sole, Vector3.ZERO, Vector3(1.95, 0.2, 0.78))           # thin curved sole
        v._put(an, v._sph(0.03), Vector3(-0.045, -0.058, 0), sole, Vector3.ZERO, Vector3(1.0, 0.45, 1.5))           # heel block
        parts[nm + "thigh"] = th
        parts[nm + "knee"] = kn
    # torso: broad chest tapering to the waist
    var torso: Node3D = _joint(hips, Vector3(0, 0.98, 0))
    parts["torso"] = torso
    v._put(torso, v._cyl(0.145, 0.135, 0.14, 24), Vector3(0, 0.06, 0), shirt, Vector3.ZERO, Vector3(0.70, 1.0, 1.18))    # belly
    v._put(torso, v._cyl(0.168, 0.145, 0.30, 26), Vector3(0, 0.27, 0), shirt, Vector3.ZERO, Vector3(0.68, 1.0, 1.28))     # chest
    v._put(torso, v._cyl(0.056, 0.056, 0.38, 14), Vector3(0, 0.425, 0), shirt, Vector3(90, 0, 0), Vector3(1.0, 1.0, 1.0))   # shoulder line
    for pz in [-1.0, 1.0]:
        _taper(torso, Vector3(0, 0.50, 0.045 * pz), Vector3(0, 0.43, 0.175 * pz), 0.04, 0.056, shirt)                          # trapezius
    v._put(torso, v._bx(Vector3(0.02, 0.26, 0.012)), Vector3(0.118, 0.20, 0), shirt_d)
    for bi in range(3):
        v._put(torso, v._sph(0.01), Vector3(0.124, 0.12 + 0.07 * float(bi), 0), white)
    # neck and collar
    v._put(torso, v._cyl(0.047, 0.058, 0.11, 14), Vector3(0, 0.52, 0), skin)
    v._put(torso, v._cyl(0.075, 0.095, 0.04, 16), Vector3(0, 0.47, 0), shirt_d)
    # arms: tapered, joints no wider than the limb
    for side2 in [-1.0, 1.0]:
        var nm2: String = "r" if side2 > 0.0 else "l"
        var sh: Node3D = _joint(torso, Vector3(0, 0.42, 0.205 * side2))
        _taper(sh, Vector3(0, 0.03, 0), Vector3(0, -0.28, 0), 0.056, 0.047, shirt)
        var el: Node3D = _joint(sh, Vector3(0, -0.29, 0))
        v._put(el, v._sph(0.045), Vector3.ZERO, shirt_d)
        _taper(el, Vector3(0, 0, 0), Vector3(0, -0.26, 0), 0.042, 0.030, skin)
        var wr: Node3D = _joint(el, Vector3(0, -0.27, 0))
        v._put(wr, v._sph(0.03), Vector3.ZERO, skin)
        v._put(wr, v._bx(Vector3(0.03, 0.08, 0.07)), Vector3(0, -0.055, 0), skin)
        for fi in range(4):
            var fz: float = (-0.027 + 0.018 * float(fi))
            var fl: float = 0.075 - 0.008 * absf(float(fi) - 1.5)
            v._limb(wr, Vector3(0.006, -0.095, fz), Vector3(0.022, -0.095 - fl * 0.95, fz), 0.0095, skin)
        v._limb(wr, Vector3(0.016, -0.03, 0.034 * side2), Vector3(0.05, -0.075, 0.03 * side2), 0.011, skin)
        parts[nm2 + "sh"] = sh
        parts[nm2 + "el"] = el
    # head
    var head: Node3D = _joint(torso, Vector3(0, 0.57, 0))
    parts["head"] = head
    v._put(head, v._sph(0.105, 1.2), Vector3(0.01, 0.12, 0), skin, Vector3.ZERO, Vector3(1.0, 1.0, 0.86))
    v._put(head, v._sph(0.065, 0.85), Vector3(0.03, 0.045, 0), skin, Vector3.ZERO, Vector3(1.05, 1.0, 0.95))  # jaw and chin
    for ez in [-1.0, 1.0]:
        v._put(head, v._sph(0.02), Vector3(0.086, 0.135, 0.037 * ez), white, Vector3.ZERO, Vector3(0.5, 0.9, 1.25))
        v._put(head, v._sph(0.0105), Vector3(0.096, 0.135, 0.037 * ez), iris)
        v._put(head, v._bx(Vector3(0.012, 0.009, 0.046)), Vector3(0.091, 0.166, 0.039 * ez), hair, Vector3(ez * 8.0, 0, 0))
        v._put(head, v._sph(0.025), Vector3(0.0, 0.11, 0.088 * ez), skin_d, Vector3.ZERO, Vector3(0.45, 1.0, 0.7))
    v._put(head, v._sph(0.02), Vector3(0.102, 0.095, 0), skin, Vector3.ZERO, Vector3(1.2, 1.5, 0.9))   # nose
    v._put(head, v._bx(Vector3(0.008, 0.009, 0.048)), Vector3(0.094, 0.052, 0), lip)                   # mouth
    v._put(head, v._sph(0.108, 0.8), Vector3(-0.012, 0.165, 0), hair, Vector3.ZERO, Vector3(1.0, 0.8, 0.9))
    v._put(head, v._cyl(0.2, 0.2, 0.012, 32), Vector3(0.0, 0.215, 0), straw, Vector3(0, 0, 4))
    v._put(head, v._sph(0.116, 0.65), Vector3(-0.005, 0.225, 0), straw)
    v._put(head, v._cyl(0.119, 0.121, 0.03, 24), Vector3(-0.005, 0.225, 0), band)

func _animate(moved: bool, amp: float, delta: float) -> void:
    var s: float = sin(phase)
    var c: float = cos(phase)
    var idle: float = 1.0 - amp
    var br: float = sin(t * 1.8) * 0.012 * idle
    (parts["hips"] as Node3D).position.y = (absf(s) * 0.045 * amp) if moved else 0.0
    for side in ["l", "r"]:
        var sg: float = 1.0 if side == "l" else -1.0     # legs swing in opposition
        var sw: float = s * sg
        var cw: float = c * sg
        (parts[side + "thigh"] as Node3D).rotation.z = sw * 0.62 * amp
        (parts[side + "knee"] as Node3D).rotation.z = -(maxf(0.0, cw) * 0.85 + 0.05) * amp
        (parts[side + "sh"] as Node3D).rotation.z = -sw * 0.5 * amp + br
        (parts[side + "el"] as Node3D).rotation.z = 0.25 + (0.35 + maxf(0.0, -sw) * 0.3) * amp
    var torso: Node3D = parts["torso"]
    torso.rotation.y = s * 0.12 * amp
    torso.rotation.z = -0.07 * amp + br
    (parts["head"] as Node3D).rotation.z = 0.07 * amp
    (parts["head"] as Node3D).rotation.y = -steer_vis * 0.35 - s * 0.05 * amp
    if hop_t > 0.0:
        var k: float = sin(clampf(hop_t / 0.4, 0.0, 1.0) * PI)
        (parts["rsh"] as Node3D).rotation.z = 1.25 * k
        (parts["rel"] as Node3D).rotation.z = 0.35 * k
        torso.rotation.z = 0.14 * k

# ----------------------------------------------------------------- enter / leave

func can_enter() -> bool:
    if on or g == null:
        return false
    if v.hb != null and (v.hb.on or v.hb.sailing):
        return false
    if g.ui_root == null or not g.ui_root.visible:
        return false
    if g._any_panel_open():
        return false
    return true

func enter() -> void:
    if on or not can_enter():
        return
    _ensure_hud()
    _build()
    _make_obstacles()
    on = true
    g.owner_on = true
    if bottom_bar == null:
        for c in g.ui_root.get_children():
            if c is HBoxContainer and absf((c as Control).anchor_left - 0.22) < 0.01 and (c as Control).anchor_top == 1.0:
                bottom_bar = c
    if bottom_bar != null:
        bottom_bar.visible = false
    top_view = false
    player.visible = true
    cam_h = heading
    enter_btn.visible = false
    exit_btn.visible = true
    view_btn.visible = true
    view_btn.text = "TOP VIEW"
    joy.visible = true
    speed = 0.0
    _update_cam(1.0)
    cam.make_current()
    g._show_toast("You are the farmer! Walk up to animals, crops and shops.")

func leave() -> void:
    if not on:
        return
    on = false
    g.owner_on = false
    player.visible = false
    g.camera.make_current()
    if bottom_bar != null:
        bottom_bar.visible = true
    exit_btn.visible = false
    view_btn.visible = false
    joy.visible = false
    act_btn.visible = false
    (joy as SailScript.Joy).vec = Vector2.ZERO
    g.cam_zoom = 16.8
    g.cam_target = Vector3(0.0, 0.25, 0.0)
    g._update_camera()
    if g.crop_bar != null and not g.crop_bar_dismissed:
        g.crop_bar.visible = true

func _toggle_view() -> void:
    if flying != 0:
        _set_pilot(not pilot_view)
        return
    top_view = not top_view
    view_btn.text = "WALK VIEW" if top_view else "TOP VIEW"
    if top_view:
        g.cam_zoom = 11.0
        g.cam_target = player.position
        g.camera.make_current()
    else:
        cam.make_current()

# ----------------------------------------------------------------- actions

func _near_producer() -> Dictionary:
    var best: Dictionary = {}
    var best_d: float = 2.5
    for p in g.producers:
        if not bool(p["ready"]):
            continue
        var n: Node3D = p["node"]
        if not is_instance_valid(n):
            continue
        var d: float = Vector2(n.global_position.x - player.position.x, n.global_position.z - player.position.z).length()
        if d < best_d:
            best_d = d
            best = {"type": "prod", "p": p, "pos": n.global_position}
    return best

func _near_plot() -> Dictionary:
    var best_key: String = ""
    var best_d: float = g.CELL * 0.85
    for k in g.plot_centers.keys():
        var c: Vector3 = g.plot_centers[k]
        var d: float = maxf(absf(c.x - player.position.x), absf(c.z - player.position.z))
        if d < best_d:
            best_d = d
            best_key = str(k)
    if best_key == "":
        return {}
    var st: Dictionary = g.crop_states[best_key]
    var c2: Vector3 = g.plot_centers[best_key]
    var planted: bool = bool(st.get("planted", false))
    var ripe: bool = planted and float(st.get("age", 0.0)) >= g._grow_time_of(st)
    if v.care.has(best_key) and not ripe:
        var kind: String = str(v.care[best_key])
        return {"type": "care", "key": best_key, "pos": c2, "label": "WATER THE CROP" if kind == "water" else "PULL THE WEEDS"}
    if ripe:
        return {"type": "harvest", "key": best_key, "pos": c2, "label": "HARVEST"}
    if not planted and still_t > 0.35:
        return {"type": "plant", "key": best_key, "pos": c2, "label": "PLANT SEEDS (%d)" % g.seeds}
    return {}

func _near_building() -> Dictionary:
    var pp := Vector2(player.position.x, player.position.z)
    if pp.distance_to(Vector2(g.OVEN_POS.x, g.OVEN_POS.z)) < 3.6:
        return {"type": "bakery", "pos": g.OVEN_POS, "label": "OPEN BAKERY"}
    for mp in [g.BARN_POS, g.MARKET_POS, g.SILO_POS]:
        if pp.distance_to(Vector2(mp.x, mp.z)) < 3.7:
            return {"type": "market", "pos": mp, "label": "OPEN MARKET"}
    if pp.distance_to(Vector2(g.WM_POS.x, g.WM_POS.z)) < 3.8:
        return {"type": "windmill", "pos": g.WM_POS, "label": "WINDMILL"}
    return {}

func _near_tc_target() -> Dictionary:
    if not _tc_active():
        return {}
    var pp := Vector2(player.position.x, player.position.z)
    var t0: Vector3 = _tp()
    if py_cur < 3.2:
        var dw: Vector3 = _door_world()
        if pp.distance_to(Vector2(dw.x, dw.z)) < 2.3:
            return {"type": "door", "pos": dw, "label": "CLOSE DOOR" if g.trade_door_open else "OPEN DOOR"}
        if in_building and pp.distance_to(Vector2(t0.x + 2.1, t0.z + 0.4)) < 2.2:
            return {"type": "trade", "pos": Vector3(t0.x + 2.1, 0.0, t0.z + 0.4), "label": "TRADE ORDERS"}
    elif py_cur >= 3.2:
        for m in [1, 2]:
            var vv: Dictionary = g.trade_veh[m]
            if int(vv["state"]) != 0:
                continue
            var pad: Vector3 = g._trade_pad(m)
            if pp.distance_to(Vector2(pad.x, pad.z)) < 1.7:
                return {"type": "fly", "mode": m, "pos": pad, "label": "GET IN " + ("DRONE" if m == 1 else "HELICOPTER")}
    return {}

func _find_target() -> void:
    target = _near_tc_target()
    if target.is_empty():
        target = _near_producer()
    if target.is_empty():
        target = _near_plot()
        if not target.is_empty() and str(target["type"]) == "plant":
            var b: Dictionary = _near_building()
            if not b.is_empty():
                target = b
    if target.is_empty():
        target = _near_building()
    if py_cur >= 2.5 and not target.is_empty() and str(target["type"]) != "fly":
        target = {}
    if target.is_empty():
        act_btn.visible = false
        return
    act_btn.visible = not g._any_panel_open()
    if str(target["type"]) == "prod":
        var kind: int = int(target["p"]["kind"])
        act_btn.text = "COLLECT " + str(g.PROD_NAMES[kind]).to_upper()
    else:
        act_btn.text = str(target["label"])

func _act() -> void:
    if flying != 0:
        f_autopilot = true
        f_phase = 0
        return
    if not on or target.is_empty() or g._any_panel_open():
        return
    var pos: Vector3 = target["pos"]
    var d := Vector2(pos.x - player.position.x, pos.z - player.position.z)
    if d.length() > 0.3:
        heading = atan2(-d.y, d.x)
    hop_t = 0.4
    var ty: String = str(target["type"])
    if ty == "prod":
        g._collect_producer(target["p"])
    elif ty == "plant" or ty == "harvest" or ty == "care":
        var old: String = g.active_action
        g.active_action = "harvest" if ty == "harvest" else "plant"
        g._flash_cell(str(target["key"]))
        g._apply_plot_action(str(target["key"]))
        g.active_action = old
    elif ty == "bakery":
        g._open_bakery()
    elif ty == "market":
        g._open_market()
    elif ty == "door":
        g.trade_door_open = not g.trade_door_open
        g._play_named("ding", -14.0)
    elif ty == "trade":
        g._open_trade()
    elif ty == "fly":
        _start_flight(int(target["mode"]))
    elif ty == "windmill":
        g._tap_buildings(Vector3(g.WM_POS.x - 1.3, 0.0, g.WM_POS.z - 1.95))
    target = {}


# ----------------------------------------------------------------- flying the drone / helicopter

func _start_flight(mode: int) -> void:
    var vv: Dictionary = g.trade_veh[mode]
    if int(vv["state"]) != 0:
        return
    fveh = vv
    vv["state"] = 5            # busy: the trade orders cannot use it while you fly
    flying = mode
    fnode = vv["node"]
    fyaw = heading
    fspeed = 0.0
    fvy = 0.0
    falt = fnode.position.y
    f_autopilot = false
    f_phase = 0
    up_held = false
    down_held = false
    player.visible = false
    exit_btn.visible = false
    view_btn.visible = false
    up_btn.visible = true
    down_btn.visible = true
    act_btn.text = "RETURN TO PAD"
    act_btn.visible = true
    cam_h = fyaw
    top_view = false
    view_btn.visible = true
    _set_pilot(false)
    cam.make_current()
    g._show_toast("You are flying! Stick: steer and go. UP / DOWN: height.")

func _end_flight() -> void:
    var m: int = flying
    g._trade_park(fveh)
    fveh["state"] = 0
    var pad: Vector3 = g._trade_pad(m)
    flying = 0
    f_autopilot = false
    up_held = false
    down_held = false
    up_btn.visible = false
    down_btn.visible = false
    player.visible = true
    player.position = Vector3(pad.x, g.ROOF_Y, pad.z + 1.5)
    py_cur = g.ROOF_Y
    heading = deg_to_rad(90.0)
    cam_h = heading
    _set_pilot(false)
    exit_btn.visible = true
    view_btn.visible = true
    view_btn.text = "TOP VIEW"
    act_btn.visible = false
    cam.make_current()
    g._show_toast("Landed. Welcome back on the roof.")

func _set_pilot(on: bool) -> void:
    pilot_view = on
    cam.fov = 78.0 if on else 62.0
    if fnode != null:
        fnode.visible = not on
    view_btn.text = "CHASE VIEW" if on else "PILOT VIEW"
    if pilot_hud == null:
        pilot_hud = Control.new()
        pilot_hud.set_anchors_preset(Control.PRESET_FULL_RECT)
        pilot_hud.mouse_filter = Control.MOUSE_FILTER_IGNORE
        hud.add_child(pilot_hud)
        hud.move_child(pilot_hud, 0)
        var cross := Label.new()
        cross.text = "+"
        cross.add_theme_font_size_override("font_size", 44)
        cross.add_theme_color_override("font_color", Color(1, 1, 1, 0.8))
        cross.set_anchors_preset(Control.PRESET_CENTER)
        cross.offset_left = -14.0
        cross.offset_top = -30.0
        cross.mouse_filter = Control.MOUSE_FILTER_IGNORE
        pilot_hud.add_child(cross)
        pilot_lbl = Label.new()
        pilot_lbl.add_theme_font_size_override("font_size", 26)
        pilot_lbl.add_theme_color_override("font_color", Color(0.6, 1.0, 0.7))
        pilot_lbl.add_theme_color_override("font_outline_color", Color(0, 0.1, 0.05))
        pilot_lbl.add_theme_constant_override("outline_size", 6)
        pilot_lbl.anchor_left = 0.5
        pilot_lbl.anchor_right = 0.5
        pilot_lbl.anchor_top = 1.0
        pilot_lbl.anchor_bottom = 1.0
        pilot_lbl.offset_left = -150.0
        pilot_lbl.offset_right = 150.0
        pilot_lbl.offset_top = -64.0
        pilot_lbl.offset_bottom = -16.0
        pilot_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
        pilot_lbl.mouse_filter = Control.MOUSE_FILTER_IGNORE
        pilot_hud.add_child(pilot_lbl)
    pilot_hud.visible = on

func _fly_tick(delta: float) -> void:
    if g.crop_bar != null:
        g.crop_bar.visible = false
    var is_h: bool = flying == 2
    var maxs: float = 9.0 if is_h else 7.0
    var jv: Vector2 = (joy as SailScript.Joy).vec
    var steer: float = jv.x if absf(jv.x) > 0.12 else 0.0
    var thr: float = -jv.y if absf(jv.y) > 0.12 else 0.0
    var pad: Vector3 = g._trade_pad(flying)
    var pos: Vector3 = fnode.position
    if f_autopilot:
        act_btn.text = "LANDING..."
        steer = 0.0
        var to := Vector2(pad.x - pos.x, pad.z - pos.z)
        var dist: float = to.length()
        if f_phase == 0:
            # climb above the roof, then fly over the pad
            var safe: float = g.ROOF_Y + 2.0
            falt = move_toward(falt, maxf(falt, safe), 3.0 * delta)
            if dist > 0.35:
                if falt >= safe - 0.2:
                    var want: float = atan2(-to.y, to.x)
                    fyaw = fyaw + clampf(wrapf(want - fyaw, -PI, PI), -2.5 * delta, 2.5 * delta)
                    fspeed = move_toward(fspeed, clampf(dist * 1.2, 0.8, 6.0), 6.0 * delta)
                else:
                    fspeed = move_toward(fspeed, 0.0, 8.0 * delta)
            else:
                fspeed = move_toward(fspeed, 0.0, 8.0 * delta)
                if fspeed < 0.2:
                    f_phase = 1
        else:
            fspeed = move_toward(fspeed, 0.0, 8.0 * delta)
            fyaw = fyaw + clampf(wrapf(0.0 - fyaw, -PI, PI), -2.0 * delta, 2.0 * delta)
            falt = move_toward(falt, pad.y, 1.8 * delta)
            if falt <= pad.y + 0.02:
                _end_flight()
                return
    else:
        act_btn.text = "RETURN TO PAD"
        fyaw -= steer * deg_to_rad(95.0 if is_h else 130.0) * delta
        var tspeed: float = thr * maxs if thr > 0.0 else thr * maxs * 0.3
        fspeed = move_toward(fspeed, tspeed, 6.0 * delta)
        var vt: float = (3.5 if up_held else 0.0) - (3.5 if down_held else 0.0)
        fvy = move_toward(fvy, vt, 9.0 * delta)
        falt += fvy * delta
    var dir := Vector3(cos(fyaw), 0.0, -sin(fyaw))
    var np: Vector3 = pos + dir * fspeed * delta
    np.x = clampf(np.x, -75.0, 75.0)
    np.z = clampf(np.z, -75.0, 75.0)
    # the Trade Centre is solid below roof height (you can still land on its roof)
    var roof_top: float = g.ROOF_Y + 0.08
    if not f_autopilot and _in_tc_box(Vector3(np.x, 0.0, np.z), 0.3) and not _in_tc_box(Vector3(pos.x, 0.0, pos.z), 0.3) and falt < roof_top + 0.7:
        np.x = pos.x
        np.z = pos.z
        fspeed *= 0.5
    var min_y: float = 0.45
    if _in_tc_box(Vector3(np.x, 0.0, np.z), 0.0):
        min_y = roof_top
    falt = clampf(falt, min_y, 18.0)
    fnode.position = Vector3(np.x, falt, np.z)
    fnode.rotation.y = fyaw
    var tilt: float = -clampf(fspeed / maxs, -0.4, 1.0) * (0.28 if is_h else 0.35)
    fnode.rotation.z = lerpf(fnode.rotation.z, tilt, clampf(5.0 * delta, 0.0, 1.0))
    steer_vis = lerpf(steer_vis, steer, clampf(5.0 * delta, 0.0, 1.0))
    fnode.rotation.x = lerpf(fnode.rotation.x, -steer_vis * 0.3, clampf(5.0 * delta, 0.0, 1.0))
    fveh["rot"] = 1.0
    if pilot_view:
        var pd := Vector3(cos(fyaw), 0.0, -sin(fyaw))
        var eye: Vector3 = fnode.position + pd * (0.55 if is_h else 0.3) + Vector3(0.0, 0.5 if is_h else 0.2, 0.0)
        cam.global_position = eye
        var pitch: float = clampf(fspeed / maxs, -0.4, 1.0) * 0.22 + fvy * 0.02
        cam.look_at(eye + pd * 10.0 + Vector3(0.0, -pitch * 10.0, 0.0), Vector3.UP)
        cam.rotate_object_local(Vector3(0, 0, 1), -fnode.rotation.x * 0.8)
        cam_h = fyaw
        pilot_lbl.text = "ALT %d m   SPEED %d" % [int(falt * 3.0), int(absf(fspeed) * 8.0)]
        return
    cam_h = lerp_angle(cam_h, fyaw, clampf(1.0 - exp(-3.0 * delta), 0.0, 1.0))
    var cdir := Vector3(cos(cam_h), 0.0, -sin(cam_h))
    var cd: float = 5.6 if is_h else 3.8
    var cp: Vector3 = fnode.position - cdir * cd + Vector3(0.0, 1.9 + cd * 0.12, 0.0)
    cp.y = maxf(cp.y, 0.6)
    cam.global_position = cam.global_position.lerp(cp, clampf(1.0 - exp(-9.0 * delta), 0.0, 1.0))
    cam.look_at(fnode.position + Vector3(0.0, 0.25, 0.0) + cdir * 2.0, Vector3.UP)

# ----------------------------------------------------------------- per frame


# ----------------------------------------------------------------- Trade Centre building

func _tp() -> Vector3:
    return g.TRADE_POS

func _rect(x0: float, z0: float, x1: float, z1: float) -> Rect2:
    var t0: Vector3 = _tp()
    return Rect2(t0.x + x0, t0.z + z0, x1 - x0, z1 - z0)

func _tc_active() -> bool:
    return g.trade_unlocked and g.trade_root != null and g.trade_root.visible

func _tc_rects(py: float) -> Array:
    var out: Array = []
    if not _tc_active():
        return out
    var hw: float = g.TC_HW
    var hd: float = g.TC_HD
    var w: float = g.TC_WALL
    var dh: float = g.TC_DOOR_HW
    if py < 3.2:
        out.append(_rect(-hw, -hd, hw, -hd + w))                 # back wall
        out.append(_rect(-hw, -hd, -hw + w, hd))                  # left wall
        out.append(_rect(hw - w, -hd, hw, hd))                    # right wall
        out.append(_rect(-hw, hd - w, -dh, hd))                   # front left
        out.append(_rect(dh, hd - w, hw, hd))                     # front right
        if g.trade_door_amt < 0.85:
            out.append(_rect(-dh, hd - w, dh, hd))                # the door
        out.append(_rect(1.0, 0.05, 3.2, 0.75))                   # counter
        out.append(_rect(-3.2, -0.3, -2.6, 2.1))                  # conveyor
        out.append(_rect(1.7, -2.2, 3.2, -1.3))                   # crates
    if py < 2.2:
        out.append(_rect(-2.5, g.TC_STAIR_Z1 - 0.02, g.TC_HOLE_X0, g.TC_STAIR_Z1 + 0.1))   # stair side rail (low part)
    out.append(_rect(g.TC_HOLE_X0, g.TC_STAIR_Z1 - 0.02, g.TC_STAIR_X1, g.TC_STAIR_Z1 + 0.1))   # stairwell rail
    if py >= 3.2:
        out.append(_rect(-hw, hd - 0.15, hw, hd))
        out.append(_rect(-hw, -hd, hw, -hd + 0.15))
        out.append(_rect(-hw, -hd, -hw + 0.15, hd))
        out.append(_rect(hw - 0.15, -hd, hw, hd))
    return out

func _push_rect(p: Vector3, r: Rect2, rad: float) -> Vector3:
    var cx: float = clampf(p.x, r.position.x, r.position.x + r.size.x)
    var cz: float = clampf(p.z, r.position.y, r.position.y + r.size.y)
    var dx: float = p.x - cx
    var dz: float = p.z - cz
    var d2: float = dx * dx + dz * dz
    if d2 >= rad * rad:
        return p
    if d2 > 0.000001:
        var d: float = sqrt(d2)
        p.x = cx + dx / d * rad
        p.z = cz + dz / d * rad
        return p
    # centre is inside the rect: leave through the nearest side
    var l: float = p.x - r.position.x
    var rr: float = r.position.x + r.size.x - p.x
    var u: float = p.z - r.position.y
    var dn: float = r.position.y + r.size.y - p.z
    var m: float = minf(minf(l, rr), minf(u, dn))
    if m == l:
        p.x = r.position.x - rad
    elif m == rr:
        p.x = r.position.x + r.size.x + rad
    elif m == u:
        p.z = r.position.y - rad
    else:
        p.z = r.position.y + r.size.y + rad
    return p

func _surface_y(x: float, z: float, cur_y: float) -> float:
    var best: float = GROUND_Y
    if not _tc_active():
        return best
    var t0: Vector3 = _tp()
    var lx: float = x - t0.x
    var lz: float = z - t0.z
    var cands: Array = [GROUND_Y]
    if lx >= g.TC_STAIR_X0 and lx <= g.TC_STAIR_X1 and lz >= g.TC_STAIR_Z0 and lz <= g.TC_STAIR_Z1:
        var tread: float = (g.TC_STAIR_X1 - g.TC_STAIR_X0) / float(g.TC_STEPS)
        var i: int = clampi(int((lx - g.TC_STAIR_X0) / tread), 0, g.TC_STEPS - 1)
        cands.append(g.TC_FLOOR + g.TC_STEP_H * float(i + 1))
    if absf(lx) <= g.TC_HW and absf(lz) <= g.TC_HD:
        var in_hole: bool = lx >= g.TC_HOLE_X0 and lx <= g.TC_STAIR_X1 and lz >= g.TC_STAIR_Z0 and lz <= g.TC_STAIR_Z1
        if not in_hole:
            cands.append(g.ROOF_Y)
    for c in cands:
        var cy: float = c
        if cy <= cur_y + 0.5 and cy > best:
            best = cy
    return best

func _inside_tc(p: Vector3) -> bool:
    if not _tc_active():
        return false
    var t0: Vector3 = _tp()
    return absf(p.x - t0.x) < g.TC_HW - 0.3 and absf(p.z - t0.z) < g.TC_HD - 0.3 and p.y < 3.2

func _door_world() -> Vector3:
    var t0: Vector3 = _tp()
    return Vector3(t0.x, 0.0, t0.z + g.TC_HD - 0.1)

func _in_tc_box(q: Vector3, m: float) -> bool:
    var t0: Vector3 = _tp()
    return absf(q.x - t0.x) < g.TC_HW + m and absf(q.z - t0.z) < g.TC_HD + m and q.y < 3.6

func _update_cam(k: float) -> void:
    var dir := Vector3(cos(cam_h), 0.0, -sin(cam_h))
    var p: Vector3 = player.position
    var want_d: float = 4.4
    var d: float = 4.4
    while d > 1.7:
        var q: Vector3 = p - dir * d
        var clear: bool = true
        for o in obstacles:
            var ov: Vector3 = o
            if Vector2(q.x - ov.x, q.z - ov.y).length() < ov.z + 1.3:
                clear = false
                break
        if clear and not in_building and p.y < 2.5 and _tc_active() and _in_tc_box(q, 0.5):
            clear = false
        if clear:
            break
        d -= 0.35
    if in_building:
        d = 2.3
    want_d = d
    cam_dist = lerpf(cam_dist, want_d, 0.25 if want_d < cam_dist else 0.05)
    var cp: Vector3 = p - dir * cam_dist + Vector3(0.0, 2.1 + cam_dist * 0.14, 0.0)
    if in_building:
        var t0: Vector3 = _tp()
        cp.x = clampf(cp.x, t0.x - g.TC_HW + 0.45, t0.x + g.TC_HW - 0.45)
        cp.z = clampf(cp.z, t0.z - g.TC_HD + 0.45, t0.z + g.TC_HD - 0.45)
        cp.y = minf(cp.y, 2.85)
    cam.global_position = cam.global_position.lerp(cp, k) if k < 1.0 else cp
    cam.look_at(p + Vector3(0.0, 1.0, 0.0) + dir * 2.2, Vector3.UP)

func tick(delta_raw: float) -> void:
    var delta: float = minf(delta_raw, 0.05)     # slow frames never let you jump through a wall
    t += delta
    if hud == null:
        if g != null and g.ui_root != null:
            _ensure_hud()
        else:
            return
    if not on:
        enter_btn.visible = can_enter()
        return
    if flying != 0:
        _fly_tick(delta)
        return
    if g.crop_bar != null:
        g.crop_bar.visible = false
    var jv: Vector2 = (joy as SailScript.Joy).vec
    var busy: bool = g._any_panel_open()
    var steer: float = jv.x if (absf(jv.x) > 0.12 and not busy) else 0.0
    var thr: float = -jv.y if not busy else 0.0
    if absf(thr) < 0.12:
        thr = 0.0
    var tspeed: float = thr * WALK_SPEED if thr > 0.0 else thr * WALK_SPEED * 0.5
    speed = move_toward(speed, tspeed, 14.0 * delta)
    var turn: float = deg_to_rad(110.0)
    if steer != 0.0:
        heading -= steer * turn * delta
    steer_vis = lerpf(steer_vis, steer, clampf(8.0 * delta, 0.0, 1.0))
    var dir := Vector3(cos(heading), 0.0, -sin(heading))
    var p: Vector3 = player.position + dir * speed * delta
    var all_obs: Array = obstacles.duplicate()
    for vn in ["Tractor", "Ambulance", "Pickup"]:
        var vnode: Node3D = g.get_node_or_null(vn)
        if vnode != null and vnode.visible:
            all_obs.append(Vector3(vnode.global_position.x, vnode.global_position.z, 1.5))
    for o in all_obs:
        var ov: Vector3 = o
        var dd := Vector2(p.x - ov.x, p.z - ov.y)
        if dd.length() < ov.z:
            var n: Vector2 = dd.normalized() if dd.length() > 0.001 else Vector2(1, 0)
            p.x = ov.x + n.x * ov.z
            p.z = ov.y + n.y * ov.z
    for rc in _tc_rects(py_cur):
        p = _push_rect(p, rc, 0.28)
    p.x = clampf(p.x, -LIMIT, LIMIT)
    p.z = clampf(p.z, -18.45, LIMIT)
    var moved: float = Vector2(p.x - player.position.x, p.z - player.position.z).length()
    phase += moved * 3.2
    player.position.x = p.x
    player.position.z = p.z
    if hop_t > 0.0:
        hop_t -= delta
    var ty: float = _surface_y(p.x, p.z, py_cur)
    py_cur = lerpf(py_cur, ty, clampf(1.0 - exp(-18.0 * delta), 0.0, 1.0))
    player.position.y = py_cur
    in_building = _inside_tc(player.position)
    player.rotation.y = heading
    _animate(moved > 0.002, clampf(absf(speed) / WALK_SPEED, 0.0, 1.0), delta)
    still_t = still_t + delta if moved < 0.002 else 0.0
    var night: float = clampf(float(g.lamp_mat.emission_energy_multiplier) / 2.2, 0.0, 1.0) if g.lamp_mat != null else 0.0
    glow.light_energy = night * 1.6
    cam_h = lerp_angle(cam_h, heading, clampf(1.0 - exp(-3.2 * delta), 0.0, 1.0))
    if top_view:
        g.cam_target = g.cam_target.lerp(player.position, clampf(1.0 - exp(-6.0 * delta), 0.0, 1.0))
        g._update_camera()
    else:
        _update_cam(clampf(1.0 - exp(-12.0 * delta), 0.0, 1.0))
    _find_target()
