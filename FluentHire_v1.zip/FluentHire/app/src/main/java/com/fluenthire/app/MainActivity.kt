package com.fluenthire.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.enableEdgeToEdge
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalView
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import com.fluenthire.app.data.JobRole
import com.fluenthire.app.data.Prefs
import com.fluenthire.app.speech.Speaker
import com.fluenthire.app.speech.SpeechInput
import com.fluenthire.app.ui.HomeScreen
import com.fluenthire.app.ui.InterviewScreen
import com.fluenthire.app.ui.InterviewSetupScreen
import com.fluenthire.app.ui.PracticeScreen
import com.fluenthire.app.ui.ProgressScreen
import com.fluenthire.app.ui.SettingsScreen
import com.fluenthire.app.ui.theme.FluentHireTheme

sealed class Screen {
    data object Home : Screen()
    data object InterviewSetup : Screen()
    data class Interview(val role: JobRole, val level: String, val count: Int) : Screen()
    data object Practice : Screen()
    data object Progress : Screen()
    data object Settings : Screen()
}

/** Things every screen needs. */
class AppDeps(
    val prefs: Prefs,
    val speaker: Speaker,
    val speech: SpeechInput,
    val requestMic: (onGranted: () -> Unit) -> Unit,
)

class MainActivity : ComponentActivity() {

    private lateinit var prefs: Prefs
    private lateinit var speaker: Speaker
    private lateinit var speech: SpeechInput

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        speaker = Speaker(this, prefs.speechRate)
        speech = SpeechInput(this)

        setContent {
            FluentHireTheme {
                var pendingGrant by remember { mutableStateOf<(() -> Unit)?>(null) }
                val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
                    if (granted) pendingGrant?.invoke()
                    else Toast.makeText(this, "Microphone permission is needed to practise speaking.", Toast.LENGTH_LONG).show()
                    pendingGrant = null
                }
                val deps = remember {
                    AppDeps(prefs, speaker, speech) { onGranted ->
                        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                            onGranted()
                        } else {
                            pendingGrant = onGranted
                            launcher.launch(Manifest.permission.RECORD_AUDIO)
                        }
                    }
                }
                AppRoot(deps)
            }
        }
    }

    override fun onStop() {
        super.onStop()
        if (::speech.isInitialized) speech.cancel()
        if (::speaker.isInitialized) speaker.stop()
    }

    override fun onDestroy() {
        super.onDestroy()
        if (::speech.isInitialized) speech.destroy()
        if (::speaker.isInitialized) speaker.shutdown()
    }
}

@Composable
private fun AppRoot(deps: AppDeps) {
    var screen by remember { mutableStateOf<Screen>(Screen.Home) }
    var refresh by remember { mutableIntStateOf(0) }   // bump to re-read stats on Home

    fun goHome() {
        deps.speech.cancel(); deps.speaker.stop()
        refresh++
        screen = Screen.Home
    }

    if (screen != Screen.Home) BackHandler { goHome() }

    // White status-bar icons on the dark Home header, dark icons on the light screens.
    val view = LocalView.current
    val lightBars = screen != Screen.Home
    SideEffect {
        val window = (view.context as? android.app.Activity)?.window ?: return@SideEffect
        WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = lightBars
        WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = true
    }

    when (val s = screen) {
        Screen.Home -> HomeScreen(
            deps = deps,
            refreshKey = refresh,
            onInterview = { screen = Screen.InterviewSetup },
            onPractice = { screen = Screen.Practice },
            onProgress = { screen = Screen.Progress },
            onSettings = { screen = Screen.Settings },
        )
        Screen.InterviewSetup -> InterviewSetupScreen(
            deps = deps,
            onBack = { goHome() },
            onOpenSettings = { screen = Screen.Settings },
            onStart = { role, level, count -> screen = Screen.Interview(role, level, count) },
        )
        is Screen.Interview -> InterviewScreen(
            deps = deps, role = s.role, level = s.level, total = s.count,
            onExit = { goHome() },
            onOpenSettings = { screen = Screen.Settings },
        )
        Screen.Practice -> PracticeScreen(deps = deps, onExit = { goHome() })
        Screen.Progress -> ProgressScreen(deps = deps, onBack = { goHome() })
        Screen.Settings -> SettingsScreen(deps = deps, onBack = { goHome() })
    }
}
