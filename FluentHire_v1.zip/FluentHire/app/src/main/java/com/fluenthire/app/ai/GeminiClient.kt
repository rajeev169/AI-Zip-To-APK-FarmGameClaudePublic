package com.fluenthire.app.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class AiException(message: String) : Exception(message)

/** Minimal Google Gemini REST client (no extra libraries). Returns the model's reply parsed as JSON. */
class GeminiClient(private val apiKey: String, private val model: String) {

    suspend fun generateJson(system: String, prompt: String, temperature: Double = 0.6): JSONObject =
        withContext(Dispatchers.IO) {
            if (apiKey.isBlank()) throw AiException("Add your free Gemini API key in Settings to use AI features.")
            val url = URL(
                "https://generativelanguage.googleapis.com/v1beta/models/" +
                    URLEncoder.encode(model, "UTF-8") + ":generateContent"
            )
            val body = JSONObject().apply {
                put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
                put("contents", JSONArray().put(
                    JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", prompt)))
                ))
                put("generationConfig", JSONObject().apply {
                    put("temperature", temperature)
                    put("responseMimeType", "application/json")
                })
            }

            var lastError: Exception? = null
            repeat(2) { attempt ->
                val conn = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 20_000
                    readTimeout = 60_000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                    setRequestProperty("x-goog-api-key", apiKey)
                }
                try {
                    conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                    val code = conn.responseCode
                    val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                    val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
                    if (code !in 200..299) {
                        val msg = try {
                            JSONObject(text).optJSONObject("error")?.optString("message")
                        } catch (e: Exception) { null }
                        val friendly = when (code) {
                            400, 403 -> "API key problem: ${msg ?: "check your key in Settings"}"
                            404 -> "Model \"$model\" not found. Change the model name in Settings."
                            429 -> "Too many requests. Please wait a minute and try again."
                            else -> "AI error ($code): ${msg ?: "please try again"}"
                        }
                        if (code == 429 || code >= 500) { lastError = AiException(friendly); Thread.sleep(1500L * (attempt + 1)); return@repeat }
                        throw AiException(friendly)
                    }
                    val reply = JSONObject(text)
                        .optJSONArray("candidates")?.optJSONObject(0)
                        ?.optJSONObject("content")?.optJSONArray("parts")
                    val sb = StringBuilder()
                    if (reply != null) for (i in 0 until reply.length()) sb.append(reply.optJSONObject(i)?.optString("text") ?: "")
                    if (sb.isBlank()) throw AiException("The AI gave an empty reply. Please try again.")
                    return@withContext parseLooseJson(sb.toString())
                } catch (e: AiException) {
                    throw e
                } catch (e: java.io.IOException) {
                    lastError = AiException("No internet connection or the server did not respond.")
                } finally {
                    conn.disconnect()
                }
            }
            throw lastError ?: AiException("Something went wrong. Please try again.")
        }

    private fun parseLooseJson(raw: String): JSONObject {
        var t = raw.trim()
        if (t.startsWith("```")) t = t.substringAfter('\n').substringBeforeLast("```").trim()
        val start = t.indexOf('{')
        val end = t.lastIndexOf('}')
        if (start < 0 || end <= start) throw AiException("Could not read the AI reply. Please try again.")
        return try { JSONObject(t.substring(start, end + 1)) } catch (e: Exception) {
            throw AiException("Could not read the AI reply. Please try again.")
        }
    }
}
