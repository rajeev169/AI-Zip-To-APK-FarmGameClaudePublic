package com.fluenthire.app.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.TimeZone

data class SessionRecord(
    val type: String,          // "Interview" or "Practice Test"
    val title: String,         // e.g. "BPO / Customer Support"
    val score: Int,            // 0..100
    val timestamp: Long,
    val summary: String,
    val subScores: Map<String, Int> = emptyMap(),
)

class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("fluenthire", Context.MODE_PRIVATE)

    var apiKey: String
        get() = sp.getString("api_key", "") ?: ""
        set(v) = sp.edit().putString("api_key", v.trim()).apply()

    var model: String
        get() = sp.getString("model", DEFAULT_MODEL) ?: DEFAULT_MODEL
        set(v) = sp.edit().putString("model", v.trim().ifEmpty { DEFAULT_MODEL }).apply()

    var hindiTips: Boolean
        get() = sp.getBoolean("hindi_tips", true)
        set(v) = sp.edit().putBoolean("hindi_tips", v).apply()

    var speechRate: Float
        get() = sp.getFloat("speech_rate", 0.95f)
        set(v) = sp.edit().putFloat("speech_rate", v).apply()

    var userName: String
        get() = sp.getString("user_name", "") ?: ""
        set(v) = sp.edit().putString("user_name", v.trim()).apply()

    val hasApiKey: Boolean get() = apiKey.isNotBlank()

    fun history(): List<SessionRecord> {
        val raw = sp.getString("history", "[]") ?: "[]"
        val arr = try { JSONArray(raw) } catch (e: Exception) { JSONArray() }
        val list = mutableListOf<SessionRecord>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val subs = mutableMapOf<String, Int>()
            o.optJSONObject("subs")?.let { s -> s.keys().forEach { k -> subs[k] = s.optInt(k) } }
            list += SessionRecord(
                type = o.optString("type"),
                title = o.optString("title"),
                score = o.optInt("score"),
                timestamp = o.optLong("ts"),
                summary = o.optString("summary"),
                subScores = subs,
            )
        }
        return list.sortedByDescending { it.timestamp }
    }

    fun addRecord(r: SessionRecord) {
        val arr = try { JSONArray(sp.getString("history", "[]")) } catch (e: Exception) { JSONArray() }
        val subs = JSONObject()
        r.subScores.forEach { (k, v) -> subs.put(k, v) }
        arr.put(JSONObject().apply {
            put("type", r.type); put("title", r.title); put("score", r.score)
            put("ts", r.timestamp); put("summary", r.summary); put("subs", subs)
        })
        // keep the last 200 sessions
        val trimmed = JSONArray()
        val start = maxOf(0, arr.length() - 200)
        for (i in start until arr.length()) trimmed.put(arr.get(i))
        sp.edit().putString("history", trimmed.toString()).apply()
        markPracticedToday()
    }

    fun clearHistory() {
        sp.edit().putString("history", "[]").putString("days", "").apply()
    }

    private fun practiceDays(): Set<Long> =
        (sp.getString("days", "") ?: "").split(",").mapNotNull { it.toLongOrNull() }.toSet()

    private fun markPracticedToday() {
        val days = practiceDays().toMutableSet()
        days += todayEpochDay()
        val recent = days.sortedDescending().take(400)
        sp.edit().putString("days", recent.joinToString(",")).apply()
    }

    /** Consecutive days practised, counting today (or yesterday if not practised yet today). */
    fun streak(): Int {
        val days = practiceDays()
        if (days.isEmpty()) return 0
        var d = todayEpochDay()
        if (d !in days) d -= 1
        var count = 0
        while (d in days) { count++; d-- }
        return count
    }

    private fun todayEpochDay(): Long {
        val now = System.currentTimeMillis()
        return (now + TimeZone.getDefault().getOffset(now)) / 86_400_000L
    }

    companion object {
        const val DEFAULT_MODEL = "gemini-2.5-flash"
    }
}
