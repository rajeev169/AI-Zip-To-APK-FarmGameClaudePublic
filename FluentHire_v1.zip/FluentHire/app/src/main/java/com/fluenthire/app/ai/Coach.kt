package com.fluenthire.app.ai

import com.fluenthire.app.data.JobRole
import org.json.JSONArray
import org.json.JSONObject

data class Correction(val wrong: String, val right: String)

data class AnswerFeedback(
    val question: String,
    val answer: String,
    val fluency: Int,
    val grammar: Int,
    val vocabulary: Int,
    val relevance: Int,
    val overall: Int,
    val feedback: String,
    val corrections: List<Correction>,
    val betterAnswer: String,
    val hindiTip: String,
    val fillers: Int,
)

data class InterviewTurnResult(val feedback: AnswerFeedback, val nextQuestion: String?)

data class FinalReport(
    val summary: String,
    val strengths: List<String>,
    val improvements: List<String>,
    val readiness: String,
)

data class OpenScore(val score: Int, val feedback: String, val hindiTip: String)

/** All AI prompts live here. */
class Coach(private val client: GeminiClient, private val hindi: Boolean) {

    private val hindiRule get() =
        if (hindi) "Also give \"hindiTip\": one short, simple tip in Hindi (Devanagari script) explaining the main mistake or how to improve."
        else "Set \"hindiTip\" to an empty string."

    private fun interviewerSystem(role: JobRole, level: String) = """
        You are a friendly but professional HR interviewer in India conducting a spoken English job interview
        for the role "${role.name}" (${role.blurb}). Candidate experience: $level.
        The candidate is practising to improve spoken English and interview skills. Their answers come from
        speech-to-text, so ignore missing punctuation and small transcription errors in spelling.
        Ask one clear question at a time, in simple international English, under 30 words.
        Always reply ONLY with valid JSON.
    """.trimIndent()

    suspend fun firstQuestion(role: JobRole, level: String): String {
        val prompt = """
            Start the interview. Greet the candidate in one short sentence and ask the first question
            (usually a variation of "Tell me about yourself").
            Example questions for this role: ${role.sampleQuestions.joinToString(" | ")}
            Reply as JSON: {"question": "..."}
        """.trimIndent()
        val o = client.generateJson(interviewerSystem(role, level), prompt, 0.8)
        return o.optString("question").ifBlank { role.sampleQuestions.first() }
    }

    suspend fun evaluate(
        role: JobRole, level: String,
        history: List<Pair<String, String>>,
        question: String, answer: String,
        questionNumber: Int, total: Int,
        fillers: Int,
    ): InterviewTurnResult {
        val isLast = questionNumber >= total
        val past = history.joinToString("\n") { (q, a) -> "Q: $q\nA: $a" }.ifBlank { "(none)" }
        val prompt = """
            Earlier in this interview:
            $past

            Current question ($questionNumber of $total): $question
            Candidate's spoken answer: "$answer"

            Evaluate ONLY the current answer. Score each 0-100:
            - fluency (flow, sentence length, natural speech; the answer contains $fillers filler words)
            - grammar
            - vocabulary (range and professional words)
            - relevance (does it answer the question well, with examples, for this job)
            Give "overall" 0-100.
            "feedback": 2-3 short, encouraging, specific sentences.
            "corrections": up to 4 items {"wrong": exact phrase they said, "right": corrected phrase}. Empty list if none.
            "betterAnswer": a model answer the candidate could say, in their own situation, 60-90 words, simple and natural.
            $hindiRule
            ${if (isLast) "This was the last question. Set \"nextQuestion\" to an empty string."
              else "\"nextQuestion\": the next interview question. Sometimes ask a natural follow-up based on their answer; otherwise move to a new topic relevant to this role. Do not repeat earlier questions."}

            Reply as JSON: {"fluency":0,"grammar":0,"vocabulary":0,"relevance":0,"overall":0,"feedback":"","corrections":[],"betterAnswer":"","hindiTip":"","nextQuestion":""}
        """.trimIndent()
        val o = client.generateJson(interviewerSystem(role, level), prompt, 0.5)
        val next = o.optString("nextQuestion").trim().takeIf { !isLast && it.isNotBlank() }
        return InterviewTurnResult(parseFeedback(o, question, answer, fillers), next)
    }

    suspend fun finalReport(role: JobRole, level: String, items: List<AnswerFeedback>): FinalReport {
        val transcript = items.joinToString("\n\n") {
            "Q: ${it.question}\nA: ${it.answer}\nScore: ${it.overall}"
        }
        val prompt = """
            The interview is over. Here is the full transcript with scores:
            $transcript

            Write a short final report for the candidate:
            "summary": 2-3 sentences on overall performance.
            "strengths": 2-3 short points.
            "improvements": 3 short, practical action points for the next week.
            "readiness": one of "Ready for interviews", "Almost ready", "Needs more practice".
            Reply as JSON: {"summary":"","strengths":[],"improvements":[],"readiness":""}
        """.trimIndent()
        val o = client.generateJson(interviewerSystem(role, level), prompt, 0.5)
        return FinalReport(
            summary = o.optString("summary"),
            strengths = o.optJSONArray("strengths").toStringList(),
            improvements = o.optJSONArray("improvements").toStringList(),
            readiness = o.optString("readiness").ifBlank { "Keep practising" },
        )
    }

    /** Scores a story retelling or an open answer in the practice test. */
    suspend fun scoreOpen(taskType: String, taskText: String, answer: String): OpenScore {
        val system = """
            You are an expert spoken English examiner for job seekers in India.
            The response is from speech-to-text, so ignore punctuation and small spelling errors.
            Always reply ONLY with valid JSON.
        """.trimIndent()
        val prompt = """
            Task type: $taskType
            Task: $taskText
            Candidate's spoken response: "$answer"

            Give a score 0-100 for overall spoken English quality on this task
            (content accuracy/completeness, grammar, vocabulary, fluency).
            "feedback": 1-2 short, specific sentences.
            $hindiRule
            Reply as JSON: {"score":0,"feedback":"","hindiTip":""}
        """.trimIndent()
        val o = client.generateJson(system, prompt, 0.3)
        return OpenScore(
            o.optInt("score").coerceIn(0, 100),
            o.optString("feedback"),
            o.optString("hindiTip"),
        )
    }

    private fun parseFeedback(o: JSONObject, q: String, a: String, fillers: Int): AnswerFeedback {
        val corr = mutableListOf<Correction>()
        o.optJSONArray("corrections")?.let { arr ->
            for (i in 0 until arr.length()) {
                val c = arr.optJSONObject(i) ?: continue
                val w = c.optString("wrong"); val r = c.optString("right")
                if (w.isNotBlank() && r.isNotBlank()) corr += Correction(w, r)
            }
        }
        val f = o.optInt("fluency").coerceIn(0, 100)
        val g = o.optInt("grammar").coerceIn(0, 100)
        val v = o.optInt("vocabulary").coerceIn(0, 100)
        val r = o.optInt("relevance").coerceIn(0, 100)
        val overall = o.optInt("overall", (f + g + v + r) / 4).coerceIn(0, 100)
        return AnswerFeedback(
            q, a, f, g, v, r, overall,
            o.optString("feedback"), corr, o.optString("betterAnswer"),
            if (hindi) o.optString("hindiTip") else "", fillers,
        )
    }
}

private fun JSONArray?.toStringList(): List<String> {
    if (this == null) return emptyList()
    return (0 until length()).mapNotNull { optString(it).takeIf { s -> s.isNotBlank() } }
}
