package com.fluenthire.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.fluenthire.app.AppDeps
import com.fluenthire.app.ai.GeminiClient
import com.fluenthire.app.ui.theme.Good
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(deps: AppDeps, onBack: () -> Unit) {
    val prefs = deps.prefs
    val scope = rememberCoroutineScope()
    val uri = LocalUriHandler.current

    var name by remember { mutableStateOf(prefs.userName) }
    var key by remember { mutableStateOf(prefs.apiKey) }
    var model by remember { mutableStateOf(prefs.model) }
    var showKey by remember { mutableStateOf(false) }
    var hindi by remember { mutableStateOf(prefs.hindiTips) }
    var rate by remember { mutableFloatStateOf(prefs.speechRate) }
    var testMsg by remember { mutableStateOf<String?>(null) }
    var testOk by remember { mutableStateOf(false) }
    var testing by remember { mutableStateOf(false) }
    var confirmClear by remember { mutableStateOf(false) }

    fun save() {
        prefs.userName = name
        prefs.apiKey = key
        prefs.model = model
        prefs.hindiTips = hindi
        prefs.speechRate = rate
        deps.speaker.setRate(rate)
    }

    BackHandler { save(); onBack() }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text("Clear all progress?") },
            text = { Text("This deletes your scores, history and streak from this phone.") },
            confirmButton = { TextButton(onClick = { prefs.clearHistory(); confirmClear = false }) { Text("Clear") } },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Cancel") } },
        )
    }

    Scaffold(topBar = { AppTopBar("Settings", onBack = { save(); onBack() }) }) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp).imePadding(),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            InfoCard {
                Text("Your name", fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(6.dp))
                OutlinedTextField(name, { name = it }, Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text("e.g. Rahul") })
            }

            InfoCard {
                Text("AI coaching (Google Gemini)", fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(4.dp))
                Text(
                    "Get a free API key from Google AI Studio and paste it here. It is stored only on this phone.",
                    style = MaterialTheme.typography.bodySmall,
                )
                TextButton(onClick = { uri.openUri("https://aistudio.google.com/apikey") }) { Text("Get a free key →") }
                OutlinedTextField(
                    value = key, onValueChange = { key = it.trim(); testMsg = null },
                    label = { Text("Gemini API key") },
                    singleLine = true,
                    visualTransformation = if (showKey) VisualTransformation.None else PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    trailingIcon = {
                        IconButton(onClick = { showKey = !showKey }) {
                            Icon(if (showKey) Icons.Filled.VisibilityOff else Icons.Filled.Visibility, "Show key")
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = model, onValueChange = { model = it.trim() },
                    label = { Text("Model") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                    supportingText = { Text("Default: gemini-2.5-flash. Change only if Google retires this model.") },
                )
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedButton(
                        enabled = key.isNotBlank() && !testing,
                        onClick = {
                            save(); testing = true; testMsg = null
                            scope.launch {
                                try {
                                    val o = GeminiClient(key, model.ifBlank { "gemini-2.5-flash" })
                                        .generateJson("Reply only with JSON.", "Reply with {\"ok\": true}", 0.0)
                                    testOk = o.optBoolean("ok", true)
                                    testMsg = "Key works! AI coaching is ready."
                                } catch (e: Exception) {
                                    testOk = false
                                    testMsg = e.message ?: "Test failed."
                                }
                                testing = false
                            }
                        },
                    ) { Text(if (testing) "Testing…" else "Test key") }
                    Spacer(Modifier.width(10.dp))
                    testMsg?.let {
                        Text(it, color = if (testOk) Good else MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                    }
                }
            }

            InfoCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Hindi tips", fontWeight = FontWeight.SemiBold)
                        Text("Explain mistakes in simple Hindi too", style = MaterialTheme.typography.bodySmall)
                    }
                    Switch(checked = hindi, onCheckedChange = { hindi = it })
                }
            }

            InfoCard {
                Text("Interviewer voice speed: ${"%.2f".format(rate)}x", fontWeight = FontWeight.SemiBold)
                Slider(value = rate, onValueChange = { rate = it }, valueRange = 0.6f..1.3f)
                TextButton(onClick = {
                    deps.speaker.setRate(rate)
                    deps.speaker.speak("Hello! Tell me about yourself.")
                }) { Text("Play sample") }
            }

            Button(
                onClick = { save(); onBack() },
                modifier = Modifier.fillMaxWidth().height(52.dp),
            ) { Text("Save") }

            OutlinedButton(onClick = { confirmClear = true }, modifier = Modifier.fillMaxWidth()) {
                Text("Clear progress history", color = MaterialTheme.colorScheme.error)
            }

            Text(
                "FluentHire v1.0 • Independent practice app. Not affiliated with Pearson or the Versant test.",
                style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline,
            )
        }
    }
}
