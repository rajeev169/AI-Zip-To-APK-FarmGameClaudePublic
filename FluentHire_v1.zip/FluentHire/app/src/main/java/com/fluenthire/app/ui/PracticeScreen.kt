package com.fluenthire.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fluenthire.app.AppDeps
import com.fluenthire.app.ai.Coach
import com.fluenthire.app.ai.GeminiClient
import com.fluenthire.app.data.QuestionBank
import com.fluenthire.app.data.SessionRecord
import com.fluenthire.app.scoring.LocalScorer
import com.fluenthire.app.ui.theme.scoreColor
import kotlinx.coroutines.launch

enum class Section(val letter: String, val title: String, val instruction: String, val weight: Double) {
    READ("A", "Read Aloud", "Read the sentence on the screen aloud, clearly and naturally.", 0.15),
    REPEAT("B", "Repeat", "Listen to the sentence and repeat it exactly. The text is hidden.", 0.20),
    SHORT("C", "Short Answers", "Listen to the question and answer with one word or a few words.", 0.15),
    BUILD("D", "Sentence Builds", "You will hear three word groups in a mixed order. Say them as one correct sentence.", 0.15),
    RETELL("E", "Story Retelling", "Listen to a short story, then retell it in your own words. Include as many details as you can.", 0.20),
    OPEN("F", "Open Question", "Listen to the question and give your opinion with reasons, for 30 to 60 seconds.", 0.15),
}

data class PracticeTask(
    val section: Section,
    val display: String?,          // text shown on screen
    val audio: String?,            // text spoken by the app
    val target: String,            // expected text (for local scoring)
    val accepted: List<String> = emptyList(),
    val keywords: List<String> = emptyList(),
    val continuous: Boolean = false,
    val maxReplays: Int = 1,
)

data class TaskResult(val task: PracticeTask, val answer: String, val score: Int, val note: String, val hindiTip: String = "")

private fun buildTest(): List<PracticeTask> {
    val b = QuestionBank
    val list = mutableListOf<PracticeTask>()
    b.readAloud.shuffled().take(4).forEach { list += PracticeTask(Section.READ, it, null, it) }
    b.repeat.shuffled().take(4).forEach { list += PracticeTask(Section.REPEAT, null, it, it) }
    b.shortAnswer.shuffled().take(4).forEach {
        list += PracticeTask(Section.SHORT, null, it.question, it.accepted.first(), accepted = it.accepted)
    }
    b.sentenceBuilds.shuffled().take(3).forEach { item ->
        var mixed = item.phrases.shuffled()
        var guard = 0
        while (mixed == item.phrases && guard++ < 5) mixed = item.phrases.shuffled()
        list += PracticeTask(Section.BUILD, null, mixed.joinToString(" ... "), item.correct)
    }
    b.stories.random().let { s ->
        list += PracticeTask(Section.RETELL, null, s.story, s.story, keywords = s.keywords, continuous = true, maxReplays = 1)
    }
    b.openQuestions.random().let { q ->
        list += PracticeTask(Section.OPEN, q, q, q, continuous = true, maxReplays = 1)
    }
    return list
}

private enum class PPhase { Intro, SectionIntro, Task, Scoring, Result, Done }

@Composable
fun PracticeScreen(deps: AppDeps, onExit: () -> Unit) {
    val prefs = deps.prefs
    val speech = deps.speech
    val speaker = deps.speaker
    val scope = rememberCoroutineScope()
    val coach = remember { if (prefs.hasApiKey) Coach(GeminiClient(prefs.apiKey, prefs.model), prefs.hindiTips) else null }

    val tasks = remember { buildTest() }
    var index by remember { mutableIntStateOf(0) }
    var phase by remember { mutableStateOf(PPhase.Intro) }
    var replaysUsed by remember { mutableIntStateOf(0) }
    var audioPlayed by remember { mutableStateOf(false) }
    val results = remember { mutableStateListOf<TaskResult>() }
    var lastResult by remember { mutableStateOf<TaskResult?>(null) }
    var confirmExit by remember { mutableStateOf(false) }
    var saved by remember { mutableStateOf(false) }

    val task = tasks.getOrNull(index)

    DisposableEffect(Unit) { onDispose { speech.cancel(); speaker.stop() } }

    fun playAudio(t: PracticeTask, auto: Boolean) {
        val a = t.audio ?: return
        speech.cancel()
        speaker.speak(a) {
            audioPlayed = true
            // For short tasks start listening automatically after the audio, like the real test.
            if (auto && !t.continuous && phase == PPhase.Task && tasks.getOrNull(index) == t) {
                deps.requestMic { speech.start(continuous = false) }
            }
        }
    }

    fun beginTask() {
        val t = tasks.getOrNull(index) ?: return
        speech.clear()
        replaysUsed = 0
        audioPlayed = t.audio == null
        phase = PPhase.Task
        if (t.audio != null) playAudio(t, auto = true)
    }

    fun goTo(i: Int) {
        index = i
        val t = tasks.getOrNull(i)
        if (t == null) { phase = PPhase.Done; return }
        val prev = tasks.getOrNull(i - 1)
        if (prev == null || prev.section != t.section) phase = PPhase.SectionIntro else beginTask()
    }

    fun check(t: PracticeTask, answer: String) {
        phase = PPhase.Scoring
        scope.launch {
            val r: TaskResult = when (t.section) {
                Section.READ, Section.REPEAT, Section.BUILD -> {
                    val s = LocalScorer.wordAccuracy(t.target, answer)
                    val missed = LocalScorer.missedWords(t.target, answer)
                    val note = when {
                        s >= 90 -> "Excellent! Clear and accurate."
                        missed.isNotEmpty() -> "Correct sentence: \"${t.target}\"\nMissed or unclear: ${missed.take(6).joinToString(", ")}"
                        else -> "Correct sentence: \"${t.target}\""
                    }
                    TaskResult(t, answer, s, note)
                }
                Section.SHORT -> {
                    val ok = LocalScorer.shortAnswerCorrect(answer, t.accepted)
                    TaskResult(t, answer, if (ok) 100 else 0,
                        if (ok) "Correct!" else "Expected answer: ${t.accepted.take(2).joinToString(" or ")}")
                }
                Section.RETELL, Section.OPEN -> {
                    val local = if (t.section == Section.RETELL) LocalScorer.retellScore(t.keywords, answer)
                    else LocalScorer.openAnswerScore(answer)
                    if (coach != null) {
                        try {
                            val ai = coach.scoreOpen(
                                if (t.section == Section.RETELL) "Story retelling" else "Open opinion question",
                                if (t.section == Section.RETELL) "Retell this story: ${t.audio}" else t.audio ?: "",
                                answer,
                            )
                            TaskResult(t, answer, ai.score, ai.feedback, ai.hindiTip)
                        } catch (e: Exception) {
                            TaskResult(t, answer, local, "Scored offline (${e.message}).")
                        }
                    } else {
                        TaskResult(
                            t, answer, local,
                            "Scored offline. Add a Gemini key in Settings for detailed AI feedback." +
                                if (t.section == Section.RETELL) "\nStory: ${t.audio}" else "",
                        )
                    }
                }
            }
            results += r
            lastResult = r
            phase = PPhase.Result
        }
    }

    BackHandler { if (phase == PPhase.Intro || phase == PPhase.Done) onExit() else confirmExit = true }

    if (confirmExit) {
        AlertDialog(
            onDismissRequest = { confirmExit = false },
            title = { Text("Leave the test?") },
            text = { Text("Your progress in this test will be lost.") },
            confirmButton = { TextButton(onClick = { confirmExit = false; onExit() }) { Text("Leave") } },
            dismissButton = { TextButton(onClick = { confirmExit = false }) { Text("Stay") } },
        )
    }

    Scaffold(topBar = {
        AppTopBar(
            when (phase) {
                PPhase.Intro -> "English Practice Test"
                PPhase.Done -> "Test Result"
                else -> "Part ${task?.section?.letter}: ${task?.section?.title}"
            },
            onBack = { if (phase == PPhase.Intro || phase == PPhase.Done) onExit() else confirmExit = true },
        )
    }) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            if (phase != PPhase.Intro && phase != PPhase.Done) {
                Text("Task ${index + 1} of ${tasks.size}", color = MaterialTheme.colorScheme.outline)
                LinearProgressIndicator(
                    progress = { index.toFloat() / tasks.size },
                    modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                )
            }

            when (phase) {
                PPhase.Intro -> {
                    InfoCard {
                        Text("How it works", fontWeight = FontWeight.SemiBold, fontSize = 18.sp)
                        Spacer(Modifier.height(8.dp))
                        Section.entries.forEach { s ->
                            Text("${s.letter}. ${s.title}", fontWeight = FontWeight.Medium, modifier = Modifier.padding(top = 6.dp))
                            Text(s.instruction, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
                        }
                    }
                    InfoCard(container = MaterialTheme.colorScheme.secondaryContainer) {
                        Text("${tasks.size} tasks • about 12 minutes", fontWeight = FontWeight.SemiBold)
                        Text("Use earphones in a quiet room. You get a score (0–100) and a CEFR level at the end.",
                            style = MaterialTheme.typography.bodySmall)
                        if (coach == null) Text("Parts E and F are scored offline until you add a Gemini key in Settings.",
                            style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 6.dp))
                    }
                    Button(
                        onClick = { deps.requestMic { goTo(0) } },
                        modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(14.dp),
                    ) { Text("Start Test", fontSize = 16.sp) }
                }

                PPhase.SectionIntro -> task?.let { t ->
                    InfoCard(container = MaterialTheme.colorScheme.primaryContainer) {
                        Text("Part ${t.section.letter}", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                        Text(t.section.title, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(8.dp))
                        Text(t.section.instruction)
                    }
                    Button(
                        onClick = { beginTask() },
                        modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(14.dp),
                    ) { Text("Begin Part ${t.section.letter}", fontSize = 16.sp) }
                }

                PPhase.Task -> task?.let { t ->
                    if (t.display != null) {
                        InfoCard(container = MaterialTheme.colorScheme.primaryContainer) {
                            Text(t.display, fontSize = 20.sp, lineHeight = 28.sp, fontWeight = FontWeight.Medium)
                        }
                    }
                    if (t.audio != null) {
                        InfoCard {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.AutoMirrored.Filled.VolumeUp, null, tint = MaterialTheme.colorScheme.primary)
                                Spacer(Modifier.width(10.dp))
                                Text(
                                    if (speaker.isSpeaking) "Listen carefully…" else "Audio finished",
                                    modifier = Modifier.weight(1f),
                                )
                                val left = t.maxReplays - replaysUsed
                                TextButton(
                                    onClick = { replaysUsed++; playAudio(t, auto = false) },
                                    enabled = left > 0 && !speaker.isSpeaking && !speech.isListening,
                                ) { Text("Replay ($left)") }
                            }
                        }
                    }

                    TranscriptBox(
                        speech.text,
                        if (t.continuous) "Tap the mic and speak. Tap ■ when you finish." else "Tap the mic and speak.",
                    )
                    speech.error?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }

                    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                        MicButton(
                            listening = speech.isListening, level = speech.level,
                            enabled = !speaker.isSpeaking,
                            onClick = {
                                if (speech.isListening) speech.stop()
                                else deps.requestMic { speech.start(continuous = t.continuous) }
                            },
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedButton(
                            onClick = { speech.clear() },
                            enabled = speech.text.isNotBlank() && !speech.isListening,
                            modifier = Modifier.weight(1f),
                        ) { Icon(Icons.Filled.Refresh, null); Spacer(Modifier.width(4.dp)); Text("Redo") }
                        Button(
                            onClick = { check(t, speech.text) },
                            enabled = speech.text.isNotBlank() && !speech.isListening,
                            modifier = Modifier.weight(2f),
                        ) { Text("Check") }
                    }
                    TextButton(
                        onClick = {
                            speech.cancel(); speaker.stop()
                            val r = TaskResult(t, "", 0, "Skipped. Correct: \"${t.target.take(160)}\"")
                            results += r; lastResult = r; phase = PPhase.Result
                        },
                        modifier = Modifier.align(Alignment.CenterHorizontally),
                    ) { Text("Skip this task") }
                }

                PPhase.Scoring -> LoadingBlock("Scoring your answer…")

                PPhase.Result -> lastResult?.let { r ->
                    InfoCard {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            ScoreRing(r.score, size = 84.dp)
                            Spacer(Modifier.width(16.dp))
                            Column(Modifier.weight(1f)) {
                                Text(r.task.section.title, color = MaterialTheme.colorScheme.outline)
                                Text(r.note, style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                    }
                    if (r.answer.isNotBlank()) TranscriptBox(r.answer, "")
                    HindiTip(r.hindiTip)
                    Button(
                        onClick = { goTo(index + 1) },
                        modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(14.dp),
                    ) { Text(if (index + 1 < tasks.size) "Next" else "See my score", fontSize = 16.sp) }
                }

                PPhase.Done -> {
                    val sectionScores = Section.entries.associateWith { s ->
                        results.filter { it.task.section == s }.map { it.score }.takeIf { it.isNotEmpty() }?.average()?.toInt() ?: 0
                    }
                    val overall = Section.entries.sumOf { sectionScores.getValue(it) * it.weight }.toInt()
                    val pron = (sectionScores.getValue(Section.READ) + sectionScores.getValue(Section.REPEAT)) / 2
                    val listen = (sectionScores.getValue(Section.SHORT) + sectionScores.getValue(Section.BUILD)) / 2
                    val speak = (sectionScores.getValue(Section.RETELL) + sectionScores.getValue(Section.OPEN)) / 2

                    LaunchedEffect(Unit) {
                        if (!saved) {
                            saved = true
                            prefs.addRecord(
                                SessionRecord(
                                    type = "Practice Test", title = "English Practice Test", score = overall,
                                    timestamp = System.currentTimeMillis(),
                                    summary = "Level: ${LocalScorer.cefr(overall)}",
                                    subScores = mapOf("Pronunciation" to pron, "Listening" to listen, "Speaking" to speak),
                                )
                            )
                        }
                    }

                    InfoCard {
                        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                            ScoreRing(overall, size = 150.dp, label = "overall")
                            Spacer(Modifier.height(8.dp))
                            Text(LocalScorer.cefr(overall), fontWeight = FontWeight.Bold, fontSize = 18.sp, color = scoreColor(overall))
                            Text(levelMessage(overall), textAlign = TextAlign.Center, style = MaterialTheme.typography.bodyMedium,
                                modifier = Modifier.padding(top = 6.dp))
                        }
                        Spacer(Modifier.height(12.dp))
                        ScoreBar("Pronunciation (A, B)", pron)
                        ScoreBar("Listening & structure (C, D)", listen)
                        ScoreBar("Speaking & content (E, F)", speak)
                    }
                    InfoCard {
                        Text("Section scores", fontWeight = FontWeight.SemiBold)
                        Section.entries.forEach { s -> ScoreBar("${s.letter}. ${s.title}", sectionScores.getValue(s)) }
                    }
                    val weakest = Section.entries.minByOrNull { sectionScores.getValue(it) }
                    weakest?.let { w ->
                        InfoCard(container = Color(0xFFFFF7ED)) {
                            Text("Focus next on: ${w.title}", fontWeight = FontWeight.SemiBold, color = Color(0xFF9A3412))
                            Text(focusTip(w), style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(top = 4.dp))
                        }
                    }
                    Button(
                        onClick = onExit, modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(14.dp),
                    ) { Text("Done", fontSize = 16.sp) }
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

private fun levelMessage(score: Int) = when {
    score >= 85 -> "Excellent! Your English is ready for most international jobs."
    score >= 70 -> "Very good. You can handle most BPO and corporate interviews."
    score >= 55 -> "Good base. Practise daily to reach interview-ready level."
    score >= 40 -> "You are improving. Focus on clear pronunciation and full sentences."
    else -> "Keep going! Practise a little every day and you will improve fast."
}

private fun focusTip(s: Section) = when (s) {
    Section.READ -> "Read English news headlines aloud for 5 minutes a day. Speak slowly and finish every word."
    Section.REPEAT -> "Listen to short English sentences and repeat them right away. This trains memory and pronunciation."
    Section.SHORT -> "Practise quick everyday vocabulary: days, months, numbers, jobs, places and common objects."
    Section.BUILD -> "Remember the basic order: Subject + Verb + Object + Place + Time. Example: \"She sent the report this morning.\""
    Section.RETELL -> "After listening, say who, what, where and why. Use linking words like first, then, after that, finally."
    Section.OPEN -> "Give your opinion, one reason, one example, then a short conclusion. Aim for 30–60 seconds."
}
