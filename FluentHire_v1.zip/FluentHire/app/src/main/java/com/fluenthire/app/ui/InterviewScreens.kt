package com.fluenthire.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Keyboard
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fluenthire.app.AppDeps
import com.fluenthire.app.ai.AnswerFeedback
import com.fluenthire.app.ai.Coach
import com.fluenthire.app.ai.FinalReport
import com.fluenthire.app.ai.GeminiClient
import com.fluenthire.app.data.JobRole
import com.fluenthire.app.data.QuestionBank
import com.fluenthire.app.data.SessionRecord
import com.fluenthire.app.scoring.LocalScorer
import com.fluenthire.app.ui.theme.Good
import com.fluenthire.app.ui.theme.Indigo
import kotlinx.coroutines.launch

// ------------------------------------------------------------------ Setup

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun InterviewSetupScreen(
    deps: AppDeps,
    onBack: () -> Unit,
    onOpenSettings: () -> Unit,
    onStart: (JobRole, String, Int) -> Unit,
) {
    var role by remember { mutableStateOf(QuestionBank.roles.first()) }
    var level by remember { mutableStateOf(QuestionBank.levels.first()) }
    var count by remember { mutableIntStateOf(5) }

    Scaffold(topBar = { AppTopBar("AI Mock Interview", onBack) }) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Text("Choose your job type", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            QuestionBank.roles.forEach { r ->
                val selected = r.id == role.id
                Card(
                    onClick = { role = r },
                    shape = RoundedCornerShape(16.dp),
                    border = if (selected) BorderStroke(2.dp, MaterialTheme.colorScheme.primary) else null,
                    colors = CardDefaults.cardColors(
                        containerColor = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface
                    ),
                    elevation = CardDefaults.cardElevation(1.dp),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(r.emoji, fontSize = 26.sp)
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text(r.name, fontWeight = FontWeight.SemiBold)
                            Text(r.blurb, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
                        }
                    }
                }
            }

            Text("Your experience", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                QuestionBank.levels.forEach { l ->
                    FilterChip(selected = l == level, onClick = { level = l }, label = { Text(l) })
                }
            }

            Text("Number of questions", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(3, 5, 8).forEach { n ->
                    FilterChip(
                        selected = n == count, onClick = { count = n },
                        label = { Text(if (n == 3) "3 • Quick" else if (n == 5) "5 • Standard" else "8 • Full") },
                    )
                }
            }

            if (!deps.prefs.hasApiKey) {
                ErrorCard(
                    "The mock interview needs your free Gemini API key. It takes 1 minute to set up.",
                    onRetry = null,
                ) { TextButton(onClick = onOpenSettings) { Text("Open Settings") } }
            }

            Button(
                onClick = { deps.requestMic { onStart(role, level, count) } },
                enabled = deps.prefs.hasApiKey,
                modifier = Modifier.fillMaxWidth().height(54.dp),
                shape = RoundedCornerShape(14.dp),
            ) { Text("Start Interview", fontSize = 16.sp) }

            Text(
                "Tip: find a quiet place and speak clearly, as you would in a real interview.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline,
            )
        }
    }
}

// ------------------------------------------------------------------ Interview

private enum class Phase { LoadingQuestion, Asking, Answering, Evaluating, Feedback, Finishing, Report }

@Composable
fun InterviewScreen(
    deps: AppDeps,
    role: JobRole,
    level: String,
    total: Int,
    onExit: () -> Unit,
    onOpenSettings: () -> Unit,
) {
    val prefs = deps.prefs
    val speech = deps.speech
    val speaker = deps.speaker
    val scope = rememberCoroutineScope()
    val coach = remember { Coach(GeminiClient(prefs.apiKey, prefs.model), prefs.hindiTips) }

    var phase by remember { mutableStateOf(Phase.LoadingQuestion) }
    var questionNo by remember { mutableIntStateOf(1) }
    var question by remember { mutableStateOf("") }
    var nextQuestion by remember { mutableStateOf<String?>(null) }
    var current by remember { mutableStateOf<AnswerFeedback?>(null) }
    val results = remember { mutableStateListOf<AnswerFeedback>() }
    var report by remember { mutableStateOf<FinalReport?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var retry by remember { mutableStateOf<(() -> Unit)?>(null) }
    var typing by remember { mutableStateOf(!speech.available) }
    var typed by remember { mutableStateOf("") }
    var confirmExit by remember { mutableStateOf(false) }
    var saved by remember { mutableStateOf(false) }

    DisposableEffect(Unit) {
        speech.clear()
        onDispose { speech.cancel(); speaker.stop() }
    }

    fun ask(q: String) {
        question = q
        speech.clear(); typed = ""
        phase = Phase.Asking
        speaker.speak(q) { if (phase == Phase.Asking) phase = Phase.Answering }
    }

    fun loadFirst() {
        error = null; phase = Phase.LoadingQuestion
        scope.launch {
            try {
                ask(coach.firstQuestion(role, level))
            } catch (e: Exception) {
                error = e.message ?: "Could not start the interview."
                retry = { loadFirst() }
            }
        }
    }

    fun finish() {
        error = null; phase = Phase.Finishing
        scope.launch {
            val r = try {
                coach.finalReport(role, level, results.toList())
            } catch (e: Exception) {
                FinalReport(
                    summary = "You completed ${results.size} questions. Review the feedback for each answer below.",
                    strengths = emptyList(), improvements = emptyList(), readiness = "Keep practising",
                )
            }
            report = r
            if (!saved && results.isNotEmpty()) {
                saved = true
                val avg = { sel: (AnswerFeedback) -> Int -> results.map(sel).average().toInt() }
                prefs.addRecord(
                    SessionRecord(
                        type = "Interview",
                        title = role.name,
                        score = avg { it.overall },
                        timestamp = System.currentTimeMillis(),
                        summary = r.summary,
                        subScores = mapOf(
                            "Fluency" to avg { it.fluency }, "Grammar" to avg { it.grammar },
                            "Vocabulary" to avg { it.vocabulary }, "Relevance" to avg { it.relevance },
                        ),
                    )
                )
            }
            phase = Phase.Report
        }
    }

    fun submit(answer: String) {
        if (answer.isBlank()) return
        error = null; phase = Phase.Evaluating
        val history = results.map { it.question to it.answer }
        scope.launch {
            try {
                val res = coach.evaluate(
                    role, level, history, question, answer, questionNo, total, LocalScorer.countFillers(answer)
                )
                current = res.feedback
                results += res.feedback
                nextQuestion = res.nextQuestion ?: if (questionNo < total)
                    role.sampleQuestions.getOrElse(questionNo) { "Do you have any questions for us?" } else null
                phase = Phase.Feedback
            } catch (e: Exception) {
                error = e.message ?: "Could not check your answer."
                retry = { submit(answer) }
                phase = Phase.Answering
            }
        }
    }

    LaunchedEffect(Unit) { loadFirst() }

    BackHandler { if (phase == Phase.Report || results.isEmpty()) onExit() else confirmExit = true }

    if (confirmExit) {
        AlertDialog(
            onDismissRequest = { confirmExit = false },
            title = { Text("Leave interview?") },
            text = { Text("Your answers so far will not be saved unless you finish.") },
            confirmButton = { TextButton(onClick = { confirmExit = false; onExit() }) { Text("Leave") } },
            dismissButton = { TextButton(onClick = { confirmExit = false }) { Text("Stay") } },
        )
    }

    Scaffold(topBar = {
        AppTopBar(
            if (phase == Phase.Report) "Interview Report" else "Question ${minOf(questionNo, total)} of $total",
            onBack = { if (phase == Phase.Report || results.isEmpty()) onExit() else confirmExit = true },
        )
    }) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp).imePadding(),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            if (phase != Phase.Report) {
                LinearProgressIndicator(
                    progress = { (results.size.toFloat() / total).coerceIn(0f, 1f) },
                    modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                )
            }

            error?.let { msg ->
                ErrorCard(msg, onRetry = retry?.let { r -> { error = null; r() } }) {
                    if (msg.contains("key", true) || msg.contains("Model", true))
                        TextButton(onClick = onOpenSettings) { Text("Settings") }
                }
            }

            when (phase) {
                Phase.LoadingQuestion -> if (error == null) LoadingBlock("The interviewer is getting ready…")

                Phase.Asking, Phase.Answering -> {
                    InterviewerBubble(question, speaking = speaker.isSpeaking) { speaker.speak(question) {
                        if (phase == Phase.Asking) phase = Phase.Answering
                    } }

                    if (phase == Phase.Asking) {
                        TextButton(onClick = { speaker.stop(); phase = Phase.Answering }, modifier = Modifier.align(Alignment.CenterHorizontally)) {
                            Text("Skip voice and answer")
                        }
                    } else if (typing) {
                        OutlinedTextField(
                            value = typed, onValueChange = { typed = it },
                            label = { Text("Type your answer") },
                            modifier = Modifier.fillMaxWidth(), minLines = 4,
                        )
                        Button(
                            onClick = { submit(typed.trim()) }, enabled = typed.isNotBlank(),
                            modifier = Modifier.fillMaxWidth().height(50.dp), shape = RoundedCornerShape(14.dp),
                        ) { Text("Submit answer") }
                        if (speech.available) TextButton(onClick = { typing = false }) { Text("Use microphone instead") }
                    } else {
                        TranscriptBox(speech.text, "Tap the mic and answer in English. Tap again when you finish.")
                        speech.error?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
                        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                            MicButton(
                                listening = speech.isListening, level = speech.level, enabled = true,
                                onClick = {
                                    if (speech.isListening) speech.stop()
                                    else deps.requestMic { speaker.stop(); speech.start(continuous = true, reset = false) }
                                },
                            )
                        }
                        Text(
                            if (speech.isListening) "Listening… tap ■ when you finish your answer" else "Tap the mic to speak",
                            modifier = Modifier.align(Alignment.CenterHorizontally),
                            color = MaterialTheme.colorScheme.outline,
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            OutlinedButton(
                                onClick = { speech.cancel(); speech.clear() },
                                enabled = speech.text.isNotBlank() && !speech.isListening,
                                modifier = Modifier.weight(1f),
                            ) { Icon(Icons.Filled.Refresh, null); Spacer(Modifier.width(4.dp)); Text("Redo") }
                            Button(
                                onClick = { submit(speech.text) },
                                enabled = speech.text.isNotBlank() && !speech.isListening,
                                modifier = Modifier.weight(2f),
                            ) { Text("Submit answer") }
                        }
                        TextButton(onClick = { speech.cancel(); typed = speech.text; typing = true }) {
                            Icon(Icons.Filled.Keyboard, null); Spacer(Modifier.width(6.dp)); Text("Type instead")
                        }
                    }
                }

                Phase.Evaluating -> {
                    InterviewerBubble(question, speaking = false, onReplay = null)
                    LoadingBlock("Checking your answer…")
                }

                Phase.Feedback -> current?.let { fb ->
                    FeedbackView(fb)
                    val hasNext = questionNo < total && nextQuestion != null
                    Button(
                        onClick = {
                            val nq = nextQuestion
                            if (hasNext && nq != null) { questionNo++; ask(nq) } else finish()
                        },
                        modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(14.dp),
                    ) { Text(if (hasNext) "Next question" else "See final report", fontSize = 16.sp) }
                    if (hasNext) TextButton(onClick = { finish() }, modifier = Modifier.align(Alignment.CenterHorizontally)) {
                        Text("End interview now")
                    }
                }

                Phase.Finishing -> LoadingBlock("Preparing your interview report…")

                Phase.Report -> ReportView(role, results.toList(), report, onExit)
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun InterviewerBubble(question: String, speaking: Boolean, onReplay: (() -> Unit)?) {
    Row(verticalAlignment = Alignment.Top) {
        Box(
            Modifier.size(44.dp).clip(CircleShape).background(Indigo),
            contentAlignment = Alignment.Center,
        ) { Text("HR", color = Color.White, fontWeight = FontWeight.Bold) }
        Spacer(Modifier.width(10.dp))
        Card(
            shape = RoundedCornerShape(topStart = 4.dp, topEnd = 18.dp, bottomEnd = 18.dp, bottomStart = 18.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
            modifier = Modifier.weight(1f),
        ) {
            Column(Modifier.padding(14.dp)) {
                Text(question, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onPrimaryContainer)
                if (onReplay != null) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = onReplay) {
                            Icon(Icons.AutoMirrored.Filled.VolumeUp, contentDescription = "Listen again")
                        }
                        Text(if (speaking) "Speaking…" else "Listen again", style = MaterialTheme.typography.labelMedium)
                    }
                }
            }
        }
    }
}

@Composable
private fun FeedbackView(fb: AnswerFeedback) {
    InfoCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            ScoreRing(fb.overall, size = 96.dp, label = "score")
            Spacer(Modifier.width(16.dp))
            Column(Modifier.weight(1f)) {
                ScoreBar("Fluency", fb.fluency)
                ScoreBar("Grammar", fb.grammar)
                ScoreBar("Vocabulary", fb.vocabulary)
                ScoreBar("Answer quality", fb.relevance)
            }
        }
        if (fb.fillers > 0) {
            Spacer(Modifier.height(8.dp))
            Text("Filler words used: ${fb.fillers} (try short pauses instead)", style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.error)
        }
    }
    InfoCard {
        Text("Feedback", fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(4.dp))
        Text(fb.feedback)
    }
    TranscriptBox(fb.answer, "")
    if (fb.corrections.isNotEmpty()) {
        InfoCard {
            Text("Corrections", fontWeight = FontWeight.SemiBold)
            fb.corrections.forEach { c ->
                Spacer(Modifier.height(8.dp))
                Text(c.wrong, textDecoration = TextDecoration.LineThrough, color = MaterialTheme.colorScheme.error)
                Text("✓ ${c.right}", color = Good, fontWeight = FontWeight.Medium)
            }
        }
    }
    if (fb.betterAnswer.isNotBlank()) {
        InfoCard(container = Color(0xFFF0FDF4)) {
            Text("A stronger answer", fontWeight = FontWeight.SemiBold, color = Color(0xFF166534))
            Spacer(Modifier.height(4.dp))
            Text(fb.betterAnswer)
        }
    }
    HindiTip(fb.hindiTip)
}

@Composable
private fun ReportView(role: JobRole, items: List<AnswerFeedback>, report: FinalReport?, onDone: () -> Unit) {
    if (items.isEmpty()) {
        Text("No answers recorded.")
        Button(onClick = onDone) { Text("Back to home") }
        return
    }
    val overall = items.map { it.overall }.average().toInt()
    InfoCard {
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(role.name, color = MaterialTheme.colorScheme.outline)
            Spacer(Modifier.height(8.dp))
            ScoreRing(overall, size = 140.dp, label = "overall")
            Spacer(Modifier.height(8.dp))
            report?.readiness?.let { Text(it, fontWeight = FontWeight.Bold, fontSize = 18.sp) }
        }
        Spacer(Modifier.height(12.dp))
        ScoreBar("Fluency", items.map { it.fluency }.average().toInt())
        ScoreBar("Grammar", items.map { it.grammar }.average().toInt())
        ScoreBar("Vocabulary", items.map { it.vocabulary }.average().toInt())
        ScoreBar("Answer quality", items.map { it.relevance }.average().toInt())
    }
    report?.let { r ->
        if (r.summary.isNotBlank()) InfoCard { Text("Summary", fontWeight = FontWeight.SemiBold); Spacer(Modifier.height(4.dp)); Text(r.summary) }
        if (r.strengths.isNotEmpty()) InfoCard(container = Color(0xFFF0FDF4)) {
            Text("Strengths", fontWeight = FontWeight.SemiBold, color = Color(0xFF166534))
            r.strengths.forEach { Text("• $it", modifier = Modifier.padding(top = 4.dp)) }
        }
        if (r.improvements.isNotEmpty()) InfoCard(container = Color(0xFFFFF7ED)) {
            Text("Practise this week", fontWeight = FontWeight.SemiBold, color = Color(0xFF9A3412))
            r.improvements.forEach { Text("• $it", modifier = Modifier.padding(top = 4.dp)) }
        }
    }
    Text("Your answers", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
    items.forEachIndexed { i, fb ->
        InfoCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Q${i + 1}. ${fb.question}", fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
                Spacer(Modifier.width(8.dp))
                ScoreRing(fb.overall, size = 48.dp, stroke = 5.dp)
            }
            if (fb.betterAnswer.isNotBlank()) {
                Spacer(Modifier.height(6.dp))
                Text("Better answer: ${fb.betterAnswer}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
            }
        }
    }
    Button(
        onClick = onDone, modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(14.dp),
    ) { Text("Done", fontSize = 16.sp) }
}
