package com.fluenthire.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fluenthire.app.AppDeps
import com.fluenthire.app.ui.theme.Amber
import com.fluenthire.app.ui.theme.Indigo
import com.fluenthire.app.ui.theme.Teal

@Composable
fun HomeScreen(
    deps: AppDeps,
    refreshKey: Int,
    onInterview: () -> Unit,
    onPractice: () -> Unit,
    onProgress: () -> Unit,
    onSettings: () -> Unit,
) {
    val prefs = deps.prefs
    val history = remember(refreshKey) { prefs.history() }
    val streak = remember(refreshKey) { prefs.streak() }
    val name = prefs.userName
    val last = history.firstOrNull()
    val best = history.maxOfOrNull { it.score }

    Column(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).verticalScroll(rememberScrollState())
    ) {
        // Header
        Box(
            Modifier.fillMaxWidth()
                .background(Brush.verticalGradient(listOf(Indigo, Color(0xFF1E5F8C), Teal)))
                .statusBarsPadding()
                .padding(horizontal = 20.dp, vertical = 16.dp)
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("FluentHire", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                        Text("AI English & Interview Coach", color = Color.White.copy(alpha = 0.85f), fontSize = 14.sp)
                    }
                    IconButton(onClick = onSettings) {
                        Icon(Icons.Filled.Settings, contentDescription = "Settings", tint = Color.White)
                    }
                }
                Spacer(Modifier.height(18.dp))
                Text(
                    if (name.isBlank()) "Hello! Ready to practise today?" else "Hello $name! Ready to practise today?",
                    color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold,
                )
                Spacer(Modifier.height(14.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatChip("🔥 $streak", "day streak", Modifier.weight(1f))
                    StatChip(last?.score?.toString() ?: "–", "last score", Modifier.weight(1f))
                    StatChip(best?.toString() ?: "–", "best score", Modifier.weight(1f))
                }
                Spacer(Modifier.height(6.dp))
            }
        }

        Column(Modifier.navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            if (!prefs.hasApiKey) {
                InfoCard(container = Color(0xFFFFFBEB)) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.clickable { onSettings() }) {
                        Icon(Icons.Filled.Key, null, tint = Amber)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Turn on AI coaching", fontWeight = FontWeight.SemiBold)
                            Text(
                                "Add your free Gemini API key to unlock mock interviews and AI feedback.",
                                style = MaterialTheme.typography.bodySmall,
                            )
                        }
                        Icon(Icons.AutoMirrored.Filled.ArrowForward, null)
                    }
                }
            }

            FeatureCard(
                emoji = "🎤",
                title = "AI Mock Interview",
                subtitle = "Real interview questions for your job. Speak your answer and get instant feedback, corrections and a better answer.",
                tag = "BPO • IT • Sales • Banking • HR • Freshers",
                colors = listOf(Color(0xFF4F46E5), Color(0xFF7C3AED)),
                onClick = onInterview,
            )
            FeatureCard(
                emoji = "📝",
                title = "English Practice Test",
                subtitle = "Versant-style speaking test: read aloud, repeat, short answers, sentence builds, story retelling and opinion.",
                tag = "About 12 minutes • Score + CEFR level",
                colors = listOf(Color(0xFF0D9488), Color(0xFF0891B2)),
                onClick = onPractice,
            )

            InfoCard {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.clickable { onProgress() }) {
                    Icon(Icons.Filled.BarChart, null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("My Progress", fontWeight = FontWeight.SemiBold)
                        Text(
                            if (history.isEmpty()) "No sessions yet. Start your first practice!"
                            else "${history.size} sessions completed",
                            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline,
                        )
                    }
                    Icon(Icons.AutoMirrored.Filled.ArrowForward, null)
                }
            }

            InfoCard(container = MaterialTheme.colorScheme.primaryContainer) {
                Text("💡 Tip of the day", fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(4.dp))
                Text(remember { tips.random() }, style = MaterialTheme.typography.bodyMedium)
            }
            Spacer(Modifier.height(8.dp))
        }
    }
}

private val tips = listOf(
    "Answer \"Tell me about yourself\" in 4 parts: name and education, experience or skills, one achievement, and why you want this job.",
    "Speak a little slower than normal. Clear speech scores better than fast speech.",
    "Replace \"umm\" with a short silent pause. Pauses sound confident; filler words do not.",
    "Use the STAR method for experience questions: Situation, Task, Action, Result.",
    "Practise 10 minutes every day. A daily streak improves fluency faster than one long session a week.",
    "Use full sentences: say \"I have worked in sales for two years\" instead of just \"two years\".",
    "Always end an interview by asking one good question, like \"What does success look like in this role?\"",
)

@Composable
private fun StatChip(value: String, label: String, modifier: Modifier) {
    Column(
        modifier.clip(RoundedCornerShape(14.dp)).background(Color.White.copy(alpha = 0.16f)).padding(vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(value, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Text(label, color = Color.White.copy(alpha = 0.85f), fontSize = 12.sp)
    }
}

@Composable
private fun FeatureCard(
    emoji: String, title: String, subtitle: String, tag: String,
    colors: List<Color>, onClick: () -> Unit,
) {
    Card(
        onClick = onClick,
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Box(Modifier.fillMaxWidth().background(Brush.linearGradient(colors)).padding(20.dp)) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(48.dp).clip(RoundedCornerShape(14.dp)).background(Color.White.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center,
                    ) { Text(emoji, fontSize = 24.sp) }
                    Spacer(Modifier.width(12.dp))
                    Text(title, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Icon(Icons.AutoMirrored.Filled.ArrowForward, null, tint = Color.White)
                }
                Spacer(Modifier.height(10.dp))
                Text(subtitle, color = Color.White.copy(alpha = 0.92f), fontSize = 14.sp)
                Spacer(Modifier.height(10.dp))
                Text(tag, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Medium)
            }
        }
    }
}
