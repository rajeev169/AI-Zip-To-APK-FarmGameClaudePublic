# FluentHire – AI English & Interview Coach (v1.0)

Android app (Kotlin + Jetpack Compose) that helps students and job seekers improve spoken English
and crack job interviews.

## Features
- **AI Mock Interview** – 6 job types (BPO, IT, Sales, Banking, HR, Freshers), 3 experience levels,
  3/5/8 questions. The AI interviewer speaks each question, listens to the spoken answer, and gives
  scores (fluency, grammar, vocabulary, answer quality), corrections, a stronger model answer,
  filler-word count and an optional Hindi tip. Asks natural follow-up questions. Final report with
  strengths, improvements and readiness.
- **English Practice Test (Versant-style)** – 17 tasks in 6 parts: Read Aloud, Repeat, Short Answers,
  Sentence Builds, Story Retelling, Open Question. Score 0–100 + CEFR level. Parts A–D are scored
  offline; E–F use AI when a key is set (offline fallback otherwise).
- **Progress** – day streak, score chart, skill averages, history.
- **Settings** – name, Gemini API key (with Test button), model name, Hindi tips, voice speed.
- "Type instead" fallback if speech recognition is not available on the phone.

## Setup
1. Build the APK (Android Studio, or the included GitHub Actions workflow / your ZIP-to-APK repo).
2. Get a free API key at https://aistudio.google.com/apikey
3. Open the app → ⚙ Settings → paste the key → **Test key** → Save.

Speech recognition uses the phone's Google speech service (Google app must be installed/updated).

## Project info
- Package: `com.fluenthire.app` • minSdk 24 • targetSdk 35 • AGP 8.5.2 • Kotlin 2.0.20 • Gradle 8.9
- No extra libraries for AI or storage (HttpURLConnection + org.json + SharedPreferences).
- `playstore_icon_512.png` – 512×512 icon for the Play Store listing.

## Before a Play Store release
- The API key is entered by each user. For a public app where users should NOT need a key,
  move AI calls to your own backend (e.g. Firebase Cloud Functions) so your key stays secret.
- Add a privacy policy (the app records voice for speech-to-text and sends answer text to Google Gemini).
- Not affiliated with Pearson or the Versant test – keep "Versant" out of the app name and icon.
