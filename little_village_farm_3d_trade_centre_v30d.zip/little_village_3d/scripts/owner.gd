extends Node
# Owner Mode (v30): you are the farmer. Walk anywhere on your land with a round
# joystick, see the farm from behind your shoulder, and do the work yourself:
# collect milk, eggs, truffles and apples, plant, water, weed and harvest crops,
# and open the shops. Coins, XP, stock and saves are shared with the normal game.

var g: Node
var v: Node

const SailScript := preload("res://scripts/sail.gd")
const GROUND_Y := 0.15
const WALK_SPEED := 4.2
const LIMIT := 18.0

var on: bool = false
var top_view: bool = false
var player: Node3D
var model: Node3D
var cam: Camera3D
var heading: float = 0.0          # player yaw; the model faces local +x
var cam_h: float = 0.0
var speed: float = 0.0
var phase: float = 0.0
var hop_t: float = 0.0
var t: float = 0.0
var built: bool = false
var obstacles: Array = []
var target: Dictionary = {}
var steer_vis: float = 0.0
var parts: Dictionary = {}
var glow: OmniLight3D
var cam_dist: float = 4.4
var still_t: float = 0.0

var hud: CanvasLayer
var enter_btn: Button
var exit_btn: Button
var view_btn: Button
var act_btn: Button
var joy: Control
var bottom_bar: Control

const SOLIDS := [
    Vector3(-4.2, -4.1, 2.3),    # farmhouse
    Vector3(3.7, -4.1, 2.4),     # barn
    Vector3(9.6, -7.4, 1.6),     # silo
    Vector3(-10.8, -1.4, 1.8),   # bakery oven
    Vector3(8.2, 11.0, 2.3),     # market tent
    Vector3(-10.0, 12.5, 2.6),   # windmill site
    Vector3(5.0, 0.1, 0.9),      # well
    Vector3(-12.0, -6.5, 3.1),   # pond
    Vector3(15.5, 7.0, 2.7),     # pond
]

# ----------------------------------------------------------------- HUD

func _style(b: Button, col: Color, radius: int) -> void:
    b.add_theme_font_size_override("font_size", 22)
    b.add_theme_color_override("font_color", Color.WHITE)
    b.add_theme_color_override("font_pressed_color", Color.WHITE)
    for st in ["normal", "hover", "pressed", "focus"]:
        var sb := StyleBoxFlat.new()
        sb.bg_color = col if st != "pressed" else col.darkened(0.3)
        sb.set_corner_radius_all(radius)
        sb.border_color = Color(1, 1, 1, 0.9)
        sb.set_border_width_all(4)
        sb.shadow_color = Color(0, 0, 0, 0.3)
        sb.shadow_size = 4
        b.add_theme_stylebox_override(st, sb)

func _ensure_hud() -> void:
    if hud != null:
        return
    hud = CanvasLayer.new()
    hud.layer = 62
    add_child(hud)
    enter_btn = Button.new()
    enter_btn.text = "WALK"
    enter_btn.anchor_top = 1.0
    enter_btn.anchor_bottom = 1.0
    enter_btn.offset_left = 14.0
    enter_btn.offset_right = 124.0
    enter_btn.offset_top = -126.0
    enter_btn.offset_bottom = -16.0
    _style(enter_btn, Color(0.25, 0.62, 0.30), 55)
    enter_btn.pressed.connect(enter)
    hud.add_child(enter_btn)
    exit_btn = Button.new()
    exit_btn.text = "< EXIT WALK"
    exit_btn.anchor_left = 0.5
    exit_btn.anchor_right = 0.5
    exit_btn.offset_left = -215.0
    exit_btn.offset_right = -5.0
    exit_btn.offset_top = 12.0
    exit_btn.offset_bottom = 72.0
    _style(exit_btn, Color(0.2, 0.3, 0.45, 0.9), 14)
    exit_btn.pressed.connect(leave)
    exit_btn.visible = false
    hud.add_child(exit_btn)
    view_btn = Button.new()
    view_btn.text = "TOP VIEW"
    view_btn.anchor_left = 0.5
    view_btn.anchor_right = 0.5
    view_btn.offset_left = 5.0
    view_btn.offset_right = 215.0
    view_btn.offset_top = 12.0
    view_btn.offset_bottom = 72.0
    _style(view_btn, Color(0.2, 0.3, 0.45, 0.9), 14)
    view_btn.pressed.connect(_toggle_view)
    view_btn.visible = false
    hud.add_child(view_btn)
    joy = SailScript.Joy.new()
    joy.anchor_top = 1.0
    joy.anchor_bottom = 1.0
    joy.offset_left = 30.0
    joy.offset_right = 290.0
    joy.offset_top = -290.0
    joy.offset_bottom = -30.0
    joy.visible = false
    hud.add_child(joy)
    act_btn = Button.new()
    act_btn.anchor_left = 1.0
    act_btn.anchor_right = 1.0
    act_btn.anchor_top = 1.0
    act_btn.anchor_bottom = 1.0
    act_btn.offset_left = -330.0
    act_btn.offset_right = -24.0
    act_btn.offset_top = -150.0
    act_btn.offset_bottom = -40.0
    _style(act_btn, Color(0.93, 0.55, 0.12), 30)
    act_btn.add_theme_font_size_override("font_size", 26)
    act_btn.pressed.connect(_act)
    act_btn.visible = false
    hud.add_child(act_btn)

# ----------------------------------------------------------------- build

func _build() -> void:
    if built:
        return
    built = true
    player = Node3D.new()
    player.name = "OwnerPlayer"
    g.add_child(player)
    model = Node3D.new()
    model.scale = Vector3.ONE * 1.12
    player.add_child(model)
    _build_human()
    glow = OmniLight3D.new()
    glow.position = Vector3(0.0, 2.2, 0.0)
    glow.omni_range = 7.0
    glow.light_energy = 0.0
    glow.light_color = Color(1.0, 0.9, 0.7)
    glow.shadow_enabled = false
    player.add_child(glow)
    cam = Camera3D.new()
    cam.fov = 62.0
    cam.near = 0.1
    cam.far = 400.0
    g.add_child(cam)
    player.position = Vector3(0.6, GROUND_Y, 5.6)
    heading = deg_to_rad(90.0)       # facing the field (towards -z)
    cam_h = heading
    player.visible = false

func _make_obstacles() -> void:
    obstacles = SOLIDS.duplicate()
    for d in g.solid_discs:
        obstacles.append(d)


# ----------------------------------------------------------------- the farmer
# A jointed human: hips, knees, shoulders, elbows, hands with fingers, a neck and a
# detailed head. The model faces local +x; local +z is the farmer's right-hand side.

func _joint(parent: Node3D, pos: Vector3) -> Node3D:
    var n := Node3D.new()
    n.position = pos
    parent.add_child(n)
    return n

func _taper(parent: Node3D, a: Vector3, b: Vector3, r1: float, r2: float, mat: Material) -> void:
    # a smooth tapered limb piece from a (radius r1) to b (radius r2)
    var d: Vector3 = b - a
    var mi := MeshInstance3D.new()
    var cm := CylinderMesh.new()
    cm.top_radius = r1
    cm.bottom_radius = r2
    cm.height = d.length()
    cm.radial_segments = 14
    mi.mesh = cm
    mi.material_override = mat
    mi.position = (a + b) * 0.5
    var dn: Vector3 = d.normalized()
    if dn.dot(Vector3.DOWN) > 0.9999:
        pass
    else:
        mi.quaternion = Quaternion(Vector3.DOWN, dn)
    parent.add_child(mi)

func _build_human() -> void:
    var skin: StandardMaterial3D = v._mm(Color(0.68, 0.47, 0.33), 0.62)
    var skin_d: StandardMaterial3D = v._mm(Color(0.55, 0.36, 0.25), 0.7)
    var shirt: StandardMaterial3D = v._mm(Color(0.20, 0.42, 0.82), 0.85)
    var shirt_d: StandardMaterial3D = v._mm(Color(0.14, 0.31, 0.64), 0.85)
    var denim: StandardMaterial3D = v._mm(Color(0.19, 0.27, 0.45), 0.9)
    var denim_d: StandardMaterial3D = v._mm(Color(0.13, 0.19, 0.33), 0.9)
    var leather: StandardMaterial3D = v._mm(Color(0.30, 0.18, 0.10), 0.55)
    var sole: StandardMaterial3D = v._mm(Color(0.10, 0.08, 0.07), 0.85)
    var gold: StandardMaterial3D = v._mm(Color(0.85, 0.7, 0.25), 0.3, 0.6)
    var hair: StandardMaterial3D = v._mm(Color(0.06, 0.05, 0.05), 0.7)
    var white: StandardMaterial3D = v._mm(Color(0.96, 0.96, 0.94), 0.4)
    var iris: StandardMaterial3D = v._mm(Color(0.14, 0.08, 0.05), 0.2)
    var lip: StandardMaterial3D = v._mm(Color(0.45, 0.2, 0.18), 0.5)
    var straw: StandardMaterial3D = v._mm(Color(0.93, 0.74, 0.3), 0.95)
    var band: StandardMaterial3D = v._mm(Color(0.72, 0.18, 0.15), 0.9)
    var hips: Node3D = _joint(model, Vector3(0, 0, 0))
    parts["hips"] = hips
    # pelvis, belt
    v._put(hips, v._cyl(0.15, 0.16, 0.16, 24), Vector3(0, 0.93, 0), denim, Vector3.ZERO, Vector3(0.72, 1.0, 1.2))
    v._put(hips, v._cyl(0.158, 0.158, 0.045, 24), Vector3(0, 1.00, 0), leather, Vector3.ZERO, Vector3(0.72, 1.0, 1.2))
    v._put(hips, v._bx(Vector3(0.02, 0.035, 0.05)), Vector3(0.118, 1.00, 0), gold)
    # legs: tapered thigh and shin, knee and ankle joints the same width as the limb
    for side in [-1.0, 1.0]:
        var nm: String = "r" if side > 0.0 else "l"
        var th: Node3D = _joint(hips, Vector3(0, 0.90, 0.1 * side))
        _taper(th, Vector3(0, 0.02, 0), Vector3(0, -0.45, 0), 0.088, 0.062, denim)
        var kn: Node3D = _joint(th, Vector3(0, -0.45, 0))
        v._put(kn, v._sph(0.062), Vector3.ZERO, denim)
        _taper(kn, Vector3(0, 0, 0), Vector3(0, -0.40, 0), 0.060, 0.043, denim_d)
        var an: Node3D = _joint(kn, Vector3(0, -0.40, 0))
        v._put(an, v._cyl(0.05, 0.062, 0.11, 14), Vector3(0, 0.02, 0), leather)
        v._put(an, v._sph(0.058), Vector3(-0.012, -0.012, 0), leather, Vector3.ZERO, Vector3(0.95, 0.9, 0.95))       # heel
        v._put(an, v._sph(0.058), Vector3(0.06, -0.026, 0), leather, Vector3.ZERO, Vector3(1.5, 0.78, 0.95))         # instep
        v._put(an, v._sph(0.05), Vector3(0.135, -0.04, 0), leather, Vector3.ZERO, Vector3(1.35, 0.62, 0.95))         # rounded toe
        v._put(an, v._sph(0.074), Vector3(0.062, -0.062, 0), sole, Vector3.ZERO, Vector3(1.95, 0.2, 0.78))           # thin curved sole
        v._put(an, v._sph(0.03), Vector3(-0.045, -0.058, 0), sole, Vector3.ZERO, Vector3(1.0, 0.45, 1.5))           # heel block
        parts[nm + "thigh"] = th
        parts[nm + "knee"] = kn
    # torso: broad chest tapering to the waist
    var torso: Node3D = _joint(hips, Vector3(0, 0.98, 0))
    parts["torso"] = torso
    v._put(torso, v._cyl(0.145, 0.135, 0.14, 24), Vector3(0, 0.06, 0), shirt, Vector3.ZERO, Vector3(0.70, 1.0, 1.18))    # belly
    v._put(torso, v._cyl(0.168, 0.145, 0.30, 26), Vector3(0, 0.27, 0), shirt, Vector3.ZERO, Vector3(0.68, 1.0, 1.28))     # chest
    v._put(torso, v._cyl(0.056, 0.056, 0.38, 14), Vector3(0, 0.425, 0), shirt, Vector3(90, 0, 0), Vector3(1.0, 1.0, 1.0))   # shoulder line
    for pz in [-1.0, 1.0]:
        _taper(torso, Vector3(0, 0.50, 0.045 * pz), Vector3(0, 0.43, 0.175 * pz), 0.04, 0.056, shirt)                          # trapezius
    v._put(torso, v._bx(Vector3(0.02, 0.26, 0.012)), Vector3(0.118, 0.20, 0), shirt_d)
    for bi in range(3):
        v._put(torso, v._sph(0.01), Vector3(0.124, 0.12 + 0.07 * float(bi), 0), white)
    # neck and collar
    v._put(torso, v._cyl(0.047, 0.058, 0.11, 14), Vector3(0, 0.52, 0), skin)
    v._put(torso, v._cyl(0.075, 0.095, 0.04, 16), Vector3(0, 0.47, 0), shirt_d)
    # arms: tapered, joints no wider than the limb
    for side2 in [-1.0, 1.0]:
        var nm2: String = "r" if side2 > 0.0 else "l"
        var sh: Node3D = _joint(torso, Vector3(0, 0.42, 0.205 * side2))
        _taper(sh, Vector3(0, 0.03, 0), Vector3(0, -0.28, 0), 0.056, 0.047, shirt)
        var el: Node3D = _joint(sh, Vector3(0, -0.29, 0))
        v._put(el, v._sph(0.045), Vector3.ZERO, shirt_d)
        _taper(el, Vector3(0, 0, 0), Vector3(0, -0.26, 0), 0.042, 0.030, skin)
        var wr: Node3D = _joint(el, Vector3(0, -0.27, 0))
        v._put(wr, v._sph(0.03), Vector3.ZERO, skin)
        v._put(wr, v._bx(Vector3(0.03, 0.08, 0.07)), Vector3(0, -0.055, 0), skin)
        for fi in range(4):
            var fz: float = (-0.027 + 0.018 * float(fi))
            var fl: float = 0.075 - 0.008 * absf(float(fi) - 1.5)
            v._limb(wr, Vector3(0.006, -0.095, fz), Vector3(0.022, -0.095 - fl * 0.95, fz), 0.0095, skin)
        v._limb(wr, Vector3(0.016, -0.03, 0.034 * side2), Vector3(0.05, -0.075, 0.03 * side2), 0.011, skin)
        parts[nm2 + "sh"] = sh
        parts[nm2 + "el"] = el
    # head
    var head: Node3D = _joint(torso, Vector3(0, 0.57, 0))
    parts["head"] = head
    v._put(head, v._sph(0.105, 1.2), Vector3(0.01, 0.12, 0), skin, Vector3.ZERO, Vector3(1.0, 1.0, 0.86))
    v._put(head, v._sph(0.065, 0.85), Vector3(0.03, 0.045, 0), skin, Vector3.ZERO, Vector3(1.05, 1.0, 0.95))  # jaw and chin
    for ez in [-1.0, 1.0]:
        v._put(head, v._sph(0.02), Vector3(0.086, 0.135, 0.037 * ez), white, Vector3.ZERO, Vector3(0.5, 0.9, 1.25))
        v._put(head, v._sph(0.0105), Vector3(0.096, 0.135, 0.037 * ez), iris)
        v._put(head, v._bx(Vector3(0.012, 0.009, 0.046)), Vector3(0.091, 0.166, 0.039 * ez), hair, Vector3(ez * 8.0, 0, 0))
        v._put(head, v._sph(0.025), Vector3(0.0, 0.11, 0.088 * ez), skin_d, Vector3.ZERO, Vector3(0.45, 1.0, 0.7))
    v._put(head, v._sph(0.02), Vector3(0.102, 0.095, 0), skin, Vector3.ZERO, Vector3(1.2, 1.5, 0.9))   # nose
    v._put(head, v._bx(Vector3(0.008, 0.009, 0.048)), Vector3(0.094, 0.052, 0), lip)                   # mouth
    v._put(head, v._sph(0.108, 0.8), Vector3(-0.012, 0.165, 0), hair, Vector3.ZERO, Vector3(1.0, 0.8, 0.9))
    v._put(head, v._cyl(0.2, 0.2, 0.012, 32), Vector3(0.0, 0.215, 0), straw, Vector3(0, 0, 4))
    v._put(head, v._sph(0.116, 0.65), Vector3(-0.005, 0.225, 0), straw)
    v._put(head, v._cyl(0.119, 0.121, 0.03, 24), Vector3(-0.005, 0.225, 0), band)

func _animate(moved: bool, amp: float, delta: float) -> void:
    var s: float = sin(phase)
    var c: float = cos(phase)
    var idle: float = 1.0 - amp
    var br: float = sin(t * 1.8) * 0.012 * idle
    (parts["hips"] as Node3D).position.y = (absf(s) * 0.045 * amp) if moved else 0.0
    for side in ["l", "r"]:
        var sg: float = 1.0 if side == "l" else -1.0     # legs swing in opposition
        var sw: float = s * sg
        var cw: float = c * sg
        (parts[side + "thigh"] as Node3D).rotation.z = sw * 0.62 * amp
        (parts[side + "knee"] as Node3D).rotation.z = -(maxf(0.0, cw) * 0.85 + 0.05) * amp
        (parts[side + "sh"] as Node3D).rotation.z = -sw * 0.5 * amp + br
        (parts[side + "el"] as Node3D).rotation.z = 0.25 + (0.35 + maxf(0.0, -sw) * 0.3) * amp
    var torso: Node3D = parts["torso"]
    torso.rotation.y = s * 0.12 * amp
    torso.rotation.z = -0.07 * amp + br
    (parts["head"] as Node3D).rotation.z = 0.07 * amp
    (parts["head"] as Node3D).rotation.y = -steer_vis * 0.35 - s * 0.05 * amp
    if hop_t > 0.0:
        var k: float = sin(clampf(hop_t / 0.4, 0.0, 1.0) * PI)
        (parts["rsh"] as Node3D).rotation.z = 1.25 * k
        (parts["rel"] as Node3D).rotation.z = 0.35 * k
        torso.rotation.z = 0.14 * k

# ----------------------------------------------------------------- enter / leave

func can_enter() -> bool:
    if on or g == null:
        return false
    if v.hb != null and (v.hb.on or v.hb.sailing):
        return false
    if g.ui_root == null or not g.ui_root.visible:
        return false
    if g._any_panel_open():
        return false
    return true

func enter() -> void:
    if on or not can_enter():
        return
    _ensure_hud()
    _build()
    _make_obstacles()
    on = true
    g.owner_on = true
    if bottom_bar == null:
        for c in g.ui_root.get_children():
            if c is HBoxContainer and absf((c as Control).anchor_left - 0.22) < 0.01 and (c as Control).anchor_top == 1.0:
                bottom_bar = c
    if bottom_bar != null:
        bottom_bar.visible = false
    top_view = false
    player.visible = true
    cam_h = heading
    enter_btn.visible = false
    exit_btn.visible = true
    view_btn.visible = true
    view_btn.text = "TOP VIEW"
    joy.visible = true
    speed = 0.0
    _update_cam(1.0)
    cam.make_current()
    g._show_toast("You are the farmer! Walk up to animals, crops and shops.")

func leave() -> void:
    if not on:
        return
    on = false
    g.owner_on = false
    player.visible = false
    g.camera.make_current()
    if bottom_bar != null:
        bottom_bar.visible = true
    exit_btn.visible = false
    view_btn.visible = false
    joy.visible = false
    act_btn.visible = false
    (joy as SailScript.Joy).vec = Vector2.ZERO
    g.cam_zoom = 16.8
    g.cam_target = Vector3(0.0, 0.25, 0.0)
    g._update_camera()
    if g.crop_bar != null and not g.crop_bar_dismissed:
        g.crop_bar.visible = true

func _toggle_view() -> void:
    top_view = not top_view
    view_btn.text = "WALK VIEW" if top_view else "TOP VIEW"
    if top_view:
        g.cam_zoom = 11.0
        g.cam_target = player.position
        g.camera.make_current()
    else:
        cam.make_current()

# ----------------------------------------------------------------- actions

func _near_producer() -> Dictionary:
    var best: Dictionary = {}
    var best_d: float = 2.5
    for p in g.producers:
        if not bool(p["ready"]):
            continue
        var n: Node3D = p["node"]
        if not is_instance_valid(n):
            continue
        var d: float = Vector2(n.global_position.x - player.position.x, n.global_position.z - player.position.z).length()
        if d < best_d:
            best_d = d
            best = {"type": "prod", "p": p, "pos": n.global_position}
    return best

func _near_plot() -> Dictionary:
    var best_key: String = ""
    var best_d: float = g.CELL * 0.85
    for k in g.plot_centers.keys():
        var c: Vector3 = g.plot_centers[k]
        var d: float = maxf(absf(c.x - player.position.x), absf(c.z - player.position.z))
        if d < best_d:
            best_d = d
            best_key = str(k)
    if best_key == "":
        return {}
    var st: Dictionary = g.crop_states[best_key]
    var c2: Vector3 = g.plot_centers[best_key]
    var planted: bool = bool(st.get("planted", false))
    var ripe: bool = planted and float(st.get("age", 0.0)) >= g._grow_time_of(st)
    if v.care.has(best_key) and not ripe:
        var kind: String = str(v.care[best_key])
        return {"type": "care", "key": best_key, "pos": c2, "label": "WATER THE CROP" if kind == "water" else "PULL THE WEEDS"}
    if ripe:
        return {"type": "harvest", "key": best_key, "pos": c2, "label": "HARVEST"}
    if not planted and still_t > 0.35:
        return {"type": "plant", "key": best_key, "pos": c2, "label": "PLANT SEEDS (%d)" % g.seeds}
    return {}

func _near_building() -> Dictionary:
    var pp := Vector2(player.position.x, player.position.z)
    if pp.distance_to(Vector2(g.OVEN_POS.x, g.OVEN_POS.z)) < 3.6:
        return {"type": "bakery", "pos": g.OVEN_POS, "label": "OPEN BAKERY"}
    for mp in [g.BARN_POS, g.MARKET_POS, g.SILO_POS]:
        if pp.distance_to(Vector2(mp.x, mp.z)) < 3.7:
            return {"type": "market", "pos": mp, "label": "OPEN MARKET"}
    if pp.distance_to(Vector2(g.WM_POS.x, g.WM_POS.z)) < 3.8:
        return {"type": "windmill", "pos": g.WM_POS, "label": "WINDMILL"}
    return {}

func _find_target() -> void:
    target = _near_producer()
    if target.is_empty():
        target = _near_plot()
        if not target.is_empty() and str(target["type"]) == "plant":
            var b: Dictionary = _near_building()
            if not b.is_empty():
                target = b
    if target.is_empty():
        target = _near_building()
    if target.is_empty():
        act_btn.visible = false
        return
    act_btn.visible = not g._any_panel_open()
    if str(target["type"]) == "prod":
        var kind: int = int(target["p"]["kind"])
        act_btn.text = "COLLECT " + str(g.PROD_NAMES[kind]).to_upper()
    else:
        act_btn.text = str(target["label"])

func _act() -> void:
    if not on or target.is_empty() or g._any_panel_open():
        return
    var pos: Vector3 = target["pos"]
    var d := Vector2(pos.x - player.position.x, pos.z - player.position.z)
    if d.length() > 0.3:
        heading = atan2(-d.y, d.x)
    hop_t = 0.4
    var ty: String = str(target["type"])
    if ty == "prod":
        g._collect_producer(target["p"])
    elif ty == "plant" or ty == "harvest" or ty == "care":
        var old: String = g.active_action
        g.active_action = "harvest" if ty == "harvest" else "plant"
        g._flash_cell(str(target["key"]))
        g._apply_plot_action(str(target["key"]))
        g.active_action = old
    elif ty == "bakery":
        g._open_bakery()
    elif ty == "market":
        g._open_market()
    elif ty == "windmill":
        g._tap_buildings(Vector3(g.WM_POS.x - 1.3, 0.0, g.WM_POS.z - 1.95))
    target = {}

# ----------------------------------------------------------------- per frame

func _update_cam(k: float) -> void:
    var dir := Vector3(cos(cam_h), 0.0, -sin(cam_h))
    var p: Vector3 = player.position
    var want_d: float = 4.4
    var d: float = 4.4
    while d > 1.7:
        var q: Vector3 = p - dir * d
        var clear: bool = true
        for o in obstacles:
            var ov: Vector3 = o
            if Vector2(q.x - ov.x, q.z - ov.y).length() < ov.z + 1.3:
                clear = false
                break
        if clear:
            break
        d -= 0.35
    want_d = d
    cam_dist = lerpf(cam_dist, want_d, 0.25 if want_d < cam_dist else 0.05)
    var cp: Vector3 = p - dir * cam_dist + Vector3(0.0, 2.1 + cam_dist * 0.14, 0.0)
    cam.global_position = cam.global_position.lerp(cp, k) if k < 1.0 else cp
    cam.look_at(p + Vector3(0.0, 1.0, 0.0) + dir * 2.2, Vector3.UP)

func tick(delta: float) -> void:
    t += delta
    if hud == null:
        if g != null and g.ui_root != null:
            _ensure_hud()
        else:
            return
    if not on:
        enter_btn.visible = can_enter()
        return
    if g.crop_bar != null:
        g.crop_bar.visible = false
    var jv: Vector2 = (joy as SailScript.Joy).vec
    var busy: bool = g._any_panel_open()
    var steer: float = jv.x if (absf(jv.x) > 0.12 and not busy) else 0.0
    var thr: float = -jv.y if not busy else 0.0
    if absf(thr) < 0.12:
        thr = 0.0
    var tspeed: float = thr * WALK_SPEED if thr > 0.0 else thr * WALK_SPEED * 0.5
    speed = move_toward(speed, tspeed, 14.0 * delta)
    var turn: float = deg_to_rad(110.0)
    if steer != 0.0:
        heading -= steer * turn * delta
    steer_vis = lerpf(steer_vis, steer, clampf(8.0 * delta, 0.0, 1.0))
    var dir := Vector3(cos(heading), 0.0, -sin(heading))
    var p: Vector3 = player.position + dir * speed * delta
    var all_obs: Array = obstacles.duplicate()
    for vn in ["Tractor", "Ambulance", "Pickup"]:
        var vnode: Node3D = g.get_node_or_null(vn)
        if vnode != null and vnode.visible:
            all_obs.append(Vector3(vnode.global_position.x, vnode.global_position.z, 1.5))
    for o in all_obs:
        var ov: Vector3 = o
        var dd := Vector2(p.x - ov.x, p.z - ov.y)
        if dd.length() < ov.z:
            var n: Vector2 = dd.normalized() if dd.length() > 0.001 else Vector2(1, 0)
            p.x = ov.x + n.x * ov.z
            p.z = ov.y + n.y * ov.z
    p.x = clampf(p.x, -LIMIT, LIMIT)
    p.z = clampf(p.z, -LIMIT, LIMIT)
    var moved: float = Vector2(p.x - player.position.x, p.z - player.position.z).length()
    phase += moved * 3.2
    player.position.x = p.x
    player.position.z = p.z
    if hop_t > 0.0:
        hop_t -= delta
    player.position.y = GROUND_Y
    player.rotation.y = heading
    _animate(moved > 0.002, clampf(absf(speed) / WALK_SPEED, 0.0, 1.0), delta)
    still_t = still_t + delta if moved < 0.002 else 0.0
    var night: float = clampf(float(g.lamp_mat.emission_energy_multiplier) / 2.2, 0.0, 1.0) if g.lamp_mat != null else 0.0
    glow.light_energy = night * 1.6
    cam_h = lerp_angle(cam_h, heading, clampf(1.0 - exp(-3.2 * delta), 0.0, 1.0))
    if top_view:
        g.cam_target = g.cam_target.lerp(player.position, clampf(1.0 - exp(-6.0 * delta), 0.0, 1.0))
        g._update_camera()
    else:
        _update_cam(clampf(1.0 - exp(-12.0 * delta), 0.0, 1.0))
    _find_target()
