extends Node
# Your own ship (v29): buy it at the Lighthouse Harbour, then sail it over the whole
# farm sea with a round joystick. A brake button stops the ship and a horn button
# sounds the horn. The ship cannot sail through land, mountains or islands.

var g: Node
var hb: Node

const SHIP_LV := 8
const SHIP_COST := 1500
const START := Vector3(45.0, -0.45, -3.0)
const MAX_SPEED := 9.0
const ACCEL := 2.6
const DECEL := 1.6
const BRAKE_DECEL := 9.0
const SEA_LIMIT := 190.0
const MOOR := Vector3(11.5, -0.35, 0.3)

var active: bool = false
var mode: int = 0                # 0 = harbour sea, 1 = farm sea
var back_btn: Button
var note_label: Label
var note_t: float = 0.0
var ship: Node3D
var speed: float = 0.0
var yaw: float = 0.0
var braked: bool = false
var horn_cool: float = 0.0
var joy_was_held: bool = false
var t: float = 0.0
# captain view (first person from the bridge)
var captain: bool = false
var cap_cam: Camera3D
var cap_btn: Button
var cap_hud: Control
var wheel: Control
var hull_nodes: Array = []
var steer_vis: float = 0.0
var obstacles: Array = []       # Vector3(x, z, radius)
var wake: CPUParticles3D
var toot: Label3D
var toot_t: float = 0.0

var hud: CanvasLayer
var joy: Control
var speed_label: Label
var brake_btn: Button
var horn_btn: Button
var hud_built: bool = false

# ----------------------------------------------------------------- joystick control

class Joy extends Control:
    var vec: Vector2 = Vector2.ZERO
    var held: bool = false
    func _ready() -> void:
        mouse_filter = Control.MOUSE_FILTER_STOP
    var tid: int = -1                # the finger that owns the joystick (multi-touch)
    func _input(e: InputEvent) -> void:
        if not is_visible_in_tree():
            return
        if e is InputEventScreenTouch:
            var t: InputEventScreenTouch = e
            if t.pressed and tid == -1 and get_global_rect().has_point(t.position):
                tid = t.index
                held = true
                _update_vec(t.position - global_position)
                get_viewport().set_input_as_handled()
            elif not t.pressed and t.index == tid:
                tid = -1
                held = false
                vec = Vector2.ZERO
                queue_redraw()
                get_viewport().set_input_as_handled()
        elif e is InputEventScreenDrag and (e as InputEventScreenDrag).index == tid:
            _update_vec((e as InputEventScreenDrag).position - global_position)
            get_viewport().set_input_as_handled()
    func _gui_input(e: InputEvent) -> void:
        if DisplayServer.is_touchscreen_available():
            return                   # touch is handled by _input above, per finger
        if e is InputEventMouseButton and (e as InputEventMouseButton).button_index == MOUSE_BUTTON_LEFT:
            held = (e as InputEventMouseButton).pressed
            if held:
                _update_vec((e as InputEventMouseButton).position)
            else:
                vec = Vector2.ZERO
                queue_redraw()
        elif e is InputEventMouseMotion and held:
            _update_vec((e as InputEventMouseMotion).position)
    func _update_vec(p: Vector2) -> void:
        var c: Vector2 = size * 0.5
        var r: float = size.x * 0.5
        vec = ((p - c) / r).limit_length(1.0)
        queue_redraw()
    func _draw() -> void:
        var c: Vector2 = size * 0.5
        var r: float = size.x * 0.5
        draw_circle(c, r, Color(0.05, 0.12, 0.2, 0.45))
        draw_arc(c, r - 2.0, 0.0, TAU, 48, Color(1, 1, 1, 0.75), 4.0)
        draw_arc(c, r * 0.5, 0.0, TAU, 40, Color(1, 1, 1, 0.25), 2.0)
        for a in [0.0, PI * 0.5, PI, PI * 1.5]:
            var d := Vector2(cos(a), sin(a))
            draw_line(c + d * r * 0.62, c + d * r * 0.86, Color(1, 1, 1, 0.55), 4.0)
        var k: Vector2 = c + vec * (r - 40.0)
        draw_circle(k, 40.0, Color(1, 1, 1, 0.92))
        draw_arc(k, 40.0, 0.0, TAU, 32, Color(0.2, 0.45, 0.75, 1.0), 4.0)

# ----------------------------------------------------------------- the ship model

class Wheel extends Control:
    var angle: float = 0.0
    func _draw() -> void:
        var c: Vector2 = size * 0.5
        var r: float = minf(size.x, size.y) * 0.46
        draw_circle(c, r * 0.2, Color(0.35, 0.2, 0.1))
        for i in range(8):
            var a: float = angle + float(i) * TAU / 8.0
            var d := Vector2(cos(a), sin(a))
            draw_line(c + d * r * 0.2, c + d * r * 1.12, Color(0.45, 0.27, 0.12), 8.0)
            draw_circle(c + d * r * 1.12, 8.0, Color(0.55, 0.34, 0.16))
        draw_arc(c, r, 0.0, TAU, 48, Color(0.5, 0.3, 0.14), 14.0)
        draw_arc(c, r, 0.0, TAU, 48, Color(0.68, 0.45, 0.22), 5.0)

func make_ship() -> Node3D:
    var s := Node3D.new()
    var hull := Color(0.12, 0.45, 0.55)
    var white := Color(0.97, 0.97, 0.94)
    g._box(s, Vector3(5.0, 0.8, 1.7), Vector3(0, 0.2, 0), hull, "Hull")
    g._box(s, Vector3(5.2, 0.14, 1.8), Vector3(0, 0.66, 0), Color(0.95, 0.95, 0.92), "Rail")
    var bow: MeshInstance3D = g._box(s, Vector3(1.2, 0.8, 1.2), Vector3(-2.7, 0.2, 0), hull, "Bow")
    bow.rotation_degrees.y = 45.0
    g._box(s, Vector3(1.6, 0.9, 1.3), Vector3(0.6, 1.15, 0), white, "Cabin")
    g._box(s, Vector3(1.0, 0.7, 1.1), Vector3(0.9, 1.9, 0), white, "Bridge")
    g._box(s, Vector3(0.2, 0.3, 1.15), Vector3(0.2, 1.9, 0), Color(0.33, 0.76, 0.92), "Glass")
    g._disc(s, 0.22, 0.7, Vector3(1.5, 2.2, 0), Color(0.85, 0.22, 0.20), "Funnel", 0.8, 10)
    g._box(s, Vector3(0.07, 1.6, 0.07), Vector3(-0.9, 1.5, 0), Color(0.55, 0.55, 0.58), "Mast")
    g._box(s, Vector3(0.5, 0.3, 0.04), Vector3(-0.65, 2.15, 0), Color(0.95, 0.75, 0.2), "Flag")
    g._disc(s, 0.18, 0.12, Vector3(-1.2, 0.8, 0.85), Color(0.95, 0.4, 0.1), "Buoy", 0.8, 10)
    g._disc(s, 0.18, 0.12, Vector3(-1.2, 0.8, -0.85), Color(0.95, 0.4, 0.1), "Buoy", 0.8, 10)
    return s

# ----------------------------------------------------------------- buy / sail

func enter_or_buy(m: int = 0) -> void:
    if not hb.unlocked:
        return
    if not hb.ship_owned:
        if int(g.level) < SHIP_LV:
            hb.say("You need Level %d to buy a ship." % SHIP_LV)
            return
        if int(g.coins) < SHIP_COST:
            hb.say("You need %d coins to buy a ship." % SHIP_COST)
            return
        g.coins -= SHIP_COST
        g._play_named("jingle", -6.0)
        hb.ship_owned = true
        hb.refresh_moored()
        g._refresh_ui()
        g._save_game()
        hb.say("You bought a ship! Choose SAIL HARBOUR SEA or SAIL FARM SEA.")
        return
    hb._fade_to(func(): _start_sail(m))

func _build_obstacles(m: int) -> void:
    obstacles.clear()
    if m == 1:
        for isle in hb.v.ISLES:
            var c: Vector2 = isle["c"]
            obstacles.append(Vector3(c.x, c.y, float(isle["r"]) + 1.6))
        for mt in g.mountain_discs:
            var mv: Vector3 = mt
            obstacles.append(Vector3(mv.x, mv.y, mv.z * 1.3))
        obstacles.append(Vector3(g.CARRIER_POS.x, g.CARRIER_POS.z, 8.0))
        obstacles.append(Vector3(g.HYDRO_POS.x, g.HYDRO_POS.z, 4.0))
    else:
        # harbour land (local harbour coordinates)
        obstacles.append(Vector3(-9.0, -7.0, 19.6))
        obstacles.append(Vector3(-22.0, -16.0, 8.8))
        for x in [6.0, 8.0, 10.0, 12.0, 14.0, 16.0]:
            obstacles.append(Vector3(x, 3.0, 2.4))
        for z in [-22.0, -24.0, -26.0, -28.0, -30.0]:
            obstacles.append(Vector3(-9.0, z, 2.0))

func _start_sail(m: int) -> void:
    if active:
        return
    mode = m
    _build_hud()
    _build_obstacles(m)
    hb.sailing = true
    active = true
    hb.ui.visible = false
    hb.hide_moored()
    ship = make_ship()
    if m == 1:
        ship.position = START
        g.add_child(ship)
        yaw = 0.0
        back_btn.text = "< BACK TO FARM"
    else:
        ship.position = MOOR
        hb.root3.add_child(ship)
        yaw = PI            # bow points out to sea, away from the dock
        back_btn.text = "< BACK TO DOCK"
    speed = 0.0
    braked = false
    ship.rotation.y = yaw
    hull_nodes = ship.get_children()
    _make_cap_cam()
    _make_wake()
    toot = g._label3d(ship, "TOOOT!", Vector3(0, 3.6, 0), 0.02, Color(1.0, 0.95, 0.5))
    toot.visible = false
    g.cam_zoom = 14.0
    g.cam_target = ship.global_position + Vector3(0, 0.3, 0)
    g._update_camera()
    hud.visible = true

func _make_cap_cam() -> void:
    cap_cam = Camera3D.new()
    cap_cam.fov = 72.0
    cap_cam.near = 0.1
    cap_cam.far = 400.0
    cap_cam.position = Vector3(-0.3, 2.4, 0.0)
    cap_cam.rotation = Vector3(deg_to_rad(-4.0), PI * 0.5, 0.0)
    ship.add_child(cap_cam)

func set_captain(on: bool) -> void:
    if on == captain or ship == null:
        return
    captain = on
    for n in hull_nodes:
        if is_instance_valid(n):
            (n as Node3D).visible = not on
    if on:
        cap_cam.make_current()
        cap_btn.text = "SKY VIEW"
        note("CAPTAIN VIEW: stick left/right steers, up = go, down = slow")
    else:
        g.camera.make_current()
        cap_btn.text = "CAPTAIN VIEW"
    if cap_hud != null:
        cap_hud.visible = on

func _on_cap_btn() -> void:
    set_captain(not captain)

func note(msg: String) -> void:
    if note_label != null:
        note_label.text = msg
        note_label.visible = true
        note_t = 3.5

func _on_back() -> void:
    if mode == 0:
        hb._fade_to(func():
            stop_sail()
            hb.home_view())
    else:
        hb.leave()

func stop_sail() -> void:
    if not active:
        return
    if captain:
        set_captain(false)
    active = false
    hb.sailing = false
    if hud != null:
        hud.visible = false
    if hb.on and mode == 0:
        hb.ui.visible = true
    if ship != null:
        ship.queue_free()
        ship = null
        cap_cam = null
    hb.refresh_moored()

func _make_wake() -> void:
    wake = CPUParticles3D.new()
    wake.amount = 60
    wake.lifetime = 1.8
    wake.local_coords = false
    wake.emitting = false
    wake.direction = Vector3(0, 0.1, 0)
    wake.spread = 70.0
    wake.initial_velocity_min = 0.2
    wake.initial_velocity_max = 0.7
    wake.gravity = Vector3.ZERO
    wake.scale_amount_min = 0.5
    wake.scale_amount_max = 1.1
    var m := SphereMesh.new()
    m.radius = 0.22
    m.height = 0.2
    m.radial_segments = 8
    m.rings = 3
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(1, 1, 1, 0.8)
    mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    m.material = mat
    wake.mesh = m
    wake.position = Vector3(2.6, 0.05, 0)
    ship.add_child(wake)

# ----------------------------------------------------------------- HUD

func _build_hud() -> void:
    if hud_built:
        return
    hud_built = true
    hud = CanvasLayer.new()
    hud.layer = 61
    hud.visible = false
    add_child(hud)
    var back := Button.new()
    back.text = "< BACK TO FARM"
    back.offset_left = 14.0
    back.offset_top = 14.0
    back.offset_right = 270.0
    back.offset_bottom = 78.0
    back.add_theme_font_size_override("font_size", 22)
    back.pressed.connect(_on_back)
    hud.add_child(back)
    back_btn = back
    cap_hud = Control.new()
    cap_hud.set_anchors_preset(Control.PRESET_FULL_RECT)
    cap_hud.mouse_filter = Control.MOUSE_FILTER_IGNORE
    cap_hud.visible = false
    hud.add_child(cap_hud)
    var dash := ColorRect.new()
    dash.color = Color(0.18, 0.11, 0.06)
    dash.anchor_left = 0.0
    dash.anchor_right = 1.0
    dash.anchor_top = 1.0
    dash.anchor_bottom = 1.0
    dash.offset_top = -120.0
    dash.mouse_filter = Control.MOUSE_FILTER_IGNORE
    cap_hud.add_child(dash)
    var top := ColorRect.new()
    top.color = Color(0.18, 0.11, 0.06)
    top.anchor_right = 1.0
    top.offset_bottom = 10.0
    top.mouse_filter = Control.MOUSE_FILTER_IGNORE
    cap_hud.add_child(top)
    for side in [0.0, 1.0]:
        var pil := ColorRect.new()
        pil.color = Color(0.18, 0.11, 0.06)
        pil.anchor_left = side
        pil.anchor_right = side
        pil.anchor_bottom = 1.0
        pil.offset_left = 0.0 if side == 0.0 else -12.0
        pil.offset_right = 12.0 if side == 0.0 else 0.0
        pil.mouse_filter = Control.MOUSE_FILTER_IGNORE
        cap_hud.add_child(pil)
    wheel = Wheel.new()
    wheel.anchor_left = 0.5
    wheel.anchor_right = 0.5
    wheel.anchor_top = 1.0
    wheel.anchor_bottom = 1.0
    wheel.offset_left = -105.0
    wheel.offset_right = 105.0
    wheel.offset_top = -170.0
    wheel.offset_bottom = 40.0
    wheel.mouse_filter = Control.MOUSE_FILTER_IGNORE
    cap_hud.add_child(wheel)
    cap_btn = Button.new()
    cap_btn.text = "CAPTAIN VIEW"
    cap_btn.offset_left = 14.0
    cap_btn.offset_top = 86.0
    cap_btn.offset_right = 270.0
    cap_btn.offset_bottom = 142.0
    cap_btn.add_theme_font_size_override("font_size", 20)
    cap_btn.pressed.connect(_on_cap_btn)
    hud.add_child(cap_btn)
    note_label = Label.new()
    note_label.anchor_left = 0.15
    note_label.anchor_right = 0.85
    note_label.anchor_top = 0.0
    note_label.offset_top = 88.0
    note_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    note_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    note_label.add_theme_font_size_override("font_size", 22)
    note_label.add_theme_color_override("font_color", Color.WHITE)
    note_label.add_theme_color_override("font_shadow_color", Color(0.05, 0.1, 0.2))
    note_label.add_theme_constant_override("shadow_offset_x", 2)
    note_label.add_theme_constant_override("shadow_offset_y", 2)
    note_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
    note_label.visible = false
    hud.add_child(note_label)
    speed_label = Label.new()
    speed_label.anchor_left = 0.35
    speed_label.anchor_right = 0.65
    speed_label.offset_top = 16.0
    speed_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    speed_label.add_theme_font_size_override("font_size", 26)
    speed_label.add_theme_color_override("font_color", Color(1, 0.95, 0.6))
    speed_label.add_theme_color_override("font_shadow_color", Color(0.05, 0.1, 0.2))
    speed_label.add_theme_constant_override("shadow_offset_x", 2)
    speed_label.add_theme_constant_override("shadow_offset_y", 2)
    hud.add_child(speed_label)
    joy = Joy.new()
    joy.anchor_top = 1.0
    joy.anchor_bottom = 1.0
    joy.offset_left = 36.0
    joy.offset_right = 306.0
    joy.offset_top = -306.0
    joy.offset_bottom = -36.0
    hud.add_child(joy)
    brake_btn = _round_button("BRAKE", Color(0.85, 0.2, 0.2), -150.0)
    brake_btn.pressed.connect(_on_brake)
    horn_btn = _round_button("HORN", Color(0.95, 0.72, 0.15), -300.0)
    horn_btn.pressed.connect(_on_horn)

func _round_button(txt: String, col: Color, off_x: float) -> Button:
    var b := Button.new()
    b.text = txt
    b.anchor_left = 1.0
    b.anchor_right = 1.0
    b.anchor_top = 1.0
    b.anchor_bottom = 1.0
    b.offset_left = off_x - 6.0
    b.offset_right = off_x + 114.0
    b.offset_top = -156.0
    b.offset_bottom = -36.0
    b.add_theme_font_size_override("font_size", 22)
    b.add_theme_color_override("font_color", Color.WHITE)
    b.add_theme_color_override("font_pressed_color", Color.WHITE)
    for st in ["normal", "hover", "pressed", "focus"]:
        var sb := StyleBoxFlat.new()
        sb.bg_color = col if st != "pressed" else col.darkened(0.3)
        sb.set_corner_radius_all(60)
        sb.border_color = Color(1, 1, 1, 0.9)
        sb.set_border_width_all(4)
        sb.shadow_color = Color(0, 0, 0, 0.3)
        sb.shadow_size = 4
        b.add_theme_stylebox_override(st, sb)
    hud.add_child(b)
    return b

func _on_brake() -> void:
    braked = true

func _on_horn() -> void:
    if horn_cool > 0.0:
        return
    horn_cool = 1.0
    g._play_named("horn", -1.0)
    if toot != null:
        toot.visible = true
        toot_t = 1.1

# ----------------------------------------------------------------- sailing

func tick(delta: float) -> void:
    if not active or ship == null:
        return
    t += delta
    horn_cool = maxf(0.0, horn_cool - delta)
    if note_label != null and note_label.visible:
        note_t -= delta
        if note_t <= 0.0:
            note_label.visible = false
    if toot != null and toot.visible:
        toot_t -= delta
        if toot_t <= 0.0:
            toot.visible = false
    var jv: Vector2 = (joy as Joy).vec
    var held: bool = (joy as Joy).held
    if held and not joy_was_held:
        braked = false       # touching the joystick again releases the brake
    joy_was_held = held
    var mag: float = jv.length()
    if mag < 0.12:
        mag = 0.0
    var cb: Basis = g.camera.global_transform.basis
    var right := Vector3(cb.x.x, 0.0, cb.x.z).normalized()
    var up := Vector3(-cb.z.x, 0.0, -cb.z.z).normalized()
    var want: Vector3 = right * jv.x + up * (-jv.y)
    var target_speed: float = 0.0
    if captain:
        var steer: float = (jv.x if absf(jv.x) > 0.12 else 0.0)
        var thr: float = (-jv.y if jv.y < -0.12 else 0.0)
        if not braked:
            target_speed = thr * MAX_SPEED
            yaw -= steer * deg_to_rad(28.0 + 40.0 * clampf(speed / 3.0, 0.0, 1.0)) * delta
        steer_vis = lerpf(steer_vis, steer, clampf(8.0 * delta, 0.0, 1.0))
        if wheel != null:
            (wheel as Wheel).angle = steer_vis * 1.6
            wheel.queue_redraw()
    elif mag > 0.0 and not braked:
        target_speed = mag * MAX_SPEED
        var want_yaw: float = atan2(want.z, -want.x)
        var diff: float = wrapf(want_yaw - yaw, -PI, PI)
        var rate: float = deg_to_rad(35.0 + 75.0 * clampf(speed / 3.0, 0.0, 1.0))
        var step: float = clampf(diff, -rate * delta, rate * delta)
        yaw += step
    if braked:
        speed = move_toward(speed, 0.0, BRAKE_DECEL * delta)
    elif target_speed > speed:
        speed = move_toward(speed, target_speed, ACCEL * delta)
    else:
        speed = move_toward(speed, target_speed, DECEL * delta)
    var dir := Vector3(-cos(yaw), 0.0, sin(yaw))
    var p: Vector3 = ship.position + dir * speed * delta
    # stay out of land, mountains and islands
    var hit: bool = false
    var dyn: Array = []
    if mode == 0 and hb.ship != null and is_instance_valid(hb.ship) and (hb.state == 1 or hb.state == 2 or hb.state == 4):
        dyn.append(Vector3(hb.ship.position.x, hb.ship.position.z, 3.6))
    for o in obstacles + dyn:
        var ov: Vector3 = o
        var d := Vector2(p.x - ov.x, p.z - ov.y)
        if d.length() < ov.z:
            var n: Vector2 = d.normalized() if d.length() > 0.001 else Vector2(1, 0)
            p.x = ov.x + n.x * ov.z
            p.z = ov.y + n.y * ov.z
            hit = true
    if mode == 1 and absf(p.x) < 20.8 and absf(p.z) < 20.8:
        var dx: float = 20.8 - absf(p.x)
        var dz: float = 20.8 - absf(p.z)
        if dx < dz:
            p.x = 20.8 * signf(p.x if p.x != 0.0 else 1.0)
        else:
            p.z = 20.8 * signf(p.z if p.z != 0.0 else 1.0)
        hit = true
    var lim: float = SEA_LIMIT if mode == 1 else 170.0
    p.x = clampf(p.x, -lim, lim)
    p.z = clampf(p.z, -lim, lim)
    if hit:
        speed *= 0.92
    ship.position.x = p.x
    ship.position.z = p.z
    ship.position.y = -0.45 + sin(t * 1.6) * 0.04
    ship.rotation.y = yaw
    ship.rotation.z = sin(t * 1.2) * 0.012
    if wake != null:
        wake.emitting = speed > 0.6
        wake.amount = 60
    speed_label.text = "SPEED %.1f kn%s" % [speed * 1.6, "   BRAKE ON" if braked and speed < 0.2 else ""]
    if captain and cap_cam != null:
        cap_cam.rotation.z = sin(t * 1.1) * 0.02 - steer_vis * 0.05 * clampf(speed / 4.0, 0.0, 1.0)
        cap_cam.rotation.x = deg_to_rad(-4.0) + sin(t * 1.7) * 0.012
        cap_cam.position.y = 2.4 + sin(t * 1.6) * 0.05
    # the camera follows the ship
    var tgt: Vector3 = ship.global_position + Vector3(0, 0.3, 0)
    g.cam_target = g.cam_target.lerp(tgt, clampf(1.0 - exp(-6.0 * delta), 0.0, 1.0))
    g._update_camera()
