package com.rajeev.familyshield.child

import android.app.AppOpsManager
import android.app.admin.DevicePolicyManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Process
import android.provider.Settings
import android.telecom.TelecomManager
import androidx.core.content.ContextCompat
import com.rajeev.familyshield.data.Day
import com.rajeev.familyshield.data.Prefs
import com.rajeev.familyshield.data.Rules
import java.util.Calendar

/** Latest rules from the parent, kept in memory and saved on the phone. */
object RulesStore {
    @Volatile
    var rules: Rules = Rules()
        private set
    private var loaded = false

    fun get(ctx: Context): Rules {
        if (!loaded) {
            rules = Rules.fromJson(Prefs(ctx).rulesJson)
            loaded = true
        }
        return rules
    }

    fun set(ctx: Context, r: Rules) {
        rules = r
        loaded = true
        Prefs(ctx).rulesJson = r.toJson()
    }

    fun clear(ctx: Context) = set(ctx, Rules())
}

/** Reads per-app screen time from Android's usage stats. */
object UsageTracker {
    private var cache: Map<String, Long> = emptyMap()
    private var cacheTime = 0L
    private var cacheDay = ""

    /** Today's usage in milliseconds, cached for 20 seconds. */
    fun today(ctx: Context, force: Boolean = false): Map<String, Long> {
        val now = System.currentTimeMillis()
        val day = Day.key(now)
        if (!force && day == cacheDay && now - cacheTime < 20_000) return cache
        cache = between(ctx, Day.startOfToday(), now)
        cacheTime = now
        cacheDay = day
        return cache
    }

    fun between(ctx: Context, start: Long, end: Long): Map<String, Long> {
        if (!Perms.hasUsageAccess(ctx)) return emptyMap()
        val usm = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val events = try {
            usm.queryEvents(start, end)
        } catch (e: Exception) {
            return emptyMap()
        }
        val ignore = Essentials.ignoredForUsage(ctx)
        val totals = HashMap<String, Long>()
        var curPkg: String? = null
        var curStart = 0L
        val e = UsageEvents.Event()

        fun close(at: Long) {
            val p = curPkg ?: return
            val d = at - curStart
            if (d > 0 && p !in ignore) totals[p] = (totals[p] ?: 0L) + d
            curPkg = null
        }

        while (events.hasNextEvent()) {
            events.getNextEvent(e)
            val pkg = e.packageName ?: continue
            when (e.eventType) {
                1 -> { // activity resumed
                    if (curPkg != pkg) {
                        close(e.timeStamp)
                        curPkg = pkg
                        curStart = e.timeStamp
                    }
                }
                2, 23 -> if (curPkg == pkg) close(e.timeStamp) // paused / stopped
                16, 17, 26 -> close(e.timeStamp) // screen off / keyguard / shutdown
            }
        }
        // App still open right now.
        if (curPkg != null && end - curStart < 6 * 3600_000L) close(end) else curPkg = null
        return totals
    }

    fun totalMinutes(map: Map<String, Long>) = map.values.sum() / 60_000
}

/** Apps that are never blocked so the phone always stays usable for calls and settings. */
object Essentials {
    private var cached: Set<String>? = null

    fun alwaysAllowed(ctx: Context): Set<String> {
        cached?.let { return it }
        val set = HashSet<String>()
        set += ctx.packageName
        set += listOf(
            "com.android.systemui", "android",
            "com.android.settings", "com.android.phone", "com.android.server.telecom",
            "com.google.android.dialer", "com.android.dialer", "com.samsung.android.dialer",
            "com.android.contacts", "com.google.android.contacts", "com.samsung.android.app.contacts",
            "com.android.emergency", "com.google.android.apps.safetyhub",
            "com.android.permissioncontroller", "com.google.android.permissioncontroller",
            "com.android.packageinstaller", "com.google.android.packageinstaller",
        )
        set += launchers(ctx)
        try {
            val tm = ctx.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
            tm.defaultDialerPackage?.let { set += it }
        } catch (_: Exception) {
        }
        try {
            val ime = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD)
            ime?.substringBefore('/')?.let { set += it }
        } catch (_: Exception) {
        }
        cached = set
        return set
    }

    fun ignoredForUsage(ctx: Context): Set<String> =
        launchers(ctx) + setOf(ctx.packageName, "com.android.systemui", "android")

    fun launchers(ctx: Context): Set<String> {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        return ctx.packageManager.queryIntentActivities(i, 0)
            .map { it.activityInfo.packageName }.toSet()
    }

    fun appLabel(ctx: Context, pkg: String): String = try {
        val pm = ctx.packageManager
        pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) {
        pkg
    }

    /** Apps the child can open from the home screen (excluding our own). */
    fun launchableApps(ctx: Context): Map<String, String> {
        val pm = ctx.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(i, 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .filter { it.first != ctx.packageName }
            .toMap()
    }
}

/** Decides whether an app must be blocked right now and why. */
object BlockPolicy {

    fun reason(ctx: Context, pkg: String): String? {
        if (!Prefs(ctx).linked) return null
        if (pkg in Essentials.alwaysAllowed(ctx)) return null
        val r = RulesStore.get(ctx)

        if (r.bedtimeOn && isBedtime(r)) return "It's bedtime. Apps are paused until morning."
        if (r.studyOn && pkg !in r.studyAllowed) return "Study mode is on. Only study apps are allowed now."
        if (pkg in r.blocked) return "Your parent has blocked this app."

        val needsUsage = r.limits.containsKey(pkg) || r.totalLimit > 0
        if (!needsUsage) return null
        val usage = UsageTracker.today(ctx)
        r.limits[pkg]?.let { limit ->
            val used = (usage[pkg] ?: 0L) / 60_000
            if (used >= limit) return "You've used your ${limit} min for this app today."
        }
        if (r.totalLimit > 0 && UsageTracker.totalMinutes(usage) >= r.totalLimit) {
            return "Today's screen time is over."
        }
        return null
    }

    fun isBedtime(r: Rules): Boolean {
        val c = Calendar.getInstance()
        val now = c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE)
        return if (r.bedStart <= r.bedEnd) now in r.bedStart until r.bedEnd
        else now >= r.bedStart || now < r.bedEnd
    }

    /** Short text shown on the child's home screen. */
    fun currentMode(ctx: Context): String {
        val r = RulesStore.get(ctx)
        return when {
            r.bedtimeOn && isBedtime(r) -> "Bedtime"
            r.studyOn -> "Study mode"
            else -> "Normal"
        }
    }
}

/** Permission checks for the child phone. */
object Perms {
    fun hasUsageAccess(ctx: Context): Boolean {
        val ops = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= 29)
            ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
        else
            @Suppress("DEPRECATION")
            ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
        return mode == AppOpsManager.MODE_ALLOWED
    }

    fun hasAccessibility(ctx: Context): Boolean {
        val enabled = Settings.Secure.getString(
            ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        val me = ComponentName(ctx, GuardAccessibilityService::class.java)
        return enabled.split(':').any {
            ComponentName.unflattenFromString(it) == me
        }
    }

    fun hasLocation(ctx: Context): Boolean =
        ContextCompat.checkSelfPermission(ctx, android.Manifest.permission.ACCESS_FINE_LOCATION) ==
                PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(ctx, android.Manifest.permission.ACCESS_COARSE_LOCATION) ==
                PackageManager.PERMISSION_GRANTED

    fun hasBackgroundLocation(ctx: Context): Boolean =
        Build.VERSION.SDK_INT < 29 || ContextCompat.checkSelfPermission(
            ctx, android.Manifest.permission.ACCESS_BACKGROUND_LOCATION
        ) == PackageManager.PERMISSION_GRANTED

    fun hasNotifications(ctx: Context): Boolean =
        Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(
            ctx, android.Manifest.permission.POST_NOTIFICATIONS
        ) == PackageManager.PERMISSION_GRANTED

    fun isAdmin(ctx: Context): Boolean {
        val dpm = ctx.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        return dpm.isAdminActive(ComponentName(ctx, AdminReceiver::class.java))
    }

    fun ignoresBattery(ctx: Context): Boolean {
        val pm = ctx.getSystemService(Context.POWER_SERVICE) as android.os.PowerManager
        return pm.isIgnoringBatteryOptimizations(ctx.packageName)
    }

    fun protectionMap(ctx: Context): Map<String, Boolean> = mapOf(
        "usage" to hasUsageAccess(ctx),
        "accessibility" to hasAccessibility(ctx),
        "location" to (hasLocation(ctx) && hasBackgroundLocation(ctx)),
        "admin" to isAdmin(ctx),
    )

    fun coreReady(ctx: Context) = hasUsageAccess(ctx) && hasAccessibility(ctx) && hasLocation(ctx)
}
