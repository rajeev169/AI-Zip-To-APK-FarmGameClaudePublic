package com.rajeev.familyshield.child

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import com.rajeev.familyshield.data.Prefs

/**
 * Watches which app comes to the front (only the app name, never screen content)
 * and shows the block screen when the parent's rules say so.
 */
class GuardAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: GuardAccessibilityService? = null
            private set

        /** Package of the app currently in front, as seen by this service. */
        @Volatile
        var currentPackage: String? = null
            private set
    }

    private var lastBlockedPkg: String? = null
    private var lastBlockTime = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        if (Prefs(this).linked) MonitorService.start(this)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        // Keyboard and system overlays should not change the "current app".
        if (pkg == "com.android.systemui" || isKeyboard(pkg)) return
        currentPackage = pkg
        check(pkg)
    }

    private fun isKeyboard(pkg: String): Boolean {
        val ime = android.provider.Settings.Secure.getString(
            contentResolver, android.provider.Settings.Secure.DEFAULT_INPUT_METHOD
        ) ?: return false
        return ime.startsWith("$pkg/")
    }

    /** Called on every app switch and every 30 seconds by MonitorService. */
    fun check(pkg: String? = currentPackage) {
        if (pkg == null || pkg == packageName) return
        val reason = BlockPolicy.reason(this, pkg) ?: return
        val now = System.currentTimeMillis()
        if (pkg == lastBlockedPkg && now - lastBlockTime < 1500) return
        lastBlockedPkg = pkg
        lastBlockTime = now
        performGlobalAction(GLOBAL_ACTION_HOME)
        BlockActivity.show(this, pkg, reason)
        MonitorService.onAppBlocked(this, pkg)
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }
}
