package com.rajeev.familyshield.child

import android.app.admin.DeviceAdminReceiver
import android.content.Context
import android.content.Intent
import com.rajeev.familyshield.data.AlertType
import com.rajeev.familyshield.data.Prefs
import com.rajeev.familyshield.data.Repo

/** Uninstall protection: while active, the app can't be uninstalled without first turning this off. */
class AdminReceiver : DeviceAdminReceiver() {

    override fun onDisableRequested(context: Context, intent: Intent): CharSequence =
        "If you turn this off, Family Shield will tell your parent."

    override fun onDisabled(context: Context, intent: Intent) {
        val prefs = Prefs(context)
        if (prefs.linked) {
            Repo.sendAlert(
                prefs, AlertType.PROTECTION_OFF,
                "Uninstall protection turned off",
                "${prefs.childName.ifBlank { "Your child" }} turned off uninstall protection on their phone."
            )
        }
    }
}
