package com.fluenthire.app.ui

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fluenthire.app.data.Topic
import com.fluenthire.app.data.Topics
import com.fluenthire.app.ui.theme.Indigo
import com.fluenthire.app.ui.theme.Teal

/** Side menu that slides in from the right and lists only practice topics. */
@Composable
fun TopicMenu(open: Boolean, onClose: () -> Unit, onTopic: (Topic) -> Unit) {
    val context = LocalContext.current
    Box(Modifier.fillMaxSize()) {
        AnimatedVisibility(visible = open, enter = fadeIn(), exit = fadeOut()) {
            Box(
                Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.45f))
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onClose() }
            )
        }
        AnimatedVisibility(
            visible = open,
            enter = slideInHorizontally { it },
            exit = slideOutHorizontally { it },
            modifier = Modifier.align(Alignment.CenterEnd),
        ) {
            Column(
                Modifier.fillMaxHeight().width(300.dp)
                    .clip(RoundedCornerShape(topStart = 24.dp, bottomStart = 24.dp))
                    .background(MaterialTheme.colorScheme.surface)
                    // swallow taps so they don't close the menu
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {}
            ) {
                Box(
                    Modifier.fillMaxWidth().background(Brush.verticalGradient(listOf(Indigo, Teal)))
                        .statusBarsPadding().padding(start = 20.dp, end = 8.dp, top = 12.dp, bottom = 20.dp)
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Practice topics", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold,
                                modifier = Modifier.weight(1f))
                            IconButton(onClick = onClose) { Icon(Icons.Filled.Close, "Close menu", tint = Color.White) }
                        }
                        Text("Choose what you want to practise", color = Color.White.copy(alpha = 0.85f), fontSize = 13.sp)
                    }
                }
                Column(
                    Modifier.verticalScroll(rememberScrollState()).padding(12.dp).navigationBarsPadding()
                ) {
                    Topics.all.forEach { topic ->
                        TopicRow(topic) {
                            if (topic.comingSoon) Toast.makeText(context, "Coming soon", Toast.LENGTH_SHORT).show()
                            else onTopic(topic)
                        }
                        Spacer(Modifier.height(8.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun TopicRow(topic: Topic, onClick: () -> Unit) {
    val soon = topic.comingSoon
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
            .background(if (soon) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.primaryContainer)
            .clickable(onClick = onClick)
            .padding(14.dp)
            .alpha(if (soon) 0.6f else 1f),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier.size(42.dp).clip(RoundedCornerShape(12.dp)).background(Color.White.copy(alpha = 0.7f)),
            contentAlignment = Alignment.Center,
        ) { Text(topic.emoji, fontSize = 22.sp) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(topic.title, fontWeight = FontWeight.SemiBold,
                color = if (soon) MaterialTheme.colorScheme.outline else MaterialTheme.colorScheme.onPrimaryContainer)
            Text(topic.subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
        }
        if (soon) {
            Text(
                "Soon", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.outline,
                modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(MaterialTheme.colorScheme.surface)
                    .padding(horizontal = 8.dp, vertical = 3.dp),
            )
        }
    }
}
