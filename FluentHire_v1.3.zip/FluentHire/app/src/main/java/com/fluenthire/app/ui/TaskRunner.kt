package com.fluenthire.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fluenthire.app.AppDeps
import com.fluenthire.app.ai.Coach
import com.fluenthire.app.data.PracticeTask
import com.fluenthire.app.data.Section
import com.fluenthire.app.data.TaskResult
import com.fluenthire.app.scoring.LocalScorer
import kotlinx.coroutines.launch

/** Scores one spoken answer: offline for parts A–D, AI (with offline fallback) for E–F. */
suspend fun scoreTask(t: PracticeTask, answer: String, coach: Coach?): TaskResult = when (t.section) {
    Section.READ, Section.REPEAT, Section.BUILD -> {
        val s = LocalScorer.wordAccuracy(t.target, answer)
        val missed = LocalScorer.missedWords(t.target, answer)
        val note = when {
            s >= 90 -> "Excellent! Clear and accurate."
            missed.isNotEmpty() -> "Correct sentence: \"${t.target}\"\nMissed or unclear: ${missed.take(6).joinToString(", ")}"
            else -> "Correct sentence: \"${t.target}\""
        }
        TaskResult(t, answer, s, note)
    }
    Section.SHORT -> {
        val ok = LocalScorer.shortAnswerCorrect(answer, t.accepted)
        TaskResult(t, answer, if (ok) 100 else 0,
            if (ok) "Correct!" else "Expected answer: ${t.accepted.take(2).joinToString(" or ")}")
    }
    Section.RETELL, Section.OPEN -> {
        val local = if (t.section == Section.RETELL) LocalScorer.retellScore(t.keywords, answer)
        else LocalScorer.openAnswerScore(answer)
        if (coach != null) {
            try {
                val ai = coach.scoreOpen(
                    if (t.section == Section.RETELL) "Story retelling" else "Open opinion question",
                    if (t.section == Section.RETELL) "Retell this story: ${t.audio}" else t.audio ?: "",
                    answer,
                )
                TaskResult(t, answer, ai.score, ai.feedback, ai.hindiTip)
            } catch (e: Exception) {
                TaskResult(t, answer, local, "Scored offline (${e.message}).")
            }
        } else {
            TaskResult(
                t, answer, local,
                "Scored offline. Add a Gemini key in Settings for detailed AI feedback." +
                    if (t.section == Section.RETELL) "\nStory: ${t.audio}" else "",
            )
        }
    }
}

private enum class TPhase { SectionIntro, Task, Scoring, Result }

/**
 * Runs a list of speaking tasks one by one: play audio → record → check → show result → next.
 * Used by the full Practice Test and by every "Test yourself" part.
 */
@Composable
fun ColumnScope.TaskSequence(
    deps: AppDeps,
    tasks: List<PracticeTask>,
    coach: Coach?,
    sectionIntros: Boolean,
    finishLabel: String,
    onFinished: (List<TaskResult>) -> Unit,
) {
    val speech = deps.speech
    val speaker = deps.speaker
    val scope = rememberCoroutineScope()

    var index by remember(tasks) { mutableIntStateOf(0) }
    var phase by remember(tasks) { mutableStateOf(if (sectionIntros) TPhase.SectionIntro else TPhase.Task) }
    var replaysUsed by remember(tasks) { mutableIntStateOf(0) }
    val results = remember(tasks) { mutableStateListOf<TaskResult>() }
    var lastResult by remember(tasks) { mutableStateOf<TaskResult?>(null) }
    val task = tasks.getOrNull(index)

    DisposableEffect(Unit) { onDispose { speech.cancel(); speaker.stop() } }

    fun playAudio(t: PracticeTask, auto: Boolean) {
        val a = t.audio ?: return
        speech.cancel()
        speaker.speak(a) {
            // For short tasks, start listening automatically after the audio, like the real test.
            if (auto && !t.continuous && phase == TPhase.Task && tasks.getOrNull(index) == t) {
                deps.requestMic { speech.start(continuous = false) }
            }
        }
    }

    fun beginTask() {
        val t = tasks.getOrNull(index) ?: return
        speech.clear()
        replaysUsed = 0
        phase = TPhase.Task
        if (t.audio != null) playAudio(t, auto = true)
    }

    fun goTo(i: Int) {
        val t = tasks.getOrNull(i)
        if (t == null) { onFinished(results.toList()); return }
        index = i
        val prev = tasks.getOrNull(i - 1)
        if (sectionIntros && (prev == null || prev.section != t.section)) phase = TPhase.SectionIntro else beginTask()
    }

    fun check(t: PracticeTask, answer: String) {
        phase = TPhase.Scoring
        scope.launch {
            val r = scoreTask(t, answer, coach)
            results += r
            lastResult = r
            phase = TPhase.Result
        }
    }

    LaunchedEffect(tasks) { if (!sectionIntros) beginTask() }

    if (task == null) return

    Text(
        "${task.section.fullTitle}  •  Question ${index + 1} of ${tasks.size}",
        color = MaterialTheme.colorScheme.outline,
    )
    LinearProgressIndicator(
        progress = { index.toFloat() / tasks.size },
        modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
    )

    when (phase) {
        TPhase.SectionIntro -> {
            InfoCard(container = MaterialTheme.colorScheme.primaryContainer) {
                Text("Part ${task.section.letter}", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                Text(task.section.title, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text(task.section.instruction)
            }
            Button(
                onClick = { beginTask() },
                modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(14.dp),
            ) { Text("Begin Part ${task.section.letter}", fontSize = 16.sp) }
        }

        TPhase.Task -> {
            val t = task
            if (t.display != null) {
                InfoCard(container = MaterialTheme.colorScheme.primaryContainer) {
                    Text(t.display, fontSize = 20.sp, lineHeight = 28.sp, fontWeight = FontWeight.Medium)
                }
            }
            if (t.audio != null) {
                InfoCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.AutoMirrored.Filled.VolumeUp, null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(10.dp))
                        Text(
                            if (speaker.isSpeaking) "Listen carefully…" else "Audio finished",
                            modifier = Modifier.weight(1f),
                        )
                        val left = t.maxReplays - replaysUsed
                        TextButton(
                            onClick = { replaysUsed++; playAudio(t, auto = false) },
                            enabled = left > 0 && !speaker.isSpeaking && !speech.isListening,
                        ) { Text("Replay ($left)") }
                    }
                }
            }

            TranscriptBox(
                speech.text,
                if (t.continuous) "Tap the mic and speak. Tap ■ when you finish." else "Tap the mic and speak.",
            )
            speech.error?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }

            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                MicButton(
                    listening = speech.isListening, level = speech.level,
                    enabled = !speaker.isSpeaking,
                    onClick = {
                        if (speech.isListening) speech.stop()
                        else deps.requestMic { speech.start(continuous = t.continuous) }
                    },
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(
                    onClick = { speech.clear() },
                    enabled = speech.text.isNotBlank() && !speech.isListening,
                    modifier = Modifier.weight(1f),
                ) { Icon(Icons.Filled.Refresh, null); Spacer(Modifier.width(4.dp)); Text("Redo") }
                Button(
                    onClick = { check(t, speech.text) },
                    enabled = speech.text.isNotBlank() && !speech.isListening,
                    modifier = Modifier.weight(2f),
                ) { Text("Check") }
            }
            TextButton(
                onClick = {
                    speech.cancel(); speaker.stop()
                    val r = TaskResult(t, "", 0, "Skipped. Correct: \"${t.target.take(160)}\"")
                    results += r; lastResult = r; phase = TPhase.Result
                },
                modifier = Modifier.align(Alignment.CenterHorizontally),
            ) { Text("Skip this question") }
        }

        TPhase.Scoring -> LoadingBlock("Scoring your answer…")

        TPhase.Result -> lastResult?.let { r ->
            InfoCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    ScoreRing(r.score, size = 84.dp)
                    Spacer(Modifier.width(16.dp))
                    Column(Modifier.weight(1f)) {
                        Text(r.task.section.title, color = MaterialTheme.colorScheme.outline)
                        Text(r.note, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
            if (r.answer.isNotBlank()) TranscriptBox(r.answer, "")
            HindiTip(r.hindiTip)
            Button(
                onClick = { goTo(index + 1) },
                modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(14.dp),
            ) { Text(if (index + 1 < tasks.size) "Next" else finishLabel, fontSize = 16.sp) }
        }
    }
}
