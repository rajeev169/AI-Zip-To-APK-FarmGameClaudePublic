package com.fluenthire.app.data

/**
 * Topics shown in the ☰ menu.
 * To add a new topic later: add an entry to [available] (and a screen for it in MainActivity).
 * "Upcoming test idea" is always shown last.
 */
enum class TopicId { TEST_YOURSELF, SENTENCE_BUILDING, UPCOMING }

data class Topic(
    val id: TopicId,
    val emoji: String,
    val title: String,
    val subtitle: String,
    val comingSoon: Boolean = false,
)

object Topics {
    private val available = listOf(
        Topic(TopicId.TEST_YOURSELF, "🎯", "Test yourself", "Practise parts A–F • 5 questions each"),
        Topic(TopicId.SENTENCE_BUILDING, "🧱", "Sentence Building", "Arrange jumbled words into sentences"),
    )

    private val upcoming = Topic(TopicId.UPCOMING, "✨", "Upcoming test idea", "Coming soon", comingSoon = true)

    val all: List<Topic> get() = available + upcoming
}
