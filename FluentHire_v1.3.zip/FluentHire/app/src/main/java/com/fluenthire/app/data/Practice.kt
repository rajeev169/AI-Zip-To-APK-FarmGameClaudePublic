package com.fluenthire.app.data

/** The six Versant-style parts used by the full test and by "Test yourself". */
enum class Section(val letter: String, val title: String, val instruction: String, val weight: Double, val emoji: String) {
    READ("A", "Read Aloud", "Read the sentence on the screen aloud, clearly and naturally.", 0.15, "📖"),
    REPEAT("B", "Repeat", "Listen to the sentence and repeat it exactly. The text is hidden.", 0.20, "🔁"),
    SHORT("C", "Short Answers", "Listen to the question and answer with one word or a few words.", 0.15, "❓"),
    BUILD("D", "Sentence Builds", "You will hear three word groups in a mixed order. Say them as one correct sentence.", 0.15, "🧩"),
    RETELL("E", "Story Retelling", "Listen to a short story, then retell it in your own words. Include as many details as you can.", 0.20, "📚"),
    OPEN("F", "Open Question", "Listen to the question and give your opinion with reasons, for 30 to 60 seconds.", 0.15, "💬");

    val fullTitle: String get() = "$letter. $title"
}

data class PracticeTask(
    val section: Section,
    val display: String?,          // text shown on screen
    val audio: String?,            // text spoken by the app
    val target: String,            // expected text (for local scoring)
    val accepted: List<String> = emptyList(),
    val keywords: List<String> = emptyList(),
    val continuous: Boolean = false,
    val maxReplays: Int = 1,
)

data class TaskResult(
    val task: PracticeTask,
    val answer: String,
    val score: Int,
    val note: String,
    val hindiTip: String = "",
)

object PracticeFactory {

    fun readAloud(text: String) = PracticeTask(Section.READ, text, null, text)
    fun repeat(text: String) = PracticeTask(Section.REPEAT, null, text, text)
    fun shortAnswer(q: String, answers: List<String>) =
        PracticeTask(Section.SHORT, null, q, answers.first(), accepted = answers)

    fun build(phrases: List<String>): PracticeTask {
        var mixed = phrases.shuffled()
        var guard = 0
        while (mixed == phrases && guard++ < 6) mixed = phrases.shuffled()
        return PracticeTask(Section.BUILD, null, mixed.joinToString(" ... "), phrases.joinToString(" "))
    }

    fun retell(story: String, keywords: List<String>) =
        PracticeTask(Section.RETELL, null, story, story, keywords = keywords, continuous = true, maxReplays = 1)

    fun open(q: String) = PracticeTask(Section.OPEN, q, q, q, continuous = true, maxReplays = 1)

    /** [n] built-in (offline) tasks for one part. */
    fun fromBank(section: Section, n: Int): List<PracticeTask> {
        val b = QuestionBank
        return when (section) {
            Section.READ -> b.readAloud.shuffled().take(n).map { readAloud(it) }
            Section.REPEAT -> b.repeat.shuffled().take(n).map { repeat(it) }
            Section.SHORT -> b.shortAnswer.shuffled().take(n).map { shortAnswer(it.question, it.accepted) }
            Section.BUILD -> b.sentenceBuilds.shuffled().take(n).map { build(it.phrases) }
            Section.RETELL -> b.stories.shuffled().take(n).map { retell(it.story, it.keywords) }
            Section.OPEN -> b.openQuestions.shuffled().take(n).map { open(it) }
        }
    }

    /** The full 17-task practice test. */
    fun fullTest(): List<PracticeTask> =
        fromBank(Section.READ, 4) + fromBank(Section.REPEAT, 4) + fromBank(Section.SHORT, 4) +
            fromBank(Section.BUILD, 3) + fromBank(Section.RETELL, 1) + fromBank(Section.OPEN, 1)
}
