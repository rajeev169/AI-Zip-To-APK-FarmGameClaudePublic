package com.fluenthire.app.data

enum class SentenceLevel(val title: String, val emoji: String, val blurb: String, val words: IntRange, val aiStyle: String) {
    EASY("Easy", "🟢", "4–5 words • simple daily sentences", 4..5,
        "very simple present or past tense sentences of 4 to 5 words about daily life or the office"),
    MEDIUM("Medium", "🟡", "6–8 words • with time and place", 6..8,
        "sentences of 6 to 8 words that include a time or place phrase (for example 'every morning', 'at the office')"),
    HARD("Hard", "🔴", "9–12 words • because, although, which", 9..12,
        "sentences of 9 to 12 words using linking words such as because, although, which, when, so that, or if"),
    INTERVIEW("Interview sentences", "💼", "Real lines used in job interviews", 7..12,
        "natural first-person sentences of 7 to 12 words a candidate would say in a job interview in India (about experience, skills, strengths, teamwork, goals)");

    val recordTitle: String get() = "Sentence Building – $title"
}

data class SentenceItem(
    val sentence: String,
    val tip: String = "",
    val hindiTip: String = "",
    val alternatives: List<String> = emptyList(),
)

object SentenceBank {
    private val easy = listOf(
        SentenceItem("She sent the report.", "Subject (She) + verb (sent) + object (the report)."),
        SentenceItem("I like my new job.", "Subject + verb + object. 'My new job' stays together."),
        SentenceItem("The bus was late today.", "Time words like 'today' usually go at the end."),
        SentenceItem("He answers customer calls.", "Subject + verb + object."),
        SentenceItem("We finished the work.", "Subject + verb + object."),
        SentenceItem("They opened a new shop.", "Adjective 'new' comes before the noun 'shop'."),
        SentenceItem("My manager is very kind.", "Subject + is + describing word."),
        SentenceItem("Please call me back.", "Polite request: Please + verb + object."),
        SentenceItem("The office opens at nine.", "Time phrase 'at nine' goes at the end."),
        SentenceItem("I need some help.", "Subject + verb + object."),
    )
    private val medium = listOf(
        SentenceItem("I reach the office at nine every day.", "Subject + verb + place + time.", alternatives = listOf("I reach the office every day at nine.")),
        SentenceItem("She completed her training in Patna last month.", "Place usually comes before time at the end of a sentence.", alternatives = listOf("She completed her training last month in Patna.")),
        SentenceItem("We have a team meeting every Monday morning.", "Time phrase at the end."),
        SentenceItem("The customer called twice about his order.", "'about his order' explains the call."),
        SentenceItem("He is learning English from an online course.", "Present continuous: is + verb-ing."),
        SentenceItem("Our new branch opened near the railway station.", "Place phrase 'near the railway station' at the end."),
        SentenceItem("Please send the documents to my email today.", "Request + object + to + person/place + time."),
        SentenceItem("They will deliver the parcel by Friday evening.", "Future: will + verb."),
        SentenceItem("My brother works in a bank in Delhi.", "Smaller place first, then bigger place."),
        SentenceItem("I usually drink tea after lunch at work.", "Frequency words like 'usually' come before the main verb.", alternatives = listOf("I usually drink tea at work after lunch.")),
    )
    private val hard = listOf(
        SentenceItem("I stayed late at the office because the report was urgent.", "'because' joins the reason to the main sentence."),
        SentenceItem("Although the work was difficult, our team finished it on time.", "'Although' clause first, then a comma, then the main clause.", alternatives = listOf("Our team finished it on time although the work was difficult.")),
        SentenceItem("The customer who called this morning wants a full refund.", "'who called this morning' describes the customer."),
        SentenceItem("If you have any questions, please contact our support team.", "'If' clause, comma, then the instruction.", alternatives = listOf("Please contact our support team if you have any questions.")),
        SentenceItem("She practises English daily so that she can clear the interview.", "'so that' shows purpose."),
        SentenceItem("When the manager arrived, everyone was ready for the meeting.", "'When' clause, comma, main clause.", alternatives = listOf("Everyone was ready for the meeting when the manager arrived.")),
        SentenceItem("The laptop which I bought last year is still working well.", "'which I bought last year' describes the laptop."),
        SentenceItem("He could not join the call because his internet was slow.", "Main clause + because + reason."),
        SentenceItem("Although it was raining, the delivery boy reached on time.", "'Although' shows contrast.", alternatives = listOf("The delivery boy reached on time although it was raining.")),
        SentenceItem("We will start the training after everyone has joined the session.", "'after' + present perfect for a finished action."),
    )
    private val interview = listOf(
        SentenceItem("I have two years of experience in customer support.", "'experience in' + field."),
        SentenceItem("My greatest strength is that I learn new things quickly.", "'My strength is that' + full sentence."),
        SentenceItem("I am comfortable working in rotational and night shifts.", "'comfortable' + verb-ing."),
        SentenceItem("I completed my graduation in commerce from Patna University.", "'graduation in' subject + 'from' college."),
        SentenceItem("I want to grow with a company that values hard work.", "'that values hard work' describes the company."),
        SentenceItem("In my last job, I handled more than fifty calls daily.", "Time phrase first, comma, then the sentence.", alternatives = listOf("I handled more than fifty calls daily in my last job.")),
        SentenceItem("I enjoy working in a team and helping my colleagues.", "'enjoy' + verb-ing."),
        SentenceItem("I am a quick learner and I can handle pressure well.", "Two ideas joined with 'and'."),
        SentenceItem("Thank you for giving me the opportunity to attend this interview.", "'Thank you for' + verb-ing."),
        SentenceItem("I see myself as a team leader in three years.", "'see myself as' + role + time."),
    )

    fun random(level: SentenceLevel, n: Int): List<SentenceItem> = when (level) {
        SentenceLevel.EASY -> easy
        SentenceLevel.MEDIUM -> medium
        SentenceLevel.HARD -> hard
        SentenceLevel.INTERVIEW -> interview
    }.shuffled().take(n)
}

/** Turns a sentence into the tiles shown on screen and checks the learner's order. */
object SentenceTiles {
    /** Words of the sentence, final punctuation removed, first word lower-cased (unless "I"). */
    fun words(sentence: String): List<String> {
        val clean = sentence.trim().trimEnd('.', '?', '!').trim()
        val parts = clean.split(Regex("\\s+")).filter { it.isNotBlank() }.toMutableList()
        if (parts.isNotEmpty()) {
            val first = parts[0]
            val keepCapital = first == "I" || first.startsWith("I'") ||
                (first.length > 1 && first.drop(1).any { it.isUpperCase() })
            if (!keepCapital) parts[0] = first.replaceFirstChar { it.lowercase() }
        }
        return parts
    }

    /** Shuffles so the result is (almost always) different from the original order. */
    fun <T> shuffled(items: List<T>, sameAs: (List<T>) -> Boolean = { it == items }): List<T> {
        if (items.size < 2) return items
        var s = items.shuffled()
        var guard = 0
        while (sameAs(s) && guard++ < 10) s = items.shuffled()
        return s
    }

    private fun norm(s: String) = s.lowercase().replace(Regex("[^a-z0-9' ]"), " ").split(Regex("\\s+")).filter { it.isNotBlank() }

    fun isCorrect(answerWords: List<String>, item: SentenceItem): Boolean {
        val a = norm(answerWords.joinToString(" "))
        return (listOf(item.sentence) + item.alternatives).any { norm(it) == a }
    }

    /** Share of words in the right relative order (0..100), for partial credit. */
    fun orderScore(answerWords: List<String>, sentence: String): Int {
        val a = norm(answerWords.joinToString(" "))
        val t = norm(sentence)
        if (a.isEmpty() || t.isEmpty()) return 0
        val dp = Array(t.size + 1) { IntArray(a.size + 1) }
        for (i in 1..t.size) for (j in 1..a.size) {
            dp[i][j] = if (t[i - 1] == a[j - 1]) dp[i - 1][j - 1] + 1 else maxOf(dp[i - 1][j], dp[i][j - 1])
        }
        return (dp[t.size][a.size] * 100 / t.size).coerceIn(0, 100)
    }

    /** Displays a sentence with a capital first letter and a full stop. */
    fun pretty(sentence: String): String {
        val s = sentence.trim()
        if (s.isEmpty()) return s
        val cap = s.replaceFirstChar { it.uppercase() }
        return if (cap.last() in ".?!") cap else "$cap."
    }
}
