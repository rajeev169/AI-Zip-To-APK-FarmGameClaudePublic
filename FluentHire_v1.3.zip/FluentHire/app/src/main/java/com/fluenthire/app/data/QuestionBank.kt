package com.fluenthire.app.data

data class JobRole(
    val id: String,
    val name: String,
    val emoji: String,
    val blurb: String,
    val sampleQuestions: List<String>,
)

data class ShortAnswerItem(val question: String, val accepted: List<String>)
data class SentenceBuildItem(val phrases: List<String>) {
    val correct: String get() = phrases.joinToString(" ")
}
data class StoryItem(val story: String, val keywords: List<String>)

object QuestionBank {

    val levels = listOf("Fresher", "1–3 years experience", "3+ years experience")

    val roles = listOf(
        JobRole(
            "bpo", "BPO / Customer Support", "🎧",
            "Voice process, chat support, international calls",
            listOf(
                "Tell me about yourself.",
                "Why do you want to work in a BPO?",
                "Are you comfortable working night shifts and rotational shifts?",
                "How would you handle an angry customer who is shouting at you?",
                "What does good customer service mean to you?",
                "A customer wants a refund that is against company policy. What will you say?",
                "How do you handle pressure and targets?",
                "Where do you see yourself in three years?",
            )
        ),
        JobRole(
            "it", "IT / Software", "💻",
            "Developer, tester, support engineer",
            listOf(
                "Tell me about yourself and your technical background.",
                "Explain a project you have worked on and your role in it.",
                "Which programming language are you most comfortable with, and why?",
                "How do you approach fixing a bug you have never seen before?",
                "Tell me about a time you worked in a team to meet a deadline.",
                "How do you keep your technical skills up to date?",
                "Why should we hire you over other candidates?",
            )
        ),
        JobRole(
            "sales", "Sales & Marketing", "📈",
            "Field sales, inside sales, business development",
            listOf(
                "Tell me about yourself.",
                "Sell me this pen.",
                "How do you handle rejection from a customer?",
                "How would you find new customers in a new city?",
                "Tell me about a time you convinced someone to change their mind.",
                "What motivates you more: salary or incentives?",
            )
        ),
        JobRole(
            "bank", "Banking & Finance", "🏦",
            "Bank PO/clerk, relationship manager, insurance",
            listOf(
                "Tell me about yourself.",
                "Why do you want to join the banking sector?",
                "How would you explain a savings account to a village customer?",
                "What would you do if a customer asks you to break a bank rule for them?",
                "How do you stay accurate when handling cash and numbers?",
                "What do you know about digital banking and UPI?",
            )
        ),
        JobRole(
            "hr", "HR & Admin", "🗂️",
            "HR executive, recruiter, office admin",
            listOf(
                "Tell me about yourself.",
                "Why did you choose a career in HR?",
                "How would you handle a conflict between two employees?",
                "How do you keep employee information confidential?",
                "What qualities do you look for when hiring someone?",
            )
        ),
        JobRole(
            "general", "Fresher / General", "🎓",
            "First job, campus placement, any role",
            listOf(
                "Tell me about yourself.",
                "What are your strengths and weaknesses?",
                "Why should we hire you?",
                "Tell me about a challenge you faced and how you solved it.",
                "What do you know about our company?",
                "Are you willing to relocate?",
                "Do you have any questions for us?",
            )
        ),
    )

    // ---------- Versant-style practice test content ----------

    val readAloud = listOf(
        "Our team handles customer calls from many different countries every day.",
        "Please make sure the report is ready before the meeting on Monday morning.",
        "The new software update will improve the speed of the application.",
        "I would like to confirm the delivery address for your order.",
        "Good communication skills are important in every kind of job.",
        "The manager asked everyone to arrive fifteen minutes early tomorrow.",
        "Thank you for your patience while I check the details of your account.",
        "Our office is located near the main railway station in the city.",
        "She completed her training and joined the support team last month.",
        "Customers can now track their parcels using the mobile app.",
        "We are sorry for the delay and will solve the problem as soon as possible.",
        "He prepared well for the interview by practising common questions.",
    )

    val repeat = listOf(
        "Please hold the line.",
        "I will call you back in ten minutes.",
        "The meeting has been moved to Thursday.",
        "Could you spell your name for me?",
        "Your request has been processed successfully.",
        "We close the office at six in the evening.",
        "Let me transfer your call to the right department.",
        "She works in the accounts team.",
        "The train was late because of heavy rain.",
        "Is there anything else I can help you with today?",
        "Please send me the documents by email.",
        "Our new branch opened last week.",
    )

    val shortAnswer = listOf(
        ShortAnswerItem("What do you use to cut paper?", listOf("scissors", "scissor", "knife", "blade", "cutter")),
        ShortAnswerItem("How many days are there in a week?", listOf("seven", "7")),
        ShortAnswerItem("What is the opposite of hot?", listOf("cold", "cool")),
        ShortAnswerItem("Where do you go to borrow books?", listOf("library", "libraries")),
        ShortAnswerItem("What do bees make?", listOf("honey")),
        ShortAnswerItem("Which month comes after March?", listOf("april")),
        ShortAnswerItem("What do you call a person who treats sick people?", listOf("doctor", "nurse", "physician")),
        ShortAnswerItem("If you are thirsty, what do you drink?", listOf("water", "juice", "milk", "tea", "coffee")),
        ShortAnswerItem("What do we use to make a phone call?", listOf("phone", "mobile", "telephone", "cellphone", "smartphone")),
        ShortAnswerItem("What season comes after winter?", listOf("spring")),
        ShortAnswerItem("How many hours are there in a day?", listOf("twenty four", "twenty-four", "24")),
        ShortAnswerItem("What is frozen water called?", listOf("ice")),
        ShortAnswerItem("Where do planes take off and land?", listOf("airport", "runway")),
        ShortAnswerItem("What colour is the sky on a clear day?", listOf("blue")),
    )

    val sentenceBuilds = listOf(
        SentenceBuildItem(listOf("the meeting", "was cancelled", "this morning")),
        SentenceBuildItem(listOf("she sent", "the report", "to the manager")),
        SentenceBuildItem(listOf("our office", "opens", "at nine")),
        SentenceBuildItem(listOf("the customer", "asked for", "a refund")),
        SentenceBuildItem(listOf("I have", "finished", "my training")),
        SentenceBuildItem(listOf("please call", "the client", "after lunch")),
        SentenceBuildItem(listOf("the new phone", "has", "a better camera")),
        SentenceBuildItem(listOf("we will", "deliver the order", "by Friday")),
        SentenceBuildItem(listOf("he forgot", "his laptop", "at home")),
        SentenceBuildItem(listOf("the train", "leaves", "at five o'clock")),
    )

    val stories = listOf(
        StoryItem(
            "Ravi wanted to buy a gift for his mother's birthday. He went to the market, but the shop he liked was closed. " +
                "So he decided to make a card at home. His mother loved the card more than any gift from a shop.",
            listOf("ravi", "gift", "mother", "birthday", "market", "shop", "closed", "card", "home", "loved")
        ),
        StoryItem(
            "Priya had an important interview on Monday. On the way, her bus broke down. She called the company and explained the problem. " +
                "The manager was impressed by her honesty and moved her interview to the afternoon. She got the job.",
            listOf("priya", "interview", "bus", "broke", "called", "company", "manager", "honest", "afternoon", "job")
        ),
        StoryItem(
            "A customer called the help centre because his internet was not working. The agent stayed calm and asked him to restart the router. " +
                "The internet started working again, and the customer thanked the agent for the quick help.",
            listOf("customer", "called", "internet", "not working", "agent", "calm", "restart", "router", "working", "thanked")
        ),
        StoryItem(
            "Amit forgot his umbrella at the office. When he left in the evening, it started to rain heavily. " +
                "His colleague Neha shared her umbrella and walked with him to the bus stop. The next day, Amit bought her a coffee to say thank you.",
            listOf("amit", "umbrella", "office", "rain", "colleague", "neha", "shared", "bus stop", "coffee", "thank")
        ),
        StoryItem(
            "The shop owner noticed that sales were falling. He started a small delivery service using his son's bicycle. " +
                "Soon, many families ordered from home, and his sales became better than before.",
            listOf("shop", "owner", "sales", "falling", "delivery", "son", "bicycle", "families", "ordered", "better")
        ),
    )

    val openQuestions = listOf(
        "Do you prefer working alone or in a team? Explain why.",
        "Describe your hometown to someone who has never been there.",
        "What is the best way to learn a new skill? Give reasons.",
        "Talk about a person who has inspired you and why.",
        "Should students do part-time jobs while studying? Give your opinion.",
        "Describe your ideal job and what you would do there.",
        "What are the advantages and disadvantages of working from home?",
    )
}
