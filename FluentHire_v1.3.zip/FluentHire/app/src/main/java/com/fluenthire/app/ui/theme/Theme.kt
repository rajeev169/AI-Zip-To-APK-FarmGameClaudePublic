package com.fluenthire.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Indigo = Color(0xFF312E81)
val IndigoLight = Color(0xFF4F46E5)
val Teal = Color(0xFF0D9488)
val Amber = Color(0xFFF59E0B)
val Good = Color(0xFF16A34A)
val Warn = Color(0xFFEA580C)
val Bad = Color(0xFFDC2626)
val Surface2 = Color(0xFFF4F4FB)

private val Colors = lightColorScheme(
    primary = IndigoLight,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE0E7FF),
    onPrimaryContainer = Indigo,
    secondary = Teal,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFCCFBF1),
    onSecondaryContainer = Color(0xFF134E4A),
    tertiary = Amber,
    background = Color(0xFFFAFAFF),
    surface = Color.White,
    surfaceVariant = Surface2,
)

@Composable
fun FluentHireTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Colors, content = content)
}

fun scoreColor(score: Int): Color = when {
    score >= 75 -> Good
    score >= 50 -> Warn
    else -> Bad
}
