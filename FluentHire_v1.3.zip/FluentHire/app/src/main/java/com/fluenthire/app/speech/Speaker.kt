package com.fluenthire.app.speech

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.util.Locale

/** Text-to-speech voice for the AI interviewer and listening tasks. */
class Speaker(context: Context, rate: Float) {

    var isSpeaking by mutableStateOf(false); private set
    var ready by mutableStateOf(false); private set

    private val main = Handler(Looper.getMainLooper())
    private val callbacks = mutableMapOf<String, () -> Unit>()
    private var counter = 0
    private var pending: Pair<String, (() -> Unit)?>? = null
    private var tts: TextToSpeech? = null

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val t = tts ?: return@TextToSpeech
                val r = t.setLanguage(Locale("en", "IN"))
                if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) t.setLanguage(Locale.US)
                t.setSpeechRate(rate)
                t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) { main.post { isSpeaking = true } }
                    override fun onDone(utteranceId: String?) = finish(utteranceId)
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) = finish(utteranceId)
                    override fun onError(utteranceId: String?, errorCode: Int) = finish(utteranceId)
                    override fun onStop(utteranceId: String?, interrupted: Boolean) {
                        main.post { isSpeaking = false }
                    }
                })
                main.post {
                    ready = true
                    pending?.let { (text, done) -> pending = null; speak(text, done) }
                }
            } else {
                main.post { ready = false }
            }
        }
    }

    private fun finish(id: String?) {
        main.post {
            isSpeaking = false
            id?.let { callbacks.remove(it)?.invoke() }
        }
    }

    fun setRate(rate: Float) { tts?.setSpeechRate(rate) }

    /** Speak [text]; [onDone] runs on the main thread when finished. */
    fun speak(text: String, onDone: (() -> Unit)? = null) {
        val t = tts
        if (t == null || !ready) { pending = text to onDone; return }
        val id = "u${counter++}"
        if (onDone != null) callbacks[id] = onDone
        isSpeaking = true
        val result = t.speak(text, TextToSpeech.QUEUE_FLUSH, null, id)
        if (result != TextToSpeech.SUCCESS) {
            isSpeaking = false
            callbacks.remove(id)?.invoke()
        }
    }

    fun stop() {
        callbacks.clear()
        pending = null
        tts?.stop()
        isSpeaking = false
    }

    fun shutdown() {
        stop()
        tts?.shutdown()
        tts = null
    }
}
