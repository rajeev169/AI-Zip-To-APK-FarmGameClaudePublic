package com.fluenthire.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fluenthire.app.AppDeps
import com.fluenthire.app.ai.Coach
import com.fluenthire.app.ai.GeminiClient
import com.fluenthire.app.data.PracticeFactory
import com.fluenthire.app.data.Section
import com.fluenthire.app.data.SessionRecord
import com.fluenthire.app.data.TaskResult
import com.fluenthire.app.scoring.LocalScorer
import com.fluenthire.app.ui.theme.scoreColor

private enum class PPhase { Intro, Running, Done }

/** Builds the AI coach if the user has a key, otherwise null (offline scoring). */
fun coachOrNull(deps: AppDeps): Coach? {
    val p = deps.prefs
    return if (p.hasApiKey) Coach(GeminiClient(p.apiKey, p.model) { p.model = it }, p.hindiTips) else null
}

@Composable
fun PracticeScreen(deps: AppDeps, onExit: () -> Unit) {
    val prefs = deps.prefs
    val coach = remember { coachOrNull(deps) }
    val tasks = remember { PracticeFactory.fullTest() }
    var phase by remember { mutableStateOf(PPhase.Intro) }
    var results by remember { mutableStateOf<List<TaskResult>>(emptyList()) }
    var confirmExit by remember { mutableStateOf(false) }
    var saved by remember { mutableStateOf(false) }

    BackHandler { if (phase != PPhase.Running) onExit() else confirmExit = true }

    if (confirmExit) {
        AlertDialog(
            onDismissRequest = { confirmExit = false },
            title = { Text("Leave the test?") },
            text = { Text("Your progress in this test will be lost.") },
            confirmButton = { TextButton(onClick = { confirmExit = false; onExit() }) { Text("Leave") } },
            dismissButton = { TextButton(onClick = { confirmExit = false }) { Text("Stay") } },
        )
    }

    Scaffold(topBar = {
        AppTopBar(
            if (phase == PPhase.Done) "Test Result" else "English Practice Test",
            onBack = { if (phase != PPhase.Running) onExit() else confirmExit = true },
        )
    }) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            when (phase) {
                PPhase.Intro -> {
                    InfoCard {
                        Text("How it works", fontWeight = FontWeight.SemiBold, fontSize = 18.sp)
                        Spacer(Modifier.height(8.dp))
                        Section.entries.forEach { s ->
                            Text(s.fullTitle, fontWeight = FontWeight.Medium, modifier = Modifier.padding(top = 6.dp))
                            Text(s.instruction, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
                        }
                    }
                    InfoCard(container = MaterialTheme.colorScheme.secondaryContainer) {
                        Text("${tasks.size} tasks • about 12 minutes", fontWeight = FontWeight.SemiBold)
                        Text("Use earphones in a quiet room. You get a score (0–100) and a CEFR level at the end.",
                            style = MaterialTheme.typography.bodySmall)
                        if (coach == null) Text("Parts E and F are scored offline until you add a Gemini key in Settings.",
                            style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 6.dp))
                    }
                    Button(
                        onClick = { deps.requestMic { phase = PPhase.Running } },
                        modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(14.dp),
                    ) { Text("Start Test", fontSize = 16.sp) }
                }

                PPhase.Running -> TaskSequence(
                    deps = deps, tasks = tasks, coach = coach, sectionIntros = true,
                    finishLabel = "See my score",
                    onFinished = { results = it; phase = PPhase.Done },
                )

                PPhase.Done -> {
                    val sectionScores = Section.entries.associateWith { s ->
                        results.filter { it.task.section == s }.map { it.score }.takeIf { it.isNotEmpty() }?.average()?.toInt() ?: 0
                    }
                    val overall = Section.entries.sumOf { sectionScores.getValue(it) * it.weight }.toInt()
                    val pron = (sectionScores.getValue(Section.READ) + sectionScores.getValue(Section.REPEAT)) / 2
                    val listen = (sectionScores.getValue(Section.SHORT) + sectionScores.getValue(Section.BUILD)) / 2
                    val speak = (sectionScores.getValue(Section.RETELL) + sectionScores.getValue(Section.OPEN)) / 2

                    LaunchedEffect(Unit) {
                        if (!saved) {
                            saved = true
                            prefs.addRecord(
                                SessionRecord(
                                    type = "Practice Test", title = "English Practice Test", score = overall,
                                    timestamp = System.currentTimeMillis(),
                                    summary = "Level: ${LocalScorer.cefr(overall)}",
                                    subScores = mapOf("Pronunciation" to pron, "Listening" to listen, "Speaking" to speak),
                                )
                            )
                        }
                    }

                    InfoCard {
                        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                            ScoreRing(overall, size = 150.dp, label = "overall")
                            Spacer(Modifier.height(8.dp))
                            Text(LocalScorer.cefr(overall), fontWeight = FontWeight.Bold, fontSize = 18.sp, color = scoreColor(overall))
                            Text(levelMessage(overall), textAlign = TextAlign.Center, style = MaterialTheme.typography.bodyMedium,
                                modifier = Modifier.padding(top = 6.dp))
                        }
                        Spacer(Modifier.height(12.dp))
                        ScoreBar("Pronunciation (A, B)", pron)
                        ScoreBar("Listening & structure (C, D)", listen)
                        ScoreBar("Speaking & content (E, F)", speak)
                    }
                    InfoCard {
                        Text("Section scores", fontWeight = FontWeight.SemiBold)
                        Section.entries.forEach { s -> ScoreBar(s.fullTitle, sectionScores.getValue(s)) }
                    }
                    val weakest = Section.entries.minByOrNull { sectionScores.getValue(it) }
                    weakest?.let { w ->
                        InfoCard(container = Color(0xFFFFF7ED)) {
                            Text("Focus next on: ${w.title}", fontWeight = FontWeight.SemiBold, color = Color(0xFF9A3412))
                            Text(focusTip(w), style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(top = 4.dp))
                            Text("Tip: practise this part on its own from ☰ → Test yourself.",
                                style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 6.dp))
                        }
                    }
                    Button(
                        onClick = onExit, modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(14.dp),
                    ) { Text("Done", fontSize = 16.sp) }
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

fun levelMessage(score: Int) = when {
    score >= 85 -> "Excellent! Your English is ready for most international jobs."
    score >= 70 -> "Very good. You can handle most BPO and corporate interviews."
    score >= 55 -> "Good base. Practise daily to reach interview-ready level."
    score >= 40 -> "You are improving. Focus on clear pronunciation and full sentences."
    else -> "Keep going! Practise a little every day and you will improve fast."
}

fun focusTip(s: Section) = when (s) {
    Section.READ -> "Read English news headlines aloud for 5 minutes a day. Speak slowly and finish every word."
    Section.REPEAT -> "Listen to short English sentences and repeat them right away. This trains memory and pronunciation."
    Section.SHORT -> "Practise quick everyday vocabulary: days, months, numbers, jobs, places and common objects."
    Section.BUILD -> "Remember the basic order: Subject + Verb + Object + Place + Time. Example: \"She sent the report this morning.\""
    Section.RETELL -> "After listening, say who, what, where and why. Use linking words like first, then, after that, finally."
    Section.OPEN -> "Give your opinion, one reason, one example, then a short conclusion. Aim for 30–60 seconds."
}
