package com.fluenthire.app.speech

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/**
 * Wraps Android's SpeechRecognizer. In "continuous" mode it restarts itself after pauses,
 * so a candidate can speak a long interview answer until they tap Stop.
 * Must be used on the main thread.
 */
class SpeechInput(private val context: Context) {

    var isListening by mutableStateOf(false); private set
    var committed by mutableStateOf(""); private set
    var partial by mutableStateOf(""); private set
    var error by mutableStateOf<String?>(null); private set
    var level by mutableFloatStateOf(0f); private set

    val text: String get() = (committed + " " + partial).trim()
    val available: Boolean get() = SpeechRecognizer.isRecognitionAvailable(context)

    private val handler = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var continuous = false
    private var wantListening = false

    private val intent: Intent
        get() = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "en-IN")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 3000L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 2500L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 4000L)
        }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) { error = null }
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) { level = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f) }
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() { level = 0f }
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onPartialResults(partialResults: Bundle?) {
            val p = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (!p.isNullOrBlank()) partial = p
        }

        override fun onResults(results: Bundle?) {
            val r = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            val piece = if (!r.isNullOrBlank()) r else partial
            if (piece.isNotBlank()) committed = (committed + " " + piece).trim()
            partial = ""
            afterSegment()
        }

        override fun onError(code: Int) {
            // keep whatever partial text we had
            if (partial.isNotBlank()) { committed = (committed + " " + partial).trim(); partial = "" }
            val benign = code == SpeechRecognizer.ERROR_NO_MATCH || code == SpeechRecognizer.ERROR_SPEECH_TIMEOUT ||
                code == SpeechRecognizer.ERROR_CLIENT
            if (!benign || !continuous) {
                if (!benign && wantListening) error = message(code)
            }
            if (code == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) { continuous = false; wantListening = false }
            afterSegment()
        }
    }

    private fun afterSegment() {
        level = 0f
        if (continuous && wantListening) {
            handler.postDelayed({ if (wantListening) startInternal() }, 150)
        } else {
            wantListening = false
            isListening = false
        }
    }

    private fun startInternal() {
        try {
            if (recognizer == null) {
                recognizer = SpeechRecognizer.createSpeechRecognizer(context).also { it.setRecognitionListener(listener) }
            }
            recognizer?.startListening(intent)
            isListening = true
        } catch (e: Exception) {
            error = "Could not start the microphone: ${e.message}"
            isListening = false
            wantListening = false
        }
    }

    /** Start listening. [continuous] keeps listening across pauses until [stop] is called. */
    fun start(continuous: Boolean, reset: Boolean = true) {
        if (!available) {
            error = "Speech recognition is not available. Install or update the Google app."
            return
        }
        if (reset) { committed = ""; partial = "" }
        error = null
        this.continuous = continuous
        wantListening = true
        recognizer?.cancel()
        startInternal()
    }

    /** Stop listening; the final words still arrive and are added to [text]. */
    fun stop() {
        continuous = false
        wantListening = false
        try { recognizer?.stopListening() } catch (_: Exception) {}
        // Some devices never call back after stopListening; make sure UI unlocks.
        handler.postDelayed({
            if (!wantListening && isListening) {
                if (partial.isNotBlank()) { committed = (committed + " " + partial).trim(); partial = "" }
                isListening = false
            }
        }, 1500)
    }

    fun cancel() {
        continuous = false
        wantListening = false
        try { recognizer?.cancel() } catch (_: Exception) {}
        isListening = false
        level = 0f
    }

    fun setText(t: String) { committed = t; partial = "" }

    fun clear() { committed = ""; partial = ""; error = null }

    fun destroy() {
        handler.removeCallbacksAndMessages(null)
        try { recognizer?.destroy() } catch (_: Exception) {}
        recognizer = null
    }

    private fun message(code: Int): String = when (code) {
        SpeechRecognizer.ERROR_AUDIO -> "Microphone error. Please try again."
        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Network problem during speech recognition."
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission is needed."
        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Speech service is busy. Tap the mic again."
        SpeechRecognizer.ERROR_SERVER -> "Speech server error. Please try again."
        else -> "Could not hear you clearly. Please try again."
    }
}
