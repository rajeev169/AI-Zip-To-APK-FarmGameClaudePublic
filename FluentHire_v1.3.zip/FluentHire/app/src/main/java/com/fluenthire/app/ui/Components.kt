package com.fluenthire.app.ui

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fluenthire.app.ui.theme.Bad
import com.fluenthire.app.ui.theme.IndigoLight
import com.fluenthire.app.ui.theme.scoreColor

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppTopBar(title: String, onBack: (() -> Unit)?, actions: @Composable () -> Unit = {}) {
    TopAppBar(
        title = { Text(title, fontWeight = FontWeight.SemiBold) },
        navigationIcon = {
            if (onBack != null) IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
            }
        },
        actions = { actions() },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background),
    )
}

/** Big round microphone button that pulses with the voice level while listening. */
@Composable
fun MicButton(listening: Boolean, level: Float, enabled: Boolean, onClick: () -> Unit, size: Dp = 88.dp) {
    val pulse = rememberInfiniteTransition(label = "pulse")
    val ring by pulse.animateFloat(
        initialValue = 1f, targetValue = 1.25f,
        animationSpec = infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "ring",
    )
    val voice by animateFloatAsState(if (listening) 1f + level * 0.25f else 1f, label = "voice")
    val bg = when {
        !enabled -> Color(0xFFCBD5E1)
        listening -> Bad
        else -> IndigoLight
    }
    Box(contentAlignment = Alignment.Center, modifier = Modifier.size(size * 1.45f)) {
        if (listening) {
            Box(
                Modifier.size(size).scale(ring * voice).clip(CircleShape)
                    .background(Bad.copy(alpha = 0.18f))
            )
        }
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier.size(size).clip(CircleShape).background(bg),
        ) {
            IconButton(onClick = onClick, enabled = enabled, modifier = Modifier.size(size)) {
                Icon(
                    if (listening) Icons.Filled.Stop else Icons.Filled.Mic,
                    contentDescription = if (listening) "Stop" else "Speak",
                    tint = Color.White, modifier = Modifier.size(size * 0.45f),
                )
            }
        }
    }
}

@Composable
fun ScoreRing(score: Int, size: Dp = 120.dp, label: String? = null, stroke: Dp = 10.dp) {
    val anim by animateFloatAsState(score / 100f, animationSpec = tween(900), label = "score")
    val color = scoreColor(score)
    val track = MaterialTheme.colorScheme.surfaceVariant
    Box(contentAlignment = Alignment.Center, modifier = Modifier.size(size)) {
        Canvas(Modifier.size(size)) {
            val sw = stroke.toPx()
            val d = this.size.minDimension - sw
            val tl = Offset(sw / 2, sw / 2)
            drawArc(track, -90f, 360f, false, tl, Size(d, d), style = Stroke(sw, cap = StrokeCap.Round))
            drawArc(color, -90f, 360f * anim, false, tl, Size(d, d), style = Stroke(sw, cap = StrokeCap.Round))
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("$score", fontSize = (size.value * 0.28f).sp, fontWeight = FontWeight.Bold, color = color)
            if (label != null) Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
        }
    }
}

@Composable
fun ScoreBar(label: String, score: Int) {
    Column(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, style = MaterialTheme.typography.bodyMedium)
            Text("$score", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold, color = scoreColor(score))
        }
        Spacer(Modifier.height(4.dp))
        LinearProgressIndicator(
            progress = { score / 100f },
            modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
            color = scoreColor(score),
            trackColor = MaterialTheme.colorScheme.surfaceVariant,
        )
    }
}

@Composable
fun InfoCard(modifier: Modifier = Modifier, container: Color = MaterialTheme.colorScheme.surface, content: @Composable () -> Unit) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = container),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    ) { Column(Modifier.padding(16.dp)) { content() } }
}

@Composable
fun ErrorCard(message: String, onRetry: (() -> Unit)?, extra: (@Composable () -> Unit)? = null) {
    InfoCard(container = Color(0xFFFEF2F2)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.ErrorOutline, null, tint = Bad)
            Spacer(Modifier.width(8.dp))
            Text(message, color = Color(0xFF7F1D1D), style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
        }
        Row {
            if (onRetry != null) TextButton(onClick = onRetry) { Text("Try again") }
            extra?.invoke()
        }
    }
}

@Composable
fun LoadingBlock(text: String) {
    Column(
        Modifier.fillMaxWidth().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        CircularProgressIndicator()
        Spacer(Modifier.height(12.dp))
        Text(text, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.outline)
    }
}

@Composable
fun TranscriptBox(text: String, placeholder: String) {
    InfoCard(container = MaterialTheme.colorScheme.surfaceVariant) {
        Text("You said", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.outline)
        Spacer(Modifier.height(4.dp))
        Text(
            text.ifBlank { placeholder },
            style = MaterialTheme.typography.bodyLarge,
            color = if (text.isBlank()) MaterialTheme.colorScheme.outline else MaterialTheme.colorScheme.onSurface,
        )
    }
}

@Composable
fun HindiTip(tip: String) {
    if (tip.isBlank()) return
    InfoCard(container = Color(0xFFFFF7ED)) {
        Text("हिंदी टिप", style = MaterialTheme.typography.labelLarge, color = Color(0xFF9A3412), fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(4.dp))
        Text(tip, style = MaterialTheme.typography.bodyMedium)
    }
}
