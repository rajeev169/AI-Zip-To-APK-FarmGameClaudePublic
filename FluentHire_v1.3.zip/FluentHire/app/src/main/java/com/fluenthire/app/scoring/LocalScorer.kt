package com.fluenthire.app.scoring

/** Offline scoring that works without an AI key. */
object LocalScorer {

    private val numberWords = mapOf(
        "0" to "zero", "1" to "one", "2" to "two", "3" to "three", "4" to "four", "5" to "five",
        "6" to "six", "7" to "seven", "8" to "eight", "9" to "nine", "10" to "ten",
        "15" to "fifteen", "24" to "twenty four",
    )

    val fillerWords = listOf("um", "umm", "uh", "uhh", "hmm", "like", "basically", "actually", "you know", "i mean", "so so")

    fun words(text: String): List<String> {
        var t = " " + text.lowercase() + " "
        t = t.replace(Regex("[^a-z0-9' ]"), " ")
        numberWords.forEach { (d, w) -> t = t.replace(" $d ", " $w ") }
        return t.split(Regex("\\s+")).filter { it.isNotBlank() }.map { it.trim('\'') }
    }

    /** Percentage (0..100) of target words spoken in the right order (LCS based), penalising extra words a little. */
    fun wordAccuracy(target: String, spoken: String): Int {
        val a = words(target)
        val b = words(spoken)
        if (a.isEmpty() || b.isEmpty()) return 0
        val dp = Array(a.size + 1) { IntArray(b.size + 1) }
        for (i in 1..a.size) for (j in 1..b.size) {
            dp[i][j] = if (a[i - 1] == b[j - 1]) dp[i - 1][j - 1] + 1 else maxOf(dp[i - 1][j], dp[i][j - 1])
        }
        val lcs = dp[a.size][b.size].toDouble()
        val recall = lcs / a.size
        val precision = lcs / b.size
        val f = if (recall + precision == 0.0) 0.0 else 2 * recall * precision / (recall + precision)
        return (f * 100).toInt().coerceIn(0, 100)
    }

    /** Words in the target that were missed. */
    fun missedWords(target: String, spoken: String): List<String> {
        val said = words(spoken).toSet()
        return words(target).filter { it !in said }.distinct()
    }

    fun shortAnswerCorrect(spoken: String, accepted: List<String>): Boolean {
        val s = " " + words(spoken).joinToString(" ") + " "
        return accepted.any { acc ->
            val a = words(acc).joinToString(" ")
            a.isNotBlank() && (s.contains(" $a ") || s.contains(" ${a}s "))
        }
    }

    /** Story retelling: keyword coverage + reasonable length. */
    fun retellScore(keywords: List<String>, spoken: String): Int {
        val s = " " + words(spoken).joinToString(" ") + " "
        if (s.isBlank()) return 0
        val hits = keywords.count { k -> val kw = words(k).joinToString(" "); s.contains(" $kw") }
        val coverage = hits.toDouble() / keywords.size
        val len = words(spoken).size
        val lengthFactor = when {
            len < 8 -> 0.5
            len < 20 -> 0.8
            else -> 1.0
        }
        return (coverage * lengthFactor * 100).toInt().coerceIn(0, 100)
    }

    /** Open question without AI: rewards length and variety of words. */
    fun openAnswerScore(spoken: String): Int {
        val w = words(spoken)
        if (w.isEmpty()) return 0
        val lengthScore = (w.size / 60.0).coerceAtMost(1.0) * 60
        val variety = (w.toSet().size.toDouble() / w.size).coerceIn(0.0, 1.0) * 40
        return (lengthScore + variety).toInt().coerceIn(0, 100)
    }

    fun countFillers(spoken: String): Int {
        val s = " " + words(spoken).joinToString(" ") + " "
        return fillerWords.sumOf { f -> Regex("(?<= )${Regex.escape(f)}(?= )").findAll(s).count() }
    }

    fun cefr(score: Int): String = when {
        score >= 85 -> "C1 – Advanced"
        score >= 70 -> "B2 – Upper Intermediate"
        score >= 55 -> "B1 – Intermediate"
        score >= 40 -> "A2 – Elementary"
        else -> "A1 – Beginner"
    }
}
