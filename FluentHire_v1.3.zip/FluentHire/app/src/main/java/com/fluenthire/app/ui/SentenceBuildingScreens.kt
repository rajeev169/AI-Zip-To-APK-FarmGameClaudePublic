package com.fluenthire.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fluenthire.app.AppDeps
import com.fluenthire.app.data.SentenceBank
import com.fluenthire.app.data.SentenceItem
import com.fluenthire.app.data.SentenceLevel
import com.fluenthire.app.data.SentenceTiles
import com.fluenthire.app.data.SessionRecord
import com.fluenthire.app.ui.theme.Bad
import com.fluenthire.app.ui.theme.Good
import com.fluenthire.app.ui.theme.scoreColor
import kotlinx.coroutines.launch

const val SENTENCE_TYPE = "Sentence Building"
private const val SENTENCES_PER_ROUND = 5

// ------------------------------------------------------------------ levels

@Composable
fun SentenceLevelsScreen(deps: AppDeps, refreshKey: Int, onBack: () -> Unit, onOpenLevel: (SentenceLevel) -> Unit) {
    val best = remember(refreshKey) { deps.prefs.bestScores(SENTENCE_TYPE) }
    Scaffold(topBar = { AppTopBar("Sentence Building", onBack) }) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            InfoCard(container = MaterialTheme.colorScheme.secondaryContainer) {
                Text("Arrange the jumbled words", fontWeight = FontWeight.SemiBold)
                Text(
                    "Tap the words in the right order to make a correct sentence. $SENTENCES_PER_ROUND sentences per round" +
                        if (deps.prefs.hasApiKey) ", new from the AI every time." else ".",
                    style = MaterialTheme.typography.bodySmall,
                )
            }
            SentenceLevel.entries.forEach { lv ->
                val b = best[lv.title]
                Card(
                    onClick = { onOpenLevel(lv) },
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(1.dp),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(lv.emoji, fontSize = 24.sp)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(lv.title, fontWeight = FontWeight.SemiBold)
                            Text(lv.blurb, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
                        }
                        if (b != null) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("$b", fontWeight = FontWeight.Bold, color = scoreColor(b), fontSize = 18.sp)
                                Text("best", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                            }
                        } else {
                            Icon(Icons.AutoMirrored.Filled.ArrowForward, null, tint = MaterialTheme.colorScheme.outline)
                        }
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
        }
    }
}

// ------------------------------------------------------------------ one round

private data class Tile(val id: Int, val word: String)

private data class SentenceResult(
    val item: SentenceItem, val answer: String, val correct: Boolean, val score: Int, val alsoCorrect: Boolean = false,
)

private enum class SPhase { Loading, Playing, Done }

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SentenceRoundScreen(deps: AppDeps, level: SentenceLevel, onBack: () -> Unit, onNextLevel: (SentenceLevel) -> Unit) {
    val prefs = deps.prefs
    val speaker = deps.speaker
    val coach = remember { coachOrNull(deps) }
    val scope = rememberCoroutineScope()
    var checking by remember { mutableStateOf(false) }

    var round by remember { mutableIntStateOf(0) }
    var phase by remember { mutableStateOf(SPhase.Loading) }
    var items by remember { mutableStateOf<List<SentenceItem>>(emptyList()) }
    var notice by remember { mutableStateOf<String?>(null) }
    var index by remember { mutableIntStateOf(0) }
    val pool = remember { mutableStateListOf<Tile>() }
    val answer = remember { mutableStateListOf<Tile>() }
    var checked by remember { mutableStateOf(false) }
    val results = remember { mutableStateListOf<SentenceResult>() }
    var confirmExit by remember { mutableStateOf(false) }

    DisposableEffect(Unit) { onDispose { speaker.stop() } }

    fun loadItem(i: Int) {
        index = i
        checked = false
        answer.clear()
        pool.clear()
        val item = items.getOrNull(i) ?: return
        val tiles = SentenceTiles.words(item.sentence).mapIndexed { n, w -> Tile(n, w) }
        pool.addAll(SentenceTiles.shuffled(tiles) { s -> s.map { it.word } == tiles.map { it.word } })
    }

    LaunchedEffect(round) {
        phase = SPhase.Loading
        notice = null
        results.clear()
        val ai: List<SentenceItem> = if (coach != null) {
            try { coach.generateSentences(level, SENTENCES_PER_ROUND) } catch (e: Exception) {
                notice = "Using built-in sentences (${e.message})"
                emptyList()
            }
        } else emptyList()
        val fill = SentenceBank.random(level, SENTENCES_PER_ROUND)
            .filter { b -> ai.none { it.sentence.equals(b.sentence, ignoreCase = true) } }
        items = (ai + fill).take(SENTENCES_PER_ROUND)
        loadItem(0)
        phase = SPhase.Playing
    }

    fun check() {
        val item = items.getOrNull(index) ?: return
        val words = answer.map { it.word }
        val answerText = words.joinToString(" ")
        if (SentenceTiles.isCorrect(words, item)) {
            results += SentenceResult(item, answerText, correct = true, score = 100)
            checked = true
            return
        }
        val partial = (SentenceTiles.orderScore(words, item.sentence) * 0.8).toInt()
        if (coach == null) {
            results += SentenceResult(item, answerText, correct = false, score = partial)
            checked = true
            return
        }
        // Different order: ask the AI whether the learner's order is ALSO correct English.
        checking = true
        scope.launch {
            val ok = try { coach.isAlsoCorrect(SentenceTiles.pretty(item.sentence), SentenceTiles.pretty(answerText)) }
            catch (e: Exception) { false }
            results += if (ok) SentenceResult(item, answerText, correct = true, score = 100, alsoCorrect = true)
                       else SentenceResult(item, answerText, correct = false, score = partial)
            checking = false
            checked = true
        }
    }

    BackHandler { if (phase == SPhase.Playing && results.isNotEmpty()) confirmExit = true else onBack() }

    if (confirmExit) {
        AlertDialog(
            onDismissRequest = { confirmExit = false },
            title = { Text("Leave this round?") },
            text = { Text("Your answers in this round will not be saved.") },
            confirmButton = { TextButton(onClick = { confirmExit = false; onBack() }) { Text("Leave") } },
            dismissButton = { TextButton(onClick = { confirmExit = false }) { Text("Stay") } },
        )
    }

    Scaffold(topBar = {
        AppTopBar(
            if (phase == SPhase.Done) "${level.title} – Result" else "Sentence Building • ${level.title}",
            onBack = { if (phase == SPhase.Playing && results.isNotEmpty()) confirmExit = true else onBack() },
        )
    }) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            when (phase) {
                SPhase.Loading -> LoadingBlock(
                    if (coach != null) "The AI is writing $SENTENCES_PER_ROUND new sentences…" else "Getting sentences ready…"
                )

                SPhase.Playing -> {
                    val item = items.getOrNull(index)
                    if (item != null) {
                        val target = SentenceTiles.words(item.sentence)
                        Text("Sentence ${index + 1} of ${items.size}", color = MaterialTheme.colorScheme.outline)
                        LinearProgressIndicator(
                            progress = { index.toFloat() / items.size },
                            modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                        )
                        notice?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline) }
                        Text("Tap the words in the right order", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)

                        // Answer line
                        InfoCard(container = MaterialTheme.colorScheme.primaryContainer) {
                            Column(Modifier.fillMaxWidth().heightIn(min = 72.dp)) {
                                Text("Your sentence", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                                Spacer(Modifier.height(8.dp))
                                if (answer.isEmpty()) {
                                    Text("Tap words below to build the sentence…", color = MaterialTheme.colorScheme.outline)
                                }
                                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    answer.forEachIndexed { pos, tile ->
                                        val state = when {
                                            !checked -> TileState.Placed
                                            results.lastOrNull()?.correct == true -> TileState.Right
                                            target.getOrNull(pos)?.equals(tile.word, ignoreCase = true) == true -> TileState.Right
                                            else -> TileState.Wrong
                                        }
                                        WordTile(tile.word, state, enabled = !checked && !checking) {
                                            answer.remove(tile); pool.add(tile)
                                        }
                                    }
                                }
                            }
                        }

                        // Word pool
                        if (!checked) {
                            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                pool.forEach { tile ->
                                    WordTile(tile.word, TileState.Pool, enabled = !checking) {
                                        pool.remove(tile); answer.add(tile)
                                    }
                                }
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(
                                    onClick = { val all = pool.toList(); pool.clear(); pool.addAll(SentenceTiles.shuffled(all)) },
                                    enabled = pool.size > 1, modifier = Modifier.weight(1f),
                                ) { Icon(Icons.Filled.Shuffle, null); Spacer(Modifier.width(4.dp)); Text("Shuffle") }
                                OutlinedButton(
                                    onClick = { pool.addAll(answer); answer.clear() },
                                    enabled = answer.isNotEmpty(), modifier = Modifier.weight(1f),
                                ) { Icon(Icons.Filled.Refresh, null); Spacer(Modifier.width(4.dp)); Text("Reset") }
                            }
                            Button(
                                onClick = { check() },
                                enabled = pool.isEmpty() && answer.isNotEmpty() && !checking,
                                modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(14.dp),
                            ) {
                                Text(
                                    when {
                                        checking -> "Checking…"
                                        pool.isEmpty() -> "Check"
                                        else -> "Use all words to check"
                                    },
                                    fontSize = 16.sp,
                                )
                            }
                        } else {
                            val r = results.lastOrNull()
                            if (r != null) {
                                InfoCard(container = if (r.correct) Color(0xFFF0FDF4) else Color(0xFFFEF2F2)) {
                                    Text(
                                        if (r.correct) "✓ Correct!" else "✗ Not quite",
                                        fontWeight = FontWeight.Bold, fontSize = 18.sp,
                                        color = if (r.correct) Good else Bad,
                                    )
                                    if (r.alsoCorrect) {
                                        Spacer(Modifier.height(6.dp))
                                        Text("Your order is also correct English. 👍", style = MaterialTheme.typography.bodyMedium)
                                        Text("Expected sentence: ${SentenceTiles.pretty(item.sentence)}",
                                            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
                                    } else if (!r.correct) {
                                        Spacer(Modifier.height(6.dp))
                                        Text("Correct sentence:", style = MaterialTheme.typography.labelMedium)
                                        Text(SentenceTiles.pretty(item.sentence), fontWeight = FontWeight.Medium)
                                    }
                                    if (item.tip.isNotBlank()) {
                                        Spacer(Modifier.height(6.dp))
                                        Text("💡 ${item.tip}", style = MaterialTheme.typography.bodyMedium)
                                    }
                                    TextButton(onClick = { speaker.speak(SentenceTiles.pretty(item.sentence)) }) {
                                        Icon(Icons.AutoMirrored.Filled.VolumeUp, null); Spacer(Modifier.width(6.dp)); Text("Listen")
                                    }
                                }
                                HindiTip(item.hindiTip)
                            }
                            val last = index + 1 >= items.size
                            Button(
                                onClick = {
                                    speaker.stop()
                                    if (last) {
                                        val avg = if (results.isEmpty()) 0 else results.map { it.score }.average().toInt()
                                        prefs.addRecord(
                                            SessionRecord(
                                                type = SENTENCE_TYPE, title = level.title, score = avg,
                                                timestamp = System.currentTimeMillis(),
                                                summary = "${results.count { it.correct }} of ${results.size} sentences correct",
                                            )
                                        )
                                        phase = SPhase.Done
                                    } else loadItem(index + 1)
                                },
                                modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(14.dp),
                            ) { Text(if (last) "See my result" else "Next sentence", fontSize = 16.sp) }
                        }
                    }
                }

                SPhase.Done -> {
                    val avg = if (results.isEmpty()) 0 else results.map { it.score }.average().toInt()
                    InfoCard {
                        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("${level.emoji} ${level.title}", color = MaterialTheme.colorScheme.outline)
                            Spacer(Modifier.height(8.dp))
                            ScoreRing(avg, size = 140.dp, label = "score")
                            Spacer(Modifier.height(8.dp))
                            Text("${results.count { it.correct }} of ${results.size} sentences correct",
                                fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            Text(
                                when {
                                    avg >= 90 -> "Excellent word order! Try the next level."
                                    avg >= 60 -> "Good work. A little more practice and you'll master this level."
                                    else -> "Keep practising. Remember: Subject + Verb + Object + Place + Time."
                                },
                                textAlign = TextAlign.Center, style = MaterialTheme.typography.bodyMedium,
                                modifier = Modifier.padding(top = 4.dp),
                            )
                        }
                    }
                    Text("Your sentences", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    results.forEachIndexed { i, r ->
                        InfoCard {
                            Text(
                                "${i + 1}. ${if (r.correct) "✓" else "✗"} ${SentenceTiles.pretty(if (r.alsoCorrect) r.answer else r.item.sentence)}",
                                fontWeight = FontWeight.Medium, color = if (r.correct) Good else MaterialTheme.colorScheme.onSurface,
                            )
                            if (r.alsoCorrect) Text("Also correct! Expected: ${SentenceTiles.pretty(r.item.sentence)}",
                                style = MaterialTheme.typography.bodySmall, color = Good, modifier = Modifier.padding(top = 4.dp))
                            if (!r.correct) Text("You made: ${r.answer}", style = MaterialTheme.typography.bodySmall,
                                color = Bad, modifier = Modifier.padding(top = 4.dp))
                            if (r.item.tip.isNotBlank()) Text("💡 ${r.item.tip}", style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.outline, modifier = Modifier.padding(top = 4.dp))
                        }
                    }
                    val nextLevel = SentenceLevel.entries.getOrNull(level.ordinal + 1)
                    val perfect = results.isNotEmpty() && results.all { it.correct }
                    if (perfect && nextLevel != null) {
                        Button(
                            onClick = { onNextLevel(nextLevel) },
                            modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(14.dp),
                        ) { Text("Next level → ${nextLevel.title}", fontSize = 16.sp) }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedButton(onClick = onBack, modifier = Modifier.weight(1f).height(52.dp)) { Text("All levels") }
                        if (perfect && nextLevel != null) {
                            OutlinedButton(onClick = { round++ }, modifier = Modifier.weight(1f).height(52.dp)) { Text("Practice more") }
                        } else {
                            Button(onClick = { round++ }, modifier = Modifier.weight(1f).height(52.dp)) { Text("Practice more") }
                        }
                    }
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

private enum class TileState { Pool, Placed, Right, Wrong }

@Composable
private fun WordTile(word: String, state: TileState, enabled: Boolean, onClick: () -> Unit) {
    val (bg, fg, border) = when (state) {
        TileState.Pool -> Triple(MaterialTheme.colorScheme.surface, MaterialTheme.colorScheme.onSurface, MaterialTheme.colorScheme.outline)
        TileState.Placed -> Triple(MaterialTheme.colorScheme.primary, Color.White, MaterialTheme.colorScheme.primary)
        TileState.Right -> Triple(Color(0xFFDCFCE7), Color(0xFF166534), Good)
        TileState.Wrong -> Triple(Color(0xFFFEE2E2), Color(0xFF991B1B), Bad)
    }
    Surface(
        onClick = onClick,
        enabled = enabled,
        shape = RoundedCornerShape(12.dp),
        color = bg,
        contentColor = fg,
        border = BorderStroke(1.dp, border),
        shadowElevation = if (state == TileState.Pool) 1.dp else 0.dp,
    ) {
        Text(word, fontSize = 17.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp))
    }
}
