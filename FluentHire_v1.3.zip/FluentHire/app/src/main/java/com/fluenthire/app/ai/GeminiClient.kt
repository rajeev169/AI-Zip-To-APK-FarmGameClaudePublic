package com.fluenthire.app.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class AiException(message: String) : Exception(message)

/**
 * Minimal Google Gemini REST client (no extra libraries). Returns the model's reply parsed as JSON.
 * If the chosen model is not available for this key (Google retires models over time), it asks
 * Google for the list of available models, switches to the newest "flash" model automatically and
 * reports the new name through [onModelChanged] so the app can remember it.
 */
class GeminiClient(
    private val apiKey: String,
    model: String,
    private val onModelChanged: ((String) -> Unit)? = null,
) {
    var model: String = model
        private set

    private class HttpResult(val code: Int, val body: String)

    suspend fun generateJson(system: String, prompt: String, temperature: Double = 0.6): JSONObject =
        withContext(Dispatchers.IO) {
            if (apiKey.isBlank()) throw AiException("Add your free Gemini API key in Settings to use AI features.")
            val body = JSONObject().apply {
                put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
                put("contents", JSONArray().put(
                    JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", prompt)))
                ))
                put("generationConfig", JSONObject().apply {
                    put("temperature", temperature)
                    put("responseMimeType", "application/json")
                })
            }.toString()

            var switched = false
            var lastError: AiException? = null
            var attempt = 0
            while (attempt < 3) {
                attempt++
                val res = try {
                    post(generateUrl(model), body)
                } catch (e: java.io.IOException) {
                    lastError = AiException("No internet connection or the server did not respond.")
                    continue
                }
                when {
                    res.code in 200..299 -> return@withContext parseReply(res.body)

                    // Model missing / retired / not allowed for this key → find a working one once.
                    (res.code == 404 || modelProblem(res)) && !switched -> {
                        switched = true
                        val best = try { findBestModel() } catch (e: Exception) { null }
                        if (best != null && best != model) {
                            model = best
                            onModelChanged?.invoke(best)
                            attempt = 0
                            continue
                        }
                        throw AiException("Model \"$model\" is not available for your key. Enter another model name in Settings (for example gemini-3.8-flash).")
                    }

                    res.code == 429 || res.code >= 500 -> {
                        lastError = AiException(
                            if (res.code == 429) "Too many requests or free limit reached. Please wait a minute and try again."
                            else "Google AI server is busy (${res.code}). Please try again."
                        )
                        Thread.sleep(1500L * attempt)
                    }

                    else -> {
                        val msg = errorMessage(res.body)
                        throw AiException(
                            when (res.code) {
                                400, 401, 403 -> "API key problem: ${msg ?: "check your key in Settings"}"
                                404 -> "Model \"$model\" not found. Change the model name in Settings."
                                else -> "AI error (${res.code}): ${msg ?: "please try again"}"
                            }
                        )
                    }
                }
            }
            throw lastError ?: AiException("Something went wrong. Please try again.")
        }

    // ---------------------------------------------------------------- helpers

    private fun generateUrl(m: String) = URL(
        "https://generativelanguage.googleapis.com/v1beta/models/" + URLEncoder.encode(m, "UTF-8") + ":generateContent"
    )

    private fun post(url: URL, body: String): HttpResult = request(url, "POST", body)

    private fun request(url: URL, method: String, body: String?): HttpResult {
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = method
            connectTimeout = 20_000
            readTimeout = 60_000
            setRequestProperty("x-goog-api-key", apiKey)
            if (body != null) {
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
            }
        }
        try {
            if (body != null) conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            return HttpResult(code, text)
        } finally {
            conn.disconnect()
        }
    }

    private fun errorMessage(body: String): String? = try {
        JSONObject(body).optJSONObject("error")?.optString("message")?.takeIf { it.isNotBlank() }
    } catch (e: Exception) { null }

    /** Some retired/limited models answer 400/403 with a "model ... not found / not supported" message. */
    private fun modelProblem(res: HttpResult): Boolean {
        if (res.code != 400 && res.code != 403) return false
        val m = (errorMessage(res.body) ?: return false).lowercase()
        return "model" in m && ("not found" in m || "not supported" in m || "no longer" in m || "not available" in m || "access" in m)
    }

    /** Asks Google which models this key can use and picks the newest general "flash" model. */
    private fun findBestModel(): String? {
        val names = mutableListOf<String>()
        var pageToken: String? = null
        var pages = 0
        do {
            val url = URL(
                "https://generativelanguage.googleapis.com/v1beta/models?pageSize=200" +
                    (pageToken?.let { "&pageToken=" + URLEncoder.encode(it, "UTF-8") } ?: "")
            )
            val res = request(url, "GET", null)
            if (res.code !in 200..299) return null
            val o = JSONObject(res.body)
            val arr = o.optJSONArray("models") ?: JSONArray()
            for (i in 0 until arr.length()) {
                val m = arr.optJSONObject(i) ?: continue
                val methods = m.optJSONArray("supportedGenerationMethods")
                var canGenerate = false
                if (methods != null) for (j in 0 until methods.length()) if (methods.optString(j) == "generateContent") canGenerate = true
                if (canGenerate) names += m.optString("name").removePrefix("models/")
            }
            pageToken = o.optString("nextPageToken").takeIf { it.isNotBlank() }
        } while (pageToken != null && ++pages < 5)
        return pickBest(names)
    }

    companion object {
        private val skipWords = listOf("image", "tts", "audio", "live", "embedding", "vision", "thinking", "8b", "learnlm", "robotics", "computer-use")

        /** Newest stable "gemini-X-flash"; prefers non-lite, non-preview. Visible for testing. */
        fun pickBest(names: List<String>): String? {
            val versionRe = Regex("""^gemini-(\d+(?:\.\d+)?)-flash""")
            val candidates = names.filter { n ->
                versionRe.containsMatchIn(n) && skipWords.none { it in n } && !n.contains("latest")
            }
            if (candidates.isEmpty()) return null
            return candidates.maxWithOrNull(
                compareBy<String>(
                    { if ("preview" in it || "exp" in it) 0 else 1 },      // stable first
                    { if ("lite" in it) 0 else 1 },                         // full flash before lite
                    { versionRe.find(it)?.groupValues?.get(1)?.toDoubleOrNull() ?: 0.0 }, // newest version
                    { -it.length },                                         // plain name over dated variants
                )
            )
        }
    }

    private fun parseReply(text: String): JSONObject {
        val reply = JSONObject(text)
            .optJSONArray("candidates")?.optJSONObject(0)
            ?.optJSONObject("content")?.optJSONArray("parts")
        val sb = StringBuilder()
        if (reply != null) for (i in 0 until reply.length()) {
            val part = reply.optJSONObject(i) ?: continue
            if (part.optBoolean("thought", false)) continue
            sb.append(part.optString("text"))
        }
        if (sb.isBlank()) throw AiException("The AI gave an empty reply. Please try again.")
        var t = sb.toString().trim()
        if (t.startsWith("```")) t = t.substringAfter('\n').substringBeforeLast("```").trim()
        val start = t.indexOf('{')
        val end = t.lastIndexOf('}')
        if (start < 0 || end <= start) throw AiException("Could not read the AI reply. Please try again.")
        return try { JSONObject(t.substring(start, end + 1)) } catch (e: Exception) {
            throw AiException("Could not read the AI reply. Please try again.")
        }
    }
}
