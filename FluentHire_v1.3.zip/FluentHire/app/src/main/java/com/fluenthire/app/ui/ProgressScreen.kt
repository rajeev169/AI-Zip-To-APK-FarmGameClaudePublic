package com.fluenthire.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fluenthire.app.AppDeps
import com.fluenthire.app.ui.theme.scoreColor
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ProgressScreen(deps: AppDeps, onBack: () -> Unit) {
    val history = remember { deps.prefs.history() }
    val streak = remember { deps.prefs.streak() }
    val fmt = remember { SimpleDateFormat("d MMM, h:mm a", Locale.getDefault()) }

    Scaffold(topBar = { AppTopBar("My Progress", onBack) }) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Stat("🔥 $streak", "day streak", Modifier.weight(1f))
                Stat("${history.size}", "sessions", Modifier.weight(1f))
                Stat(if (history.isEmpty()) "–" else "${history.map { it.score }.average().toInt()}", "average", Modifier.weight(1f))
            }

            if (history.isEmpty()) {
                InfoCard { Text("No sessions yet. Finish a mock interview or practice test to see your progress here.") }
            } else {

            val recent = history.take(12).reversed()
            InfoCard {
                Text("Last ${recent.size} scores", fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(12.dp))
                val track = MaterialTheme.colorScheme.surfaceVariant
                Canvas(Modifier.fillMaxWidth().height(140.dp)) {
                    val n = recent.size
                    val gap = 8.dp.toPx()
                    val w = (size.width - gap * (n - 1)) / n
                    recent.forEachIndexed { i, r ->
                        val x = i * (w + gap)
                        drawRoundRect(track, Offset(x, 0f), Size(w, size.height), CornerRadius(6.dp.toPx()))
                        val h = size.height * (r.score / 100f)
                        drawRoundRect(scoreColor(r.score), Offset(x, size.height - h), Size(w, h), CornerRadius(6.dp.toPx()))
                    }
                }
                Spacer(Modifier.height(6.dp))
                Text("Green 75+ • Orange 50–74 • Red below 50", style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.outline)
            }

            val interviews = history.filter { it.type == "Interview" }
            if (interviews.isNotEmpty()) {
                InfoCard {
                    Text("Interview skills (average)", fontWeight = FontWeight.SemiBold)
                    listOf("Fluency", "Grammar", "Vocabulary", "Relevance").forEach { k ->
                        val v = interviews.mapNotNull { it.subScores[k] }
                        if (v.isNotEmpty()) ScoreBar(if (k == "Relevance") "Answer quality" else k, v.average().toInt())
                    }
                }
            }

            Text("History", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            history.forEach { r ->
                InfoCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(r.type, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                            Text(r.title, fontWeight = FontWeight.SemiBold)
                            Text(fmt.format(Date(r.timestamp)), style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.outline)
                            if (r.summary.isNotBlank()) Text(r.summary, style = MaterialTheme.typography.bodySmall,
                                maxLines = 3, modifier = Modifier.padding(top = 4.dp))
                        }
                        Spacer(Modifier.width(10.dp))
                        ScoreRing(r.score, size = 56.dp, stroke = 6.dp)
                    }
                }
            }
            }
        }
    }
}

@Composable
private fun Stat(value: String, label: String, modifier: Modifier) {
    InfoCard(modifier) {
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, fontWeight = FontWeight.Bold, fontSize = 20.sp)
            Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
        }
    }
}
