package com.fluenthire.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fluenthire.app.AppDeps
import com.fluenthire.app.data.PracticeFactory
import com.fluenthire.app.data.PracticeTask
import com.fluenthire.app.data.Section
import com.fluenthire.app.data.SessionRecord
import com.fluenthire.app.data.TaskResult
import com.fluenthire.app.ui.theme.scoreColor

const val TEST_YOURSELF_TYPE = "Test yourself"
private const val QUESTIONS_PER_PART = 5

// ------------------------------------------------------------------ list of parts

@Composable
fun TestYourselfScreen(deps: AppDeps, refreshKey: Int, onBack: () -> Unit, onOpenPart: (Section) -> Unit) {
    val best = remember(refreshKey) { deps.prefs.bestScores(TEST_YOURSELF_TYPE) }

    Scaffold(topBar = { AppTopBar("Test yourself", onBack) }) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            InfoCard(container = MaterialTheme.colorScheme.secondaryContainer) {
                Text("Practise one part at a time", fontWeight = FontWeight.SemiBold)
                Text(
                    if (deps.prefs.hasApiKey) "Pick a part. The AI asks $QUESTIONS_PER_PART new questions every time, one by one, and shows your result at the end."
                    else "Pick a part. You get $QUESTIONS_PER_PART questions one by one. Add a Gemini key in Settings to get new AI questions every time.",
                    style = MaterialTheme.typography.bodySmall,
                )
            }
            Section.entries.forEach { s ->
                val b = best[s.fullTitle]
                Card(
                    onClick = { onOpenPart(s) },
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(1.dp),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier.size(46.dp).clip(RoundedCornerShape(12.dp)).background(MaterialTheme.colorScheme.primaryContainer),
                            contentAlignment = Alignment.Center,
                        ) { Text(s.letter, fontWeight = FontWeight.Bold, fontSize = 20.sp, color = MaterialTheme.colorScheme.primary) }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("${s.emoji} ${s.title}", fontWeight = FontWeight.SemiBold)
                            Text(s.instruction, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline, maxLines = 2)
                        }
                        Spacer(Modifier.width(8.dp))
                        if (b != null) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("$b", fontWeight = FontWeight.Bold, color = scoreColor(b), fontSize = 18.sp)
                                Text("best", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                            }
                        } else {
                            Icon(Icons.AutoMirrored.Filled.ArrowForward, null, tint = MaterialTheme.colorScheme.outline)
                        }
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
        }
    }
}

// ------------------------------------------------------------------ one part

private enum class PartPhase { Loading, Ready, Running, Done }

@Composable
fun PartPracticeScreen(deps: AppDeps, section: Section, onBack: () -> Unit) {
    val prefs = deps.prefs
    val coach = remember { coachOrNull(deps) }
    var round by remember { mutableIntStateOf(0) }
    var phase by remember { mutableStateOf(PartPhase.Loading) }
    var tasks by remember { mutableStateOf<List<PracticeTask>>(emptyList()) }
    var results by remember { mutableStateOf<List<TaskResult>>(emptyList()) }
    var notice by remember { mutableStateOf<String?>(null) }
    var confirmExit by remember { mutableStateOf(false) }

    // Generate a fresh set of questions for every round.
    LaunchedEffect(round) {
        phase = PartPhase.Loading
        notice = null
        val best = prefs.bestScores(TEST_YOURSELF_TYPE)[section.fullTitle] ?: 0
        val ai: List<PracticeTask> = if (coach != null) {
            try {
                coach.generatePart(section, QUESTIONS_PER_PART, harder = best >= 80)
            } catch (e: Exception) {
                notice = "Using built-in questions (${e.message})"
                emptyList()
            }
        } else emptyList()
        val fill = PracticeFactory.fromBank(section, QUESTIONS_PER_PART)
            .filter { b -> ai.none { it.target.equals(b.target, ignoreCase = true) } }
        tasks = (ai + fill).take(QUESTIONS_PER_PART)
        phase = PartPhase.Ready
    }

    BackHandler { if (phase == PartPhase.Running) confirmExit = true else onBack() }

    if (confirmExit) {
        AlertDialog(
            onDismissRequest = { confirmExit = false },
            title = { Text("Leave this practice?") },
            text = { Text("Your answers in this round will not be saved.") },
            confirmButton = { TextButton(onClick = { confirmExit = false; onBack() }) { Text("Leave") } },
            dismissButton = { TextButton(onClick = { confirmExit = false }) { Text("Stay") } },
        )
    }

    Scaffold(topBar = {
        AppTopBar(
            if (phase == PartPhase.Done) "${section.title} – Result" else section.fullTitle,
            onBack = { if (phase == PartPhase.Running) confirmExit = true else onBack() },
        )
    }) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            when (phase) {
                PartPhase.Loading -> LoadingBlock(
                    if (coach != null) "The AI is preparing $QUESTIONS_PER_PART new questions…" else "Getting your questions ready…"
                )

                PartPhase.Ready -> {
                    InfoCard(container = MaterialTheme.colorScheme.primaryContainer) {
                        Text("Part ${section.letter}", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                        Text("${section.emoji} ${section.title}", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(8.dp))
                        Text(section.instruction)
                        Spacer(Modifier.height(8.dp))
                        Text("${tasks.size} questions • one by one • result at the end",
                            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
                    }
                    notice?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline) }
                    Button(
                        onClick = { deps.requestMic { phase = PartPhase.Running } },
                        modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(14.dp),
                    ) { Text("Start", fontSize = 16.sp) }
                }

                PartPhase.Running -> TaskSequence(
                    deps = deps, tasks = tasks, coach = coach, sectionIntros = false,
                    finishLabel = "See my result",
                    onFinished = { r ->
                        results = r
                        val avg = if (r.isEmpty()) 0 else r.map { it.score }.average().toInt()
                        prefs.addRecord(
                            SessionRecord(
                                type = TEST_YOURSELF_TYPE, title = section.fullTitle, score = avg,
                                timestamp = System.currentTimeMillis(),
                                summary = "${r.count { it.score >= 70 }} of ${r.size} answers scored 70+",
                            )
                        )
                        phase = PartPhase.Done
                    },
                )

                PartPhase.Done -> PartResult(section, results,
                    onTryAgain = { results = emptyList(); round++ },
                    onBack = onBack)
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun PartResult(section: Section, results: List<TaskResult>, onTryAgain: () -> Unit, onBack: () -> Unit) {
    val avg = if (results.isEmpty()) 0 else results.map { it.score }.average().toInt()
    InfoCard {
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(section.fullTitle, color = MaterialTheme.colorScheme.outline)
            Spacer(Modifier.height(8.dp))
            ScoreRing(avg, size = 140.dp, label = "score")
            Spacer(Modifier.height(8.dp))
            Text(levelMessage(avg), textAlign = TextAlign.Center, style = MaterialTheme.typography.bodyMedium)
        }
    }
    InfoCard(container = Color(0xFFFFF7ED)) {
        Text("How to improve", fontWeight = FontWeight.SemiBold, color = Color(0xFF9A3412))
        Text(focusTip(section), style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(top = 4.dp))
    }
    Text("Your answers", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
    results.forEachIndexed { i, r ->
        val prompt = (r.task.display ?: r.task.audio ?: r.task.target).take(140)
        InfoCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Q${i + 1}. $prompt", fontWeight = FontWeight.Medium, maxLines = 4)
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "You said: " + r.answer.ifBlank { "(skipped)" },
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline,
                    )
                    if (r.note.isNotBlank()) Text(r.note, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 4.dp))
                }
                Spacer(Modifier.width(8.dp))
                ScoreRing(r.score, size = 48.dp, stroke = 5.dp)
            }
        }
        if (r.hindiTip.isNotBlank()) HindiTip(r.hindiTip)
    }
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        OutlinedButton(onClick = onBack, modifier = Modifier.weight(1f).height(52.dp)) { Text("All parts") }
        Button(onClick = onTryAgain, modifier = Modifier.weight(1f).height(52.dp)) { Text("Practice more") }
    }
}
